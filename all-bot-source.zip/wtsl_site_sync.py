"""Sync screenshot-workbook match data to the WTSL Forum.

Each workbook row describes the `Player` side of one match. The sync forwards the
row's stats with that player as `player1`; the matching opponent-side workbook row
is sent separately with its own stats. This keeps every player's Serve, Return, and
Under Pressure inputs tied to the screenshots recorded for that player.

Required environment variables:
  FORUM_URL        e.g. https://wtslforum.space
  WTSL_SYNC_SECRET same value configured on the forum deployment
"""

from __future__ import annotations

import logging
import os
from typing import Any

import requests
from openpyxl import load_workbook

from tennis_stats_scraper import MASTER_WORKBOOK

log = logging.getLogger("wtsl_site_sync")

_SHEET_TO_TOUR = {"atp": "TE4", "wta": "TE4_(F)"}
_BATCH_SIZE = 200

# Workbook header -> forum field. Values are forwarded only when they are numeric.
_STAT_COLUMNS = {
    "1st Serve %": "firstServePct",
    "1st Serve Won %": "firstServeWonPct",
    "2nd Serve Won %": "secondServeWonPct",
    "Aces": "aces",
    "Double Faults": "doubleFaults",
    "1st Serve Return Points Won %": "firstServeReturnWonPct",
    "2nd Serve Return Points Won %": "secondServeReturnWonPct",
    "Return Points Won %": "returnPointsWonPct",
    "Break Points Won %": "breakPointsWonPct",
    "Break Points Saved %": "breakPointsSavedPct",
    "Tie-breaks Won %": "tieBreaksWonPct",
    "Deciding Sets Won %": "decidingSetsWonPct",
    "Set Points Saved": "setPointsSaved",
    "Match Points Saved": "matchPointsSaved",
}


def _number(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number == number and number not in (float("inf"), float("-inf")) else None


def _read_sheet_rows(sheet) -> list[dict[str, Any]]:
    """Read completed workbook rows, including the recorded player-side stats."""
    rows_iter = sheet.iter_rows(values_only=True)
    headers = [str(value).strip() if value is not None else "" for value in next(rows_iter, ())]
    positions = {header: index for index, header in enumerate(headers) if header}

    required = ("Player", "Opponent", "Result")
    missing = [name for name in required if name not in positions]
    if missing:
        raise RuntimeError(f"Workbook sheet is missing {', '.join(missing)} columns")

    def value_at(row: tuple[Any, ...], header: str) -> Any:
        index = positions.get(header)
        return row[index] if index is not None and index < len(row) else None

    output: list[dict[str, Any]] = []
    for row in rows_iter:
        player1 = value_at(row, "Player")
        player2 = value_at(row, "Opponent")
        score = value_at(row, "Result")
        if not player1 or not player2 or not score:
            continue

        match: dict[str, Any] = {
            "player1": str(player1).strip(),
            "player2": str(player2).strip(),
            "score": str(score).strip(),
        }
        tournament = value_at(row, "Tournament")
        if tournament:
            match["tournamentName"] = str(tournament).strip()
        date = value_at(row, "Date")
        if date:
            match["date"] = str(date).strip()

        for header, field in _STAT_COLUMNS.items():
            number = _number(value_at(row, header))
            if number is not None:
                match[field] = number
        output.append(match)
    return output


def _post_batch(forum_url: str, secret: str, tour: str, matches: list[dict[str, Any]]) -> dict[str, Any]:
    response = requests.post(
        f"{forum_url}/api/sync/match-history",
        headers={"x-wtsl-sync-secret": secret, "content-type": "application/json"},
        json={"tour": tour, "matches": matches},
        timeout=55,
    )
    response.raise_for_status()
    return response.json()


def sync_match_history_to_forum() -> dict[str, Any]:
    """Send all completed ATP and WTA workbook rows to the forum, safely idempotently."""
    forum_url = os.environ.get("FORUM_URL", "").rstrip("/")
    secret = os.environ.get("WTSL_SYNC_SECRET", "")
    if not forum_url or not secret:
        raise RuntimeError("FORUM_URL and WTSL_SYNC_SECRET must both be set")

    workbook = load_workbook(MASTER_WORKBOOK, read_only=True, data_only=True)
    try:
        summary: dict[str, Any] = {}
        for sheet_name, tour in _SHEET_TO_TOUR.items():
            if sheet_name not in workbook.sheetnames:
                continue
            rows = _read_sheet_rows(workbook[sheet_name])
            inserted = seen = skipped = 0
            unmatched: set[str] = set()
            for start in range(0, len(rows), _BATCH_SIZE):
                result = _post_batch(forum_url, secret, tour, rows[start:start + _BATCH_SIZE])
                seen += int(result.get("seen", 0))
                inserted += int(result.get("inserted", 0))
                skipped += int(result.get("skippedNoScore", 0))
                unmatched.update(result.get("unmatchedPlayers", []))
            summary[tour] = {
                "rowsRead": len(rows),
                "seen": seen,
                "inserted": inserted,
                "skipped": skipped,
                "unmatchedPlayers": sorted(unmatched),
            }
            log.info("wtsl_site_sync: %s -> %s", tour, summary[tour])
        return summary
    finally:
        workbook.close()
