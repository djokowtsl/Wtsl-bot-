"""WTSL Challonge prediction parsing, retention, aggregation, and identity links."""
from __future__ import annotations

import os
import re
import json
import csv
from typing import Any
from urllib.parse import urlparse

import psycopg
from bs4 import BeautifulSoup


CHALLONGE_SUBDOMAIN = "91d510368cb4170cd5ac3776"
CHALLONGE_HOST = f"{CHALLONGE_SUBDOMAIN}.challonge.com"
PREDICTION_TABLE_SELECTOR = "table.table-predictions"
PREDICTION_SCAN_VERSION = 2


def prediction_module_url(tournament_id: str) -> str:
    """Build the public Challonge predictions module for an exact draw."""
    tournament_id = str(tournament_id or "").strip()
    if not tournament_id:
        raise ValueError("A tournament ID is required")
    return f"https://{CHALLONGE_HOST}/{tournament_id}/predictions/module"


def _clean_text(node: Any) -> str:
    return " ".join(node.get_text(" ", strip=True).split()) if node else ""


def _integer(value: Any) -> int:
    match = re.search(r"-?\d+", str(value or ""))
    return int(match.group(0)) if match else 0


def _pick_pair(value: Any) -> tuple[int, int]:
    match = re.search(r"(\d+)\s*/\s*(\d+)", str(value or ""))
    return (int(match.group(1)), int(match.group(2))) if match else (0, 0)


def _prediction_id(href: str) -> str:
    match = re.search(r"/predictions/([^/?#]+)", str(href or ""))
    return match.group(1) if match else ""


def _profile_username(href: str) -> str:
    parsed = urlparse(str(href or ""))
    return parsed.path.rstrip("/").rsplit("/", 1)[-1] if parsed.path else ""


def parse_prediction_module(
    html: str,
    tournament_id: str,
    tournament_name: str,
    tour: str,
) -> list[dict[str, Any]]:
    """Parse the public Challonge prediction standings table."""
    soup = BeautifulSoup(html or "", "html.parser")
    table = soup.select_one(PREDICTION_TABLE_SELECTOR)
    if table is None:
        return []

    headers = table.select("thead tr th")
    header_text = [_clean_text(header).casefold() for header in headers]
    points_header_index = next(
        (
            index
            for index, value in enumerate(header_text)
            if value.startswith("points per round")
        ),
        None,
    )
    rounds_count = (
        int(headers[points_header_index].get("colspan", 5))
        if points_header_index is not None
        else 5
    )
    has_score_potential = any(
        value.startswith("score potential") for value in header_text
    )
    has_losers_bracket = any(
        value.startswith("losers bracket points") for value in header_text
    )
    has_picks_potential = any(
        value.startswith("picks potential") for value in header_text
    )
    if not headers:
        # Older saved fixtures/modules may omit the thead while retaining the
        # original five-round, score-potential, and losers-bracket columns.
        rounds_count = 5
        has_score_potential = True
        has_losers_bracket = True
        has_picks_potential = True

    entries: list[dict[str, Any]] = []
    for row in table.select("tbody tr"):
        cells = row.find_all("td", recursive=False)
        required_cells = (
            3
            + int(has_score_potential)
            + rounds_count
            + int(has_losers_bracket)
            + 1
            + int(has_picks_potential)
        )
        if len(cells) < required_cells:
            continue

        prediction_link = row.select_one(".prediction-link a[href]")
        prediction_name = _clean_text(prediction_link)
        prediction_id = _prediction_id(
            prediction_link.get("href", "") if prediction_link else ""
        )
        user_node = row.select_one("[data-user-id]")
        challonge_user_id = str(user_node.get("data-user-id", "")).strip() if user_node else ""
        profile_link = row.select_one('a[href*="/users/"]')
        challonge_username = _clean_text(profile_link)
        if not challonge_username and profile_link:
            challonge_username = _profile_username(profile_link.get("href", ""))
        if not prediction_id or not challonge_user_id:
            continue

        value_index = 3
        score_potential = 0
        if has_score_potential:
            score_potential = _integer(cells[value_index])
            value_index += 1
        round_points = [
            _integer(cell)
            for cell in cells[value_index : value_index + rounds_count]
        ]
        value_index += rounds_count
        losers_bracket_points = 0
        if has_losers_bracket:
            losers_bracket_points = _integer(cells[value_index])
            value_index += 1
        picks, picks_potential = _pick_pair(cells[value_index])
        value_index += 1
        if has_picks_potential and value_index < len(cells):
            picks_potential = _integer(cells[value_index])
        entries.append(
            {
                "tournament_id": str(tournament_id),
                "tournament_name": str(tournament_name or tournament_id),
                "tour": str(tour or "TE4"),
                "prediction_id": prediction_id,
                "challonge_user_id": challonge_user_id,
                "challonge_username": challonge_username or prediction_name,
                "prediction_name": prediction_name or challonge_username,
                "profile_url": (
                    str(profile_link.get("href"))
                    if profile_link and profile_link.get("href")
                    else None
                ),
                "rank": _integer(cells[1]),
                "score": _integer(cells[2]),
                "score_potential": score_potential,
                "round_points": round_points,
                "losers_bracket_points": losers_bracket_points,
                "picks": picks,
                "picks_potential": picks_potential,
            }
        )
    return entries


def aggregate_prediction_rows(
    entries: list[dict[str, Any]],
    identity_links: dict[str, int] | None = None,
) -> list[dict[str, Any]]:
    """Aggregate one latest prediction per user and tournament."""
    latest: dict[tuple[str, str], dict[str, Any]] = {}
    for entry in entries:
        user_id = str(entry.get("challonge_user_id") or "").strip()
        tournament_id = str(entry.get("tournament_id") or "").strip()
        if not user_id or not tournament_id:
            continue
        key = (user_id, tournament_id)
        old = latest.get(key)
        if old is None or (
            int(entry.get("score") or 0),
            int(entry.get("picks") or 0),
        ) >= (
            int(old.get("score") or 0),
            int(old.get("picks") or 0),
        ):
            latest[key] = entry

    tournament_leaders: dict[str, str] = {}
    tournament_leader_keys: dict[str, tuple[int, int, int, str]] = {}
    for entry in latest.values():
        tournament_id = str(entry["tournament_id"])
        rank = int(entry.get("rank") or 0)
        leader_key = (
            int(entry.get("score") or 0),
            int(entry.get("picks") or 0),
            -(rank if rank > 0 else 1_000_000),
            str(entry.get("challonge_user_id") or ""),
        )
        if (
            tournament_id not in tournament_leader_keys
            or leader_key > tournament_leader_keys[tournament_id]
        ):
            tournament_leader_keys[tournament_id] = leader_key
            tournament_leaders[tournament_id] = str(entry["challonge_user_id"])

    grouped: dict[str, dict[str, Any]] = {}
    for entry in latest.values():
        user_id = str(entry["challonge_user_id"])
        row = grouped.setdefault(
            user_id,
            {
                "challonge_user_id": user_id,
                "challonge_username": entry.get("challonge_username") or "",
                "prediction_name": entry.get("prediction_name") or "",
                "discord_user_id": (
                    int(identity_links[user_id])
                    if identity_links and user_id in identity_links
                    else None
                ),
                "tournaments": 0,
                "tournaments_won": 0,
                "total_score": 0,
                "total_score_potential": 0,
                "total_picks": 0,
                "total_picks_potential": 0,
                "total_losers_bracket_points": 0,
                "round_points": [0, 0, 0, 0, 0],
            },
        )
        row["tournaments"] += 1
        if tournament_leaders.get(str(entry["tournament_id"])) == user_id:
            row["tournaments_won"] += 1
        row["total_score"] += int(entry.get("score") or 0)
        row["total_score_potential"] += int(entry.get("score_potential") or 0)
        row["total_picks"] += int(entry.get("picks") or 0)
        row["total_picks_potential"] += int(entry.get("picks_potential") or 0)
        row["total_losers_bracket_points"] += int(
            entry.get("losers_bracket_points") or 0
        )
        for index, value in enumerate(entry.get("round_points") or []):
            if index >= len(row["round_points"]):
                row["round_points"].append(0)
            row["round_points"][index] += int(value or 0)

    rows = list(grouped.values())
    for row in rows:
        row["average_score"] = (
            row["total_score"] / row["tournaments"]
            if row["tournaments"]
            else 0.0
        )
    rows.sort(
        key=lambda row: (
            -int(row["total_score"]),
            -int(row["tournaments"]),
            -int(row["total_picks"]),
            str(row["challonge_username"]).casefold(),
        )
    )
    return rows


def _connect():
    database_url = os.environ.get("DATABASE_URL")
    if not database_url:
        raise RuntimeError("DATABASE_URL is not available")
    return psycopg.connect(database_url)


def ensure_prediction_tables(cursor) -> None:
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_prediction_entries (
            tournament_id TEXT NOT NULL,
            tournament_name TEXT NOT NULL,
            tour TEXT NOT NULL,
            prediction_id TEXT NOT NULL,
            challonge_user_id TEXT NOT NULL,
            challonge_username TEXT NOT NULL,
            prediction_name TEXT NOT NULL,
            profile_url TEXT,
            rank INTEGER NOT NULL DEFAULT 0,
            score INTEGER NOT NULL DEFAULT 0,
            score_potential INTEGER NOT NULL DEFAULT 0,
            round_points JSONB NOT NULL DEFAULT '[0, 0, 0, 0, 0]'::jsonb,
            losers_bracket_points INTEGER NOT NULL DEFAULT 0,
            picks INTEGER NOT NULL DEFAULT 0,
            picks_potential INTEGER NOT NULL DEFAULT 0,
            fetched_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            PRIMARY KEY (tournament_id, prediction_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_prediction_identity_links (
            discord_user_id BIGINT PRIMARY KEY,
            challonge_user_id TEXT NOT NULL UNIQUE,
            challonge_username TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'approved',
            requested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            approved_at TIMESTAMPTZ,
            approved_by BIGINT
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_prediction_link_requests (
            request_id BIGSERIAL PRIMARY KEY,
            discord_user_id BIGINT NOT NULL,
            requested_name TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            reviewed_at TIMESTAMPTZ,
            reviewed_by BIGINT,
            UNIQUE (discord_user_id, requested_name, status)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_prediction_tournament_scans (
            tournament_id TEXT PRIMARY KEY,
            tournament_name TEXT NOT NULL,
            tour TEXT NOT NULL,
            rows_fetched INTEGER NOT NULL DEFAULT 0,
            parser_version INTEGER NOT NULL DEFAULT 1,
            scanned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            status TEXT NOT NULL DEFAULT 'success'
        )
        """
    )
    cursor.execute(
        """
        ALTER TABLE wtsl_prediction_tournament_scans
        ADD COLUMN IF NOT EXISTS parser_version INTEGER NOT NULL DEFAULT 1
        """
    )


def upsert_prediction_entries(entries: list[dict[str, Any]]) -> int:
    """Persist a non-empty snapshot; empty/failed pages never erase history."""
    if not entries:
        return 0
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            for entry in entries:
                cursor.execute(
                    """
                    INSERT INTO wtsl_prediction_entries (
                        tournament_id, tournament_name, tour, prediction_id,
                        challonge_user_id, challonge_username, prediction_name,
                        profile_url, rank, score, score_potential, round_points,
                        losers_bracket_points, picks, picks_potential, fetched_at
                    )
                    VALUES (
                        %(tournament_id)s, %(tournament_name)s, %(tour)s,
                        %(prediction_id)s, %(challonge_user_id)s,
                        %(challonge_username)s, %(prediction_name)s,
                        %(profile_url)s, %(rank)s, %(score)s,
                        %(score_potential)s, %(round_points)s::jsonb,
                        %(losers_bracket_points)s, %(picks)s,
                        %(picks_potential)s, now()
                    )
                    ON CONFLICT (tournament_id, prediction_id) DO UPDATE SET
                        tournament_name = EXCLUDED.tournament_name,
                        tour = EXCLUDED.tour,
                        challonge_user_id = EXCLUDED.challonge_user_id,
                        challonge_username = EXCLUDED.challonge_username,
                        prediction_name = EXCLUDED.prediction_name,
                        profile_url = EXCLUDED.profile_url,
                        rank = EXCLUDED.rank,
                        score = EXCLUDED.score,
                        score_potential = EXCLUDED.score_potential,
                        round_points = EXCLUDED.round_points,
                        losers_bracket_points = EXCLUDED.losers_bracket_points,
                        picks = EXCLUDED.picks,
                        picks_potential = EXCLUDED.picks_potential,
                        fetched_at = now()
                    """,
                    {
                        **entry,
                        "round_points": json.dumps(
                            entry.get("round_points") or [0, 0, 0, 0, 0]
                        ),
                    },
                )
            return len(entries)


def load_successful_prediction_scan_ids() -> set[str]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            cursor.execute(
                """
                SELECT tournament_id
                FROM wtsl_prediction_tournament_scans
                WHERE status = 'success' AND parser_version = %s
                """,
                (PREDICTION_SCAN_VERSION,),
            )
            return {str(row[0]) for row in cursor.fetchall()}


def record_prediction_tournament_scans(
    scans: list[dict[str, Any]],
) -> int:
    if not scans:
        return 0
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            for scan in scans:
                cursor.execute(
                    """
                    INSERT INTO wtsl_prediction_tournament_scans (
                        tournament_id, tournament_name, tour, rows_fetched,
                        parser_version, scanned_at, status
                    )
                    VALUES (%s, %s, %s, %s, %s, now(), 'success')
                    ON CONFLICT (tournament_id) DO UPDATE SET
                        tournament_name = EXCLUDED.tournament_name,
                        tour = EXCLUDED.tour,
                        rows_fetched = EXCLUDED.rows_fetched,
                        parser_version = EXCLUDED.parser_version,
                        scanned_at = now(),
                        status = 'success'
                    """,
                    (
                        str(scan["tournament_id"]),
                        str(scan.get("tournament_name") or scan["tournament_id"]),
                        str(scan.get("tour") or "TE4"),
                        int(scan.get("rows_fetched") or 0),
                        PREDICTION_SCAN_VERSION,
                    ),
                )
            return len(scans)


def load_prediction_identity_links() -> dict[str, int]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            cursor.execute(
                """
                SELECT challonge_user_id, discord_user_id
                FROM wtsl_prediction_identity_links
                WHERE status = 'approved'
                """
            )
            return {str(user_id): int(discord_id) for user_id, discord_id in cursor.fetchall()}


def load_prediction_leaderboard(limit: int = 25) -> list[dict[str, Any]]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            cursor.execute(
                """
                WITH latest AS (
                    SELECT DISTINCT ON (challonge_user_id, tournament_id)
                        *
                    FROM wtsl_prediction_entries
                    ORDER BY challonge_user_id, tournament_id,
                             fetched_at DESC, score DESC, prediction_id DESC
                ),
                ranked_tournaments AS (
                    SELECT latest.*,
                           ROW_NUMBER() OVER (
                               PARTITION BY tournament_id
                               ORDER BY score DESC, picks DESC,
                                        NULLIF(rank, 0) ASC NULLS LAST,
                                        prediction_id DESC
                           ) AS predictor_position
                    FROM latest
                ),
                tournament_wins AS (
                    SELECT challonge_user_id,
                           COUNT(*)::int AS tournaments_won
                    FROM ranked_tournaments
                    WHERE predictor_position = 1
                    GROUP BY challonge_user_id
                )
                SELECT latest.challonge_user_id,
                       MAX(latest.challonge_username) AS challonge_username,
                       MAX(latest.prediction_name) AS prediction_name,
                       link.discord_user_id,
                       COUNT(*)::int AS tournaments,
                       COALESCE(MAX(tournament_wins.tournaments_won), 0)::int
                           AS tournaments_won,
                       SUM(latest.score)::int AS total_score,
                       SUM(latest.score_potential)::int AS total_score_potential,
                       SUM(latest.picks)::int AS total_picks,
                       SUM(latest.picks_potential)::int AS total_picks_potential,
                       SUM(latest.losers_bracket_points)::int
                           AS total_losers_bracket_points,
                       AVG(latest.score)::float AS average_score
                FROM latest
                LEFT JOIN wtsl_prediction_identity_links link
                  ON link.challonge_user_id = latest.challonge_user_id
                 AND link.status = 'approved'
                LEFT JOIN tournament_wins
                  ON tournament_wins.challonge_user_id = latest.challonge_user_id
                GROUP BY latest.challonge_user_id, link.discord_user_id
                ORDER BY total_score DESC, tournaments DESC,
                         total_picks DESC, challonge_username ASC
                LIMIT %s
                """,
                (max(1, int(limit)),),
            )
            columns = [
                "challonge_user_id", "challonge_username", "prediction_name",
                "discord_user_id", "tournaments", "tournaments_won", "total_score",
                "total_score_potential", "total_picks", "total_picks_potential",
                "total_losers_bracket_points", "average_score",
            ]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]


def export_prediction_leaderboard_csv(path: str) -> int:
    """Write the complete retained leaderboard, not only the Discord top 25."""
    rows = load_prediction_leaderboard(10000)
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "rank",
                "discord_user_id",
                "challonge_username",
                "prediction_name",
                "tournaments",
                "tournaments_won",
                "total_score",
                "total_picks",
                "total_picks_potential",
                "correct_pick_percentage",
                "average_score",
            ],
        )
        writer.writeheader()
        for rank, row in enumerate(rows, 1):
            possible = int(row.get("total_picks_potential") or 0)
            correct = int(row.get("total_picks") or 0)
            writer.writerow(
                {
                    "rank": rank,
                    "discord_user_id": row.get("discord_user_id") or "",
                    "challonge_username": row.get("challonge_username") or "",
                    "prediction_name": row.get("prediction_name") or "",
                    "tournaments": int(row.get("tournaments") or 0),
                    "tournaments_won": int(row.get("tournaments_won") or 0),
                    "total_score": int(row.get("total_score") or 0),
                    "total_picks": correct,
                    "total_picks_potential": possible,
                    "correct_pick_percentage": (
                        round(correct / possible * 100, 2) if possible else 0.0
                    ),
                    "average_score": round(float(row.get("average_score") or 0), 2),
                }
            )
    return len(rows)


def create_prediction_link_request(
    discord_user_id: int,
    requested_name: str,
) -> int:
    requested_name = " ".join(str(requested_name or "").split())
    if not requested_name:
        raise ValueError("A Challonge username is required")
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            cursor.execute(
                """
                INSERT INTO wtsl_prediction_link_requests (
                    discord_user_id, requested_name
                )
                VALUES (%s, %s)
                ON CONFLICT (discord_user_id, requested_name, status)
                DO UPDATE SET created_at = now()
                RETURNING request_id
                """,
                (int(discord_user_id), requested_name),
            )
            return int(cursor.fetchone()[0])


def list_pending_prediction_link_requests() -> list[dict[str, Any]]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            cursor.execute(
                """
                SELECT request_id, discord_user_id, requested_name, created_at
                FROM wtsl_prediction_link_requests
                WHERE status = 'pending'
                ORDER BY created_at
                """
            )
            return [
                dict(zip(("request_id", "discord_user_id", "requested_name", "created_at"), row))
                for row in cursor.fetchall()
            ]


def _resolve_prediction_identity(cursor, requested_name: str) -> tuple[str, str]:
    requested = str(requested_name or "").strip().casefold()
    cursor.execute(
        """
        SELECT DISTINCT challonge_user_id, challonge_username
        FROM wtsl_prediction_entries
        WHERE lower(challonge_username) = %s
           OR lower(prediction_name) = %s
        """,
        (requested, requested),
    )
    matches = cursor.fetchall()
    if len(matches) != 1:
        if not matches:
            raise ValueError("No matching Challonge prediction identity has been fetched yet")
        raise ValueError("That name matches multiple Challonge prediction identities")
    return str(matches[0][0]), str(matches[0][1])


def approve_prediction_link_request(
    request_id: int,
    approved_by: int,
) -> tuple[int, str]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            cursor.execute(
                """
                SELECT discord_user_id, requested_name
                FROM wtsl_prediction_link_requests
                WHERE request_id = %s AND status = 'pending'
                """,
                (int(request_id),),
            )
            request = cursor.fetchone()
            if request is None:
                raise ValueError("That prediction link request is missing or already reviewed")
            discord_user_id, requested_name = request
            challonge_user_id, challonge_username = _resolve_prediction_identity(
                cursor, requested_name
            )
            cursor.execute(
                """
                INSERT INTO wtsl_prediction_identity_links (
                    discord_user_id, challonge_user_id, challonge_username,
                    status, approved_at, approved_by
                )
                VALUES (%s, %s, %s, 'approved', now(), %s)
                ON CONFLICT (discord_user_id) DO UPDATE SET
                    challonge_user_id = EXCLUDED.challonge_user_id,
                    challonge_username = EXCLUDED.challonge_username,
                    status = 'approved',
                    approved_at = now(),
                    approved_by = EXCLUDED.approved_by
                """,
                (int(discord_user_id), challonge_user_id, challonge_username, int(approved_by)),
            )
            cursor.execute(
                """
                UPDATE wtsl_prediction_link_requests
                SET status = 'approved', reviewed_at = now(), reviewed_by = %s
                WHERE request_id = %s
                """,
                (int(approved_by), int(request_id)),
            )
            return int(discord_user_id), challonge_username


def reject_prediction_link_request(request_id: int, reviewed_by: int) -> None:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            cursor.execute(
                """
                UPDATE wtsl_prediction_link_requests
                SET status = 'rejected', reviewed_at = now(), reviewed_by = %s
                WHERE request_id = %s AND status = 'pending'
                """,
                (int(reviewed_by), int(request_id)),
            )
            if cursor.rowcount != 1:
                raise ValueError("That prediction link request is missing or already reviewed")


def _identity_token(value: Any) -> str:
    """Normalize an exact display-name match without doing fuzzy matching."""
    return re.sub(r"[^a-z0-9]+", "", str(value or "").casefold())


def auto_link_prediction_identities(
    members: list[dict[str, Any]],
    *,
    approved_by: int = 0,
) -> int:
    """Approve only one-to-one exact matches between Challonge and Discord names."""
    member_by_token: dict[str, set[int]] = {}
    for member in members:
        member_id = int(member.get("id") or 0)
        if not member_id:
            continue
        for name in member.get("names") or []:
            token = _identity_token(name)
            if token:
                member_by_token.setdefault(token, set()).add(member_id)

    if not member_by_token:
        return 0
    linked = 0
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            cursor.execute(
                """
                SELECT DISTINCT challonge_user_id, challonge_username,
                                prediction_name
                FROM wtsl_prediction_entries
                """
            )
            identities = cursor.fetchall()
            for challonge_user_id, challonge_username, prediction_name in identities:
                tokens = {
                    _identity_token(challonge_username),
                    _identity_token(prediction_name),
                } - {""}
                candidate_ids = {
                    member_id
                    for token in tokens
                    for member_id in member_by_token.get(token, set())
                }
                if len(candidate_ids) != 1:
                    continue
                discord_user_id = candidate_ids.pop()
                cursor.execute(
                    """
                    SELECT discord_user_id, challonge_user_id
                    FROM wtsl_prediction_identity_links
                    WHERE discord_user_id = %s OR challonge_user_id = %s
                    """,
                    (discord_user_id, str(challonge_user_id)),
                )
                existing = cursor.fetchall()
                if existing:
                    if any(
                        int(existing_user_id) == discord_user_id
                        and str(existing_challonge_id) == str(challonge_user_id)
                        for existing_user_id, existing_challonge_id in existing
                    ):
                        continue
                    # Never overwrite a manually approved or another
                    # automatically unique identity.
                    continue
                cursor.execute(
                    """
                    INSERT INTO wtsl_prediction_identity_links (
                        discord_user_id, challonge_user_id, challonge_username,
                        status, approved_at, approved_by
                    )
                    VALUES (%s, %s, %s, 'approved', now(), %s)
                    """,
                    (
                        discord_user_id,
                        str(challonge_user_id),
                        str(challonge_username or prediction_name),
                        int(approved_by),
                    ),
                )
                linked += 1
    return linked


def link_prediction_identity_direct(
    discord_user_id: int,
    requested_name: str,
    approved_by: int,
) -> str:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            challonge_user_id, challonge_username = _resolve_prediction_identity(
                cursor, requested_name
            )
            cursor.execute(
                """
                INSERT INTO wtsl_prediction_identity_links (
                    discord_user_id, challonge_user_id, challonge_username,
                    status, approved_at, approved_by
                )
                VALUES (%s, %s, %s, 'approved', now(), %s)
                ON CONFLICT (discord_user_id) DO UPDATE SET
                    challonge_user_id = EXCLUDED.challonge_user_id,
                    challonge_username = EXCLUDED.challonge_username,
                    status = 'approved',
                    approved_at = now(),
                    approved_by = EXCLUDED.approved_by
                """,
                (
                    int(discord_user_id),
                    challonge_user_id,
                    challonge_username,
                    int(approved_by),
                ),
            )
            return challonge_username


def relink_prediction_identity(
    discord_user_id: int,
    requested_name: str,
    approved_by: int,
) -> str:
    """Replace any existing link for a fetched prediction identity."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_prediction_tables(cursor)
            challonge_user_id, challonge_username = _resolve_prediction_identity(
                cursor, requested_name
            )
            cursor.execute(
                """
                SELECT discord_user_id, status
                FROM wtsl_prediction_identity_links
                WHERE challonge_user_id = %s
                """,
                (challonge_user_id,),
            )
            current = cursor.fetchone()
            if (
                current
                and int(current[0]) == int(discord_user_id)
                and str(current[1]) == "approved"
            ):
                return challonge_username
            cursor.execute(
                """
                DELETE FROM wtsl_prediction_identity_links
                WHERE challonge_user_id = %s OR discord_user_id = %s
                """,
                (challonge_user_id, int(discord_user_id)),
            )
            cursor.execute(
                """
                INSERT INTO wtsl_prediction_identity_links (
                    discord_user_id, challonge_user_id, challonge_username,
                    status, approved_at, approved_by
                )
                VALUES (%s, %s, %s, 'approved', now(), %s)
                """,
                (
                    int(discord_user_id),
                    challonge_user_id,
                    challonge_username,
                    int(approved_by),
                ),
            )
            return challonge_username