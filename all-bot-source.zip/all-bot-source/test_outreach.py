import asyncio
import tempfile
import time
import unittest
from decimal import Decimal
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, PropertyMock, patch

import main
from outreach import (
    OutreachState,
    fixture_key,
    parse_h2h_percentage_odds,
    parse_official_player_avatar,
    parse_reported_tournament_results,
    parse_scheduled_tournament_fixtures,
    parse_upcoming_fixtures,
    resolve_member_exact,
    tour_from_tournament_id,
)


FIXTURES = """
<table><tr><th>Tournament</th><th>Tour</th><th>Match</th><th>Odds</th></tr>
<tr><td>Rome</td><td>ATP</td><td><a href="player_page.php?player=1">Alpha</a> -
<a href="player_page.php?player=2">Beta</a></td><td>1.80 / 2.10</td></tr></table>
"""

HOMEPAGE_FIXTURES = """
<div id="wtsl-fixtures-pane-bootstrap">
  <div class="fixture-card">
    <a href="pages/player_page.php?player=4647">
      <img src="../../files/img/avatars/st_avatar.png" alt="federerson">federerson
    </a>
    <a href="pages/player_page.php?player=4629">
      <img src="../../files/img/avatars/wtsl_default_player_avatar.svg" alt="Federer21">
      Federer21
    </a>
    <a href="pages/tournament_page.php?tournament=Jingshan_2026_TE4">
      Jingshan (R32)
    </a>
    <a href="pages/h2h.php?pl_one=4647&amp;pl_two=4629">2.00 / 2.00 H2H</a>
  </div>
</div>
"""

SCHEDULED_TOURNAMENT = """
<table>
  <thead>
    <tr><th>Date</th><th>Round</th><th>Winner</th><th>Opponent</th>
        <th>Match stats</th><th>Result</th></tr>
  </thead>
  <tbody>
    <tr>
      <td>14.09.2026</td><td>Quarter-Final</td>
      <td><a href="../pages/player_page.php?player=4647">federerson</a></td>
      <td><a href="../pages/player_page.php?player=4635">goldenfq</a></td>
      <td></td><td>Scheduled</td>
    </tr>
  </tbody>
</table>
"""

H2H_PERCENTAGE = """
<div class="h2h-winbar">
  <div class="h2h-winfill" style="width: 60%">60%</div>
</div>
"""


class OutreachTests(unittest.IsolatedAsyncioTestCase):
    @staticmethod
    def _history(messages):
        async def iterator():
            for message in messages:
                yield message
        return lambda **kwargs: iterator()

    def test_parser_and_stable_key(self):
        fixtures = parse_upcoming_fixtures(FIXTURES)
        self.assertEqual(len(fixtures), 1)
        self.assertEqual(fixtures[0]["first_name"], "Alpha")
        self.assertEqual(fixtures[0]["odds"], [1.8, 2.1])
        self.assertEqual(fixtures[0]["key"], fixture_key(fixtures[0]))
        reversed_fixture = {**fixtures[0], "first_id": "2", "second_id": "1"}
        self.assertEqual(fixture_key(fixtures[0]), fixture_key(reversed_fixture))
        next_year = parse_upcoming_fixtures(FIXTURES, season="2027")[0]
        this_year = parse_upcoming_fixtures(FIXTURES, season="2026")[0]
        self.assertNotEqual(next_year["key"], this_year["key"])

    def test_parser_reads_fixture_schedule_for_chronological_selection(self):
        html = """
        <table><tr><th>Tournament</th><th>Tour</th><th>Match</th><th>Odds</th></tr>
        <tr><td>Rome 10.09.2026 18:30</td><td>ATP</td><td>
        <a href="player_page.php?player=1">Alpha</a> -
        <a href="player_page.php?player=2">Beta</a></td><td>1.80 / 2.10</td></tr>
        </table>
        """
        fixture = parse_upcoming_fixtures(html)[0]
        self.assertEqual(fixture["scheduled_at"], "2026-09-10T18:30:00")

    def test_parser_reads_current_homepage_fixture_cards_and_official_odds(self):
        fixtures = parse_upcoming_fixtures(HOMEPAGE_FIXTURES, season="2026")
        self.assertEqual(len(fixtures), 1)
        self.assertEqual(fixtures[0]["first_name"], "federerson")
        self.assertEqual(fixtures[0]["second_id"], "4629")
        self.assertEqual(fixtures[0]["tournament_id"], "Jingshan_2026_TE4")
        self.assertEqual(fixtures[0]["odds"], [2.0, 2.0])
        self.assertTrue(fixtures[0]["first_avatar"].endswith("st_avatar.png"))
        self.assertTrue(
            fixtures[0]["second_avatar"].endswith("wtsl_default_player_avatar.svg")
        )

    def test_parser_detects_wta_from_f_suffix(self):
        html = HOMEPAGE_FIXTURES.replace(
            "Jingshan_2026_TE4",
            "US_Open_2026_TE4_F",
        )
        fixture = parse_upcoming_fixtures(html, season="2026")[0]
        self.assertEqual(fixture["tournament_id"], "US_Open_2026_TE4_F")
        self.assertEqual(fixture["tour"], "TE4_(F)")
        self.assertEqual(tour_from_tournament_id("US_Open_2026_TE4_F"), "TE4_(F)")

    def test_parser_reads_avatar_from_official_player_page(self):
        html = """
        <img src="../../files/img/wtsl_header_logo.png">
        <img src="../../files/img/avatars/st_avatar.png" alt="Alpha">
        <img src="../../files/img/country_logos/Portugal.png" alt="Portugal">
        """
        self.assertTrue(
            parse_official_player_avatar(html, "Alpha").endswith("st_avatar.png")
        )

    def test_parser_reads_scheduled_tournament_matches(self):
        fixtures = parse_scheduled_tournament_fixtures(
            SCHEDULED_TOURNAMENT,
            "Guiyang_2026_TE4",
            "Guiyang",
            season="2026",
        )
        self.assertEqual(len(fixtures), 1)
        self.assertEqual(fixtures[0]["tournament"], "Guiyang (QF)")
        self.assertEqual(fixtures[0]["odds"], None)
        self.assertFalse(fixtures[0]["betting_enabled"])

    def test_parser_reads_reported_tournament_matches(self):
        reported = SCHEDULED_TOURNAMENT.replace(
            "<td></td><td>Scheduled</td>",
            "<td></td><td>6-3,6-2</td>",
        )
        results = parse_reported_tournament_results(
            reported,
            "Guiyang",
            "TE4",
        )
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["p1"], "federerson")
        self.assertEqual(results[0]["p2"], "goldenfq")
        self.assertEqual(results[0]["result"], "6-3,6-2")
        self.assertEqual(results[0]["tour"], "TE4")

    def test_scheduled_parser_detects_wta_from_f_suffix(self):
        fixture = parse_scheduled_tournament_fixtures(
            SCHEDULED_TOURNAMENT,
            "US_Open_2026_TE4_F",
            "US Open",
            season="2026",
        )[0]
        self.assertEqual(fixture["tour"], "TE4_(F)")

    def test_h2h_percentage_converts_to_fair_decimal_odds(self):
        self.assertEqual(
            parse_h2h_percentage_odds(
                H2H_PERCENTAGE,
                first_id="1",
                second_id="2",
            ),
            [1.667, 2.5],
        )

    def test_betting_embeds_show_both_official_avatars(self):
        embeds, view = main._build_wtsl_betting_page(
            [{
                "key": "fixture",
                "first_name": "Alpha",
                "first_id": "1",
                "first_avatar": "https://playwtsl.com/files/img/avatars/alpha.png",
                "second_name": "Beta",
                "second_id": "2",
                "second_avatar": "https://playwtsl.com/files/img/avatars/beta.png",
                "tournament": "Rome",
                "odds": [1.8, 2.1],
            }],
            1,
            1,
        )
        payload = embeds[0].to_dict()
        self.assertEqual(len(embeds), 1)
        self.assertEqual(payload["title"], "Upcoming Fixtures & Odds")
        self.assertEqual(
            [field["name"] for field in payload["fields"]],
            ["🎾 Rome"],
        )
        self.assertIn("Alpha", payload["fields"][0]["value"])
        self.assertIn("Beta", payload["fields"][0]["value"])
        self.assertEqual(
            payload["thumbnail"]["url"],
            main.WTSL_DEFAULT_AVATAR_URL,
        )
        self.assertEqual(
            payload["footer"]["text"],
            (
                "Virtual WTSL Currency • 5% house vig • "
                "Pool settlement with guaranteed minimum returns"
            ),
        )
        self.assertEqual(len(view.children), 5)
        self.assertEqual(
            [child.row for child in view.children],
            [0, 0, 4, 4, 4],
        )

    def test_betting_embeds_show_round_deadline_and_active_scheduler_note(self):
        original_records = main._match_scheduler_records
        try:
            main._match_scheduler_records = {
                "MS-active": {
                    "status": "active",
                    "is_test": False,
                    "tournament_id": "Rome_2026_TE4",
                    "player_one": "Alpha",
                    "player_two": "Beta",
                }
            }
            embeds, _ = main._build_wtsl_betting_page(
                [{
                    "key": "fixture",
                    "first_name": "Alpha",
                    "first_id": "1",
                    "second_name": "Beta",
                    "second_id": "2",
                    "tournament_id": "Rome_2026_TE4",
                    "tournament": "Rome",
                    "odds": [1.8, 2.1],
                    "scheduled_at": "2026-09-18T00:00:00",
                    "round_deadline": datetime(
                        2026, 9, 19, 22, 59, tzinfo=timezone.utc
                    ),
                }],
                1,
                1,
            )
        finally:
            main._match_scheduler_records = original_records

        value = embeds[0].to_dict()["fields"][0]["value"]
        self.assertIn("Round deadline: <t:", value)
        self.assertIn("Currently scheduling this match.", value)
        self.assertNotIn("Scheduled:", value)
        self.assertNotIn("00:00:00", value)

    def test_only_first_fixture_embed_has_collection_title(self):
        fixture = {
            "key": "fixture",
            "first_name": "Alpha",
            "first_id": "1",
            "second_name": "Beta",
            "second_id": "2",
            "tournament": "Rome",
            "odds": [1.8, 2.1],
        }
        first, _ = main._build_wtsl_betting_page([fixture], 1, 2)
        second, _ = main._build_wtsl_betting_page([fixture], 2, 2)
        self.assertEqual(first[0].to_dict()["title"], "Upcoming Fixtures & Odds")
        self.assertNotIn("title", second[0].to_dict())

    def test_betting_summaries_are_on_last_fixture_embed(self):
        fixtures = [{
            "key": "fixture",
            "first_name": "Alpha",
            "first_id": "1",
            "second_name": "Beta",
            "second_id": "2",
            "tournament": "Rome",
            "odds": [1.8, 2.1],
        }]
        leaderboard = [{
            "discord_user_id": 7,
            "total_profit": Decimal("10.00"),
            "successful_bets": 1,
            "failed_bets": 0,
        }]
        results = [{
            "first_name": "Alpha",
            "first_id": "1",
            "second_name": "Beta",
            "second_id": "2",
            "winner_id": "1",
            "total_bets": 1,
            "first_bets": 1,
            "second_bets": 0,
            "result_note": "6-0, 6-0",
        }]
        first, _ = main._build_wtsl_betting_page(
            fixtures, 1, 2, leaderboard_rows=None, result_rows=None
        )
        last, _ = main._build_wtsl_betting_page(
            fixtures, 2, 2,
            leaderboard_rows=leaderboard,
            result_rows=results,
        )
        first_names = [field["name"] for field in first[0].to_dict()["fields"]]
        last_names = [field["name"] for field in last[0].to_dict()["fields"]]
        self.assertNotIn(main.WTSL_BETTING_LEADERBOARD_TITLE, first_names)
        self.assertNotIn(main.WTSL_BETTING_RESULTS_TITLE, first_names)
        self.assertIn(main.WTSL_BETTING_LEADERBOARD_TITLE, last_names)
        self.assertIn(main.WTSL_BETTING_RESULTS_TITLE, last_names)

    def test_betting_embeds_repair_legacy_avatar_name_mapping(self):
        embeds, view = main._build_wtsl_betting_page(
            [{
                "key": "legacy-fixture",
                "first_name": "Alpha",
                "first_id": "1",
                # Legacy reader shape: first_avatar and second_name were swapped.
                "second_name": "https://playwtsl.com/files/img/avatars/alpha.png",
                "second_id": "2",
                "first_avatar": "Beta",
                "second_avatar": "https://playwtsl.com/files/img/avatars/beta.png",
                "tournament": "Rome",
                "odds": [2.0, 1.5],
            }],
            1,
            1,
        )
        payload = embeds[0].to_dict()
        self.assertEqual(
            [field["name"] for field in payload["fields"]],
            ["🎾 Rome"],
        )
        self.assertIn("Alpha", payload["fields"][0]["value"])
        self.assertIn("Beta", payload["fields"][0]["value"])
        self.assertEqual(
            [child.label for child in view.children[:2]],
            ["Alpha · 1.90", "Beta · 1.43"],
        )

    def test_betting_page_includes_leaderboard_and_recent_matches(self):
        embeds, _view = main._build_wtsl_betting_page(
            [{
                "key": "fixture",
                "first_name": "Alpha",
                "first_id": "1",
                "second_name": "Beta",
                "second_id": "2",
                "tournament": "Rome",
                "odds": [1.8, 2.1],
            }],
            1,
            1,
            leaderboard_rows=[{
                "discord_user_id": 7,
                "total_profit": Decimal("125.00"),
                "successful_bets": 2,
                "failed_bets": 1,
            }],
            result_rows=[{
                "first_name": "Alpha",
                "first_id": "1",
                "second_name": "Beta",
                "second_id": "2",
                "winner_id": "1",
                "tournament": "Rome",
                "result_note": "6-3, 6-4 Final",
                "total_bets": 3,
                "first_bets": 2,
                "second_bets": 1,
            }],
        )
        payload = embeds[0].to_dict()
        field_names = [field["name"] for field in payload["fields"]]
        self.assertIn("🏆 Earnings Leaderboard", field_names)
        self.assertIn("✅ Completed Matches", field_names)
        self.assertIn("W$125.00", str(payload))
        self.assertIn("Alpha", str(payload))
        self.assertIn("Bets: **Alpha 67%** (2)", str(payload))
        self.assertIn("6-3, 6-4 Final", str(payload))
        leaderboard_field = next(
            field for field in payload["fields"]
            if field["name"] == "🏆 Earnings Leaderboard"
        )
        self.assertEqual(
            leaderboard_field["value"],
            "**1.** <@7> — W$125.00 earnings (2W/1L)",
        )

    def test_betting_controls_wait_until_last_fixture_page(self):
        fixture = {
            "key": "fixture",
            "first_name": "Alpha",
            "first_id": "1",
            "second_name": "Beta",
            "second_id": "2",
            "tournament": "Rome",
            "odds": [1.8, 2.1],
            "pool_total": Decimal("100.00"),
            "pool_one": Decimal("50.00"),
            "pool_two": Decimal("50.00"),
        }
        _first_embed, first_view = main._build_wtsl_betting_page(
            [fixture],
            1,
            2,
        )
        self.assertEqual(
            [child.label for child in first_view.children],
            ["Alpha · 1.90", "Beta · 2.00"],
        )
        _last_embed, last_view = main._build_wtsl_betting_page(
            [fixture],
            2,
            2,
        )
        self.assertEqual(
            [child.label for child in last_view.children],
            [
                "Alpha · 1.90",
                "Beta · 2.00",
                "➕ Build Parlay",
                "🪙  My W$ Balance",
                "📒  My Bet Ledger",
            ],
        )
        embed_text = str(_first_embed[0].to_dict())
        self.assertIn("WTSL odds:", embed_text)
        self.assertIn("House-adjusted live odds:", embed_text)
        self.assertIn("Guaranteed minimum odds:", embed_text)
        self.assertIn(
            "Pool settlement with guaranteed minimum returns",
            str(_first_embed[0].to_dict()),
        )

    def test_managed_component_scan_finds_legacy_action_rows(self):
        message = SimpleNamespace(
            components=[
                SimpleNamespace(
                    children=[
                        SimpleNamespace(
                            custom_id="wtsl_bet:v1:fixture:one",
                            label="Alpha · 1.90",
                            disabled=False,
                        ),
                        SimpleNamespace(
                            custom_id="wtsl_bet:v1:balance",
                            label="My W$ Balance",
                            disabled=False,
                        ),
                    ]
                )
            ]
        )
        self.assertTrue(main._wtsl_has_managed_components(message))

    def test_betting_odds_use_decimal_format(self):
        self.assertEqual(main._wtsl_odds("2.00"), "2.00")
        self.assertEqual(main._wtsl_odds("2.50"), "2.50")
        self.assertEqual(main._wtsl_odds("1.80"), "1.80")
        self.assertEqual(main._wtsl_odds("1.667"), "1.67")
        self.assertEqual(main._wtsl_odds("0.95"), "0.95")

    def test_house_odds_show_live_pool_and_opening_fallback(self):
        fixture = {
            "pool_total": Decimal("100.00"),
            "pool_one": Decimal("60.00"),
            "pool_two": Decimal("40.00"),
        }
        self.assertEqual(
            main._wtsl_pool_decimal_odds(fixture, "one"),
            Decimal("1.58"),
        )
        self.assertEqual(
            main._wtsl_pool_odds_label(
                {"pool_total": Decimal("100.00"), "pool_one": Decimal("100.00")},
                "two",
                Decimal("1.80"),
            ),
            "1.80",
        )
        self.assertEqual(
            main._wtsl_house_odds_label(fixture, "one", Decimal("1.80")),
            "1.71",
        )
        self.assertEqual(
            main._wtsl_pool_return_label(fixture, "one", Decimal("1.80")),
            "W$171.00",
        )
        self.assertEqual(
            main._wtsl_house_odds_label(
                {"pool_total": Decimal("0.00")},
                "one",
                Decimal("1.80"),
            ),
            "1.71",
        )

    def test_pool_odds_never_return_less_than_the_stake(self):
        fixture = {
            "pool_total": Decimal("100.00"),
            "pool_one": Decimal("100.00"),
            "pool_two": Decimal("0.00"),
        }
        self.assertEqual(
            main._wtsl_pool_decimal_odds(fixture, "one"),
            Decimal("1.00"),
        )
        self.assertEqual(
            main._wtsl_house_odds_label(
                fixture,
                "one",
                Decimal("1.80"),
            ),
            "1.71",
        )

    def test_embed_explains_pool_return_can_move(self):
        fixture = {
            "key": "hsm09",
            "first_name": "HSM09",
            "first_id": "4543",
            "second_name": "bigwill",
            "second_id": "927",
            "tournament": "Jingshan",
            "odds": [Decimal("2.510"), Decimal("1.660")],
            "pool_total": Decimal("115.00"),
            "pool_one": Decimal("100.00"),
            "pool_two": Decimal("15.00"),
        }
        embeds, _view = main._build_wtsl_betting_page([fixture], 1, 1)
        value = embeds[0].fields[0].value
        self.assertIn("HSM09 1.09", value)
        self.assertIn("bigwill 7.28", value)
        self.assertNotIn("Guaranteed W$100 minimum return:", value)
        self.assertNotIn("Pool odds update as stakes arrive", value)

    def test_embed_uses_wtsl_odds_when_a_side_has_no_bets(self):
        fixture = {
            "key": "no-bet-side",
            "first_name": "Alpha",
            "first_id": "1",
            "second_name": "Beta",
            "second_id": "2",
            "tournament": "Rome",
            "odds": [Decimal("2.510"), Decimal("1.660")],
            "pool_total": Decimal("100.00"),
            "pool_one": Decimal("100.00"),
            "pool_two": Decimal("0.00"),
        }
        embeds, _view = main._build_wtsl_betting_page([fixture], 1, 1)
        value = embeds[0].fields[0].value
        self.assertIn(
            "House-adjusted live odds: **Alpha 1.00** • **Beta 1.66**",
            value,
        )
        self.assertNotIn("No bets", value)

    def test_fixed_parlay_odds_include_wtsl_vig(self):
        self.assertEqual(
            main._wtsl_parlay_decimal_odds("2.00"),
            Decimal("1.905"),
        )

    def test_parlay_copy_calls_prices_fixed_wtsl_odds(self):
        view = main.WTSLParlayView(7, [
            {
                "key": "fixture-one",
                "first_name": "Alpha",
                "first_id": "1",
                "second_name": "Beta",
                "second_id": "2",
                "tournament": "Rome",
                "odds_one": Decimal("2.00"),
                "odds_two": Decimal("1.50"),
            },
            {
                "key": "fixture-two",
                "first_name": "Gamma",
                "first_id": "3",
                "second_name": "Delta",
                "second_id": "4",
                "tournament": "Paris",
                "odds_one": Decimal("1.80"),
                "odds_two": Decimal("2.10"),
            },
        ])
        view.selected_legs = [
            {"selection_name": "Alpha", "odds": Decimal("1.905")},
            {"selection_name": "Gamma", "odds": Decimal("1.714")},
        ]
        self.assertIn("fixed WTSL odds", view._summary())
        self.assertTrue(
            any("fixed WTSL odds" in option.description for option in view.selector.options)
        )

    def test_betting_controls_can_follow_all_fixture_embeds(self):
        fixtures = []
        for index in range(5):
            fixtures.append({
                "key": f"fixture-{index}",
                "first_name": f"Alpha{index}",
                "first_id": str(index * 2 + 1),
                "second_name": f"Beta{index}",
                "second_id": str(index * 2 + 2),
                "tournament": "Rome",
                "odds": [1.8, 2.1],
            })
        fixture_controls = main._build_wtsl_betting_controls(
            fixtures,
            include_account_controls=False,
        )
        self.assertEqual(len(fixture_controls.children), 15)
        self.assertEqual(
            sorted({child.row for child in fixture_controls.children}),
            [0, 1, 2, 3, 4],
        )
        self.assertEqual(
            [child.label for child in fixture_controls.children[:3]],
            ["Alpha0 · 1.71", "vs.", "Beta0 · 2.00"],
        )
        account_controls = main._build_wtsl_betting_controls(
            fixtures[:4],
            include_account_controls=True,
        )
        self.assertEqual(
            [child.label for child in account_controls.children[-2:]],
            ["🪙  My W$ Balance", "📒  My Bet Ledger"],
        )

    def test_prediction_leaderboard_uses_confirmed_squeaky_alias(self):
        self.assertEqual(
            main._prediction_leaderboard_name({
                "discord_user_id": 859691230941282304,
                "challonge_username": "Squeaky94",
            }),
            "<@859691230941282304> (`Squeaky94`)",
        )

    def test_bet_ledger_shows_single_and_parlay_history(self):
        pages = main._build_wtsl_bet_ledger_pages([
            {
                "kind": "single",
                "id": 7,
                "fixture": "Alpha vs Beta",
                "selection": "Alpha",
                "stake": Decimal("25.00"),
                "odds": Decimal("1.80"),
                "potential_return": Decimal("45.00"),
                "return_amount": Decimal("0.00"),
                "status": "open",
                "placed_at": datetime(2026, 9, 18, 12, 0, tzinfo=timezone.utc),
            },
            {
                "kind": "parlay",
                "id": 8,
                "selection": "Alpha @ Rome • Gamma @ Paris",
                "stake": Decimal("10.00"),
                "odds": Decimal("3.600"),
                "potential_return": Decimal("36.00"),
                "return_amount": Decimal("36.00"),
                "status": "won",
                "placed_at": datetime(2026, 9, 17, 12, 0, tzinfo=timezone.utc),
            },
        ])
        self.assertEqual(len(pages), 1)
        payload = pages[0].to_dict()
        self.assertIn("Alpha vs Beta", str(payload))
        self.assertIn("Alpha @ Rome", str(payload))
        self.assertIn("Guaranteed minimum", str(payload))

    def test_jingshan_official_result_matches_fixture_round_and_te4_tour(self):
        matched = main._betting_result_for_fixture(
            {
                "first_name": "karyj8",
                "first_id": "4618",
                "second_name": "Nick1234567",
                "second_id": "1284",
                "tour": "TE4",
                "tournament": "Jingshan (R16)",
            },
            [{
                "p1": "Nick1234567",
                "p2": "karyj8",
                "tour": "atp",
                "tournament": (
                    "Tennis Elbow 4 (ATP Characters) - Jingshan 2026"
                ),
                "result": "Walkover",
                "round": "Round of 16",
                "date": "18.09.2026",
            }],
        )
        self.assertEqual(matched[0], "1284")
        self.assertIn("Walkover", matched[1])

    def test_scheduled_official_result_does_not_settle_fixture(self):
        matched = main._betting_result_for_fixture(
            {
                "first_name": "HSM09",
                "first_id": "927",
                "second_name": "goldenfq",
                "second_id": "927",
                "tour": "TE4",
                "tournament": "Jingshan (R16)",
            },
            [{
                "p1": "HSM09",
                "p2": "goldenfq",
                "tour": "atp",
                "tournament": (
                    "Tennis Elbow 4 (ATP Characters) - Jingshan 2026"
                ),
                "result": "Scheduled",
                "round": "Round of 16",
                "date": "14.09.2026",
            }],
        )
        self.assertIsNone(matched)

    def test_settled_results_show_bet_percentages_or_no_bets(self):
        embed = main._build_wtsl_betting_results([{
            "first_name": "Alpha",
            "second_name": "Beta",
            "first_id": "1",
            "second_id": "2",
            "winner_id": "1",
            "tournament": "Rome",
            "result_note": "Final",
            "total_bets": 3,
            "first_bets": 2,
            "second_bets": 1,
        }])
        value = embed.to_dict()["fields"][0]["value"]
        self.assertIn("Alpha 67%", value)
        self.assertIn("Beta 33%", value)
        no_bets = main._build_wtsl_betting_results([{
            "first_name": "Alpha",
            "second_name": "Beta",
            "first_id": "1",
            "second_id": "2",
            "winner_id": "2",
            "tournament": "Rome",
            "result_note": "Final",
        }])
        self.assertIn(
            "No bets were placed",
            no_bets.to_dict()["fields"][0]["value"],
        )
        self.assertNotIn("description", no_bets.to_dict())

    def test_parlay_builder_lists_two_outcomes_per_fixture_and_combines_odds(self):
        view = main.WTSLParlayView(7, [
            {
                "key": "fixture-one",
                "first_name": "Alpha",
                "first_id": "1",
                "second_name": "Beta",
                "second_id": "2",
                "tournament": "Rome",
                "odds_one": Decimal("2.00"),
                "odds_two": Decimal("1.50"),
            },
            {
                "key": "fixture-two",
                "first_name": "Gamma",
                "first_id": "3",
                "second_name": "Delta",
                "second_id": "4",
                "tournament": "Paris",
                "odds_one": Decimal("1.80"),
                "odds_two": Decimal("2.20"),
            },
        ])
        self.assertEqual(len(view.selector.options), 4)
        self.assertEqual(
            main._parlay_combined_odds([
                {"odds": Decimal("2.00")},
                {"odds": Decimal("1.80")},
            ]),
            Decimal("3.600"),
        )
        self.assertTrue(view.place_button.disabled)

    def test_parlay_builder_does_not_use_avatar_url_as_player_name(self):
        view = main.WTSLParlayView(7, [{
            "key": "legacy-fixture",
            "first_name": "Alpha",
            "first_id": "1",
            # Legacy reader shape: first_avatar and second_name were swapped.
            "second_name": "https://playwtsl.com/files/img/avatars/alpha.png",
            "second_id": "2",
            "first_avatar": "Beta",
            "second_avatar": "https://playwtsl.com/files/img/avatars/beta.png",
            "tournament": "Rome",
            "odds_one": Decimal("2.00"),
            "odds_two": Decimal("1.50"),
        }])
        self.assertEqual(
            [option.label for option in view.selector.options],
            ["Alpha", "Beta"],
        )

    async def test_live_wtsl_best_of_three_blocks_single_bet_submission(self):
        fixture = {
            "key": "fixture-one",
            "first_name": "Alpha",
            "second_name": "Beta",
        }
        live_matches = [{
            "players": [" beta ", "ALPHA"],
            "message": "XKT(WTSL)",
            "best_of": "Best of 3",
        }]
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=7),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        modal = main.WTSLBetModal(
            {
                **fixture,
                "first_id": "1",
                "second_id": "2",
                "odds_one": Decimal("2.00"),
                "odds_two": Decimal("1.50"),
            },
            "one",
        )
        modal.stake._value = "10"
        with patch.object(
            main,
            "_wtsl_current_live_matches_for_betting",
            new=AsyncMock(return_value=live_matches),
        ), patch.object(
            main,
            "_is_wtsl_betting_verified",
            new=AsyncMock(return_value=True),
        ):
            await modal.on_submit(interaction)
        self.assertIn(
            "currently ongoing",
            interaction.followup.send.await_args.args[0],
        )
        interaction.followup.send.assert_awaited_once()

    def test_live_betting_requires_a_wtsl_best_of_three_or_five_match(self):
        fixture = {
            "first_name": "Alpha",
            "second_name": "Beta",
        }
        self.assertTrue(main._wtsl_fixture_is_currently_live(
            fixture,
            [{
                "players": ["ALPHA", "beta"],
                "message": "XKT(WTSL)",
                "best_of": "Best of 3",
            }],
        ))
        self.assertTrue(main._wtsl_fixture_is_currently_live(
            fixture,
            [{
                "players": ["ALPHA", "beta"],
                "message": "XKT(WTSL)",
                "best_of": "Best of 5",
            }],
        ))
        self.assertFalse(main._wtsl_fixture_is_currently_live(
            fixture,
            [{
                "players": ["ALPHA", "beta"],
                "message": "XKT(WTSL)",
                "best_of": "Best of 1",
            }],
        ))
        self.assertFalse(main._wtsl_fixture_is_currently_live(
            fixture,
            [{
                "players": ["ALPHA", "beta"],
                "message": "XKT",
                "best_of": "Best of 3",
            }],
        ))

    def test_te4_result_uses_verified_tour_identity_before_aliases(self):
        message = SimpleNamespace(
            author=SimpleNamespace(bot=False),
            content="WTA US Open Losers bracket <@11> def <@22> 6/1 6/4",
            mentions=[
                SimpleNamespace(
                    id=11,
                    bot=False,
                    name="iakumii",
                    global_name="kumi",
                    display_name="kumi",
                ),
                SimpleNamespace(
                    id=22,
                    bot=False,
                    name="deatekk",
                    global_name="Deatek",
                    display_name="Deatek",
                ),
            ],
            attachments=[SimpleNamespace(filename="image.png")],
        )
        fixture = {
            "tour": "TE4_(F)",
            "first_name": "Iakumi",
            "second_name": "Deatekk",
        }
        self.assertTrue(main._wtsl_result_message_matches_fixture(
            message,
            fixture,
            {11: {"wta": "Iakumi"}, 22: {}},
        ))

        # A verified identity must not fall back to a conflicting display-name
        # alias for the same tour.
        self.assertFalse(main._wtsl_result_message_matches_fixture(
            message,
            fixture,
            {11: {"wta": "Different Player"}, 22: {}},
        ))
        self.assertFalse(main._wtsl_result_message_matches_fixture(
            message,
            {**fixture, "tour": "TE4"},
            {11: {"atp": "Iakumi"}, 22: {}},
        ))

    async def test_recent_te4_result_blocks_single_bet_submission(self):
        message = SimpleNamespace(
            author=SimpleNamespace(bot=False),
            content="WTA US Open Losers bracket <@11> def <@22> 6/1 6/4",
            mentions=[
                SimpleNamespace(
                    id=11,
                    bot=False,
                    name="iakumii",
                    global_name="kumi",
                    display_name="kumi",
                ),
                SimpleNamespace(
                    id=22,
                    bot=False,
                    name="deatekk",
                    global_name="Deatek",
                    display_name="Deatek",
                ),
            ],
            attachments=[SimpleNamespace(filename="image.png")],
        )
        fixture = {
            "key": "fixture-one",
            "first_name": "Iakumi",
            "first_id": "1166",
            "second_name": "Deatekk",
            "second_id": "1275",
            "tour": "TE4_(F)",
            "odds_one": Decimal("2.00"),
            "odds_two": Decimal("1.50"),
        }
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=7),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        modal = main.WTSLBetModal(fixture, "one")
        modal.stake._value = "10"
        with patch.object(
            main,
            "_wtsl_current_live_matches_for_betting",
            new=AsyncMock(return_value=[]),
        ), patch.object(
            main,
            "_wtsl_recent_te4_result_posts",
            new=AsyncMock(return_value=[{
                "message": message,
                "verified_links_by_user": {
                    11: {"wta": "Iakumi"},
                    22: {},
                },
            }]),
        ), patch.object(
            main,
            "_is_wtsl_betting_verified",
            new=AsyncMock(return_value=True),
        ), patch.object(
            main,
            "place_wtsl_bet",
        ) as place_bet:
            await modal.on_submit(interaction)

        self.assertIn(
            "already been reported as played",
            interaction.followup.send.await_args.args[0],
        )
        place_bet.assert_not_called()

    async def test_recent_te4_result_blocks_parlay_submission(self):
        message = SimpleNamespace(
            author=SimpleNamespace(bot=False),
            content="WTA US Open Losers bracket <@11> def <@22> 6/1 6/4",
            mentions=[
                SimpleNamespace(
                    id=11,
                    bot=False,
                    name="iakumii",
                    global_name="kumi",
                    display_name="kumi",
                ),
                SimpleNamespace(
                    id=22,
                    bot=False,
                    name="deatekk",
                    global_name="Deatek",
                    display_name="Deatek",
                ),
            ],
            attachments=[SimpleNamespace(filename="image.png")],
        )
        modal = main.WTSLParlayStakeModal(7, [
            {
                "fixture_key": "fixture-one",
                "selection_id": "1166",
                "selection_name": "Iakumi",
                "odds": Decimal("1.900"),
                "first_name": "Iakumi",
                "second_name": "Deatekk",
                "tour": "TE4_(F)",
            },
            {
                "fixture_key": "fixture-two",
                "selection_id": "3",
                "selection_name": "Gamma",
                "odds": Decimal("1.700"),
                "first_name": "Gamma",
                "second_name": "Delta",
                "tour": "TE4",
            },
        ])
        modal.stake._value = "10"
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=7),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        with patch.object(
            main,
            "_wtsl_current_live_matches_for_betting",
            new=AsyncMock(return_value=[]),
        ), patch.object(
            main,
            "_wtsl_recent_te4_result_posts",
            new=AsyncMock(return_value=[{
                "message": message,
                "verified_links_by_user": {
                    11: {"wta": "Iakumi"},
                    22: {},
                },
            }]),
        ), patch.object(
            main,
            "_is_wtsl_betting_verified",
            new=AsyncMock(return_value=True),
        ), patch.object(
            main,
            "place_wtsl_parlay",
        ) as place_parlay:
            await modal.on_submit(interaction)

        self.assertIn(
            "already been reported as played",
            interaction.followup.send.await_args.args[0],
        )
        place_parlay.assert_not_called()

    async def test_live_wtsl_match_cannot_be_selected_for_a_parlay(self):
        view = main.WTSLParlayView(7, [
            {
                "key": "fixture-one",
                "first_name": "Alpha",
                "first_id": "1",
                "second_name": "Beta",
                "second_id": "2",
                "tournament": "Rome",
                "odds_one": Decimal("2.00"),
                "odds_two": Decimal("1.50"),
            },
            {
                "key": "fixture-two",
                "first_name": "Gamma",
                "first_id": "3",
                "second_name": "Delta",
                "second_id": "4",
                "tournament": "Paris",
                "odds_one": Decimal("1.80"),
                "odds_two": Decimal("2.20"),
            },
        ])
        first_token = main._betting_fixture_token("fixture-one")
        second_token = main._betting_fixture_token("fixture-two")
        view.selector._values = [
            f"{first_token}:one",
            f"{second_token}:one",
        ]
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=7),
            response=SimpleNamespace(
                send_message=AsyncMock(),
                edit_message=AsyncMock(),
            ),
        )
        with patch.object(
            main,
            "_wtsl_current_live_matches_for_betting",
            new=AsyncMock(
                return_value=[{
                    "players": ["gamma", "DELTA"],
                    "message": "xkt(wtsl)",
                    "best_of": "Best of 5",
                }]
            ),
        ):
            await view._select_callback(interaction)
        self.assertIn(
            "currently ongoing",
            interaction.response.send_message.await_args.args[0],
        )
        interaction.response.edit_message.assert_not_awaited()

    async def test_live_wtsl_match_blocks_stale_parlay_placement(self):
        legs = [
            {
                "fixture_key": "fixture-one",
                "selection_id": "1",
                "selection_name": "Alpha",
                "odds": Decimal("1.900"),
                "first_name": "Alpha",
                "second_name": "Beta",
            },
            {
                "fixture_key": "fixture-two",
                "selection_id": "3",
                "selection_name": "Gamma",
                "odds": Decimal("1.700"),
                "first_name": "Gamma",
                "second_name": "Delta",
            },
        ]
        modal = main.WTSLParlayStakeModal(7, legs)
        modal.stake._value = "10"
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=7),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        with patch.object(
            main,
            "_wtsl_current_live_matches_for_betting",
            new=AsyncMock(
                return_value=[{
                    "players": ["DELTA", "gamma"],
                    "message": "XKT(WTSL)",
                    "best_of": "Best of 3",
                }]
            ),
        ):
            await modal.on_submit(interaction)
        self.assertIn(
            "currently ongoing",
            interaction.followup.send.await_args.args[0],
        )
        interaction.followup.send.assert_awaited_once()

    def test_exact_member_matching_rejects_collisions(self):
        one = SimpleNamespace(display_name="Squeaky", name="other", global_name=None)
        two = SimpleNamespace(display_name="squeaky", name="another", global_name=None)
        self.assertIsNone(resolve_member_exact([one, two], "Squeaky"))
        self.assertIs(resolve_member_exact([one], " squeaky "), one)
        self.assertIsNone(resolve_member_exact([one], "Squeak"))

    def test_member_matching_ignores_capitalization_and_emojis(self):
        member = SimpleNamespace(
            display_name="🎾 SQUEAKY 🔥",
            name="different-user",
            global_name=None,
        )
        self.assertIs(resolve_member_exact([member], "Squeaky"), member)

    def test_member_matching_ignores_unicode_accents_but_rejects_collisions(self):
        accented = SimpleNamespace(
            display_name="Lampjävel",
            name="different-user",
            global_name=None,
        )
        self.assertIs(resolve_member_exact([accented], "Lampjavel"), accented)
        plain = SimpleNamespace(
            display_name="Lampjavel",
            name="another-user",
            global_name=None,
        )
        self.assertIsNone(
            resolve_member_exact([accented, plain], "Lampjavel")
        )

    def test_member_matching_accepts_explicit_aka_alias_with_emoji(self):
        member = SimpleNamespace(
            display_name="Dani21✈️ aka Halapeno",
            name="unrelated-account",
            global_name=None,
        )
        self.assertIs(resolve_member_exact([member], "Dani21"), member)
        self.assertIs(resolve_member_exact([member], "Halapeno"), member)

    def test_outreach_resolution_uses_approved_identity_binding(self):
        member = SimpleNamespace(
            id=42,
            display_name="Different Discord nickname",
            name="different-account",
            global_name=None,
        )
        with patch.object(
            main,
            "_matchlog_identity_index",
            {42: {"atp": "lewar"}},
        ):
            self.assertIs(
                main._resolve_outreach_member([member], "lewar"),
                member,
            )

    async def test_outreach_member_fetch_fills_incomplete_startup_cache(self):
        cached = SimpleNamespace(id=1, display_name="Someone", name="someone")
        fetched = SimpleNamespace(id=2, display_name="🎾 SQUEAKY", name="squeaky")

        class Guild:
            members = [cached]

            async def fetch_members(self, limit=None):
                yield cached
                yield fetched

        members = await main._outreach_guild_members(Guild())
        self.assertEqual({member.id for member in members}, {1, 2})
        self.assertIs(resolve_member_exact(members, "Squeaky"), fetched)

    async def test_startup_repairs_every_active_persisted_prompt_by_member_id(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure(
                    "real", {"first_name": "Alpha", "second_name": "Beta"}
                )
                item = main._outreach_state.data["fixtures"]["real"]
                item["prompts"] = {
                    "side1": {"member_id": 7, "message_id": 70},
                    "side2": {"member_id": 8, "message_id": 80, "reply": "done"},
                }
                member = SimpleNamespace(id=7)
                guild = SimpleNamespace(fetch_member=AsyncMock())

                async def repaired(_member, prompt):
                    prompt.update(status="awaiting_reply", message_id=77)
                    return True

                with patch.object(
                    main, "_reconcile_dm_prompt",
                    new=AsyncMock(side_effect=repaired),
                ) as reconcile:
                    await main._repair_persisted_outreach_prompts(
                        guild, [member]
                    )
                reconcile.assert_awaited_once_with(member, item["prompts"]["side1"])
                self.assertEqual(item["prompts"]["side1"]["side"], "side1")
                self.assertTrue(item["prompts"]["side1"]["operation_ref"])
                self.assertEqual(item["prompts"]["side1"]["message_id"], 77)
                guild.fetch_member.assert_not_awaited()

                restarted = OutreachState(Path(directory) / "state.json")
                await restarted.load()
                saved = restarted.data["fixtures"]["real"]["prompts"]["side1"]
                self.assertEqual(saved["message_id"], 77)
                self.assertEqual(saved["status"], "awaiting_reply")
        finally:
            main._outreach_state = old

    async def test_startup_repair_continues_after_one_dm_history_failure(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "state.json"
                main._outreach_state = OutreachState(path)
                await main._outreach_state.load()
                for key, member_id in (("broken", 7), ("working", 8)):
                    await main._outreach_state.ensure(
                        key, {"first_name": key, "second_name": "Opponent"}
                    )
                    main._outreach_state.data["fixtures"][key]["prompts"] = {
                        "side1": {"member_id": member_id, "message_id": member_id}
                    }
                members = [SimpleNamespace(id=7), SimpleNamespace(id=8)]

                async def reconcile(member, prompt):
                    if member.id == 7:
                        raise RuntimeError("history unavailable")
                    prompt.update(status="awaiting_reply", message_id=88)
                    return True

                with patch.object(
                    main, "_reconcile_dm_prompt",
                    new=AsyncMock(side_effect=reconcile),
                ) as repair:
                    await main._repair_persisted_outreach_prompts(
                        SimpleNamespace(), members
                    )
                self.assertEqual(repair.await_count, 2)
                broken = main._outreach_state.data["fixtures"]["broken"]["prompts"]["side1"]
                working = main._outreach_state.data["fixtures"]["working"]["prompts"]["side1"]
                self.assertEqual(broken["side"], "side1")
                self.assertTrue(broken["operation_ref"])
                self.assertEqual(working["message_id"], 88)

                restarted = OutreachState(path)
                await restarted.load()
                saved_broken = restarted.data["fixtures"]["broken"]["prompts"]["side1"]
                self.assertEqual(saved_broken["side"], "side1")
                self.assertTrue(saved_broken["operation_ref"])
        finally:
            main._outreach_state = old

    async def test_startup_outreach_waits_until_other_startup_messages_finish(self):
        with patch.object(main, "OUTREACH_STARTUP_DELAY_SECONDS", 0):
            with patch.object(main, "_start_fixture_outreach", new=AsyncMock()) as start:
                await main._safe_start_fixture_outreach()
        start.assert_awaited_once()

    async def test_real_scanner_does_not_start_before_prompt_repair(self):
        old_state = main._outreach_state
        old_pending = getattr(main.client, "_outreach_pending_started", False)
        old_scanner = getattr(main.client, "_fixture_outreach_started", False)
        old_preexisting = main._outreach_preexisting_fixture_keys
        old_repair_complete = main._outreach_repair_complete
        main.client._outreach_pending_started = False
        main.client._fixture_outreach_started = False
        state = SimpleNamespace(
            load=AsyncMock(),
            remove=AsyncMock(return_value=False),
            data={"fixtures": {}},
            ensure=AsyncMock(return_value={"fixture": {}, "prompts": {}}),
        )
        main._outreach_state = state
        created = []

        def capture(coroutine):
            created.append(coroutine.cr_code.co_name)
            coroutine.close()

        try:
            with (
                patch.object(main, "FIXTURE_OUTREACH_ENABLED", True),
                patch.object(main.asyncio, "create_task", side_effect=capture),
                patch.object(
                    main,
                    "_clean_published_outreach_traces",
                    new=AsyncMock(side_effect=RuntimeError("slow repair blocked")),
                ),
            ):
                with self.assertRaisesRegex(RuntimeError, "slow repair blocked"):
                    await main._start_fixture_outreach()
            self.assertEqual(
                created,
                [],
            )
            self.assertFalse(main._outreach_repair_complete)
        finally:
            main._outreach_state = old_state
            main.client._outreach_pending_started = old_pending
            main.client._fixture_outreach_started = old_scanner
            main._outreach_preexisting_fixture_keys = old_preexisting
            main._outreach_repair_complete = old_repair_complete

    async def test_scanner_only_skips_preexisting_fixtures_during_repair(self):
        fixture = parse_upcoming_fixtures(FIXTURES, season="2026")[0]
        begin = AsyncMock()

        class Response:
            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                return False

            def raise_for_status(self):
                return None

            async def text(self):
                return FIXTURES

        class Session:
            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                return False

            def get(self, _url):
                return Response()

        async def run_once(preexisting):
            main._outreach_preexisting_fixture_keys = set(preexisting)
            main._outreach_repair_complete = False
            begin.reset_mock()
            with (
                patch.object(main.aiohttp, "ClientSession", return_value=Session()),
                patch.object(main.client, "get_guild", return_value=object()),
                patch.object(
                    main,
                    "_outreach_guild_members",
                    new=AsyncMock(return_value=[]),
                ),
                patch.object(
                    main,
                    "_load_open_draw_matches",
                    new=AsyncMock(return_value=[{
                        "players": ["Alpha", "Beta"],
                        "deadline": datetime(
                            2026, 9, 11, 12, tzinfo=timezone.utc
                        ),
                    }]),
                ),
                patch.object(main, "_begin_outreach", new=begin),
            ):
                await main._scan_fixture_outreach_once()
            return begin.await_count

        old_preexisting = main._outreach_preexisting_fixture_keys
        old_repair_complete = main._outreach_repair_complete
        try:
            self.assertEqual(await run_once({fixture["key"]}), 0)
            self.assertEqual(await run_once(set()), 1)
        finally:
            main._outreach_preexisting_fixture_keys = old_preexisting
            main._outreach_repair_complete = old_repair_complete

    async def test_state_dedupes_fixture_and_is_atomic(self):
        with tempfile.TemporaryDirectory() as directory:
            state = OutreachState(Path(directory) / "state.json")
            await state.load()
            await state.ensure("fixture", {"first_name": "Alpha"})
            await state.ensure("fixture", {"first_name": "Changed"})
            self.assertEqual(state.data["fixtures"]["fixture"]["fixture"]["first_name"], "Alpha")
            self.assertTrue((Path(directory) / "state.json").exists())

    async def test_postgres_backend_survives_restart_without_runtime_file(self):
        stored = None

        def load():
            return stored

        def save(value):
            nonlocal stored
            stored = value

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.json"
            state = OutreachState(
                path, load_backend=load, save_backend=save
            )
            await state.load()
            await state.ensure(
                "fixture", {"first_name": "Alpha", "second_name": "Beta"}
            )
            await state.update(
                "fixture",
                prompts={"side1": {"reply": "Stored response"}},
            )
            self.assertFalse(path.exists())

            restarted = OutreachState(
                path, load_backend=load, save_backend=save
            )
            await restarted.load()
            self.assertEqual(
                restarted.data["fixtures"]["fixture"]["prompts"]["side1"][
                    "reply"
                ],
                "Stored response",
            )

    async def test_postgres_backend_imports_existing_json_once(self):
        stored = None

        def load():
            return stored

        def save(value):
            nonlocal stored
            stored = value

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.json"
            path.write_text(
                '{"fixtures":{"old":{"prompts":{"side1":'
                '{"reply":"Recovered"}}}}}',
                encoding="utf8",
            )
            state = OutreachState(
                path, load_backend=load, save_backend=save
            )
            await state.load()
            self.assertEqual(
                stored["fixtures"]["old"]["prompts"]["side1"]["reply"],
                "Recovered",
            )

    async def test_two_same_player_prompts_route_by_prompt_reference(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure("test", {"first_name": "Squeaky", "second_name": "Squeaky"})
                item = main._outreach_state.data["fixtures"]["test"]
                item["prompts"] = {
                    "side1": {"member_id": 7, "message_id": 10, "status": "awaiting_reply"},
                    "side2": {"member_id": 7, "message_id": 11, "status": "awaiting_reply"},
                }
                await main._outreach_state.update("test", prompts=item["prompts"])
                channel = SimpleNamespace(send=AsyncMock())
                message = SimpleNamespace(
                    guild=None, author=SimpleNamespace(id=7, bot=False), channel=channel,
                    content="First thoughts", id=50, reference=SimpleNamespace(message_id=10),
                )
                with patch.object(main, "_publish_outreach", new=AsyncMock()):
                    self.assertTrue(await main._route_outreach_reply(message))
                self.assertEqual(item["prompts"]["side1"]["reply"], "First thoughts")
                self.assertNotIn("reply", item["prompts"]["side2"])
        finally:
            main._outreach_state = old

    async def test_publish_fake_path_uses_thread_destination_not_parent_posts(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                fixture = {
                    "first_name": "Squeaky", "second_name": "Squeaky",
                    "tournament": "Test Cup", "key": main.FAKE_OUTREACH_KEY,
                }
                await main._outreach_state.ensure(main.FAKE_OUTREACH_KEY, fixture)
                item = main._outreach_state.data["fixtures"][main.FAKE_OUTREACH_KEY]
                item["prompts"] = {"side1": {"reply": "one"}, "side2": {"reply": "two"}}
                preview = {"first": {"name": "Squeaky"}, "second": {"name": "Squeaky"}}
                parent = SimpleNamespace(send=AsyncMock())
                thread = SimpleNamespace(id=99)
                with patch.object(main, "collect_match_data", new=AsyncMock(return_value=preview)) as collect, \
                     patch.object(main, "generate_match_preview_copy", new=AsyncMock(return_value=None)), \
                     patch.object(main.client, "get_channel", return_value=parent), \
                     patch.object(main, "_publish_automated_match_preview", new=AsyncMock(return_value=thread)) as publish:
                    await main._publish_outreach(main.FAKE_OUTREACH_KEY)
                    collect.assert_awaited_once_with(
                        "Squeaky",
                        "Squeaky",
                        main.MATCH_STATS_WORKBOOK,
                        allow_same_player=True,
                    )
                self.assertTrue(preview["same_player_test"])
                publish.assert_awaited_once_with(preview, parent, main.FAKE_OUTREACH_KEY)
                parent.send.assert_not_awaited()
                self.assertTrue(item["published"])
        finally:
            main._outreach_state = old

    async def test_deadline_publishes_real_but_not_incomplete_fake(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure("real", {"first_name": "A", "second_name": "B"})
                await main._outreach_state.ensure(main.FAKE_OUTREACH_KEY, {"first_name": "Squeaky", "second_name": "Squeaky"})
                for item in main._outreach_state.data["fixtures"].values():
                    item["deadline"] = 0
                # Exercise one loop pass by cancelling its sleep after publish calls.
                with patch.object(main, "_publish_outreach", new=AsyncMock()) as publish, \
                     patch.object(main.asyncio, "sleep", new=AsyncMock(side_effect=asyncio.CancelledError)):
                    with self.assertRaises(asyncio.CancelledError):
                        await main._pending_outreach_loop()
                publish.assert_awaited_once_with("real")
        finally:
            main._outreach_state = old

    async def test_prompt_has_clear_reply_button_without_visible_tracking_code(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure("x", {
                    "first_name": "Alpha", "second_name": "Beta", "tournament": "Rome"
                })
                member = SimpleNamespace(id=4, send=AsyncMock(return_value=SimpleNamespace(id=123)))
                await main._send_outreach_prompt("x", "side1", member)
                text = member.send.await_args.args[0]
                self.assertIn("Alpha vs Beta", text)
                self.assertIn("Rome", text)
                self.assertIn("Side 1", text)
                self.assertIn("Reply with thoughts", text)
                self.assertNotIn("Outreach ref:", text)
                sent_kwargs = member.send.await_args.kwargs
                self.assertTrue(sent_kwargs["nonce"])
                button = sent_kwargs["view"].children[0]
                self.assertEqual(button.label, "Reply with thoughts")
                self.assertEqual(button.custom_id[-6:], ":side1")
                self.assertEqual(main._outreach_state.data["fixtures"]["x"]["prompts"]["side1"]["message_id"], 123)
        finally:
            main._outreach_state = old

    async def test_deadline_starts_only_after_both_prompts_are_delivered(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(
                    Path(directory) / "state.json"
                )
                await main._outreach_state.load()
                await main._outreach_state.ensure(
                    "x", {"first_name": "A", "second_name": "B"}
                )
                item = main._outreach_state.data["fixtures"]["x"]
                item["draw_publish_cutoff"] = time.time() + 24 * 3600
                first = SimpleNamespace(
                    id=1,
                    send=AsyncMock(return_value=SimpleNamespace(id=11)),
                )
                second = SimpleNamespace(
                    id=2,
                    send=AsyncMock(return_value=SimpleNamespace(id=22)),
                )
                await main._send_outreach_prompt("x", "side1", first)
                self.assertNotIn("deadline", item)
                await main._send_outreach_prompt("x", "side2", second)
                self.assertAlmostEqual(
                    item["deadline"] - item["outreach_completed_at"],
                    12 * 3600,
                )
        finally:
            main._outreach_state = old

    async def test_draw_cutoff_can_end_response_window_early(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(
                    Path(directory) / "state.json"
                )
                await main._outreach_state.load()
                await main._outreach_state.ensure(
                    "x", {"first_name": "A", "second_name": "B"}
                )
                item = main._outreach_state.data["fixtures"]["x"]
                cutoff = time.time() + 2 * 3600
                item["draw_publish_cutoff"] = cutoff
                item["prompts"] = {
                    "side1": {
                        "message_id": 11, "status": "awaiting_reply"
                    },
                    "side2": {
                        "message_id": 22, "status": "awaiting_reply"
                    },
                }
                await main._start_outreach_response_clock_if_ready("x")
                self.assertEqual(item["deadline"], cutoff)
                self.assertLess(
                    item["deadline"] - item["outreach_completed_at"],
                    12 * 3600,
                )
        finally:
            main._outreach_state = old

    async def test_one_time_outreach_uses_fixed_deadline_without_draw_match(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(
                    Path(directory) / "state.json"
                )
                await main._outreach_state.load()
                fixture = {
                    "key": "one-time",
                    "first_name": "Dani21",
                    "second_name": "Madferit",
                    "one_time_publish_deadline": 12345.0,
                }
                with patch.object(main, "_schedule_outreach_deadline"):
                    await main._begin_outreach(
                        fixture,
                        SimpleNamespace(members=[]),
                        members=[],
                    )
                item = main._outreach_state.data["fixtures"]["one-time"]
                self.assertTrue(item["one_time_outreach"])
                self.assertEqual(item["deadline"], 12345.0)
        finally:
            main._outreach_state = old

    async def test_published_preview_is_not_reset_by_legacy_commentary_retry(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                fixture = {
                    "key": "dani-madferit",
                    "first_name": "Madferit",
                    "second_name": "Dani21",
                }
                await main._outreach_state.ensure(fixture["key"], fixture)
                item = main._outreach_state.data["fixtures"][fixture["key"]]
                item.update({
                    "published": True,
                    "publish_status": "published",
                    "thread_id": 123,
                    "publish_operation_ref": "old-publish",
                    "prompts": {
                        "side1": {
                            "member_id": 1,
                            "message_id": 11,
                            "status": "awaiting_reply",
                            "operation_ref": "old-side1-ref",
                        },
                        "side2": {
                            "member_id": 2,
                            "message_id": 22,
                            "status": "awaiting_reply",
                            "operation_ref": "old-side2-ref",
                        },
                    },
                })
                response = AsyncMock()
                response.__aenter__.return_value = response
                response.__aexit__.return_value = None
                response.raise_for_status = MagicMock()
                session = MagicMock()
                session.__aenter__ = AsyncMock(return_value=session)
                session.__aexit__ = AsyncMock(return_value=None)
                session.get.return_value = response
                with (
                    patch.object(
                        main, "parse_upcoming_fixtures", return_value=[fixture]
                    ),
                    patch.object(main.aiohttp, "ClientSession", return_value=session),
                    patch.object(main, "_begin_outreach", new=AsyncMock()) as begin,
                ):
                    await main._run_one_time_dani_madferit_outreach(
                        SimpleNamespace(members=[]), []
                    )
                item = main._outreach_state.data["fixtures"][fixture["key"]]
                self.assertTrue(item["published"])
                self.assertEqual(item["publish_status"], "published")
                self.assertEqual(item["thread_id"], 123)
                self.assertEqual(item["publish_operation_ref"], "old-publish")
                self.assertEqual(item["prompts"]["side1"]["message_id"], 11)
                self.assertEqual(item["prompts"]["side2"]["message_id"], 22)
                begin.assert_not_awaited()
        finally:
            main._outreach_state = old

    def test_outreach_uses_earliest_matching_draw_deadline(self):
        fixture = {"first_name": "Alpha", "second_name": "Beta"}
        later = datetime.now(timezone.utc) + timedelta(days=3)
        earlier = later - timedelta(days=1)
        deadline = main._outreach_draw_deadline(fixture, [
            {"players": ["Other", "Beta"], "deadline": earlier},
            {"players": ["Beta", "Alpha"], "deadline": later},
            {"players": ["Alpha", "Beta"], "deadline": earlier},
        ])
        self.assertEqual(deadline, earlier)

    async def test_second_reply_publishes_immediately_and_failure_is_acknowledged(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure("x", {"first_name": "Alpha", "second_name": "Beta"})
                item = main._outreach_state.data["fixtures"]["x"]
                item["prompts"] = {
                    "side1": {"member_id": 9, "message_id": 1, "reply": "already saved"},
                    "side2": {"member_id": 9, "message_id": 2},
                }
                channel = SimpleNamespace(send=AsyncMock())
                message = SimpleNamespace(
                    guild=None, author=SimpleNamespace(id=9), channel=channel,
                    content="second reply", id=3, reference=SimpleNamespace(message_id=2),
                )
                publish = AsyncMock(side_effect=RuntimeError("temporary"))
                with patch.object(main, "_publish_outreach", new=publish):
                    self.assertTrue(await main._route_outreach_reply(message))
                self.assertEqual(item["prompts"]["side2"]["reply"], "second reply")
                publish.assert_awaited_once_with("x")
                self.assertIn("safely recorded", channel.send.await_args_list[-1].args[0])
        finally:
            main._outreach_state = old

    async def test_unreferenced_dm_is_not_recorded(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure("x", {"first_name": "A", "second_name": "B"})
                item = main._outreach_state.data["fixtures"]["x"]
                item["prompts"] = {"side1": {"member_id": 2, "message_id": 10}}
                channel = SimpleNamespace(send=AsyncMock())
                message = SimpleNamespace(
                    guild=None, author=SimpleNamespace(id=2), channel=channel,
                    content="unrelated", id=11, reference=None,
                )
                self.assertTrue(await main._route_outreach_reply(message))
                self.assertNotIn("reply", item["prompts"]["side1"])
                self.assertIn("Choose the correct", channel.send.await_args.args[0])
                button = channel.send.await_args.kwargs["view"].children[0]
                self.assertEqual(button.custom_id[-6:], ":side1")
        finally:
            main._outreach_state = old

    async def test_unreferenced_dm_offers_both_active_side_buttons(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure(
                    "x", {"first_name": "Same", "second_name": "Same"}
                )
                item = main._outreach_state.data["fixtures"]["x"]
                item["prompts"] = {
                    "side1": {
                        "member_id": 2, "message_id": 10,
                        "operation_ref": "ABCDEF1234",
                    },
                    "side2": {
                        "member_id": 2, "message_id": 11,
                        "operation_ref": "123456ABCD",
                    },
                }
                channel = SimpleNamespace(send=AsyncMock())
                message = SimpleNamespace(
                    guild=None, author=SimpleNamespace(id=2), channel=channel,
                    content="thoughts", id=12, reference=None,
                )
                self.assertTrue(await main._route_outreach_reply(message))
                buttons = channel.send.await_args.kwargs["view"].children
                self.assertEqual(len(buttons), 2)
                self.assertEqual(
                    {button.custom_id for button in buttons},
                    {
                        "outreach_reply:ABCDEF1234:side1",
                        "outreach_reply:123456ABCD:side2",
                    },
                )
        finally:
            main._outreach_state = old

    async def test_concurrent_publish_claim_only_calls_publisher_once(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure("real", {"first_name": "Alpha", "second_name": "Beta"})
                item = main._outreach_state.data["fixtures"]["real"]
                item["prompts"] = {"side1": {"reply": "a"}, "side2": {"reply": "b"}}
                preview = {"first": {"name": "Alpha"}, "second": {"name": "Beta"}}
                parent, thread = SimpleNamespace(), SimpleNamespace(id=55)
                publisher = AsyncMock(return_value=thread)
                with patch.object(main, "collect_match_data", new=AsyncMock(return_value=preview)), \
                     patch.object(main, "generate_match_preview_copy", new=AsyncMock(return_value=None)), \
                     patch.object(main.client, "get_channel", return_value=parent), \
                     patch.object(main, "_publish_automated_match_preview", new=publisher):
                    await asyncio.gather(main._publish_outreach("real"), main._publish_outreach("real"))
                publisher.assert_awaited_once()
                self.assertEqual(item["publish_status"], "published")
        finally:
            main._outreach_state = old

    async def test_failed_prompt_is_saved_and_other_side_can_continue(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure("x", {"first_name": "A", "second_name": "B"})
                bad = SimpleNamespace(id=1, send=AsyncMock(side_effect=asyncio.TimeoutError()))
                good = SimpleNamespace(id=2, send=AsyncMock(return_value=SimpleNamespace(id=22)))
                await main._send_outreach_prompt("x", "side1", bad)
                await main._send_outreach_prompt("x", "side2", good)
                prompts = main._outreach_state.data["fixtures"]["x"]["prompts"]
                self.assertEqual(prompts["side1"]["status"], "failed")
                self.assertLessEqual(len(prompts["side1"]["last_error"]), 300)
                self.assertEqual(prompts["side2"]["status"], "awaiting_reply")
        finally:
            main._outreach_state = old

    async def test_publish_claim_fresh_blocks_and_stale_reclaims_on_load(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.json"
            state = OutreachState(path)
            await state.load(now=100)
            await state.ensure("x", {})
            self.assertTrue(await state.claim_publish("x", now=100, lease_seconds=600))
            self.assertFalse(await state.claim_publish("x", now=699, lease_seconds=600))
            restarted = OutreachState(path)
            await restarted.load(now=701, lease_seconds=600)
            self.assertEqual(restarted.data["fixtures"]["x"]["publish_status"], "pending")
            self.assertTrue(await restarted.claim_publish("x", now=701, lease_seconds=600))

    async def test_send_started_with_existing_dm_recovers_without_resend(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure("x", {"first_name": "A", "second_name": "B"})
                prompt = {
                    "member_id": 1, "status": "send_started", "attempts": 1,
                    "operation_ref": "ABC123", "side": "side1",
                    "send_started_at": "2020-01-01T00:00:00+00:00",
                }
                main._outreach_state.data["fixtures"]["x"]["prompts"] = {"side1": prompt}
                member = SimpleNamespace(id=1, send=AsyncMock())
                async def recover(_member, value, **_kwargs):
                    value.update({"status": "awaiting_reply", "message_id": 77})
                    return True
                with patch.object(main, "_reconcile_dm_prompt", new=AsyncMock(side_effect=recover)):
                    await main._send_outreach_prompt("x", "side1", member)
                member.send.assert_not_awaited()
                self.assertEqual(prompt["status"], "awaiting_reply")
                self.assertEqual(prompt["message_id"], 77)
        finally:
            main._outreach_state = old

    async def test_fresh_deployment_reconciles_existing_prompt_before_send(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure(
                    "x", {"first_name": "A", "second_name": "B"}
                )
                member = SimpleNamespace(id=1, send=AsyncMock())

                async def recover(_member, prompt, **_kwargs):
                    prompt.update({"status": "awaiting_reply", "message_id": 77})
                    return True

                with patch.object(
                    main, "_reconcile_dm_prompt",
                    new=AsyncMock(side_effect=recover),
                ):
                    await main._send_outreach_prompt("x", "side1", member)
                member.send.assert_not_awaited()
                prompt = main._outreach_state.data["fixtures"]["x"]["prompts"]["side1"]
                self.assertEqual(prompt["message_id"], 77)
        finally:
            main._outreach_state = old

    async def test_replacement_deployment_reuses_visible_matching_prompt(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure(
                    "new-key",
                    {
                        "first_name": "Madferit",
                        "second_name": "Ptacek",
                        "tournament": "US Open (QF)",
                    },
                )
                existing = SimpleNamespace(
                    id=77,
                    content=(
                        "**Pre-match outreach — Side 2**\n"
                        "**Match:** Madferit vs Ptacek\n"
                        "**Tournament:** US Open (QF)\n"
                        "Select **Reply with thoughts** below."
                    ),
                    author=SimpleNamespace(id=999),
                    components=[],
                    edit=AsyncMock(),
                )
                near_collision = SimpleNamespace(
                    id=78,
                    content=(
                        "**Pre-match outreach — Side 2**\n"
                        "**Match:** Madferit vs Ptacek\n"
                        "**Tournament:** US Open\n"
                        "Select **Reply with thoughts** below."
                    ),
                    author=SimpleNamespace(id=999),
                    components=[],
                    edit=AsyncMock(),
                )

                async def history(**_kwargs):
                    yield near_collision
                    yield existing

                channel = SimpleNamespace(history=history)
                member = SimpleNamespace(
                    id=2,
                    dm_channel=channel,
                    send=AsyncMock(),
                )
                with patch.object(
                    main.client._connection,
                    "user",
                    SimpleNamespace(id=999),
                ):
                    await main._send_outreach_prompt("new-key", "side2", member)
                member.send.assert_not_awaited()
                existing.edit.assert_awaited_once()
                near_collision.edit.assert_not_awaited()
                prompt = main._outreach_state.data["fixtures"]["new-key"]["prompts"]["side2"]
                self.assertEqual(prompt["message_id"], 77)
        finally:
            main._outreach_state = old

    async def test_stale_send_started_without_dm_retries_once(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure("x", {"first_name": "A", "second_name": "B"})
                prompt = {
                    "member_id": 1, "status": "send_started", "attempts": 1,
                    "operation_ref": "ABC123", "send_started_at": "2020-01-01T00:00:00+00:00",
                }
                main._outreach_state.data["fixtures"]["x"]["prompts"] = {"side1": prompt}
                member = SimpleNamespace(id=1, send=AsyncMock(return_value=SimpleNamespace(id=8)))
                with patch.object(main, "_reconcile_dm_prompt", new=AsyncMock(return_value=False)):
                    await main._send_outreach_prompt("x", "side1", member)
                member.send.assert_awaited_once()
                self.assertEqual(prompt["attempts"], 2)
                self.assertEqual(prompt["message_id"], 8)
        finally:
            main._outreach_state = old

    async def test_legacy_prompt_is_upgraded_in_place_with_button(self):
        prompt = {
            "member_id": 1,
            "operation_ref": "ABCDEF1234",
            "side": "side1",
            "send_started_at": "2020-01-01T00:00:00+00:00",
        }
        legacy = SimpleNamespace(id=77, components=[], edit=AsyncMock())
        member = SimpleNamespace(id=1, send=AsyncMock())
        with patch.object(
            main, "_find_message_with_ref",
            new=AsyncMock(side_effect=[None, legacy]),
        ):
            self.assertTrue(await main._reconcile_dm_prompt(member, prompt))
        legacy.edit.assert_awaited_once()
        member.send.assert_not_awaited()
        button = legacy.edit.await_args.kwargs["view"].children[0]
        self.assertEqual(
            button.custom_id, "outreach_reply:ABCDEF1234:side1"
        )
        self.assertEqual(prompt["message_id"], 77)

    async def test_uneditable_legacy_prompt_gets_one_marked_replacement(self):
        prompt = {
            "member_id": 1,
            "operation_ref": "ABCDEF1234",
            "side": "side2",
            "send_started_at": "2020-01-01T00:00:00+00:00",
        }
        legacy = SimpleNamespace(
            id=77, components=[], edit=AsyncMock(side_effect=RuntimeError("old"))
        )
        replacement = SimpleNamespace(id=88)
        member = SimpleNamespace(id=1, send=AsyncMock(return_value=replacement))
        with patch.object(
            main, "_find_message_with_ref",
            new=AsyncMock(side_effect=[None, legacy]),
        ):
            self.assertTrue(await main._reconcile_dm_prompt(member, prompt))
        member.send.assert_awaited_once()
        text = member.send.await_args.args[0]
        self.assertIn("Reply with thoughts", text)
        self.assertIn(
            main._outreach_hidden_marker("dm:ABCDEF1234:button"), text
        )
        self.assertEqual(prompt["message_id"], 88)

    async def test_current_prompt_button_reconciles_without_edit_or_resend(self):
        prompt = {
            "member_id": 1,
            "operation_ref": "ABCDEF1234",
            "side": "side1",
            "send_started_at": "2020-01-01T00:00:00+00:00",
        }
        button = SimpleNamespace(custom_id="outreach_reply:ABCDEF1234:side1")
        current = SimpleNamespace(
            id=99,
            components=[SimpleNamespace(children=[button])],
            edit=AsyncMock(),
        )
        member = SimpleNamespace(id=1, send=AsyncMock())
        with patch.object(
            main, "_find_message_with_ref", new=AsyncMock(return_value=current)
        ):
            self.assertTrue(await main._reconcile_dm_prompt(member, prompt))
        current.edit.assert_not_awaited()
        member.send.assert_not_awaited()
        self.assertEqual(prompt["message_id"], 99)

    async def test_stored_partial_thread_resumes_without_creating(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                fixture = {"first_name": "A", "second_name": "B"}
                await main._outreach_state.ensure("x", fixture)
                item = main._outreach_state.data["fixtures"]["x"]
                item.update({
                    "thread_id": 44, "publish_operation_ref": "REF",
                    "publishing_started_at": "2026-01-01T00:00:00+00:00",
                    "sent_units": {"chunk:0": 1},
                })
                thread = SimpleNamespace(send=AsyncMock(side_effect=[SimpleNamespace(id=2), SimpleNamespace(id=3)]))
                parent = SimpleNamespace(create_thread=AsyncMock())
                preview = {"first": {"name": "A"}, "second": {"name": "B"}}
                with patch.object(main.client, "get_channel", return_value=thread), \
                     patch.object(main, "format_match_preview", return_value="one\ntwo"), \
                     patch.object(main, "split_discord_message", return_value=["one", "two"]), \
                     patch.object(main, "_matchpreview_avatar_embeds", return_value=[]), \
                     patch.object(main, "_find_message_with_ref", new=AsyncMock(return_value=None)):
                    result = await main._publish_automated_match_preview(preview, parent, "x")
                self.assertIs(result, thread)
                parent.create_thread.assert_not_awaited()
                self.assertEqual(thread.send.await_count, 2)  # missing chunk plus poll
        finally:
            main._outreach_state = old

    async def test_lost_unit_response_is_reconciled_without_duplicate(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure("x", {"first_name": "A", "second_name": "B"})
                item = main._outreach_state.data["fixtures"]["x"]
                item.update({"thread_id": 4, "publish_operation_ref": "REF",
                             "publishing_started_at": "2026-01-01T00:00:00+00:00"})
                thread = SimpleNamespace(send=AsyncMock())
                preview = {"first": {"name": "A"}, "second": {"name": "B"}}
                found = [SimpleNamespace(id=11), SimpleNamespace(id=12)]
                with patch.object(main.client, "get_channel", return_value=thread), \
                     patch.object(main, "format_match_preview", return_value="one"), \
                     patch.object(main, "split_discord_message", return_value=["one"]), \
                     patch.object(main, "_matchpreview_avatar_embeds", return_value=[]), \
                     patch.object(main, "_find_message_with_ref", new=AsyncMock(side_effect=found)):
                    await main._publish_automated_match_preview(preview, SimpleNamespace(), "x")
                thread.send.assert_not_awaited()
                self.assertEqual(item["sent_units"]["chunk:0"], 11)
                self.assertEqual(item["poll_message_id"], 12)
        finally:
            main._outreach_state = old

    async def test_automated_preview_messages_stay_within_discord_limit(self):
        old = main._outreach_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                main._outreach_state = OutreachState(Path(directory) / "state.json")
                await main._outreach_state.load()
                await main._outreach_state.ensure(
                    "x", {"first_name": "Alpha", "second_name": "Beta"}
                )
                item = main._outreach_state.data["fixtures"]["x"]
                item.update({
                    "thread_id": 4,
                    "publish_operation_ref": "ABCDEF1234",
                    "publishing_started_at": "2026-01-01T00:00:00+00:00",
                })
                thread = SimpleNamespace(
                    send=AsyncMock(return_value=SimpleNamespace(id=10))
                )
                preview = {
                    "first": {"name": "Alpha"},
                    "second": {"name": "Beta"},
                }
                with patch.object(main.client, "get_channel", return_value=thread), \
                     patch.object(main, "format_match_preview", return_value="x" * 5000), \
                     patch.object(main, "_matchpreview_avatar_embeds", return_value=[]), \
                     patch.object(main, "_find_message_with_ref", new=AsyncMock(return_value=None)):
                    await main._publish_automated_match_preview(
                        preview, SimpleNamespace(), "x"
                    )
                for call in thread.send.await_args_list:
                    content = call.args[0] if call.args else ""
                    self.assertLessEqual(len(content or ""), 2000)
        finally:
            main._outreach_state = old

    async def test_ambiguous_thread_reconciliation_fails_closed(self):
        item = {
            "fixture": {"first_name": "A", "second_name": "B"},
            "publishing_started_at": "2026-01-01T00:00:00+00:00",
        }
        threads = [
            SimpleNamespace(name="Match Preview - A vs B", owner_id=1,
                            created_at=main.datetime(2026, 1, 1, tzinfo=main.timezone.utc),
                            history=self._history([]))
            for _ in range(2)
        ]
        with patch.object(type(main.client), "user", new_callable=PropertyMock,
                          return_value=SimpleNamespace(id=1)):
            with self.assertRaisesRegex(RuntimeError, "ambiguous"):
                await main._reconcile_preview_thread(
                    SimpleNamespace(threads=threads), item, "REF"
                )

    def test_player_submission_is_clean_and_editorial_copy_stays_identified(self):
        data = {
            "first": {"name": "Alpha"}, "second": {"name": "Beta"},
            "player_quotes": ["Actual reply", "Generated reply"],
            "player_quote_sources": ["Submitted by player", "Editorial copy (no response received)"],
        }
        from match_preview import _article_player_quote_lines
        text = "\n".join(_article_player_quote_lines(data))
        self.assertIn("Actual reply", text)
        self.assertNotIn("Submitted by player", text)
        self.assertNotIn("Editorial copy (no response received)", text)
        self.assertIn("*(fictional)*", text)

    async def test_existing_preview_trace_is_cleaned_on_startup(self):
        old = main._outreach_state
        try:
            main._outreach_state = SimpleNamespace(data={"fixtures": {"x": {
                "published": True, "thread_id": 44, "publish_operation_ref": "ABC123"
            }}})
            message = SimpleNamespace(
                author=SimpleNamespace(id=1),
                content=(
                    '> “Actual reply” — **Alpha** *(Submitted by player)*\n'
                    "[Outreach ABC123 · chunk:3]"
                ),
                edit=AsyncMock(),
            )
            poll_message = SimpleNamespace(
                author=SimpleNamespace(id=1),
                content="[Outreach ABC123 · poll]",
                edit=AsyncMock(),
            )
            thread = SimpleNamespace(history=self._history([message, poll_message]))
            with patch.object(
                type(main.client), "user", new_callable=PropertyMock,
                return_value=SimpleNamespace(id=1),
            ), patch.object(main.client, "get_channel", return_value=thread):
                await main._clean_published_outreach_traces()
            message.edit.assert_awaited_once_with(
                content='> “Actual reply” — **Alpha**'
            )
            poll_message.edit.assert_awaited_once_with(content=None)
        finally:
            main._outreach_state = old

    async def test_hidden_marker_recovers_message_when_history_has_no_nonce(self):
        reference = "ABC123:chunk:0"
        message = SimpleNamespace(
            author=SimpleNamespace(id=1),
            content="Visible preview text" + main._outreach_hidden_marker(reference),
            nonce=None,
        )
        channel = SimpleNamespace(history=self._history([message]))
        with patch.object(
            type(main.client), "user", new_callable=PropertyMock,
            return_value=SimpleNamespace(id=1),
        ):
            self.assertIs(await main._find_message_with_ref(channel, reference), message)

    async def test_modal_acknowledges_before_persisting_reply(self):
        old = main._outreach_state
        events = []
        try:
            prompt = {
                "operation_ref": "ABCDEF1234",
                "member_id": 7,
            }
            item = {"published": False, "prompts": {"side1": prompt, "side2": {}}}
            main._outreach_state = SimpleNamespace(
                data={"fixtures": {"x": item}},
                update=AsyncMock(side_effect=lambda *args, **kwargs: events.append("persist")),
            )
            response = SimpleNamespace(
                defer=AsyncMock(side_effect=lambda **kwargs: events.append("ack"))
            )
            interaction = SimpleNamespace(
                user=SimpleNamespace(id=7),
                id=99,
                response=response,
                edit_original_response=AsyncMock(),
            )
            modal = main._OutreachThoughtsModal("ABCDEF1234", "side1")
            modal.thoughts._value = "My match thoughts"
            await modal.on_submit(interaction)
            self.assertEqual(events[:2], ["ack", "persist"])
            self.assertEqual(prompt["reply"], "My match thoughts")
            interaction.edit_original_response.assert_awaited_once()
        finally:
            main._outreach_state = old

    def test_fake_key_is_namespaced_and_destination_is_fixed(self):
        self.assertTrue(main.FAKE_OUTREACH_KEY.startswith("test:"))
        self.assertEqual(main.OUTREACH_CHANNEL_ID, 812742338669576252)