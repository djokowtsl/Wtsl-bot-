import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from wtsl_results import (
    enrich_event_metadata,
    _merge_without_history_loss,
    _player_page_result_rows,
    get_all_results,
    parse_all_results_html,
    tournament_category,
)


class WTSLResultsTests(unittest.TestCase):
    def test_parser_extracts_characters_from_real_us_open_row_shape(self):
        html = """
        <table>
          <tr>
            <th>Tournament</th><th>Round</th><th>Player 1</th>
            <th>Player 2</th><th>Date</th><th>Reported</th><th>Result</th>
          </tr>
          <tr>
            <td>Tennis Elbow 4 (ATP Characters) - US Open 2026</td>
            <td>Round of 32</td>
            <td>Squeaky (R. Federer)</td>
            <td>gosydar (S. Wawrinka)</td>
            <td>01.09.2026</td><td>2026-09-01 16:39:01</td>
            <td>6-2,1-6,6-2,6-7,6-0</td>
          </tr>
        </table>
        """
        result = parse_all_results_html(html)[0]
        self.assertEqual(result["p1"], "Squeaky")
        self.assertEqual(result["p1_character"], "R. Federer")
        self.assertEqual(result["p2"], "gosydar")
        self.assertEqual(result["p2_character"], "S. Wawrinka")

    def test_parser_handles_leading_cell_and_characters(self):
        html = """
        <table>
          <tr>
            <th>Tournament</th><th>Round</th>
            <th>Player 1 (Char)</th><th>Player 2 (Char)</th>
            <th>Date</th><th>Reported</th><th>Result</th>
          </tr>
          <tr>
            <td></td><td>TE4 ATP 500</td><td>Final</td>
            <td>alpha (J. Sinner)</td><td>beta (D. Thiem)</td>
            <td>08.09.2026</td><td>Yes</td><td>6-4 6-4</td>
          </tr>
        </table>
        """
        result = parse_all_results_html(html)[0]
        self.assertEqual(result["tournament"], "TE4 ATP 500")
        self.assertEqual(result["round"], "Final")
        self.assertEqual(result["p1"], "alpha")
        self.assertEqual(result["p1_character"], "J. Sinner")
        self.assertEqual(result["p2_character"], "D. Thiem")

    def test_official_results_get_event_start_and_category_metadata(self):
        results = enrich_event_metadata([
            {
                "tour": "atp",
                "tournament": "Tennis Elbow 4 (ATP Characters) - Lexus Challenger 2026",
                "date": "15.06.2026",
            },
            {
                "tour": "atp",
                "tournament": "Tennis Elbow 4 (ATP Characters) - Lexus Challenger 2026",
                "date": "09.06.2026",
            },
            {
                "tour": "atp",
                "tournament": "Lyon ATP 250",
                "date": "09.06.2026",
            },
            {
                "tour": "atp",
                "tournament": "Washington ATP 500",
                "date": "09.06.2026",
            },
        ])
        self.assertEqual(results[0]["event_start_date"], "2026-06-09")
        self.assertEqual(results[0]["event_category"], "challenger")
        self.assertEqual(results[2]["event_category"], "250")
        self.assertEqual(results[3]["event_category"], "500")
        self.assertEqual(tournament_category("WTSL Futures (M25)"), "futures")

    def test_same_day_same_category_events_keep_separate_metadata_groups(self):
        results = enrich_event_metadata([
            {
                "tour": "atp",
                "tournament": "A Challenger",
                "date": "09.06.2026",
            },
            {
                "tour": "atp",
                "tournament": "B Challenger",
                "date": "09.06.2026",
            },
        ])
        self.assertEqual(
            [(item["tournament"], item["event_start_date"], item["event_category"])
             for item in results],
            [
                ("A Challenger", "2026-06-09", "challenger"),
                ("B Challenger", "2026-06-09", "challenger"),
            ],
        )

    def test_truncated_refresh_merges_without_losing_history(self):
        stored = [
            {
                "tournament": "TE4 ATP",
                "round": "R1",
                "p1": f"Player {index}",
                "p2": "Opponent",
                "date": "01.09.2026",
                "result": "6-0 6-0",
            }
            for index in range(100)
        ]
        fresh = [
            {
                "tournament": "TE4 ATP",
                "round": "R1",
                "p1": f"Player {index}",
                "p2": "Opponent",
                "date": "01.09.2026",
                "result": "6-0 6-0",
            }
            for index in range(95, 105)
        ]
        merged, partial = _merge_without_history_loss(fresh, stored)
        self.assertTrue(partial)
        self.assertEqual(len(merged), 105)
        self.assertEqual(merged[:10], fresh)

    def test_partial_refresh_replaces_corrected_event_row(self):
        stored = [{
            "tournament": "Tennis Elbow 4 (ATP Characters) - WTSL Finals 2024",
            "round": "Final",
            "p1": "Dani21",
            "p2": "Katy",
            "date": "18.12.2024",
            "result": "4-6,6-4,6-2",
        }]
        fresh = [{
            **stored[0],
            "tournament": "Tennis Elbow 4 (ATP Characters) - ATP Finals 2024",
            "result": "4-6,6-3,6-2",
        }]

        merged, partial = _merge_without_history_loss(fresh, stored)

        self.assertTrue(partial)
        self.assertEqual(len(merged), 1)
        self.assertEqual(merged[0]["tournament"], "Tennis Elbow 4 (ATP Characters) - ATP Finals 2024")
        self.assertEqual(merged[0]["result"], "4-6,6-3,6-2")

    def test_player_page_rows_are_normalized_for_shared_history(self):
        rows = _player_page_result_rows(
            "Dani21",
            "atp",
            [{
                "tournament": "US Open",
                "round": "Semi-Final",
                "opponent": "Madferit",
                "date": "10.09.2026",
                "result": "0-6,1-6,4-6",
            }],
        )

        self.assertEqual(len(rows), 1)
        self.assertEqual(
            rows[0]["tournament"],
            "Tennis Elbow 4 (ATP Characters) - US Open 2026",
        )
        self.assertEqual(rows[0]["p1"], "Dani21")
        self.assertEqual(rows[0]["p2"], "Madferit")


class WTSLResultsAsyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_allow_stale_does_not_contact_slow_endpoint_without_cache(self):
        missing_cache = MagicMock()
        missing_cache.exists.return_value = False
        with (
            patch("wtsl_results.FULL_CACHE_PATH", missing_cache),
            patch(
                "wtsl_results._load_durable_cache",
                return_value=[],
            ),
            patch(
                "wtsl_results.aiohttp.ClientSession",
                new=AsyncMock(),
            ) as session,
            patch("wtsl_results._memory_results", None),
        ):
            self.assertEqual(await get_all_results(allow_stale=True), [])
        session.assert_not_called()

    async def test_allow_stale_reads_durable_cache_before_refresh_lock(self):
        cached = [{"p1": "Alpha", "p2": "Beta"}]

        class NeverEnterLock:
            async def __aenter__(self):
                raise AssertionError("stale read waited for refresh lock")

            async def __aexit__(self, *_args):
                return False

        missing_cache = MagicMock()
        missing_cache.exists.return_value = False
        with (
            patch("wtsl_results.FULL_CACHE_PATH", missing_cache),
            patch(
                "wtsl_results._load_durable_cache",
                return_value=cached,
            ),
            patch("wtsl_results._save_caches"),
            patch("wtsl_results._memory_results", None),
            patch("wtsl_results._refresh_lock", NeverEnterLock()),
        ):
            result = await get_all_results(allow_stale=True)
        self.assertEqual(result, cached)


if __name__ == "__main__":
    unittest.main()