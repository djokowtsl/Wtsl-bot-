"""Persistent, conservative state helpers for pre-match Discord outreach."""
from __future__ import annotations

import asyncio
import json
import os
import re
import time
import unicodedata
import copy
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from bs4 import BeautifulSoup
from match_preview import normalize_name
from urllib.parse import parse_qs, urljoin, urlparse

STATE_PATH = Path("fixture_outreach_state.json")


def tour_from_tournament_id(tournament_id: Any, default: str = "TE4") -> str:
    """Return the official WTSL tour tag encoded by a tournament ID."""
    value = str(tournament_id or "").strip()
    if re.search(r"_F(?:_|$)", value, flags=re.IGNORECASE):
        return "TE4_(F)"
    return default


def fixture_key(fixture: dict[str, Any]) -> str:
    """Stable key: IDs are preferred because player display names can change."""
    player_ids = sorted(
        (str(fixture.get("first_id", "")).strip(), str(fixture.get("second_id", "")).strip())
    )
    return "|".join(
        [
            str(fixture.get("season", "")).strip(),
            str(fixture.get("tour", "")).strip(),
            str(fixture.get("tournament", "")).strip(),
        ]
        + player_ids
    )


def parse_upcoming_fixtures(html: str, season: str | None = None) -> list[dict[str, Any]]:
    """Parse every official homepage fixture row/card which has odds."""
    result: list[dict[str, Any]] = []
    soup = BeautifulSoup(html, "html.parser")

    # The current WTSL homepage renders open matches as cards in this pane,
    # rather than as table rows. The H2H link is the official odds source.
    fixture_pane = soup.select_one("#wtsl-fixtures-pane-bootstrap")
    if fixture_pane is not None:
        for card in fixture_pane.find_all("div", recursive=False):
            players = []
            for link in card.select('a[href*="player_page.php?player="]'):
                ident = (parse_qs(urlparse(link["href"]).query).get("player") or [""])[0]
                name = link.get_text(" ", strip=True)
                if ident and name:
                    image = link.find("img", src=True)
                    avatar = (
                        urljoin("https://playwtsl.com/TE4/", image["src"])
                        if image is not None else None
                    )
                    players.append((name, ident, avatar))
            tournament_link = card.select_one(
                'a[href*="tournament_page.php?tournament="]'
            )
            odds_link = card.select_one('a[href*="h2h.php"]')
            odds = re.search(
                r"(\d+(?:[.,]\d+)?)\s*/\s*(\d+(?:[.,]\d+)?)",
                odds_link.get_text(" ", strip=True) if odds_link else "",
            )
            if len(players) < 2 or tournament_link is None or odds is None:
                continue
            tournament_query = parse_qs(
                urlparse(tournament_link["href"]).query
            )
            tournament_id = (tournament_query.get("tournament") or [""])[0]
            fixture = {
                "first_name": players[0][0],
                "first_id": players[0][1],
                "first_avatar": players[0][2],
                "second_name": players[1][0],
                "second_id": players[1][1],
                "second_avatar": players[1][2],
                "tournament": tournament_link.get_text(" ", strip=True),
                "tournament_id": tournament_id,
                "tour": tour_from_tournament_id(tournament_id),
                "season": str(season or ""),
                "odds": [float(x.replace(",", ".")) for x in odds.groups()],
                "scheduled_at": None,
            }
            fixture["key"] = fixture_key(fixture)
            if not any(item["key"] == fixture["key"] for item in result):
                result.append(fixture)

    for table in soup.find_all("table"):
        headers = [normalize_name(x.get_text(" ", strip=True)) for x in table.find_all("th")]
        if "match" not in headers:
            continue
        for row in table.find_all("tr"):
            links = row.find_all("a", href=True)
            players = []
            for link in links:
                ident = (parse_qs(urlparse(link["href"]).query).get("player") or [""])[0]
                if ident:
                    players.append((link.get_text(" ", strip=True), ident))
            if len(players) < 2:
                continue
            cells = [cell.get_text(" ", strip=True) for cell in row.find_all("td")]
            odds = re.search(r"(\d+(?:[.,]\d+)?)\s*/\s*(\d+(?:[.,]\d+)?)", " ".join(cells))
            if not odds:
                continue
            fixture = {
                "first_name": players[0][0], "first_id": players[0][1],
                "second_name": players[1][0], "second_id": players[1][1],
                "tournament": cells[0] if cells else "",
                "tour": (
                    tour_from_tournament_id(
                        next(
                            (
                                (parse_qs(urlparse(link["href"]).query).get("tournament") or [""])[0]
                                for link in links
                                if "tournament_page.php" in link.get("href", "")
                            ),
                            "",
                        )
                    )
                    if any("tournament_page.php" in link.get("href", "") for link in links)
                    else (cells[1] if len(cells) > 1 else "")
                ),
                "season": str(season or ""),
                "odds": [float(x.replace(",", ".")) for x in odds.groups()],
            }
            row_text = " ".join(cells)
            scheduled = None
            for pattern, formats in (
                (
                    r"\b(20\d{2}[-/]\d{1,2}[-/]\d{1,2}"
                    r"(?:\s+\d{1,2}:\d{2})?)\b",
                    ("%Y-%m-%d %H:%M", "%Y/%m/%d %H:%M", "%Y-%m-%d", "%Y/%m/%d"),
                ),
                (
                    r"\b(\d{1,2}[./]\d{1,2}[./]20\d{2}"
                    r"(?:\s+\d{1,2}:\d{2})?)\b",
                    ("%d.%m.%Y %H:%M", "%d/%m/%Y %H:%M", "%d.%m.%Y", "%d/%m/%Y"),
                ),
            ):
                match = re.search(pattern, row_text)
                if not match:
                    continue
                for date_format in formats:
                    try:
                        scheduled = datetime.strptime(
                            match.group(1), date_format
                        ).isoformat()
                        break
                    except ValueError:
                        continue
                if scheduled:
                    break
            fixture["scheduled_at"] = scheduled
            fixture["key"] = fixture_key(fixture)
            result.append(fixture)
    return result


def parse_scheduled_tournament_fixtures(
    html: str,
    tournament_id: str,
    tournament_name: str,
    season: str | None = None,
    tour: str | None = None,
) -> list[dict[str, Any]]:
    """Parse scheduled matches listed on an ongoing tournament page."""
    tour = tour or tour_from_tournament_id(tournament_id)
    soup = BeautifulSoup(html, "html.parser")
    result: list[dict[str, Any]] = []
    for table in soup.find_all("table"):
        headers = [
            normalize_name(cell.get_text(" ", strip=True))
            for cell in table.find_all("th")
        ]
        if not {"date", "round", "winner", "opponent", "result"}.issubset(headers):
            continue
        header_index = {header: index for index, header in enumerate(headers)}
        for row in table.select("tbody tr"):
            cells = row.find_all("td")
            values = [cell.get_text(" ", strip=True) for cell in cells]
            result_value = values[header_index["result"]] if (
                header_index["result"] < len(values)
            ) else ""
            if "scheduled" not in result_value.casefold():
                continue
            players = []
            for field in ("winner", "opponent"):
                index = header_index[field]
                cell = cells[index] if index < len(cells) else None
                link = cell.find("a", href=True) if cell else None
                if link is None:
                    players = []
                    break
                player_id = (
                    parse_qs(urlparse(link["href"]).query).get("player") or [""]
                )[0]
                player_name = link.get_text(" ", strip=True)
                if not player_id or not player_name:
                    players = []
                    break
                image = link.find("img", src=True)
                avatar = (
                    urljoin("https://playwtsl.com/TE4/", image["src"])
                    if image is not None else None
                )
                players.append((player_name, player_id, avatar))
            if len(players) != 2:
                continue
            round_name = values[header_index["round"]] if (
                header_index["round"] < len(values)
            ) else ""
            display_round = {
                "quarter-final": "QF",
                "semi-final": "SF",
                "final": "F",
            }.get(round_name.casefold(), round_name)
            display_round = re.sub(
                r"^round of (\d+)$",
                r"R\1",
                display_round,
                flags=re.IGNORECASE,
            )
            tournament_label = (
                f"{tournament_name} ({display_round})"
                if display_round else tournament_name
            )
            date_value = values[header_index["date"]] if (
                header_index["date"] < len(values)
            ) else ""
            scheduled_at = None
            for date_format in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
                try:
                    scheduled_at = datetime.strptime(
                        date_value, date_format
                    ).isoformat()
                    break
                except ValueError:
                    continue
            fixture = {
                "first_name": players[0][0],
                "first_id": players[0][1],
                "first_avatar": players[0][2],
                "second_name": players[1][0],
                "second_id": players[1][1],
                "second_avatar": players[1][2],
                "tournament": tournament_label,
                "tournament_id": tournament_id,
                "round": round_name,
                "tour": tour,
                "season": str(season or ""),
                "odds": None,
                "scheduled_at": scheduled_at,
                "betting_enabled": False,
            }
            fixture["key"] = fixture_key(fixture)
            if not any(item["key"] == fixture["key"] for item in result):
                result.append(fixture)
    return result


def parse_reported_tournament_results(
    html: str,
    tournament_name: str,
    tour: str | None = None,
) -> list[dict[str, Any]]:
    """Parse played results from an official WTSL tournament page."""
    soup = BeautifulSoup(html, "html.parser")
    parsed: list[dict[str, Any]] = []
    for table in soup.find_all("table"):
        headers = [
            normalize_name(cell.get_text(" ", strip=True))
            for cell in table.find_all("th")
        ]
        required = {"date", "round", "winner", "opponent", "result"}
        if not required.issubset(headers):
            continue
        header_index = {header: index for index, header in enumerate(headers)}
        for row in table.select("tbody tr"):
            cells = row.find_all("td")
            values = [cell.get_text(" ", strip=True) for cell in cells]
            if len(values) < len(headers):
                continue
            winner = values[header_index["winner"]]
            opponent = values[header_index["opponent"]]
            result = values[header_index["result"]]
            if not winner or not opponent or not result:
                continue
            parsed.append({
                "tournament": tournament_name,
                "round": values[header_index["round"]],
                "p1": winner,
                "p2": opponent,
                "player1": winner,
                "player2": opponent,
                "date": values[header_index["date"]],
                "result": result,
                "tour": tour or "",
            })
        if parsed:
            break
    return parsed


def parse_official_player_avatar(html: str, player_name: str | None = None) -> str | None:
    """Return the official avatar URL from a WTSL player page."""
    soup = BeautifulSoup(html, "html.parser")
    normalized_player = normalize_name(player_name or "")
    candidates = []
    for image in soup.find_all("img", src=True):
        source = str(image.get("src") or "")
        if "/avatars/" not in source.casefold():
            continue
        alt = normalize_name(image.get("alt") or "")
        candidates.append((alt == normalized_player and bool(normalized_player), source))
    if not candidates:
        return None
    _, source = max(candidates, key=lambda item: item[0])
    return urljoin("https://playwtsl.com/TE4/", source)


def parse_h2h_percentage_odds(
    html: str,
    *,
    first_id: str,
    second_id: str,
) -> list[float] | None:
    """Convert the H2H win bar percentage into fair decimal odds."""
    soup = BeautifulSoup(html, "html.parser")
    percentages: list[float] = []
    for fill in soup.select(".h2h-winfill"):
        candidates = [
            fill.get_text(" ", strip=True),
            str(fill.get("style") or ""),
        ]
        match = next(
            (
                re.search(r"(?<!\d)(\d{1,3}(?:[.,]\d+)?)\s*%", candidate)
                for candidate in candidates
                if re.search(r"(?<!\d)(\d{1,3}(?:[.,]\d+)?)\s*%", candidate)
            ),
            None,
        )
        if match:
            percentages.append(float(match.group(1).replace(",", ".")))
    if not percentages:
        return None
    first_probability = percentages[0]
    second_probability = (
        percentages[1] if len(percentages) > 1 else 100.0 - first_probability
    )
    if (
        first_probability <= 0
        or second_probability <= 0
        or first_probability > 100
        or second_probability > 100
    ):
        return None
    return [
        round(100.0 / first_probability, 3),
        round(100.0 / second_probability, 3),
    ]


def _normalize_discord_name(value: Any) -> str:
    """Ignore case, accents, whitespace, and emoji before exact comparison."""
    without_emoji = "".join(
        character
        for character in str(value or "")
        if character not in {"\u200d", "\ufe0f"}
        and unicodedata.category(character) not in {"So", "Sk"}
    )
    without_accents = "".join(
        character
        for character in unicodedata.normalize("NFKD", without_emoji)
        if unicodedata.category(character) != "Mn"
    )
    return normalize_name(without_accents)


def _discord_name_aliases(value: Any) -> set[str]:
    """Return exact aliases explicitly separated by 'aka' in a Discord name."""
    normalized = _normalize_discord_name(value)
    if not normalized:
        return set()
    aliases = {normalized}
    aliases.update(
        alias.strip()
        for alias in re.split(r"\baka\b", normalized)
        if alias.strip()
    )
    return aliases


def resolve_member_exact(members: list[Any], player_name: str) -> Any | None:
    """Return one exact display, username, global-name, or explicit aka match."""
    wanted = _normalize_discord_name(player_name)
    matches = [
        member for member in members
        if wanted and wanted in set().union(*(
            _discord_name_aliases(getattr(member, attribute, ""))
            for attribute in ("display_name", "name", "global_name")
        ))
    ]
    return matches[0] if len(matches) == 1 else None


class OutreachState:
    """Atomic outreach state backed by PostgreSQL in production or a test file."""
    def __init__(
        self,
        path: Path = STATE_PATH,
        *,
        load_backend: Callable[[], dict[str, Any] | None] | None = None,
        save_backend: Callable[[dict[str, Any]], None] | None = None,
    ):
        self.path = Path(path)
        self.load_backend = load_backend
        self.save_backend = save_backend
        self.lock = asyncio.Lock()
        self.data: dict[str, Any] = {"fixtures": {}}

    async def load(self, *, now: float | None = None, lease_seconds: float = 900) -> None:
        async with self.lock:
            stored = (
                await asyncio.to_thread(self.load_backend)
                if self.load_backend else None
            )
            if stored is not None:
                self.data = copy.deepcopy(stored)
            else:
                try:
                    self.data = json.loads(self.path.read_text(encoding="utf8"))
                except FileNotFoundError:
                    self.data = {"fixtures": {}}
                except (json.JSONDecodeError, OSError) as exc:
                    raise RuntimeError(
                        f"cannot load outreach state: {exc}"
                    ) from exc
                if self.load_backend:
                    await self.save()
            self.data.setdefault("fixtures", {})
            current = time.time() if now is None else now
            changed = False
            for item in self.data["fixtures"].values():
                if (
                    item.get("publish_status") == "publishing"
                    and current - float(item.get("claimed_at", 0)) >= lease_seconds
                ):
                    item["publish_status"] = "pending"
                    changed = True
            if changed:
                await self.save()

    async def save(self) -> None:
        if self.save_backend:
            await asyncio.to_thread(
                self.save_backend, copy.deepcopy(self.data)
            )
            return
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(json.dumps(self.data, indent=2, sort_keys=True), encoding="utf8")
        os.replace(temp, self.path)

    async def ensure(self, key: str, fixture: dict[str, Any]) -> dict[str, Any]:
        async with self.lock:
            item = self.data["fixtures"].setdefault(key, {
                "fixture": fixture, "prompts": {}, "published": False,
                "publish_status": "pending",
            })
            await self.save()
            return item

    async def claim_publish(
        self, key: str, *, now: float | None = None, lease_seconds: float = 900
    ) -> bool:
        """Atomically reserve a pending fixture for exactly one publisher."""
        async with self.lock:
            item = self.data["fixtures"][key]
            current = time.time() if now is None else now
            fresh_claim = (
                item.get("publish_status") == "publishing"
                and current - float(item.get("claimed_at", 0)) < lease_seconds
            )
            if item.get("published") or fresh_claim:
                return False
            item["publish_status"] = "publishing"
            item["claimed_at"] = current
            await self.save()
            return True

    async def release_publish(self, key: str) -> None:
        async with self.lock:
            item = self.data["fixtures"][key]
            if not item.get("published"):
                item["publish_status"] = "pending"
                await self.save()

    async def update(self, key: str, **values: Any) -> dict[str, Any]:
        async with self.lock:
            item = self.data["fixtures"][key]
            item.update(values)
            await self.save()
            return item

    async def remove(self, key: str) -> bool:
        async with self.lock:
            removed = self.data["fixtures"].pop(key, None) is not None
            if removed:
                await self.save()
            return removed