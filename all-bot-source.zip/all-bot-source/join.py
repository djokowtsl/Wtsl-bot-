'''import discord
import os
class MyClient(discord.Client):
  async def startup(self):
    pass
class MyClient(discord.Client):
   async def on_ready(self):
        print('Logged in as')
        print(self.user.name)
        print(self.user.id)
        print('------')
        print(f'{self.user} succesfully logged in!')
        #print('bot has started')
        djokorer = await self.fetch_user(859691230941282304)
        await djokorer.send('bot has started')

  
    
async def on_member_join(self, member):
  arrival_channel = client2.get_channel(953651276296634369) #join-logs channel
        #print(member.name+" Joined")
  await arrival_channel.send(member.mention+ "Website: http://wtetour.com Please type **dc.verify** into this channel to complete the verification process.**You will receive a private message from the Double Counter bot, after typing this message into the channel, asking to verify your account. You must complete the verification before an admin can assign you a role.** Please wait to be assigned a role, an admin (#admins) will contact you or assign you a role shortly or you can private message one of them asking to be assigned a role.")

intents = discord.Intents.default()
intents.members = True

client2 = MyClient(intents=intents)
#client2.run(os.getenv('TOKEN'))
try:
  client2.run(os.getenv('TOKEN'))
except Exception as e:
  print(f"An error occurred: {e}")'''