Complete Bot Source Export
==========================

Contains all active Python bot modules and Python tests, the SQL schema, and
safe dependency/deployment manifests. The active entry point is main.py; the
package also includes the bot's stats, betting, predictions, rankings, fixture,
moderation, reminders, deployment, and integration modules.

Included source/test files: 43 (.py/.sql)
Included manifests: requirements.txt, pyproject.toml, railway.toml

Intentionally excluded: .replit (contains hard-coded credentials), environment
files, secrets, backup copies of main.py, databases, JSON state/caches, CSV/XLS
workbooks, screenshots, logs, attached assets, package caches, and generated
exports. The project should use Replit Secrets/environment configuration for
credentials; this archive does not contain those values.
