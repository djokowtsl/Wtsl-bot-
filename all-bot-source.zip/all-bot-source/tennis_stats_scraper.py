"""Vision extraction and workbook persistence for TE4 Discord result screenshots."""

from __future__ import annotations

import base64
import csv
from copy import copy
import difflib
import json
import math
import os
import re
import shutil
import unicodedata
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any
from xml.etree import ElementTree

import aiohttp
from bs4 import BeautifulSoup
from ai_budget import BudgetedAsyncOpenAI as AsyncOpenAI
from openpyxl import load_workbook
from openpyxl.formula.translate import Translator
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import TableColumn
from overall_ratings import (
    OVERALL_RATING_COLUMNS,
    calculate_partial_overall_ratings,
    calculate_relative_profiles,
)

MASTER_WORKBOOK = Path(
    "attached_assets/TE4_HUB_3008_FINAL_cleaned_match_summaries_1788038050097.xlsx"
)
PROCESSED_FILE = Path("stats_scraped_messages.json")
MODEL = "gpt-5-mini"
VISION_MAX_COMPLETION_TOKENS = 10000
REFERENCE_WORKBOOK = MASTER_WORKBOOK
REQUIRED_WORKBOOK_SHEETS = ("atp", "wta", "ATP Summary", "WTA Summary")
from wtsl_results import (
    find_confident_official_match,
    result_score_equivalence_key,
)

def export_atp_columns_csv(output_path: Path) -> int:
    """Export legacy ATP columns A through AH and AK, plus character fields."""
    workbook = load_workbook(MASTER_WORKBOOK, read_only=True, data_only=True)
    try:
        sheet = workbook["atp"]
        # Keep the established positional export intact.  Character columns are
        # deliberately located by header, since newer workbooks may place them
        # outside A:AH while old workbooks do not have them at all.
        headers = {
            str(cell.value).strip(): cell.column
            for cell in sheet[1]
            if cell.value not in (None, "")
        }
        # The established export is A:AH followed by the match key.  Look up
        # that key by its header rather than treating an incidental position as
        # data; normal source sheets keep it in AK.
        match_key_column = headers.get(MATCH_KEY_HEADER, MATCH_KEY_COLUMN)
        selected_columns = list(range(1, 35))
        if match_key_column not in selected_columns:
            selected_columns.append(match_key_column)
        for header in ("Character", "Opponent Character"):
            column = headers.get(header)
            if column is not None and column not in selected_columns:
                selected_columns.append(column)
        rows_written = 0
        with output_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(
                [sheet.cell(1, column).value for column in selected_columns]
            )
            for row in sheet.iter_rows(min_row=2, max_col=max(selected_columns)):
                values = [row[column - 1].value for column in selected_columns]
                if not any(value is not None and str(value) != "" for value in values):
                    continue
                writer.writerow(values)
                rows_written += 1
        return rows_written
    finally:
        workbook.close()

SINGLES_COLUMNS = [
    "Image Name", "Player", "ELO", "Crc", "Result", "Opponent", "Opponent ELO",
    "Opponent Crc", "Tournament", "Date", "1st Serve %", "Aces",
    "Double Faults", "Fastest Serve", "Avg 1st Serve Speed",
    "Avg 2nd Serve Speed", "Winners", "Forced Errors", "Unforced Errors",
    "Net Points Won %", "Break Points Won %", "Total Points Won",
    "Short Rallies Won (<5) %", "Medium Rallies Won (5-8) %",
    "Long Rallies Won (>8) %", "Average Rally Length", "Set Points Saved",
    "Match Points Saved", "1st Serve Won %", "2nd Serve Won %",
    "Return Points Won %", "Return Winners", "Breaks / Games %", "Notes",
]

SYSTEM_PROMPT = """You extract structured tennis match statistics from one or more
screenshots of the SAME match. Screens may be Match Statistics, Match Summary,
Resume du Match, United Cup, Davis Cup, Billie Jean King Cup, or a text-log
layout, in English/French/Spanish/Polish.

Rules:
- Never invent a value. Use null for anything not visible.
- Support singles and doubles. Set is_doubles=true if either side is a team.
- For doubles, return each side as one name joined exactly with " & ", preserving
  both screenshot player names and their left-to-right order.
- Return stadium exactly as visibly written. A stadium or court name may contain
  an unrelated ATP/WTA label, so never infer tour_hint from stadium text. Set
  tour_hint to "wta" only when the competition/header visibly says
  WTA/women/female, "atp" only when it visibly says ATP/men/male, otherwise
  null.
- Determine the winner from an explicit winner label, sets won, or (last resort)
  total points. Return result from the winner's perspective.
- Percentages must be decimals from 0 to 1. Counts remain integers.
- Convert every mph serve speed to km/h using mph * 1.60934, rounded to the
  nearest integer, and mention the original mph value in that player's note.
- Forehand + backhand winners may be summed only when the screen presents those
  as the winner components. Break Point Conversions maps to breaks_games_pct.
- Sparse game screens do not show tracker-scale ELO/Crc. Leave elo/crc null and
  put any visibly different in-game ELO in note.
- Preserve uncertainty in notes and warnings.
- Message context may clarify tournament/date/score, but screenshot values take
  priority. Names must be read from the screenshots.

Return ONLY one JSON object with this exact structure:
{
 "is_doubles": false, "tour_hint": null, "stadium": null,
 "tournament": null, "date": null, "result": null,
 "player": {
  "name": "", "elo": null, "crc": null, "first_serve_pct": null,
  "aces": null, "double_faults": null, "fastest_serve_kmh": null,
  "avg_1st_serve_speed_kmh": null, "avg_2nd_serve_speed_kmh": null,
  "winners": null, "forced_errors": null, "unforced_errors": null,
  "net_points_won_pct": null, "break_points_won_pct": null,
  "total_points_won": null, "short_rallies_won_pct": null,
  "medium_rallies_won_pct": null, "long_rallies_won_pct": null,
  "average_rally_length": null, "set_points_saved": null,
  "match_points_saved": null, "first_serve_won_pct": null,
  "second_serve_won_pct": null, "return_points_won_pct": null,
  "return_winners": null, "breaks_games_pct": null, "note": null
 },
 "opponent": { "name": "", "elo": null, "crc": null,
  "first_serve_pct": null, "aces": null, "double_faults": null,
  "fastest_serve_kmh": null, "avg_1st_serve_speed_kmh": null,
  "avg_2nd_serve_speed_kmh": null, "winners": null, "forced_errors": null,
  "unforced_errors": null, "net_points_won_pct": null,
  "break_points_won_pct": null, "total_points_won": null,
  "short_rallies_won_pct": null, "medium_rallies_won_pct": null,
  "long_rallies_won_pct": null, "average_rally_length": null,
  "set_points_saved": null, "match_points_saved": null,
  "first_serve_won_pct": null, "second_serve_won_pct": null,
  "return_points_won_pct": null, "return_winners": null,
  "breaks_games_pct": null, "note": null },
 "warnings": []
}"""


def normalize_name(value: str) -> str:
    value = unicodedata.normalize("NFKC", value or "")
    return re.sub(r"\s+", " ", value).strip().casefold()


def load_historical_workbook_names() -> dict[str, dict[str, str]]:
    """Load trusted Player/Opponent spellings from the supplied ATP/WTA sheets."""
    result: dict[str, dict[str, str]] = {"atp": {}, "wta": {}}
    if not REFERENCE_WORKBOOK.exists():
        return result
    namespace = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    try:
        with zipfile.ZipFile(REFERENCE_WORKBOOK) as archive:
            shared: list[str] = []
            if "xl/sharedStrings.xml" in archive.namelist():
                root = ElementTree.fromstring(archive.read("xl/sharedStrings.xml"))
                shared = [
                    "".join(node.text or "" for node in item.findall(".//m:t", namespace))
                    for item in root.findall("m:si", namespace)
                ]
            for sheet, number in (("atp", 1), ("wta", 2)):
                root = ElementTree.fromstring(
                    archive.read(f"xl/worksheets/sheet{number}.xml")
                )
                for cell in root.findall(".//m:c", namespace):
                    reference = cell.get("r", "")
                    column = re.match(r"[A-Z]+", reference)
                    if not column or column.group() not in {"C", "G"}:
                        continue
                    if cell.get("t") == "s":
                        value_node = cell.find("m:v", namespace)
                        value = shared[int(value_node.text)] if value_node is not None else ""
                    else:
                        value = "".join(
                            node.text or "" for node in cell.findall(".//m:t", namespace)
                        )
                    value = value.strip()
                    if value and value.casefold() not in {"player", "opponent"}:
                        result[sheet].setdefault(normalize_name(value), value)
    except (OSError, KeyError, ValueError, zipfile.BadZipFile, ElementTree.ParseError):
        return {"atp": {}, "wta": {}}
    return result


async def fetch_canonical_rankings() -> dict[str, dict[str, str]]:
    """Return live names plus trusted historical names from the supplied tracker."""
    tours = {"atp": "TE4", "wta": "TE4_(F)"}
    result: dict[str, dict[str, str]] = {}
    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        for sheet, tour in tours.items():
            url = f"https://www.playwtsl.com/TE4/pages/rankings_fetch_list.php?tour={tour}"
            async with session.get(url) as response:
                response.raise_for_status()
                soup = BeautifulSoup(await response.text(), "html.parser")
            names: dict[str, str] = {}
            rank_table = soup.find("table", id="rankTable")
            if rank_table is None:
                raise RuntimeError(f"Rankings table not found for {sheet.upper()}")
            for row in rank_table.find_all("tr"):
                cells = row.find_all("td")
                if len(cells) < 3:
                    continue
                link = cells[2].find("a")
                if not link:
                    continue
                canonical = link.get_text(" ", strip=True)
                if canonical:
                    names.setdefault(normalize_name(canonical), canonical)
            if not names:
                raise RuntimeError(f"No canonical names found for {sheet.upper()}")
            result[sheet] = names
    historical = load_historical_workbook_names()
    for sheet, names in historical.items():
        for normalized, canonical in names.items():
            result[sheet].setdefault(normalized, canonical)
    return result


async def extract_match(
    images: list[tuple[str, str, bytes]],
    message_context: str,
    base_url: str,
    api_key: str,
) -> dict[str, Any]:
    if not images:
        raise ValueError("No supported image attachments")
    content: list[dict[str, Any]] = [{
        "type": "text",
        "text": (
            f"Extract this match. Discord result context: {message_context[:1000]!r}. "
            f"There are {len(images)} screenshots from the same result post."
        ),
    }]
    for _, media_type, raw in images:
        encoded = base64.b64encode(raw).decode("ascii")
        content.append({
            "type": "image_url",
            "image_url": {"url": f"data:{media_type};base64,{encoded}", "detail": "high"},
        })

    client = AsyncOpenAI(base_url=base_url, api_key=api_key, timeout=90.0, max_retries=2)
    response = await client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": content},
        ],
        response_format={"type": "json_object"},
        # GPT-5 reasoning tokens share this completion budget with the JSON
        # payload. Vision extraction needs room to inspect several screenshots
        # before emitting the structured result.
        max_completion_tokens=VISION_MAX_COMPLETION_TOKENS,
    )
    choice = response.choices[0] if response.choices else None
    message = getattr(choice, "message", None)
    raw = getattr(message, "content", "") if message else ""
    if not raw:
        finish_reason = getattr(choice, "finish_reason", None)
        refusal = getattr(message, "refusal", None) if message else None
        detail = f"finish_reason={finish_reason!r}"
        if refusal:
            detail += f", refusal={str(refusal)[:300]!r}"
        raise RuntimeError(f"Vision model returned no content ({detail})")
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.I)
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Vision model returned invalid JSON: {exc}") from exc


def _team_parts(value: str) -> list[str]:
    """Split the model's canonical doubles separator without splitting ordinary names."""
    parts = [part.strip() for part in re.split(r"\s*&\s*", value) if part.strip()]
    return parts or [value.strip()]


def _resolve_observed_name(
    observed: str,
    rankings: dict[str, dict[str, str]],
) -> dict[str, Any]:
    observed = _canonicalize_name_alias(observed)
    normalized = normalize_name(observed)
    scores = {
        sheet: max(
            (
                difflib.SequenceMatcher(None, normalized, candidate).ratio()
                for candidate in names
            ),
            default=0.0,
        )
        for sheet, names in rankings.items()
    }
    exact_sheets = {
        sheet for sheet, names in rankings.items() if normalized in names
    }
    if exact_sheets:
        # ATP wins a spelling tie; the match-level classifier separately decides tour.
        canonical_sheet = "atp" if "atp" in exact_sheets else sorted(exact_sheets)[0]
        return {
            "name": rankings[canonical_sheet][normalized],
            "exact_sheets": exact_sheets,
            "scores": scores,
            "resolution": "exact",
        }

    candidates = sorted(
        (
            (score, sheet, canonical)
            for sheet, names in rankings.items()
            for candidate, canonical in names.items()
            for score in [difflib.SequenceMatcher(None, normalized, candidate).ratio()]
        ),
        reverse=True,
    )
    best = candidates[0] if candidates else (0.0, None, observed)
    second_score = candidates[1][0] if len(candidates) > 1 else 0.0
    if best[0] >= 0.78 and best[0] - second_score >= 0.035:
        return {
            "name": best[2],
            "exact_sheets": set(),
            "scores": scores,
            "resolution": "fuzzy",
        }
    return {
        "name": observed,
        "exact_sheets": set(),
        "scores": scores,
        "resolution": "unmatched",
    }


def canonicalize_match(
    extracted: dict[str, Any],
    rankings: dict[str, dict[str, str]],
) -> tuple[str, dict[str, Any]]:
    player = extracted.get("player") or {}
    opponent = extracted.get("opponent") or {}
    observed_sides = [
        str(player.get("name", "")).strip(),
        str(opponent.get("name", "")).strip(),
    ]
    if not all(normalize_name(name) for name in observed_sides):
        raise ValueError("Could not read both player/team names from the screenshot")

    is_doubles = bool(
        extracted.get("is_doubles")
        or any("&" in name for name in observed_sides)
    )
    extracted["is_doubles"] = is_doubles
    all_resolutions: list[dict[str, Any]] = []
    observed_parts_by_side = [
        _team_parts(name) if is_doubles else [name]
        for name in observed_sides
    ]
    has_wta_alias = any(
        normalize_name(part) in WTA_SCREENSHOT_NAME_ALIASES
        for parts in observed_parts_by_side
        for part in parts
    )
    resolutions_by_side = []

    for parts in observed_parts_by_side:
        resolved_parts = [
            _resolve_observed_name(part, rankings) for part in parts
        ]
        all_resolutions.extend(resolved_parts)
        resolutions_by_side.append(resolved_parts)

    # Explicit competition/header evidence takes priority. Stadium and court
    # labels are deliberately excluded: a venue can be named after the
    # opposite tour and must not override the player/ranking evidence.
    hint_text = str(extracted.get("tour_hint") or "")
    explicit_wta = bool(
        re.search(r"\b(?:wta|women|woman|female)\b", hint_text, re.I)
    )
    explicit_atp = bool(
        re.search(r"\b(?:atp|men|male)\b", hint_text, re.I)
    )
    if explicit_wta:
        sheet = "wta"
    elif explicit_atp:
        sheet = "atp"
    elif has_wta_alias:
        sheet = "wta"
    else:
        exact_counts = {
            tour: sum(tour in item["exact_sheets"] for item in all_resolutions)
            for tour in ("atp", "wta")
        }
        score_totals = {
            tour: sum(item["scores"].get(tour, 0.0) for item in all_resolutions)
            for tour in ("atp", "wta")
        }
        clear_wta_fuzzy = (
            score_totals["wta"] > score_totals["atp"] + 0.08
            and any(item["scores"].get("wta", 0.0) >= 0.78 for item in all_resolutions)
        )
        sheet = (
            "wta"
            if exact_counts["wta"] > exact_counts["atp"] or (
                exact_counts["wta"] == exact_counts["atp"] == 0 and clear_wta_fuzzy
            )
            else "atp"
        )

    for side, observed_parts, resolved_parts in zip(
        (player, opponent), observed_parts_by_side, resolutions_by_side
    ):
        canonical_names = []
        for observed, resolution in zip(observed_parts, resolved_parts):
            alias_target = (
                WTA_SCREENSHOT_NAME_ALIASES.get(normalize_name(observed))
                if sheet == "wta"
                else None
            )
            if alias_target:
                alias_key = normalize_name(alias_target)
                alias_target = rankings.get("wta", {}).get(alias_key, alias_target)
                resolution["name"] = alias_target
                resolution["resolution"] = "wta_alias"
            canonical_names.append(resolution["name"])
        side["name"] = " & ".join(canonical_names)

        name_resolutions = {item["resolution"] for item in resolved_parts}
        extra_note = ""
        if "unmatched" in name_resolutions:
            extra_note = "Name not found in rankings; screenshot spelling retained"
        elif "fuzzy" in name_resolutions:
            extra_note = "Name canonicalized by close ranking/history match"
        if extra_note:
            side["note"] = "; ".join(
                value for value in (str(side.get("note") or ""), extra_note) if value
            )

    extracted["player"], extracted["opponent"] = player, opponent
    return sheet, extracted


def validate_extracted(extracted: dict[str, Any]) -> dict[str, Any]:
    """Coerce safe numeric strings and reject malformed model output."""
    if not isinstance(extracted, dict):
        raise ValueError("Vision response is not an object")
    for side_name in ("player", "opponent"):
        side = extracted.get(side_name)
        if not isinstance(side, dict):
            raise ValueError(f"Vision response has no {side_name} object")

        integer_fields = (
            "elo", "crc", "aces", "double_faults", "fastest_serve_kmh",
            "avg_1st_serve_speed_kmh", "avg_2nd_serve_speed_kmh", "winners",
            "forced_errors", "unforced_errors", "total_points_won",
            "set_points_saved", "match_points_saved", "return_winners",
        )
        decimal_fields = ("average_rally_length",)
        percentage_fields = (
            "first_serve_pct", "net_points_won_pct", "break_points_won_pct",
            "short_rallies_won_pct", "medium_rallies_won_pct",
            "long_rallies_won_pct", "first_serve_won_pct",
            "second_serve_won_pct", "return_points_won_pct", "breaks_games_pct",
        )

        def finite_number(value: Any, field: str) -> float:
            if isinstance(value, bool):
                raise ValueError(f"{side_name}.{field} cannot be boolean")
            try:
                number = float(value)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"{side_name}.{field} is not numeric") from exc
            if not math.isfinite(number):
                raise ValueError(f"{side_name}.{field} must be finite")
            return number

        for field in integer_fields:
            value = side.get(field)
            if value in (None, ""):
                side[field] = None
                continue
            number = finite_number(value, field)
            if number < 0 or not number.is_integer():
                raise ValueError(f"{side_name}.{field} must be a non-negative integer")
            side[field] = int(number)
        for field in decimal_fields:
            value = side.get(field)
            if value in (None, ""):
                side[field] = None
                continue
            number = finite_number(value, field)
            if number < 0:
                raise ValueError(f"{side_name}.{field} must be non-negative")
            side[field] = number
        for field in percentage_fields:
            value = side.get(field)
            if value in (None, ""):
                side[field] = None
                continue
            number = finite_number(value, field)
            if not 0 <= number <= 1:
                raise ValueError(f"{side_name}.{field} must be between 0 and 1")
            side[field] = number

    if not str(extracted.get("result") or "").strip():
        raise ValueError("No match score/result was found")
    if not str(extracted.get("tournament") or "").strip():
        raise ValueError("No tournament name was found")
    try:
        date.fromisoformat(str(extracted.get("date") or ""))
    except ValueError as exc:
        raise ValueError("Match date must be YYYY-MM-DD") from exc
    warnings = extracted.get("warnings")
    if warnings is not None and not isinstance(warnings, list):
        raise ValueError("Warnings must be a list")
    return extracted


def _value(value: Any) -> Any:
    return None if value in (None, "") else value


def build_rows(
    extracted: dict[str, Any],
    sheet: str,
    image_names: list[str],
    *,
    player_character: str | None = None,
    opponent_character: str | None = None,
    character: str | None = None,
) -> list[dict[str, Any]]:
    """Build both players' raw rows, including optional character selections.

    ``character`` is retained as a concise alias for ``player_character`` for
    callers that collect the submitting player's pick under that name.
    """
    if player_character is None:
        player_character = character
    player = extracted.get("player") or {}
    opponent = extracted.get("opponent") or {}
    result = extracted.get("result") or ""
    warnings = "; ".join(str(w) for w in (extracted.get("warnings") or []))

    def row(
        side: dict[str, Any],
        other: dict[str, Any],
        character: str | None,
        other_character: str | None,
        oriented_result: str,
    ) -> dict[str, Any]:
        notes = "; ".join(x for x in [str(side.get("note") or ""), warnings] if x)
        values = {
            "Sheet": sheet,
            "Image Name": " + ".join(image_names),
            "Player": side.get("name") or "",
            "Character": _value(character),
            "ELO": _value(side.get("elo")),
            "Crc": _value(side.get("crc")),
            "Result": oriented_result,
            "Opponent": other.get("name") or "",
            "Opponent Character": _value(other_character),
            "Opponent ELO": _value(other.get("elo")),
            "Opponent Crc": _value(other.get("crc")),
            "Tournament": extracted.get("tournament") or "",
            "Date": extracted.get("date") or "",
            "1st Serve %": _value(side.get("first_serve_pct")),
            "Aces": _value(side.get("aces")),
            "Double Faults": _value(side.get("double_faults")),
            "Fastest Serve": _value(side.get("fastest_serve_kmh")),
            "Avg 1st Serve Speed": _value(side.get("avg_1st_serve_speed_kmh")),
            "Avg 2nd Serve Speed": _value(side.get("avg_2nd_serve_speed_kmh")),
            "Winners": _value(side.get("winners")),
            "Forced Errors": _value(side.get("forced_errors")),
            "Unforced Errors": _value(side.get("unforced_errors")),
            "Net Points Won %": _value(side.get("net_points_won_pct")),
            "Break Points Won %": _value(side.get("break_points_won_pct")),
            "Total Points Won": _value(side.get("total_points_won")),
            "Short Rallies Won (<5) %": _value(side.get("short_rallies_won_pct")),
            "Medium Rallies Won (5-8) %": _value(side.get("medium_rallies_won_pct")),
            "Long Rallies Won (>8) %": _value(side.get("long_rallies_won_pct")),
            "Average Rally Length": _value(side.get("average_rally_length")),
            "Set Points Saved": _value(side.get("set_points_saved")),
            "Match Points Saved": _value(side.get("match_points_saved")),
            "1st Serve Won %": _value(side.get("first_serve_won_pct")),
            "2nd Serve Won %": _value(side.get("second_serve_won_pct")),
            "Return Points Won %": _value(side.get("return_points_won_pct")),
            "Return Winners": _value(side.get("return_winners")),
            "Breaks / Games %": _value(side.get("breaks_games_pct")),
            "Notes": notes,
        }
        values.update(_derived_row_metrics(values, {
            "1st Serve Won %": _value(other.get("first_serve_won_pct")),
            "2nd Serve Won %": _value(other.get("second_serve_won_pct")),
            "Break Points Won %": _value(other.get("break_points_won_pct")),
        }))
        return values
    return [
        row(player, opponent, player_character, opponent_character, result),
        row(opponent, player, opponent_character, player_character, _reverse_result(result)),
    ]


def _last_data_row(worksheet: Any, image_column: int) -> int:
    for row_number in range(worksheet.max_row, 1, -1):
        if worksheet.cell(row_number, image_column).value not in (None, ""):
            return row_number
    return 1


DERIVED_SUMMARY_METRICS = (
    "1st Serve Return Points Won %",
    "2nd Serve Return Points Won %",
    "Break Points Saved %",
    "Tie-breaks Won %",
    "Deciding Sets Won %",
)
SUMMARY_METRICS = (*SINGLES_COLUMNS[10:33], *DERIVED_SUMMARY_METRICS)
MATCH_KEY_HEADER = "Unique ID B"
MATCH_KEY_COLUMN = 37  # AK in both tour sheets
REVIEW_STATUS_HEADER = "Review Status"
REVIEW_REASON_HEADER = "Review Reason"
SUMMARY_MATCH_COUNT_HEADER = "Unique matches"
FAVORITE_CHARACTER_HEADER = "Most Picked Character"
FAVORITE_CHARACTER_COUNT_HEADER = "Character Picks"
FAVORITE_CHARACTER_PERCENTAGE_HEADER = "Character Pick %"
NAME_ALIASES = {
    "hsm88": "HSM09",
    "ruze": "itsruze",
    "squeaky94": "Squeaky",
    "dje3303": "Dyl",
    "dje333": "Dyl",
    # Historical screenshot names are occasionally written without the
    # underscore or with the display-space variant used in result posts.
    "lalasong": "Lala_Song",
    "lala song": "Lala_Song",
    "cotillion": "IsCotillion",
    "unicahlover": "Unicah",
    "brofessorsecrethuband": "Brofessor",
    "theboss-94": "TheBoss94",
}

# Tour-specific aliases should not rewrite same-spelled ATP screenshot names.
WTA_SCREENSHOT_NAME_ALIASES = {
    "lvl_0_gurl": "Danishusband-chan",
}

# Defined after SUMMARY_METRICS so candidate validation tracks the same source
# columns used by summary rebuilding.
REQUIRED_SOURCE_HEADERS = (
    "ID", "Player", "Opponent", "Tournament", "Date", "Result", *SINGLES_COLUMNS[10:33],
)


def validate_statistics_workbook(path: Path) -> dict[str, int]:
    """Validate a candidate without changing it and return source row counts."""
    if not path.exists() or not path.is_file() or path.stat().st_size == 0:
        raise ValueError(f"Statistics workbook is missing or empty: {path}")
    try:
        workbook = load_workbook(path, read_only=True, data_only=False)
    except Exception as exc:
        raise ValueError(f"Statistics workbook cannot be opened: {path.name}: {exc}") from exc
    try:
        missing_sheets = [
            name for name in REQUIRED_WORKBOOK_SHEETS
            if name not in workbook.sheetnames
        ]
        if missing_sheets:
            raise ValueError(
                "Statistics workbook is missing required sheets: "
                + ", ".join(missing_sheets)
            )
        counts: dict[str, int] = {}
        for sheet_name in ("atp", "wta"):
            sheet = workbook[sheet_name]
            rows = sheet.iter_rows(values_only=True)
            header_values = next(rows, ())
            headers = {
                str(value).strip(): index
                for index, value in enumerate(header_values)
                if value not in (None, "")
            }
            missing_headers = [
                header for header in REQUIRED_SOURCE_HEADERS
                if header not in headers
            ]
            if missing_headers:
                raise ValueError(
                    f"{sheet_name.upper()} sheet is missing required headers: "
                    + ", ".join(missing_headers)
                )
            player_column = headers["Player"]
            counts[sheet_name] = sum(
                1
                for row in rows
                if player_column < len(row)
                and row[player_column] not in (None, "")
            )
            if counts[sheet_name] == 0:
                raise ValueError(
                    f"{sheet_name.upper()} sheet has no nonempty player rows"
                )
        return counts
    finally:
        workbook.close()


def promote_statistics_workbook(
    candidate: Path,
    canonical: Path = MASTER_WORKBOOK,
) -> dict[str, Any]:
    """Stage, rebuild, back up, and atomically promote one validated workbook."""
    candidate = Path(candidate)
    canonical = Path(canonical)
    if candidate.resolve() == canonical.resolve():
        raise ValueError("Candidate workbook is already the active workbook")
    if not canonical.exists() or canonical.stat().st_size == 0:
        raise FileNotFoundError(f"Active statistics workbook not found: {canonical}")

    source_counts = validate_statistics_workbook(candidate)
    canonical.parent.mkdir(parents=True, exist_ok=True)
    staged = canonical.with_name(f".{canonical.stem}.promotion.tmp.xlsx")
    timestamp = datetime.now().strftime("%Y%m%dT%H%M%S%f")
    backup = canonical.with_name(f"{canonical.stem}.backup-{timestamp}{canonical.suffix}")
    try:
        shutil.copy2(candidate, staged)
        workbook = load_workbook(staged, data_only=False)
        try:
            recalculate_summary_sheets(workbook)
            workbook.calculation.fullCalcOnLoad = True
            workbook.calculation.forceFullCalc = True
            workbook.save(staged)
        finally:
            workbook.close()
        rebuilt_counts = validate_statistics_workbook(staged)
        if rebuilt_counts != source_counts:
            raise RuntimeError("Staged workbook row counts changed during summary rebuild")

        shutil.copy2(canonical, backup)
        os.replace(staged, canonical)
        return {
            "candidate": candidate,
            "active": canonical,
            "backup": backup,
            "rows": rebuilt_counts,
        }
    except Exception:
        staged.unlink(missing_ok=True)
        raise


def _is_numeric(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _score_signature(value: Any) -> tuple[tuple[int, int], ...]:
    """Extract score sets using the MatchLog score parsing convention."""
    return tuple(
        (int(first), int(second))
        for first, second in re.findall(r"(\d+)\s*-\s*(\d+)", str(value or ""))
    )


def _match_date_key(value: Any) -> str:
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    text = str(value or "").strip()
    for format_string in ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(text[:10], format_string).date().isoformat()
        except ValueError:
            continue
    return text[:10]


def _match_player_key(value: Any) -> str:
    return normalize_name(_canonicalize_name_alias(str(value or "")))


def _reverse_score_signature(
    signature: tuple[tuple[int, int], ...],
) -> tuple[tuple[int, int], ...]:
    return tuple((second, first) for first, second in signature)


def _tours_match_score(
    source_signature: tuple[tuple[int, int], ...],
    official_signature: tuple[tuple[int, int], ...],
) -> bool:
    return bool(source_signature) and (
        source_signature == official_signature
        or source_signature == _reverse_score_signature(official_signature)
    )


def reconcile_workbook_tours(
    official_results: list[dict[str, Any]],
    path: Path = MASTER_WORKBOOK,
) -> dict[str, Any]:
    """Move only uniquely matched source rows to their official tour sheet.

    A source match must agree with one official result on both player pair,
    calendar date, and score. Ambiguous or incomplete matches are left alone.
    The workbook is replaced atomically after formulas and summaries rebuild.
    """
    path = Path(path)
    if not path.exists() or path.stat().st_size == 0:
        raise FileNotFoundError(f"Stats workbook not found: {path}")

    official_candidates: dict[
        tuple[frozenset[str], str], list[dict[str, Any]]
    ] = {}
    for result in official_results or []:
        tour = str(result.get("tour") or "").casefold()
        players = frozenset(
            (
                _match_player_key(result.get("p1") or result.get("player1")),
                _match_player_key(result.get("p2") or result.get("player2")),
            )
        )
        date_key = _match_date_key(result.get("date"))
        score = _score_signature(result.get("result"))
        if tour not in {"atp", "wta"} or len(players) != 2 or not date_key or not score:
            continue
        official_candidates.setdefault((players, date_key), []).append({
            "tour": tour,
            "players": players,
            "date": date_key,
            "score": score,
            "tournament": result.get("tournament"),
        })

    workbook = load_workbook(path, data_only=False)
    moved: list[dict[str, Any]] = []
    try:
        sheets: dict[str, Any] = {}
        headers_by_sheet: dict[str, dict[str, int]] = {}
        rows_by_sheet: dict[str, list[dict[str, Any]]] = {}
        for sheet_name in ("atp", "wta"):
            worksheet = workbook[sheet_name]
            sheets[sheet_name] = worksheet
            headers = {
                str(cell.value).strip(): cell.column
                for cell in worksheet[1]
                if cell.value not in (None, "")
            }
            headers_by_sheet[sheet_name] = headers
            rows: list[dict[str, Any]] = []
            for row_number in range(2, worksheet.max_row + 1):
                player = worksheet.cell(row_number, headers["Player"]).value
                opponent = worksheet.cell(row_number, headers["Opponent"]).value
                date_value = worksheet.cell(row_number, headers["Date"]).value
                players = frozenset(
                    (_match_player_key(player), _match_player_key(opponent))
                )
                if len(players) != 2:
                    continue
                rows.append({
                    "sheet": sheet_name,
                    "row": row_number,
                    "players": players,
                    "date": _match_date_key(date_value),
                    "score": _score_signature(
                        worksheet.cell(row_number, headers["Result"]).value
                    ),
                })
            rows_by_sheet[sheet_name] = rows

        moves: list[tuple[str, int, str]] = []
        for source_sheet, source_rows in rows_by_sheet.items():
            for source in source_rows:
                candidates = [
                    result
                    for result in official_candidates.get(
                        (source["players"], source["date"]), []
                    )
                    if _tours_match_score(source["score"], result["score"])
                ]
                if len(candidates) != 1:
                    continue
                result = candidates[0]
                if result["tour"] == source_sheet:
                    continue
                target_sheet = result["tour"]
                target_exists = any(
                    row["sheet"] == target_sheet
                    and row["players"] == source["players"]
                    and row["date"] == source["date"]
                    and _tours_match_score(row["score"], result["score"])
                    for rows in rows_by_sheet.values()
                    for row in rows
                )
                if target_exists:
                    continue
                moves.append((source_sheet, source["row"], target_sheet))
                moved.append({
                    "from": source_sheet,
                    "to": target_sheet,
                    "row": source["row"],
                    "players": sorted(source["players"]),
                    "date": source["date"],
                })

        if not moves:
            return {"moved": [], "backup": None}

        next_ids: dict[str, int] = {}
        next_target_rows: dict[str, int] = {}
        for sheet_name, worksheet in sheets.items():
            id_column = headers_by_sheet[sheet_name]["ID"]
            image_header = next(
                header for header in headers_by_sheet[sheet_name]
                if header == "Image Name" or header.startswith("Image Name (")
            )
            next_ids[sheet_name] = max(
                (
                    int(worksheet.cell(row_number, id_column).value)
                    for row_number in range(2, worksheet.max_row + 1)
                    if str(worksheet.cell(row_number, id_column).value or "").isdigit()
                ),
                default=0,
            ) + 1
            next_target_rows[sheet_name] = _last_data_row(
                worksheet, headers_by_sheet[sheet_name][image_header]
            ) + 1

        appended_rows: dict[str, list[int]] = {"atp": [], "wta": []}
        for source_sheet, source_row_number, target_sheet in moves:
            source_ws = sheets[source_sheet]
            target_ws = sheets[target_sheet]
            source_headers = headers_by_sheet[source_sheet]
            target_headers = headers_by_sheet[target_sheet]
            image_header = next(
                header for header in target_headers
                if header == "Image Name" or header.startswith("Image Name (")
            )
            target_row_number = next_target_rows[target_sheet]
            next_target_rows[target_sheet] += 1
            appended_rows[target_sheet].append(target_row_number)
            template_row = max(2, target_row_number - 1)
            target_ws.row_dimensions[target_row_number].height = (
                target_ws.row_dimensions[template_row].height
            )
            for column in range(1, target_ws.max_column + 1):
                source = target_ws.cell(template_row, column)
                target = target_ws.cell(target_row_number, column)
                if source.has_style:
                    target._style = copy(source._style)
                target.value = None

            for header, source_column in source_headers.items():
                target_header = (
                    image_header
                    if header == "Image Name" or header.startswith("Image Name (")
                    else header
                )
                if target_header not in target_headers:
                    continue
                target_column = target_headers[target_header]
                value = source_ws.cell(source_row_number, source_column).value
                if header == "ID":
                    value = next_ids[target_sheet]
                elif header == "Tournament":
                    value = re.sub(r"\b(?:ATP|WTA)\b", target_sheet.upper(), str(value or ""))
                if isinstance(value, str) and value.startswith("="):
                    continue
                target_ws.cell(target_row_number, target_column).value = value
            next_ids[target_sheet] += 1

            for header, target_column in target_headers.items():
                template = target_ws.cell(template_row, target_column)
                if isinstance(template.value, str) and template.value.startswith("="):
                    target = target_ws.cell(target_row_number, target_column)
                    target.value = Translator(
                        template.value,
                        origin=template.coordinate,
                    ).translate_formula(target.coordinate)

        for sheet_name, worksheet in sheets.items():
            for row_number in sorted(
                (row["row"] for row in rows_by_sheet[sheet_name]
                 if any(move[0] == sheet_name and move[1] == row["row"] for move in moves)),
                reverse=True,
            ):
                worksheet.delete_rows(row_number, 1)
            _ensure_match_key_column(worksheet)
        recalculate_summary_sheets(workbook)
        workbook.calculation.fullCalcOnLoad = True
        workbook.calculation.forceFullCalc = True
        temporary = path.with_suffix(".tour-reconcile.tmp.xlsx")
        workbook.save(temporary)
    finally:
        workbook.close()

    check = load_workbook(temporary, read_only=True, data_only=False)
    try:
        for sheet_name, row_numbers in appended_rows.items():
            if sheet_name not in check.sheetnames:
                raise RuntimeError(f"Reconciled workbook has no {sheet_name} sheet")
    finally:
        check.close()
    timestamp = datetime.now().strftime("%Y%m%dT%H%M%S%f")
    backup = path.with_name(f"{path.stem}.backup-{timestamp}{path.suffix}")
    shutil.copy2(path, backup)
    temporary.replace(path)
    return {"moved": moved, "backup": backup}


def _result_components(result: Any) -> dict[str, float]:
    """Return score-derived components for a result oriented to its player."""
    sets = _score_signature(result)
    derived: dict[str, float] = {}
    tiebreaks = [
        float(first > second)
        for first, second in sets
        if {first, second} == {6, 7}
    ]
    if tiebreaks:
        derived["Tie-breaks Won %"] = sum(tiebreaks) / len(tiebreaks)
    if len(sets) >= 3:
        prior_player_sets = sum(first > second for first, second in sets[:-1])
        prior_opponent_sets = sum(second > first for first, second in sets[:-1])
        final_first, final_second = sets[-1]
        if prior_player_sets == prior_opponent_sets and final_first != final_second:
            derived["Deciding Sets Won %"] = float(final_first > final_second)
    return derived


def _reverse_result(result: Any) -> str:
    """Orient each visible set score to the other screenshot player."""
    return re.sub(
        r"(\d+)(\s*-\s*)(\d+)",
        lambda match: f"{match.group(3)}{match.group(2)}{match.group(1)}",
        str(result or ""),
    )


def _derived_row_metrics(row: dict[str, Any], opponent: dict[str, Any] | None) -> dict[str, float]:
    """Derive ATP-style return and pressure components from reciprocal rows."""
    derived: dict[str, Any] = {}
    if opponent is not None:
        for source, target in (
            ("1st Serve Won %", "1st Serve Return Points Won %"),
            ("2nd Serve Won %", "2nd Serve Return Points Won %"),
            ("Break Points Won %", "Break Points Saved %"),
        ):
            value = opponent.get(source)
            if _is_numeric(value):
                derived[target] = 1 - float(value)
    for label, value in _result_components(row.get("Result")).items():
        # A screenshot raw row represents one match, so multiple tie-breaks
        # are collapsed to that match's tie-break win rate.
        derived[label] = value
    return derived


def _clean_cell_text(value: Any) -> str:
    """Apply the same whitespace/name cleanup before creating match keys."""
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", str(value or ""))).strip()


def _favorite_character(values: list[Any]) -> dict[str, Any] | None:
    """Return the most frequent nonblank character and its raw-row share."""
    counts: dict[str, list[Any]] = {}
    total = 0
    for value in values:
        character = _clean_cell_text(value)
        if not character:
            continue
        total += 1
        key = character.casefold()
        if key not in counts:
            counts[key] = [character, 0]
        counts[key][1] += 1
    if not total:
        return None
    # A stable alphabetical tie break avoids workbook row-order surprises.
    character, count = sorted(
        counts.values(), key=lambda item: (-item[1], item[0].casefold())
    )[0]
    return {"character": character, "count": count, "percentage": count / total}


def _is_completed_result(value: Any) -> bool:
    """Reject rows that explicitly represent an unresolved fixture."""
    result = _clean_cell_text(value).casefold()
    if not result:
        return False
    pending = {
        "scheduled", "pending", "tbd", "to be played", "not started",
        "upcoming", "cancelled", "canceled", "postponed",
    }
    return not any(
        re.search(rf"\b{re.escape(marker)}\b", result)
        for marker in pending
    )


def _is_reviewable_match_result(value: Any) -> bool:
    """Keep unknown scores while excluding rows that are plainly fixtures."""
    result = _clean_cell_text(value).casefold()
    fixture_status = (
        r"(?:match\s+)?(?:scheduled|pending|tbd|to\s+be\s+played|"
        r"not\s+started|upcoming|cancelled|canceled|postponed)"
    )
    return not re.match(
        rf"^(?:(?:result|status)\s*[:\-]?\s*)?{fixture_status}\b",
        result,
    )


def player_summary(
    path: Path,
    player_name: str,
    tour: str,
    period: str = "career",
    as_of: date | datetime | str | None = None,
    *,
    excluded_match_keys_by_player: dict[str, set[str]] | None = None,
) -> dict[str, Any] | None:
    """Read one player's screenshot-derived summary from exactly one tour.

    Bounded periods are calculated from the raw tour sheet so their metric
    denominators retain the same per-match duplicate-collapse rules as the
    persisted career summary.
    """
    selected_tour = str(tour or "").casefold()
    if selected_tour not in {"atp", "wta"}:
        raise ValueError("Screenshot statistics require an ATP or WTA tour")
    period_key = str(period or "career").strip().casefold()
    period_labels = {
        "career": "Career",
        "30d": "Last 30 days",
        "90d": "Last 90 days",
        "year": "Year to date",
        "52w": "Last 52 weeks",
    }
    if period_key not in period_labels:
        raise ValueError("Screenshot statistics period must be career, 30d, 90d, year, or 52w")

    def parse_date(value: Any) -> date | None:
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, date):
            return value
        if isinstance(value, str):
            try:
                return date.fromisoformat(value.strip()[:10])
            except ValueError:
                return None
        return None

    if as_of is None:
        period_end = date.today()
    else:
        period_end = parse_date(as_of)
        if period_end is None:
            raise ValueError("as_of must be a date or ISO YYYY-MM-DD string")
    period_start = {
        "30d": period_end - timedelta(days=29),
        "90d": period_end - timedelta(days=89),
        "year": date(period_end.year, 1, 1),
        "52w": period_end - timedelta(days=363),
    }.get(period_key)

    def in_period(match_date: date | None) -> bool:
        if period_key == "career":
            return True
        # An unknown date cannot truthfully be assigned to a bounded period.
        return match_date is not None and period_start <= match_date <= period_end

    summary_name = "ATP Summary" if selected_tour == "atp" else "WTA Summary"
    raw_name = selected_tour
    wanted = normalize_name(_canonicalize_name_alias(player_name))
    excluded_match_keys = {
        normalize_name(_canonicalize_name_alias(player)): {
            _clean_cell_text(match_key).casefold()
            for match_key in match_keys
            if _clean_cell_text(match_key)
        }
        for player, match_keys in (excluded_match_keys_by_player or {}).items()
    }
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        summary = workbook[summary_name]
        header_values = [cell.value for cell in summary[5]]
        summary_headers = {
            str(value).strip(): index for index, value in enumerate(header_values)
            if value not in (None, "")
        }
        summary_player_column = summary_headers.get("Player")
        found = None
        if summary_player_column is not None:
            for values in summary.iter_rows(min_row=6, values_only=True):
                row = dict(zip(header_values, values))
                if row.get("Player") and normalize_name(
                    _canonicalize_name_alias(values[summary_player_column])
                ) == wanted:
                    found = row

        source = workbook[raw_name]
        source_header_values = [cell.value for cell in source[1]]
        source_headers = {
            str(value).strip(): index for index, value in enumerate(source_header_values)
            if value not in (None, "")
        }
        required = (
            "Player", "Opponent", "Tournament", "Date", "Result",
            *SINGLES_COLUMNS[10:33],
        )
        if any(header not in source_headers for header in required):
            # Retain legacy career behavior for old workbooks that only have a
            # persisted summary; bounded summaries cannot be derived safely.
            if period_key != "career" or found is None or excluded_match_keys:
                return None
            canonical = _clean_cell_text(found.get("Player"))
            metrics = [
                (metric, found[metric], int(found.get(f"{metric} matches used") or 0))
                for metric in SUMMARY_METRICS
                if _is_numeric(found.get(metric))
                and int(found.get(f"{metric} matches used") or 0) > 0
            ]
            return {
                "player": canonical, "tour": selected_tour, "source": "screenshots",
                "matches": int(found.get(SUMMARY_MATCH_COUNT_HEADER) or 0),
                "source_matches": int(found.get(SUMMARY_MATCH_COUNT_HEADER) or 0),
                "favorite_character": (
                    {
                        "character": found[FAVORITE_CHARACTER_HEADER],
                        "count": int(found.get(FAVORITE_CHARACTER_COUNT_HEADER) or 0),
                        "percentage": found.get(FAVORITE_CHARACTER_PERCENTAGE_HEADER),
                    }
                    if found.get(FAVORITE_CHARACTER_HEADER)
                    else None
                ),
                "metrics": metrics,
                "ratings": [
                    (label.replace(" (Overall)", " Rating"),
                     found.get(label) if _is_numeric(found.get(label)) else None)
                    for label in OVERALL_RATING_COLUMNS
                ],
                "recent_matches": [], "relative_profile": calculate_relative_profiles(found, []),
                "period": period_key, "period_key": period_key,
                "period_label": period_labels[period_key],
                "as_of": period_end.isoformat(),
            }

        # Filter source rows before collapsing duplicates: a row with no date
        # must never leak into a bounded period through a dated duplicate.
        match_groups: dict[tuple[str, str], dict[str, Any]] = {}
        all_player_names: dict[str, str] = {}
        for values in source.iter_rows(min_row=2, values_only=True):
            row = dict(zip(source_header_values, values))
            player = _clean_cell_text(row.get("Player"))
            player_key = normalize_name(_canonicalize_name_alias(player))
            if not player_key:
                continue
            all_player_names.setdefault(player_key, player)
            if not _is_completed_result(row.get("Result")):
                continue
            if not in_period(parse_date(row.get("Date"))):
                continue
            match_key = _clean_cell_text(row.get(MATCH_KEY_HEADER))
            if not match_key:
                match_key = _build_match_key(
                    player, row.get("Opponent"), row.get("Tournament"), row.get("Date")
                )
            group = match_groups.setdefault(
                (player_key, match_key.casefold()),
                {"name": player, "match_key": match_key, "rows": []},
            )
            group["rows"].append(row)

        aggregates: dict[str, dict[str, Any]] = {}
        for (player_key, _), group in match_groups.items():
            if (
                group["match_key"].casefold()
                in excluded_match_keys.get(player_key, set())
            ):
                continue
            aggregate = aggregates.setdefault(player_key, {
                "name": group["name"], "matches": 0,
                "values": {metric: [] for metric in SUMMARY_METRICS},
                "characters": [],
            })
            aggregate["matches"] += 1
            aggregate["characters"].extend(
                row.get("Character") for row in group["rows"]
            )
            for metric in SUMMARY_METRICS:
                usable = [row.get(metric) for row in group["rows"] if _is_numeric(row.get(metric))]
                if usable:
                    aggregate["values"][metric].append(sum(usable) / len(usable))

        canonical = (
            aggregates.get(wanted, {}).get("name")
            or all_player_names.get(wanted)
            or (found and _clean_cell_text(found.get("Player")))
        )
        if not canonical:
            return None
        population = []
        rows_by_player: dict[str, dict[str, Any]] = {}
        for player_key, aggregate in aggregates.items():
            row = {"Player": aggregate["name"], SUMMARY_MATCH_COUNT_HEADER: aggregate["matches"]}
            favorite = _favorite_character(aggregate["characters"])
            if favorite:
                row[FAVORITE_CHARACTER_HEADER] = favorite["character"]
                row[FAVORITE_CHARACTER_COUNT_HEADER] = favorite["count"]
                row[FAVORITE_CHARACTER_PERCENTAGE_HEADER] = favorite["percentage"]
            for metric, values in aggregate["values"].items():
                row[f"{metric} matches used"] = len(values)
                row[metric] = sum(values) / len(values) if values else None
            rows_by_player[player_key] = row
            population.append(row)
        target = rows_by_player.get(wanted, {
            "Player": canonical, SUMMARY_MATCH_COUNT_HEADER: 0,
            FAVORITE_CHARACTER_HEADER: None,
            FAVORITE_CHARACTER_COUNT_HEADER: 0,
            FAVORITE_CHARACTER_PERCENTAGE_HEADER: None,
            **{f"{metric} matches used": 0 for metric in SUMMARY_METRICS},
            **{metric: None for metric in SUMMARY_METRICS},
        })
        source_match_count = sum(
            1 for (player_key, _match_key) in match_groups if player_key == wanted
        )
        ratings_by_label = calculate_partial_overall_ratings(target)
        metrics = [
            (metric, target[metric], int(target[f"{metric} matches used"]))
            for metric in SUMMARY_METRICS
            if _is_numeric(target[metric]) and target[f"{metric} matches used"] > 0
        ]
        match_records = []
        for (player_key, _), group in match_groups.items():
            if player_key != wanted:
                continue
            rows = group["rows"]
            first = rows[0]
            match_records.append({
                "match_key": group["match_key"],
                "date": first.get("Date"),
                "tournament": first.get("Tournament"),
                "opponent": first.get("Opponent"),
                "result": first.get("Result"),
                "metrics_present": [
                    metric for metric in SUMMARY_METRICS
                    if any(_is_numeric(row.get(metric)) for row in rows)
                ],
            })
        return {
            "player": _clean_cell_text(canonical),
            "tour": selected_tour,
            "source": "screenshots",
            "matches": int(target[SUMMARY_MATCH_COUNT_HEADER]),
            "source_matches": source_match_count,
            "favorite_character": (
                {
                    "character": target[FAVORITE_CHARACTER_HEADER],
                    "count": int(target[FAVORITE_CHARACTER_COUNT_HEADER]),
                    "percentage": target[FAVORITE_CHARACTER_PERCENTAGE_HEADER],
                }
                if target.get(FAVORITE_CHARACTER_HEADER)
                else None
            ),
            "metrics": metrics,
            "ratings": [
                (label.replace(" (Overall)", " Rating"), ratings_by_label[label])
                for label in OVERALL_RATING_COLUMNS
            ],
            "recent_matches": [],
            "match_records": match_records,
            "relative_profile": calculate_relative_profiles(target, population),
            "period": period_key,
            "period_key": period_key,
            "period_label": period_labels[period_key],
            "as_of": period_end.isoformat(),
        }
    finally:
        workbook.close()


def match_record_summaries(path: Path) -> list[dict[str, Any]]:
    """Return all completed screenshot match records grouped by player and tour.

    This is intentionally limited to the evidence needed by reconciliation
    reports.  It reads each raw sheet once, so a scheduled all-player review
    does not need to reopen the workbook for every player.
    """
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        summaries = []
        required = ("Player", "Opponent", "Tournament", "Date", "Result")
        for tour in ("atp", "wta"):
            if tour not in workbook.sheetnames:
                continue
            source = workbook[tour]
            header_values = list(next(
                source.iter_rows(min_row=1, max_row=1, values_only=True),
                (),
            ))
            headers = {
                str(value).strip(): index
                for index, value in enumerate(header_values)
                if value not in (None, "")
            }
            if any(header not in headers for header in required):
                continue

            groups: dict[tuple[str, str], dict[str, Any]] = {}
            player_names: dict[str, str] = {}
            for values in source.iter_rows(min_row=2, values_only=True):
                row = dict(zip(header_values, values))
                player = _clean_cell_text(row.get("Player"))
                player_key = normalize_name(_canonicalize_name_alias(player))
                if not player_key or not _is_reviewable_match_result(
                    row.get("Result")
                ):
                    continue
                player_names.setdefault(player_key, player)
                match_key = _clean_cell_text(row.get(MATCH_KEY_HEADER))
                if not match_key:
                    match_key = _build_match_key(
                        player,
                        row.get("Opponent"),
                        row.get("Tournament"),
                        row.get("Date"),
                    )
                group = groups.setdefault(
                    (player_key, match_key.casefold()),
                    {"player": player, "match_key": match_key, "rows": []},
                )
                group["rows"].append(row)

            by_player: dict[str, list[dict[str, Any]]] = {}
            for (player_key, _), group in groups.items():
                first = group["rows"][0]
                by_player.setdefault(player_key, []).append({
                    "match_key": group["match_key"],
                    "date": first.get("Date"),
                    "tournament": first.get("Tournament"),
                    "opponent": first.get("Opponent"),
                    "result": first.get("Result"),
                })
            for player_key, records in by_player.items():
                summaries.append({
                    "player": player_names[player_key],
                    "tour": tour,
                    "source": "screenshots",
                    "matches": len(records),
                    "match_records": records,
                    "period": "career",
                })
        return sorted(
            summaries,
            key=lambda summary: (
                str(summary["tour"]),
                normalize_name(summary["player"]),
            ),
        )
    finally:
        workbook.close()


def query_match_stat_values(
    path: Path,
    metric_label: str,
    *,
    tour: str | None = None,
    period: str | None = None,
    set_count: int | None = None,
    player_name: str | None = None,
    opponent_name: str | None = None,
) -> list[dict[str, Any]]:
    """Return verified single-match values from screenshot rows."""
    metric_label = str(metric_label or "").strip()
    if metric_label not in (*SINGLES_COLUMNS, *DERIVED_SUMMARY_METRICS):
        raise ValueError("That metric is not available in screenshot statistics")
    is_derived = metric_label in DERIVED_SUMMARY_METRICS
    selected_tour = str(tour or "").strip().casefold() or None
    if selected_tour not in {None, "atp", "wta"}:
        raise ValueError("tour must be ATP or WTA")
    if set_count is not None and (int(set_count) < 1 or int(set_count) > 5):
        raise ValueError("set_count must be between 1 and 5")
    period_key = str(period or "career").strip().casefold()
    period_labels = {
        "career": "Career",
        "30d": "Last 30 days",
        "90d": "Last 90 days",
        "year": "Year to date",
        "52w": "Last 52 weeks",
    }
    if period_key not in period_labels:
        raise ValueError("period must be career, 30d, 90d, year, or 52w")
    period_end = date.today()
    period_start = {
        "30d": period_end - timedelta(days=29),
        "90d": period_end - timedelta(days=89),
        "year": date(period_end.year, 1, 1),
        "52w": period_end - timedelta(days=363),
    }.get(period_key)
    wanted_player = normalize_name(_canonicalize_name_alias(player_name)) if player_name else None
    wanted_opponent = (
        normalize_name(_canonicalize_name_alias(opponent_name))
        if opponent_name
        else None
    )

    def parse_date(value: Any) -> date | None:
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, date):
            return value
        if isinstance(value, str):
            try:
                return date.fromisoformat(value.strip()[:10])
            except ValueError:
                return None
        return None

    def in_period(value: Any) -> bool:
        if period_key == "career":
            return True
        match_date = parse_date(value)
        return match_date is not None and period_start <= match_date <= period_end

    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        candidates: list[dict[str, Any]] = []
        seen_rows: set[tuple[str, str, str]] = set()
        for current_tour in ("atp", "wta"):
            if selected_tour is not None and current_tour != selected_tour:
                continue
            if current_tour not in workbook.sheetnames:
                continue
            source = workbook[current_tour]
            header_values = list(next(
                source.iter_rows(min_row=1, max_row=1, values_only=True),
                (),
            ))
            headers = {
                str(value).strip(): index
                for index, value in enumerate(header_values)
                if value not in (None, "")
            }
            if not is_derived and metric_label not in headers:
                continue
            for values in source.iter_rows(min_row=2, values_only=True):
                row = dict(zip(header_values, values))
                player = _clean_cell_text(row.get("Player"))
                opponent = _clean_cell_text(row.get("Opponent"))
                if not player or (
                    wanted_player is not None
                    and normalize_name(_canonicalize_name_alias(player))
                    != wanted_player
                ):
                    continue
                if (
                    wanted_opponent is not None
                    and normalize_name(_canonicalize_name_alias(opponent))
                    != wanted_opponent
                ):
                    continue
                if not _is_reviewable_match_result(row.get("Result")):
                    continue
                if not in_period(row.get("Date")):
                    continue
                result = _clean_cell_text(row.get("Result"))
                actual_sets = len(re.findall(r"\d+\s*[-–]\s*\d+", result))
                if set_count is not None and actual_sets != int(set_count):
                    continue
                value = (
                    _result_components(result).get(metric_label)
                    if is_derived
                    else row.get(metric_label)
                )
                if not _is_numeric(value):
                    continue
                match_key = _clean_cell_text(
                    row.get(MATCH_KEY_HEADER)
                    or _build_match_key(
                        player,
                        row.get("Opponent"),
                        row.get("Tournament"),
                        row.get("Date"),
                    )
                )
                row_key = (current_tour, normalize_name(player), match_key.casefold())
                if row_key in seen_rows:
                    continue
                seen_rows.add(row_key)
                candidates.append({
                    "value": float(value),
                    "player": player,
                    "opponent": opponent,
                    "character": _clean_cell_text(row.get("Character")),
                    "opponent_character": _clean_cell_text(
                        row.get("Opponent Character")
                    ),
                    "tour": current_tour,
                    "date": _clean_cell_text(row.get("Date")),
                    "tournament": _clean_cell_text(row.get("Tournament")),
                    "result": result,
                    "sets": actual_sets,
                    "metric": metric_label,
                    "metric_label": metric_label,
                    "source": "screenshots",
                })
        return candidates
    finally:
        workbook.close()


def query_match_stat_record(
    path: Path,
    metric_label: str,
    *,
    tour: str | None = None,
    period: str | None = None,
    set_count: int | None = None,
    player_name: str | None = None,
) -> dict[str, Any] | None:
    """Return the highest single-match value from verified screenshot rows."""
    values = query_match_stat_values(
        path,
        metric_label,
        tour=tour,
        period=period,
        set_count=set_count,
        player_name=player_name,
    )
    return max(
        values,
        key=lambda candidate: (candidate["value"], str(candidate["date"])),
        default=None,
    )


def leaderboard_rows(
    path: Path,
    tour: str,
    *,
    excluded_match_keys_by_player: dict[str, set[str]] | None = None,
) -> list[dict[str, Any]]:
    """Read career rating rows for one screenshot-statistics tour."""
    selected_tour = str(tour or "").casefold()
    if selected_tour not in {"atp", "wta"}:
        raise ValueError("Screenshot leaderboard requires an ATP or WTA tour")
    excluded_match_keys = {
        normalize_name(_canonicalize_name_alias(player)): {
            _clean_cell_text(match_key).casefold()
            for match_key in match_keys
            if _clean_cell_text(match_key)
        }
        for player, match_keys in (excluded_match_keys_by_player or {}).items()
    }
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        if excluded_match_keys:
            source = workbook[selected_tour]
            source_header_values = [cell.value for cell in source[1]]
            source_headers = {
                str(value).strip(): index
                for index, value in enumerate(source_header_values)
                if value not in (None, "")
            }
            required = (
                "Player", "Opponent", "Tournament", "Date", "Result",
                *SINGLES_COLUMNS[10:33],
            )
            if any(header not in source_headers for header in required):
                return []
            match_groups: dict[tuple[str, str], dict[str, Any]] = {}
            for values in source.iter_rows(min_row=2, values_only=True):
                row = dict(zip(source_header_values, values))
                player = _clean_cell_text(row.get("Player"))
                player_key = normalize_name(_canonicalize_name_alias(player))
                if not player_key or not _is_completed_result(row.get("Result")):
                    continue
                match_key = _clean_cell_text(row.get(MATCH_KEY_HEADER))
                if not match_key:
                    match_key = _build_match_key(
                        player, row.get("Opponent"), row.get("Tournament"),
                        row.get("Date"),
                    )
                group = match_groups.setdefault(
                    (player_key, match_key.casefold()),
                    {"name": player, "match_key": match_key, "rows": []},
                )
                group["rows"].append(row)

            aggregates: dict[str, dict[str, Any]] = {}
            for (player_key, _), group in match_groups.items():
                if (
                    group["match_key"].casefold()
                    in excluded_match_keys.get(player_key, set())
                ):
                    continue
                aggregate = aggregates.setdefault(player_key, {
                    "name": group["name"],
                    "matches": 0,
                    "values": {metric: [] for metric in SUMMARY_METRICS},
                    "characters": [],
                })
                aggregate["matches"] += 1
                aggregate["characters"].extend(
                    row.get("Character") for row in group["rows"]
                )
                for metric in SUMMARY_METRICS:
                    usable = [
                        row.get(metric)
                        for row in group["rows"]
                        if _is_numeric(row.get(metric))
                    ]
                    if usable:
                        aggregate["values"][metric].append(
                            sum(usable) / len(usable)
                        )

            rows = []
            for aggregate in aggregates.values():
                row = {
                    "Player": aggregate["name"],
                    SUMMARY_MATCH_COUNT_HEADER: aggregate["matches"],
                }
                favorite = _favorite_character(aggregate["characters"])
                if favorite:
                    row[FAVORITE_CHARACTER_HEADER] = favorite["character"]
                    row[FAVORITE_CHARACTER_COUNT_HEADER] = favorite["count"]
                    row[FAVORITE_CHARACTER_PERCENTAGE_HEADER] = favorite[
                        "percentage"
                    ]
                for metric, values in aggregate["values"].items():
                    row[f"{metric} matches used"] = len(values)
                    row[metric] = sum(values) / len(values) if values else None
                calculated = calculate_partial_overall_ratings(row)
                ratings = {
                    label: calculated.get(label)
                    for label in OVERALL_RATING_COLUMNS
                    if _is_numeric(calculated.get(label))
                }
                if ratings:
                    rows.append({
                        "player": aggregate["name"],
                        "tour": selected_tour,
                        "source": "screenshots",
                        "matches": aggregate["matches"],
                        "favorite_character": favorite,
                        "ratings": ratings,
                        "metrics": {
                            metric: row.get(metric)
                            for metric in SUMMARY_METRICS
                            if _is_numeric(row.get(metric))
                            and int(row.get(
                                f"{metric} matches used"
                            ) or 0) > 0
                        },
                    })
            return rows
        sheet_name = "ATP Summary" if selected_tour == "atp" else "WTA Summary"
        if sheet_name not in workbook.sheetnames:
            return []
        sheet = workbook[sheet_name]
        headers = [cell.value for cell in sheet[5]]
        rows = []
        for values in sheet.iter_rows(min_row=6, values_only=True):
            row = dict(zip(headers, values))
            player = _clean_cell_text(row.get("Player"))
            if not player:
                continue
            calculated = calculate_partial_overall_ratings(row)
            ratings = {
                label: calculated.get(label)
                for label in OVERALL_RATING_COLUMNS
                if _is_numeric(calculated.get(label))
            }
            if ratings:
                rows.append({
                    "player": player,
                    "tour": selected_tour,
                    "source": "screenshots",
                    "matches": int(row.get(SUMMARY_MATCH_COUNT_HEADER) or 0),
                    "favorite_character": (
                        {
                            "character": row[FAVORITE_CHARACTER_HEADER],
                            "count": int(row.get(FAVORITE_CHARACTER_COUNT_HEADER) or 0),
                            "percentage": row.get(FAVORITE_CHARACTER_PERCENTAGE_HEADER),
                        }
                        if row.get(FAVORITE_CHARACTER_HEADER)
                        else None
                    ),
                    "ratings": ratings,
                    "metrics": {
                        metric: row.get(metric)
                        for metric in SUMMARY_METRICS
                        if _is_numeric(row.get(metric))
                        and int(row.get(f"{metric} matches used") or 0) > 0
                    },
                })
        return rows
    finally:
        workbook.close()


def _canonicalize_name_alias(value: Any) -> str:
    cleaned = _clean_cell_text(value)
    parts = re.split(r"\s*&\s*", cleaned)
    return " & ".join(
        NAME_ALIASES.get(normalize_name(part), part) for part in parts if part
    )

def _tour_correction_match_key(
    player: Any,
    opponent: Any,
    match_date: Any,
    result: Any,
) -> tuple[Any, ...] | None:
    player_key = normalize_name(_canonicalize_name_alias(player))
    opponent_key = normalize_name(_canonicalize_name_alias(opponent))
    score_key = result_score_equivalence_key(result)
    if not player_key or not opponent_key or not score_key:
        return None
    if isinstance(match_date, datetime):
        date_key = match_date.date().isoformat()
    elif isinstance(match_date, date):
        date_key = match_date.isoformat()
    else:
        date_key = _clean_cell_text(match_date).casefold()
    if not date_key:
        return None
    return (min(player_key, opponent_key), max(player_key, opponent_key), date_key, score_key)
def _match_key_component(value: Any, *, name: bool = False) -> str:
    cleaned = _clean_cell_text(value)
    if isinstance(value, datetime):
        cleaned = value.date().isoformat()
    elif isinstance(value, date):
        cleaned = value.isoformat()
    return normalize_name(cleaned) if name else cleaned.casefold()


def _build_match_key(
    player: Any,
    opponent: Any,
    tournament: Any,
    match_date: Any,
) -> str:
    """Return a stable AK key for one player's view of one match."""
    return "|".join(
        (
            _match_key_component(player, name=True),
            _match_key_component(opponent, name=True),
            _match_key_component(tournament),
            _match_key_component(match_date),
        )
    )


def _ensure_match_key_column(source: Any) -> dict[str, int]:
    """Ensure cleaned source rows have the workbook's AK Unique ID B values."""
    headers = {
        str(cell.value).strip(): cell.column
        for cell in source[1]
        if cell.value not in (None, "")
    }
    if MATCH_KEY_HEADER in headers and headers[MATCH_KEY_HEADER] != MATCH_KEY_COLUMN:
        raise ValueError(
            f"{MATCH_KEY_HEADER} must be in AK (column {MATCH_KEY_COLUMN}), "
            f"found column {headers[MATCH_KEY_HEADER]}"
        )
    ak_header = source.cell(1, MATCH_KEY_COLUMN).value
    if ak_header not in (None, "", MATCH_KEY_HEADER):
        raise ValueError(
            f"Cannot use AK for {MATCH_KEY_HEADER}: it contains {ak_header!r}"
        )
    source.cell(1, MATCH_KEY_COLUMN).value = MATCH_KEY_HEADER
    headers[MATCH_KEY_HEADER] = MATCH_KEY_COLUMN

    required = ("Player", "Opponent", "Tournament", "Date")
    missing = [header for header in required if header not in headers]
    if missing:
        raise ValueError(
            f"Cannot build {MATCH_KEY_HEADER}: missing headers {', '.join(missing)}"
        )

    for row_number in range(2, source.max_row + 1):
        player = _canonicalize_name_alias(
            source.cell(row_number, headers["Player"]).value
        )
        opponent = _canonicalize_name_alias(
            source.cell(row_number, headers["Opponent"]).value
        )
        if player:
            source.cell(row_number, headers["Player"]).value = player
        if opponent:
            source.cell(row_number, headers["Opponent"]).value = opponent
        if not player:
            source.cell(row_number, MATCH_KEY_COLUMN).value = None
            continue
        source.cell(row_number, MATCH_KEY_COLUMN).value = _build_match_key(
            player,
            opponent,
            source.cell(row_number, headers["Tournament"]).value,
            source.cell(row_number, headers["Date"]).value,
        )
    return headers


def _ensure_character_columns(source: Any) -> dict[str, int]:
    """Add character headers only in truly unused columns, never shifting AK.

    Older workbooks reserve AK for ``Unique ID B`` and often have formula or
    legacy-ID columns beside it.  A blank header is reusable only when the
    complete column is blank; otherwise the new field is appended after the
    existing sheet extent.
    """
    headers = {
        str(cell.value).strip(): cell.column
        for cell in source[1]
        if cell.value not in (None, "")
    }
    missing = [
        header for header in ("Character", "Opponent Character")
        if header not in headers
    ]
    for header in missing:
        column = next(
            (
                candidate
                for candidate in range(1, source.max_column + 1)
                if candidate != MATCH_KEY_COLUMN
                and source.cell(1, candidate).value in (None, "")
                and all(
                    source.cell(row_number, candidate).value in (None, "")
                    for row_number in range(2, source.max_row + 1)
                )
            ),
            None,
        )
        if column is None:
            column = source.max_column + 1
            while column == MATCH_KEY_COLUMN:
                column += 1
        source.cell(1, column).value = header
        headers[header] = column
    return headers


def _ensure_derived_metric_columns(source: Any) -> dict[str, int]:
    """Add derivable metric columns without moving legacy columns or AK."""
    headers = {
        str(cell.value).strip(): cell.column
        for cell in source[1]
        if cell.value not in (None, "")
    }
    for header in DERIVED_SUMMARY_METRICS:
        if header in headers:
            continue
        column = next(
            (
                candidate for candidate in range(1, source.max_column + 1)
                if candidate != MATCH_KEY_COLUMN
                and source.cell(1, candidate).value in (None, "")
                and all(
                    source.cell(row_number, candidate).value in (None, "")
                    for row_number in range(2, source.max_row + 1)
                )
            ),
            None,
        )
        if column is None:
            column = source.max_column + 1
            while column == MATCH_KEY_COLUMN:
                column += 1
        source.cell(1, column).value = header
        headers[header] = column
    return headers


def recalculate_summary_sheets(workbook: Any) -> None:
    """Rebuild ATP/WTA summaries from one row per player per AK match."""
    for source_name, summary_name in (("atp", "ATP Summary"), ("wta", "WTA Summary")):
        source = workbook[source_name]
        summary = workbook[summary_name]
        _ensure_character_columns(source)
        _ensure_derived_metric_columns(source)
        source_headers = _ensure_match_key_column(source)
        previous_last_row = summary.max_row
        required = ["Player", *SUMMARY_METRICS]
        missing = [
            header
            for header in required
            if header not in source_headers
        ]
        if missing:
            raise ValueError(
                f"Cannot recalculate {summary_name}: missing headers "
                f"{', '.join(missing)}"
            )

        summary_headers_list = [
            "Player",
            SUMMARY_MATCH_COUNT_HEADER,
            FAVORITE_CHARACTER_HEADER,
            FAVORITE_CHARACTER_COUNT_HEADER,
            FAVORITE_CHARACTER_PERCENTAGE_HEADER,
            *[f"{metric} matches used" for metric in SUMMARY_METRICS],
            *SUMMARY_METRICS,
            *OVERALL_RATING_COLUMNS,
        ]
        summary_headers = {
            header: index
            for index, header in enumerate(summary_headers_list, start=1)
        }
        template_styles = {
            column: copy(summary.cell(6, min(column, summary.max_column))._style)
            for column in range(1, len(summary_headers_list) + 1)
            if summary.max_row >= 6
        }

        # The key is Player + AK, not the number of source rows. A source post
        # can contribute several rows to the same match and metric.
        raw_rows: list[dict[str, Any]] = []
        reciprocal_rows: dict[tuple[str, str, str, str], list[dict[str, Any]]] = {}
        for row_number in range(2, source.max_row + 1):
            row = {
                header: source.cell(row_number, column).value
                for header, column in source_headers.items()
            }
            row["_row_number"] = row_number
            player_key = normalize_name(_clean_cell_text(row.get("Player")))
            opponent_key = normalize_name(_clean_cell_text(row.get("Opponent")))
            if player_key and opponent_key:
                reciprocal_key = (
                    min(player_key, opponent_key), max(player_key, opponent_key),
                    _match_key_component(row.get("Tournament")),
                    _match_key_component(row.get("Date")),
                )
                reciprocal_rows.setdefault(reciprocal_key, []).append(row)
            raw_rows.append(row)

        match_groups: dict[tuple[str, str], dict[str, Any]] = {}
        for row in raw_rows:
            player = _clean_cell_text(row.get("Player"))
            player_key = normalize_name(player)
            if not player_key:
                continue
            match_key = _clean_cell_text(row.get(MATCH_KEY_HEADER))
            if not match_key:
                continue
            opponent_key = normalize_name(_clean_cell_text(row.get("Opponent")))
            reciprocal_key = (
                min(player_key, opponent_key), max(player_key, opponent_key),
                _match_key_component(row.get("Tournament")),
                _match_key_component(row.get("Date")),
            )
            opponent = next(
                (
                    candidate for candidate in reciprocal_rows.get(reciprocal_key, [])
                    if normalize_name(_clean_cell_text(candidate.get("Player"))) == opponent_key
                    and normalize_name(_clean_cell_text(candidate.get("Opponent"))) == player_key
                ),
                None,
            )
            derived = _derived_row_metrics(row, opponent)
            for metric in DERIVED_SUMMARY_METRICS:
                value = derived.get(metric)
                row[metric] = value
                source.cell(
                    row["_row_number"], source_headers[metric]
                ).value = value
            group = match_groups.setdefault(
                (player_key, match_key.casefold()),
                {"name": player, "rows": []},
            )
            group["rows"].append(
                {
                    metric: row.get(metric)
                    for metric in SUMMARY_METRICS
                } | {
                    "Character": source.cell(
                        row["_row_number"], source_headers["Character"]
                    ).value
                }
            )

        aggregates: dict[str, dict[str, Any]] = {}
        for (player_key, _), group in match_groups.items():
            aggregate = aggregates.setdefault(
                player_key,
                {
                    "name": group["name"],
                    "matches": 0,
                    "values": {metric: [] for metric in SUMMARY_METRICS},
                    "characters": [],
                },
            )
            aggregate["matches"] += 1
            aggregate["characters"].extend(
                row["Character"] for row in group["rows"]
            )
            for metric in SUMMARY_METRICS:
                usable = [
                    row[metric]
                    for row in group["rows"]
                    if _is_numeric(row[metric])
                ]
                if usable:
                    # If duplicate rows contain the same metric, first
                    # collapse them to one match value, then average matches.
                    aggregate["values"][metric].append(sum(usable) / len(usable))

        output = sorted(
            aggregates.values(),
            key=lambda item: normalize_name(item["name"]),
        )
        for row_number in range(6, max(summary.max_row, 6) + 1):
            for column in range(1, max(summary.max_column, len(summary_headers_list)) + 1):
                summary.cell(row_number, column).value = None

        for column, header in enumerate(summary_headers_list, start=1):
            summary.cell(5, column).value = header

        template_row = 6
        for index, aggregate in enumerate(output, start=6):
            if index > summary.max_row:
                summary.insert_rows(index)
                for column in range(1, len(summary_headers_list) + 1):
                    source_cell = summary.cell(template_row, column)
                    target_cell = summary.cell(index, column)
                    if source_cell.has_style:
                        target_cell._style = copy(source_cell._style)
                    target_cell.number_format = source_cell.number_format
            for column, style in template_styles.items():
                if style:
                    summary.cell(index, column)._style = copy(style)
            summary.cell(index, summary_headers["Player"]).value = aggregate["name"]
            summary.cell(index, summary_headers[SUMMARY_MATCH_COUNT_HEADER]).value = (
                aggregate["matches"]
            )
            favorite = _favorite_character(aggregate["characters"])
            if favorite:
                summary.cell(index, summary_headers[FAVORITE_CHARACTER_HEADER]).value = favorite["character"]
                summary.cell(index, summary_headers[FAVORITE_CHARACTER_COUNT_HEADER]).value = favorite["count"]
                summary.cell(index, summary_headers[FAVORITE_CHARACTER_PERCENTAGE_HEADER]).value = favorite["percentage"]
            for metric in SUMMARY_METRICS:
                values = aggregate["values"][metric]
                count_header = f"{metric} matches used"
                summary.cell(index, summary_headers[count_header]).value = len(values)
                summary.cell(index, summary_headers[metric]).value = (
                    sum(values) / len(values) if values else None
                )
            metric_averages = {
                metric: (
                    sum(values) / len(values) if values else None
                )
                for metric, values in aggregate["values"].items()
            }
            ratings = calculate_partial_overall_ratings(metric_averages)
            for label in OVERALL_RATING_COLUMNS:
                summary.cell(index, summary_headers[label]).value = ratings[label]

        last_output_row = 5 + len(output)
        if last_output_row < previous_last_row:
            summary.delete_rows(
                last_output_row + 1,
                previous_last_row - last_output_row,
            )
        table_end_column = get_column_letter(max(summary_headers.values()))
        for table in summary.tables.values():
            table.ref = f"A5:{table_end_column}{last_output_row}"
            table.tableColumns = [
                TableColumn(id=index, name=str(header))
                for index, header in enumerate(summary_headers_list, start=1)
            ]
            if table.autoFilter is not None:
                table.autoFilter.ref = table.ref
        summary.cell(3, 1).value = (
            f"Players represented: {len(output)} | "
            f"Unique matches: {sum(item['matches'] for item in output)}"
        )
        summary.cell(2, 1).value = (
            "AK Unique ID B defines one match per player. Duplicate Player + "
            "Unique ID B rows are collapsed first; each metric averages only "
            "matches where that metric is populated. Overall columns use "
            "WTSL-adapted ATP-style formulas from the available metrics."
        )


def append_rows(
    rows: list[dict[str, Any]],
    path: Path = MASTER_WORKBOOK,
    *,
    recalculate_summaries: bool = True,
) -> None:
    """Append extracted match rows and atomically replace the workbook.

    Summary sheets are recalculated by default so match previews always use
    current player statistics. Set recalculate_summaries=False only for an
    explicitly extraction-only workbook operation.
    """
    if not rows:
        return
    if not path.exists():
        raise FileNotFoundError(f"Stats workbook not found: {path}")
    sheets = {str(row.get("Sheet") or "").casefold() for row in rows}
    if len(sheets) != 1 or not sheets.issubset({"atp", "wta"}):
        raise ValueError("One append must contain rows for exactly one ATP/WTA sheet")
    sheet = sheets.pop()

    workbook = load_workbook(path, data_only=False)
    try:
        if sheet not in workbook.sheetnames:
            raise ValueError(f"Workbook has no {sheet!r} sheet")
        worksheet = workbook[sheet]
        _ensure_character_columns(worksheet)
        _ensure_derived_metric_columns(worksheet)
        headers = {
            str(cell.value).strip(): cell.column
            for cell in worksheet[1]
            if cell.value not in (None, "")
        }
        image_header = next(
            (header for header in headers if header == "Image Name" or header.startswith("Image Name (")),
            None,
        )
        unique_id_header = next(
            (header for header in ("Unique ID", "Unique ID A", "Full Unique ID") if header in headers),
            None,
        )
        required = {"ID", "Player", "Opponent", "Notes"}
        missing = required - headers.keys()
        if image_header is None:
            missing.add("Image Name")
        if unique_id_header is None:
            missing.add("Unique ID")
        if missing:
            raise ValueError(
                f"{sheet.upper()} sheet is missing headers: {', '.join(sorted(missing))}"
            )

        image_column = headers[image_header]
        last_row = _last_data_row(worksheet, image_column)
        numeric_ids = (
            int(worksheet.cell(row_number, headers["ID"]).value)
            for row_number in range(2, last_row + 1)
            if str(worksheet.cell(row_number, headers["ID"]).value or "").isdigit()
        )
        next_id = max(numeric_ids, default=0) + 1
        appended_row_numbers: list[int] = []

        for offset, row_values in enumerate(rows):
            target_row = last_row + offset + 1
            appended_row_numbers.append(target_row)
            source_row = target_row - 1
            worksheet.row_dimensions[target_row].height = (
                worksheet.row_dimensions[source_row].height
            )
            for column in range(1, worksheet.max_column + 1):
                source = worksheet.cell(source_row, column)
                target = worksheet.cell(target_row, column)
                if source.has_style:
                    target._style = copy(source._style)
                if source.hyperlink:
                    target._hyperlink = copy(source.hyperlink)
                if source.comment:
                    target.comment = copy(source.comment)
                target.value = None

            worksheet.cell(target_row, headers["ID"]).value = next_id + offset
            for header, value in row_values.items():
                if header == "Sheet":
                    continue
                target_header = image_header if header == "Image Name" else header
                if target_header not in headers:
                    continue
                if header == "Date" and isinstance(value, str) and value:
                    value = date.fromisoformat(value)
                worksheet.cell(target_row, headers[target_header]).value = value
            worksheet.cell(
                target_row, headers[unique_id_header]
            ).value = f"=B{target_row}&C{target_row}"

        if worksheet.auto_filter.ref:
            end_column = get_column_letter(max(headers.values()))
            worksheet.auto_filter.ref = f"A1:{end_column}{last_row + len(rows)}"
        if recalculate_summaries:
            recalculate_summary_sheets(workbook)
            workbook.calculation.fullCalcOnLoad = True
            workbook.calculation.forceFullCalc = True

        temporary = path.with_suffix(".tmp.xlsx")
        workbook.save(temporary)
    finally:
        workbook.close()

    # Refuse to replace the master if the generated workbook cannot be read or
    # does not contain both newly appended source rows.
    check = load_workbook(temporary, read_only=True, data_only=False)
    try:
        check_sheet = check[sheet]
        appended = [
            check_sheet.cell(row_number, image_column).value
            for row_number in appended_row_numbers
        ]
        expected = {str(row["Image Name"]) for row in rows}
        if not expected.issubset({str(value) for value in appended}):
            raise RuntimeError("Workbook append validation failed")
    finally:
        check.close()
    temporary.replace(path)


def workbook_has_source_message(
    message_id: int,
    path: Path = MASTER_WORKBOOK,
) -> bool:
    """The workbook is the dedupe authority if a crash precedes ledger update."""
    if not path.exists() or path.stat().st_size == 0:
        return False
    prefix = f"{message_id}_"
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        for sheet in ("atp", "wta"):
            worksheet = workbook[sheet]
            for (value,) in worksheet.iter_rows(
                min_row=2, min_col=2, max_col=2, values_only=True
            ):
                if str(value or "").startswith(prefix):
                    return True
        return False
    finally:
        workbook.close()


def verify_workbook_source_message(
    message_id: int,
    path: Path = MASTER_WORKBOOK,
    repair_formulas: bool = False,
) -> dict[str, Any]:
    """Assert that one source maps to one reciprocal row pair on one tour sheet."""
    prefix = f"{message_id}_"
    workbook = load_workbook(path, read_only=False, data_only=False)
    temporary = path.with_suffix(".verify.tmp.xlsx")
    repaired = False
    try:
        matches: list[tuple[str, int, dict[str, int]]] = []
        for sheet in ("atp", "wta"):
            worksheet = workbook[sheet]
            headers = {
                str(cell.value).strip(): cell.column
                for cell in worksheet[1]
                if cell.value not in (None, "")
            }
            image_header = next(
                (
                    header
                    for header in headers
                    if header == "Image Name" or header.startswith("Image Name (")
                ),
                None,
            )
            unique_id_header = next(
                (
                    header
                    for header in ("Unique ID", "Unique ID A", "Full Unique ID")
                    if header in headers
                ),
                None,
            )
            if image_header is None or unique_id_header is None:
                raise ValueError(f"{sheet.upper()} sheet has incompatible source headers")
            headers["Image Name"] = headers[image_header]
            headers["Unique ID"] = headers[unique_id_header]
            for row_number in range(2, worksheet.max_row + 1):
                value = worksheet.cell(row_number, headers["Image Name"]).value
                if str(value or "").startswith(prefix):
                    matches.append((sheet, row_number, headers))

        if len(matches) != 2:
            raise ValueError(
                f"Expected exactly 2 workbook rows for message {message_id}; "
                f"found {len(matches)}"
            )
        if matches[0][0] != matches[1][0]:
            raise ValueError("Source rows were split across ATP and WTA sheets")

        sheet = matches[0][0]
        worksheet = workbook[sheet]
        row_numbers = [item[1] for item in matches]
        headers = matches[0][2]
        first_player = str(
            worksheet.cell(row_numbers[0], headers["Player"]).value or ""
        )
        first_opponent = str(
            worksheet.cell(row_numbers[0], headers["Opponent"]).value or ""
        )
        second_player = str(
            worksheet.cell(row_numbers[1], headers["Player"]).value or ""
        )
        second_opponent = str(
            worksheet.cell(row_numbers[1], headers["Opponent"]).value or ""
        )
        if normalize_name(first_player) != normalize_name(second_opponent) or (
            normalize_name(first_opponent) != normalize_name(second_player)
        ):
            raise ValueError("Workbook source rows are not reciprocal player/opponent rows")

        for row_number in row_numbers:
            unique_cell = worksheet.cell(row_number, headers["Unique ID"])
            expected_formula = f"=B{row_number}&C{row_number}"
            if unique_cell.value != expected_formula:
                if not repair_formulas:
                    raise ValueError(
                        f"Missing Unique ID formula at {unique_cell.coordinate}"
                    )
                unique_cell.value = expected_formula
                repaired = True
        if repaired:
            workbook.calculation.fullCalcOnLoad = True
            workbook.calculation.forceFullCalc = True
            workbook.save(temporary)
    finally:
        workbook.close()

    if repaired:
        check = load_workbook(temporary, read_only=True, data_only=False)
        try:
            check_sheet = check[sheet]
            for row_number in row_numbers:
                if (
                    check_sheet.cell(row_number, headers["Unique ID"]).value
                    != f"=B{row_number}&C{row_number}"
                ):
                    raise RuntimeError("Workbook source formula repair validation failed")
        finally:
            check.close()
        temporary.replace(path)


def apply_review_annotations(
    annotations_by_tour: dict[
        str,
        dict[str | tuple[str, str], dict[str, str]],
    ],
    path: Path = MASTER_WORKBOOK,
) -> int:
    """Write filterable screenshot-review annotations to the ATP/WTA source tabs."""
    if not path.exists():
        raise FileNotFoundError(f"Stats workbook not found: {path}")
    normalized: dict[
        str,
        dict[tuple[str, str], dict[str, str]],
    ] = {"atp": {}, "wta": {}}
    for tour, entries in annotations_by_tour.items():
        tour_key = str(tour).casefold()
        if tour_key not in normalized or not isinstance(entries, dict):
            continue
        for locator, annotation in entries.items():
            if not isinstance(annotation, dict):
                continue
            if isinstance(locator, tuple) and len(locator) == 2:
                player_key = normalize_name(
                    _canonicalize_name_alias(_clean_cell_text(locator[0]))
                )
                match_key = _clean_cell_text(locator[1]).casefold()
            else:
                player_key = ""
                match_key = _clean_cell_text(locator).casefold()
            if not match_key:
                continue
            normalized[tour_key][(player_key, match_key)] = {
                "status": _clean_cell_text(annotation.get("status")),
                "reason": _clean_cell_text(annotation.get("reason")),
            }
    temporary = path.with_name(f".{path.stem}.review-annotations.tmp.xlsx")
    workbook = load_workbook(path, data_only=False)
    changed = 0
    marked = 0
    try:
        for tour in ("atp", "wta"):
            if tour not in workbook.sheetnames:
                continue
            worksheet = workbook[tour]
            seen_annotated_matches: set[tuple[str, str]] = set()
            headers = {
                str(cell.value).strip(): cell.column
                for cell in worksheet[1]
                if cell.value not in (None, "")
            }
            status_column = headers.get(REVIEW_STATUS_HEADER)
            reason_column = headers.get(REVIEW_REASON_HEADER)
            if status_column is None:
                status_column = worksheet.max_column + 1
                worksheet.cell(1, status_column, REVIEW_STATUS_HEADER)
                changed += 1
                worksheet.column_dimensions[
                    get_column_letter(status_column)
                ].width = 16
            if reason_column is None:
                reason_column = worksheet.max_column + 1
                worksheet.cell(1, reason_column, REVIEW_REASON_HEADER)
                changed += 1
                worksheet.column_dimensions[
                    get_column_letter(reason_column)
                ].width = 54
            match_key_column = headers.get(MATCH_KEY_HEADER)
            player_column = headers.get("Player")
            if match_key_column is None:
                raise ValueError(
                    f"{tour.upper()} sheet is missing {MATCH_KEY_HEADER!r}"
                )
            if player_column is None:
                raise ValueError(f"{tour.upper()} sheet is missing 'Player'")
            for row_number in range(2, worksheet.max_row + 1):
                player_key = normalize_name(_canonicalize_name_alias(
                    _clean_cell_text(
                        worksheet.cell(row_number, player_column).value
                    )
                ))
                match_key = _clean_cell_text(
                    worksheet.cell(row_number, match_key_column).value
                ).casefold()
                annotation = (
                    normalized[tour].get((player_key, match_key))
                    or normalized[tour].get(("", match_key))
                    or {}
                )
                locator = (player_key, match_key)
                if annotation and locator in seen_annotated_matches:
                    status = "DUPLICATE"
                    reason = (
                        f"Duplicate row for {annotation.get('status', 'review')} "
                        "match; review the first row with this match key."
                    )
                else:
                    status = annotation.get("status", "")
                    reason = annotation.get("reason", "")
                    if annotation:
                        seen_annotated_matches.add(locator)
                if status:
                    marked += 1
                for column, value in (
                    (status_column, status),
                    (reason_column, reason),
                ):
                    cell = worksheet.cell(row_number, column)
                    if cell.value != value:
                        cell.value = value
                        changed += 1
            worksheet.auto_filter.ref = worksheet.dimensions
        if changed:
            workbook.save(temporary)
    finally:
        workbook.close()
    if changed:
        os.replace(temporary, path)
    elif temporary.exists():
        temporary.unlink()
    return marked

    return {
        "sheet": sheet,
        "rows": row_numbers,
        "player": first_player,
        "opponent": first_opponent,
        "repaired_formulas": repaired,
    }


def load_processed() -> set[str]:
    try:
        data = json.loads(PROCESSED_FILE.read_text(encoding="utf-8"))
        return set(str(item) for item in data)
    except Exception:
        return set()


def save_processed(keys: set[str]) -> None:
    temporary = PROCESSED_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(sorted(keys), indent=2), encoding="utf-8")
    temporary.replace(PROCESSED_FILE)

def _copy_workbook_cell(source_cell: Any, target_cell: Any) -> None:
    target_cell.value = source_cell.value
    if isinstance(source_cell.value, str) and source_cell.value.startswith("="):
        try:
            from openpyxl.formula.translate import Translator
            target_cell.value = Translator(
                source_cell.value,
                origin=source_cell.coordinate,
            ).translate_formula(target_cell.coordinate)
        except Exception:
            # A formula that cannot be translated is still more useful than
            # dropping the source value during a cross-sheet correction.
            target_cell.value = source_cell.value
    if source_cell.has_style:
        target_cell._style = copy(source_cell._style)
    if source_cell.number_format:
        target_cell.number_format = source_cell.number_format
    if source_cell.hyperlink:
        target_cell._hyperlink = copy(source_cell.hyperlink)
    if source_cell.comment:
        target_cell.comment = copy(source_cell.comment)

def correct_existing_match_tours(
    official_results: list[dict[str, Any]],
    path: Path = MASTER_WORKBOOK,
) -> dict[str, Any]:
    """Move only exact official-result tour corrections between source sheets.

    Rows are matched by player pair, date, and complete score. A unique
    official result whose tour disagrees with the stored sheet moves every
    confidently matched row for that match, including its reciprocal row.
    Source values, styles, formulas, and review annotations are copied before
    the source rows are removed; both summary sheets are then rebuilt from the
    same in-memory workbook and replaced atomically.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Stats workbook not found: {path}")

    workbook = load_workbook(path, data_only=False)
    temporary = path.with_name(f".{path.stem}.tour-correction.tmp{path.suffix}")
    moves: list[dict[str, Any]] = []
    try:
        rows_by_key: dict[tuple[Any, ...], list[dict[str, Any]]] = {}
        for tour in ("atp", "wta"):
            sheet = workbook[tour]
            headers = {
                _workbook_header_key(sheet.cell(1, column).value): column
                for column in range(1, sheet.max_column + 1)
                if sheet.cell(1, column).value not in (None, "")
            }
            required = ("player", "opponent", "date", "result")
            if any(header not in headers for header in required):
                raise ValueError(
                    f"{tour.upper()} sheet is missing a tour-correction field"
                )
            for row_number in range(2, sheet.max_row + 1):
                player = sheet.cell(row_number, headers["player"]).value
                opponent = sheet.cell(row_number, headers["opponent"]).value
                match_date = sheet.cell(row_number, headers["date"]).value
                result = sheet.cell(row_number, headers["result"]).value
                match_key = _tour_correction_match_key(
                    player, opponent, match_date, result
                )
                if match_key is None:
                    continue
                official = find_confident_official_match(
                    official_results,
                    player,
                    opponent,
                    match_date,
                    result,
                    name_aliases=NAME_ALIASES,
                )
                if official is None:
                    continue
                official_tour = str(official.get("tour") or "").casefold()
                if official_tour not in {"atp", "wta"} or official_tour == tour:
                    continue
                rows_by_key.setdefault(match_key, []).append({
                    "source_tour": tour,
                    "source_row": row_number,
                    "official_tour": official_tour,
                    "official": official,
                })

        for match_key, candidates in rows_by_key.items():
            # Keep the correction fail-closed if an unusual workbook has
            # conflicting official tours for the same stored match identity.
            official_tours = {candidate["official_tour"] for candidate in candidates}
            if len(official_tours) != 1:
                continue
            moves.extend(candidates)

        if moves:
            # Capture the destination header maps after discovering all moves.
            destination_headers: dict[str, dict[str, int]] = {}
            for tour in ("atp", "wta"):
                sheet = workbook[tour]
                destination_headers[tour] = {
                    _workbook_header_key(sheet.cell(1, column).value): column
                    for column in range(1, sheet.max_column + 1)
                    if sheet.cell(1, column).value not in (None, "")
                }

            for move in moves:
                source = workbook[move["source_tour"]]
                target_tour = move["official_tour"]
                target = workbook[target_tour]
                source_headers = {
                    _workbook_header_key(source.cell(1, column).value): column
                    for column in range(1, source.max_column + 1)
                    if source.cell(1, column).value not in (None, "")
                }
                target_headers = destination_headers[target_tour]
                for key, source_column in source_headers.items():
                    if key in target_headers:
                        continue
                    source_header = source.cell(1, source_column).value
                    new_column = target.max_column + 1
                    target.cell(1, new_column).value = source_header
                    target_headers[key] = new_column
                source_row = move["source_row"]
                target_row = target.max_row + 1
                for key, source_column in source_headers.items():
                    target_column = target_headers[key]
                    _copy_workbook_cell(
                        source.cell(source_row, source_column),
                        target.cell(target_row, target_column),
                    )
                source_dimension = source.row_dimensions[source_row]
                if source_dimension.height is not None:
                    target.row_dimensions[target_row].height = source_dimension.height
                move["target_row"] = target_row

            rows_to_delete: dict[str, list[int]] = {"atp": [], "wta": []}
            for move in moves:
                rows_to_delete[move["source_tour"]].append(move["source_row"])
            for tour, row_numbers in rows_to_delete.items():
                sheet = workbook[tour]
                for row_number in sorted(set(row_numbers), reverse=True):
                    sheet.delete_rows(row_number)

        recalculate_summary_sheets(workbook)
        workbook.calculation.fullCalcOnLoad = True
        workbook.calculation.forceFullCalc = True
        workbook.save(temporary)
    finally:
        workbook.close()
    temporary.replace(path)
    return {
        "moved_rows": len(moves),
        "moved_matches": len({
            _tour_correction_match_key(
                move["official"].get("player1"),
                move["official"].get("player2"),
                move["official"].get("date"),
                move["official"].get("result"),
            )
            for move in moves
        }),
        "moves": [
            {
                "from": move["source_tour"],
                "to": move["official_tour"],
                "player1": move["official"].get("player1") or move["official"].get("p1"),
                "player2": move["official"].get("player2") or move["official"].get("p2"),
                "date": move["official"].get("date"),
                "result": move["official"].get("result"),
            }
            for move in moves
        ],
    }

def _workbook_header_key(value: Any) -> str:
    header = _clean_cell_text(value)
    if header.casefold().startswith("image name"):
        return "image name"
    return header.casefold()
