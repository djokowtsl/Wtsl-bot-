from keep_alive import keep_alive
if __name__ == "__main__":
    # Start the HTTP health endpoint before importing the heavyweight bot and
    # statistics modules. VM promotion can then verify / while Discord boots.
    keep_alive()
import time
import re
import asyncio
import json
import io
import typing
import functools
import shutil
from collections import defaultdict
import aiohttp
from datetime import datetime
import pip
from ai_budget import (
    AIBudgetExceeded,
    AIBudgetStateError,
    BudgetedOpenAI as OpenAI,
)
from twitter_bridge import (
    TwitterConfigurationError,
    TwitterPoster,
    build_tweet_text,
    is_image_attachment,
)
AI_MODEL = "gpt-5-mini"
INTERVIEW_OPENING_TIMEOUT_SECONDS = 45
INTERVIEW_OPENAI_TIMEOUT_SECONDS = 30.0
INTERVIEW_FALLBACK_OPENING_QUESTION = (
    "What was the key moment in the match for you?"
)
INTERVIEW_FALLBACK_FOLLOWUP = (
    "Thanks for that — what was the biggest adjustment you made as the match went on?"
)
INTERVIEW_REPLY_COMPLETION_TOKENS = 768
INTERVIEW_RECOVERY_LOOKBACK_SECONDS = 48 * 60 * 60
INTERVIEW_RECOVERY_DELAY_SECONDS = 20
#pip install flask
#import join
#!pip install lxml
#pip install tweepy --upgrade
import xlwt
import xlrd
import lxml
import bracket
import predictions
from predictions import data, data2, headtohead, unplayed, fixText, calcWp, createTuple, writeMatrixCSV
import tweepy
import pandas as pd
import numpy as np
import discord
import os, types
from os import system
import subprocess
import random, copy
import math
import datetime
import requests
import csv
import hashlib
from urllib.parse import parse_qs, urlparse
from decimal import Decimal, InvalidOperation
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace
from flask import Flask, Response, request
import bs4
from bs4 import BeautifulSoup
from tennis_stats_scraper import (
    MASTER_WORKBOOK as MATCH_STATS_WORKBOOK,
    PROCESSED_FILE as MATCH_STATS_RECEIPTS_FILE,
    SUMMARY_METRICS as SCREENSHOT_LEADERBOARD_METRICS,
    apply_review_annotations as apply_screenshot_review_annotations,
    append_rows as append_match_stats_rows,
    build_rows as build_match_stats_rows,
    canonicalize_match,
    extract_match,
    fetch_canonical_rankings,
    export_atp_columns_csv,
    load_processed as load_processed_stats,
    NAME_ALIASES as SCREENSHOT_NAME_ALIASES,
    leaderboard_rows as get_screenshot_leaderboard_rows,
    match_record_summaries as get_screenshot_match_record_summaries,
    player_summary as get_screenshot_player_summary,
    query_match_stat_values as query_screenshot_match_stat_values,
    save_processed as save_processed_stats,
    promote_statistics_workbook,
    validate_extracted,
    verify_workbook_source_message,
    workbook_has_source_message,
)
from screenshot_stats_store import (
    persist_processed_messages as persist_screenshot_receipts,
    persist_workbook as persist_screenshot_workbook,
    restore_current_snapshot as restore_screenshot_workbook_from_store,
    restore_or_seed as restore_screenshot_stats_store,
)
from match_preview import (
    PlayerResolutionError,
    _parse_ranking_table,
    collect_match_data,
    fetch_player_results,
    fetch_rankings as fetch_match_preview_rankings,
    format_match_preview,
    personalized_match_keys,
    parse_player_avatar,
    result_period_summary_text,
    season_summary_text,
    split_discord_message,
    winner_for_result,
)
from player_insights import metric_insight, training_focus
from outreach import (
    OutreachState,
    fixture_key,
    parse_h2h_percentage_odds,
    parse_official_player_avatar,
    parse_reported_tournament_results,
    parse_scheduled_tournament_fixtures,
    parse_upcoming_fixtures,
    resolve_member_exact,
    tour_from_tournament_id,
)
from deadline_reminders import (
    DeadlineReminderState,
    discord_lookup_name,
    ONGOING_TOURNAMENTS_URL,
    ONGOING_TOURNAMENTS_WTA_URL,
    TOURNAMENT_PAGE_URL,
    admin_reminder_window,
    parse_completed_draw_matches,
    parse_challonge_svg_url,
    parse_draw_matches,
    parse_ongoing_tournaments,
    parse_tournament_directory,
    reminder_key,
    reminder_window,
    reminder_window_started_at,
)
from matchlog_stats import (
    AmbiguousPlayerNameError,
    ALL_RESULTS_URL as MATCHLOG_ALL_RESULTS_URL,
    SUMMARY_STATS as MATCHLOG_SUMMARY_STATS,
    append_submission as append_matchlog_submission,
    bind_player_identity as bind_matchlog_player_identity,
    build_composite_log_csv as build_matchlog_composite_csv,
    build_screenshot_stats_upload_csv as build_screenshot_player_upload_csv,
    build_upload_csv as build_matchlog_upload_csv,
    canonicalize_and_verify as verify_matchlog_matches,
    format_player_summary as format_matchlog_player_summary,
    format_player_comparison as format_matchlog_player_comparison,
    identifiable_raw_coverage as get_identifiable_raw_coverage,
    normalize_name as normalize_matchlog_name,
    parse_matchlog_html,
    parse_official_results as parse_matchlog_official_results,
    leaderboard_rows as get_matchlog_leaderboard_rows,
    player_summary as get_matchlog_player_summary,
    player_summary_by_name as get_matchlog_player_summary_by_name,
    player_summary_names as get_matchlog_player_summary_names,
    query_match_stat_values,
    reconcile_source_matches as reconcile_matchlog_source,
    SUMMARY_STATS as MATCHLOG_STATS,
    rebuild_from_sources as rebuild_matchlog_from_sources,
    reset_matchlog_data,
    select_official_matches,
)
from character_stats import (
    attribute_names as get_character_attribute_names,
    attribute_ranking as get_character_attribute_ranking,
    compare_characters as compare_character_profiles,
    character_names as get_character_names,
    character_profile as get_character_profile,
    country_flag as get_country_flag,
    current_workbook_path as get_character_workbook_path,
    fetch_official_profile as fetch_character_official_profile,
    format_ranked_line as format_character_ranked_line,
    format_value as format_character_value,
    install_workbook as install_character_workbook,
    recommend_characters as recommend_character_choices,
    resolve_attribute as resolve_character_attribute,
    resolve_character,
)
from matchlog_store import (
    MATCHLOG_VERIFICATION_VERSION,
    load_bot_message,
    load_identity as load_matchlog_identity,
    load_identities as load_matchlog_identities,
    load_source_message_ids as load_matchlog_source_message_ids,
    load_sources as load_matchlog_sources,
    load_outreach_state,
    release_bot_lease,
    release_verification_request,
    reserve_verification_request,
    save_bot_message,
    load_match_schedules,
    save_match_schedule,
    update_match_schedule,
    claim_match_scheduler_notice,
    mark_match_scheduler_notice_sent,
    match_scheduler_notice_was_sent,
    release_match_scheduler_notice,
    save_identity as save_matchlog_identity,
    save_reverified_sources as save_reverified_matchlog_sources,
    save_source as save_matchlog_source,
    save_outreach_state,
    try_acquire_bot_lease,
)
from overall_ratings import (
    calculate_partial_overall_ratings,
    rating_formula_footnote,
)
from wtsl_results import (
    get_all_results,
    get_tournament_schedule,
    result_score_equivalence_key,
)
from predictions_leaderboard import (
    aggregate_prediction_rows,
    auto_link_prediction_identities,
    create_prediction_link_request,
    ensure_prediction_tables,
    load_prediction_identity_links,
    link_prediction_identity_direct,
    list_pending_prediction_link_requests,
    load_prediction_leaderboard,
    load_successful_prediction_scan_ids,
    parse_prediction_module,
    prediction_module_url,
    approve_prediction_link_request,
    record_prediction_tournament_scans,
    relink_prediction_identity,
    reject_prediction_link_request,
    upsert_prediction_entries,
)

# Initialize Flask app
app = Flask(__name__)

from keep_alive import keep_alive
import time
import re
import asyncio
import json
import io
import typing
import aiohttp
from datetime import datetime
import pip
from ai_budget import (
    AIBudgetExceeded,
    AIBudgetStateError,
    BudgetedOpenAI as OpenAI,
)
AI_MODEL = "gpt-5-mini"
#pip install flask
#import join
#!pip install lxml
#pip install tweepy --upgrade
import xlwt
import xlrd
import lxml
import bracket
import predictions
from predictions import data, data2, headtohead, unplayed, fixText, calcWp, createTuple, writeMatrixCSV
import tweepy
import pandas as pd
import numpy as np
import discord
import os, types
from os import system
import subprocess
import random, copy
import math
import datetime
import requests
import csv
import hashlib
from pathlib import Path
from types import SimpleNamespace
from flask import Flask, Response, request
import bs4
from bs4 import BeautifulSoup
from tennis_stats_scraper import (
    MASTER_WORKBOOK as MATCH_STATS_WORKBOOK,
    SUMMARY_METRICS as SCREENSHOT_LEADERBOARD_METRICS,
    apply_review_annotations as apply_screenshot_review_annotations,
    append_rows as append_match_stats_rows,
    build_rows as build_match_stats_rows,
    canonicalize_match,
    extract_match,
    fetch_canonical_rankings,
    export_atp_columns_csv,
    load_processed as load_processed_stats,
    NAME_ALIASES as SCREENSHOT_NAME_ALIASES,
    leaderboard_rows as get_screenshot_leaderboard_rows,
    match_record_summaries as get_screenshot_match_record_summaries,
    player_summary as get_screenshot_player_summary,
    save_processed as save_processed_stats,
    promote_statistics_workbook,
    validate_extracted,
    verify_workbook_source_message,
    workbook_has_source_message,
)
from match_preview import (
    PlayerResolutionError,
    _parse_ranking_table,
    collect_match_data,
    fetch_player_results,
    fetch_rankings as fetch_match_preview_rankings,
    format_match_preview,
    personalized_match_keys,
    parse_player_avatar,
    result_period_summary_text,
    season_summary_text,
    split_discord_message,
    winner_for_result,
)
from player_insights import metric_insight, training_focus
from outreach import (
    OutreachState,
    fixture_key,
    parse_h2h_percentage_odds,
    parse_scheduled_tournament_fixtures,
    parse_upcoming_fixtures,
    resolve_member_exact,
)
from deadline_reminders import (
    DeadlineReminderState,
    discord_lookup_name,
    ONGOING_TOURNAMENTS_URL,
    TOURNAMENT_PAGE_URL,
    parse_challonge_svg_url,
    parse_draw_matches,
    parse_ongoing_tournaments,
    parse_tournament_directory,
    reminder_key,
    reminder_window,
    reminder_window_started_at,
)
from matchlog_stats import (
    AmbiguousPlayerNameError,
    ALL_RESULTS_URL as MATCHLOG_ALL_RESULTS_URL,
    SUMMARY_STATS as MATCHLOG_SUMMARY_STATS,
    append_submission as append_matchlog_submission,
    bind_player_identity as bind_matchlog_player_identity,
    build_composite_log_csv as build_matchlog_composite_csv,
    build_screenshot_stats_upload_csv as build_screenshot_player_upload_csv,
    build_upload_csv as build_matchlog_upload_csv,
    canonicalize_and_verify as verify_matchlog_matches,
    format_player_summary as format_matchlog_player_summary,
    format_player_comparison as format_matchlog_player_comparison,
    identifiable_raw_coverage as get_identifiable_raw_coverage,
    normalize_name as normalize_matchlog_name,
    parse_matchlog_html,
    parse_official_results as parse_matchlog_official_results,
    leaderboard_rows as get_matchlog_leaderboard_rows,
    player_summary as get_matchlog_player_summary,
    player_summary_by_name as get_matchlog_player_summary_by_name,
    player_summary_names as get_matchlog_player_summary_names,
    reconcile_source_matches as reconcile_matchlog_source,
    rebuild_from_sources as rebuild_matchlog_from_sources,
    reset_matchlog_data,
    select_official_matches,
)
from matchlog_store import (
    MATCHLOG_VERIFICATION_VERSION,
    load_bot_message,
    load_identity as load_matchlog_identity,
    load_identities as load_matchlog_identities,
    load_source_message_ids as load_matchlog_source_message_ids,
    load_sources as load_matchlog_sources,
    load_outreach_state,
    release_bot_lease,
    release_verification_request,
    reserve_verification_request,
    save_bot_message,
    save_identity as save_matchlog_identity,
    save_reverified_sources as save_reverified_matchlog_sources,
    save_source as save_matchlog_source,
    save_outreach_state,
    try_acquire_bot_lease,
)
from overall_ratings import (
    calculate_partial_overall_ratings,
    rating_formula_footnote,
)
from wtsl_betting import (
    POOL_TAKEOUT,
    REFERRAL_REWARD,
    attach_pending_referrals,
    bet_return_breakdown,
    claim_notification_receipt,
    claim_pending_referral_reminders,
    create_referral,
    get_fixture as get_betting_fixture,
    leaderboard as get_betting_leaderboard,
    list_unnotified_referral_rewards,
    list_unnotified_refunded_bets,
    list_unnotified_winning_bets,
    list_open_fixtures as list_open_betting_fixtures,
    list_recent_settled_fixtures,
    list_user_bets,
    load_account as load_betting_account,
    house_adjusted_odds,
    hybrid_guaranteed_odds,
    mark_notification_sent,
    place_bet as place_wtsl_bet,
    place_parlay as place_wtsl_parlay,
    pool_decimal_odds,
    reset_all_betting_data,
    release_notification_receipt,
    seed_account as seed_wtsl_account,
    settle_fixture as settle_betting_fixture,
    settle_referral_rewards,
    sync_fixture as sync_betting_fixture,
    weekly_betting_earner,
)
from wtsl_results import (
    enrich_event_metadata,
    get_all_results,
    is_exhibition_tournament,
    merge_player_recent_results,
    tournament_category,
)

# Initialize Flask app
app = Flask(__name__)

@app.route('/')
def home():
    return "Bot is running!"

rankings = pd.read_csv('rankingscsv.csv')
rankings.set_index('name', inplace = True)
#install requests bs4 tqdm
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo
import warnings
warnings.filterwarnings("ignore")


from discord.ext import commands, tasks
from discord import app_commands


'''class MyClient(discord.Client):
   async def on_ready(self):
        print('Logged in as')
        print(self.user.name)
        print(self.user.id)
        print('------')
        print(f'{self.user} succesfully logged in!')
        #print('bot has started')
        djokorer = await self.fetch_user(859691230941282304)
        await djokorer.send('bot has started')'''


'''from discord.ext.commands import AutoShardedBot
from discord import Intents
#client = discord.Client()
#@client.event
#async def on_ready():
#    print('We have logged in as {0.user}'.format(client))

#@client.event
#async def on_message(message):
#    if message.author == client.user:
#        return
#    if message.content.startswith('$hello'):
#        await message.channel.send('Hello!')
class Example(AutoShardedBot):
    def __init__(self):
        super().__init__(
            command_prefix = "!",
            description = "test",
            help_command = None,
            shard_count = 1,
            intents = Intents.all()
        )
        self.run()
            
    def run(self) -> None:
        super().run(
        token = "",
        reconnect = True,
        )
    async def on_ready(self):
        print(f"Logged in as {self.user} (ID: {self.user.id})")
        djokorer = await client.fetch_user(859691230941282304)
        await djokorer.send('bot has started')
        try:
          today.start()
        #  await asyncio.sleep(10)# important to start the loop
        except:
            today.cancel() 
            today.start()
        #await asyncio.sleep(60)
        #  pass
Example()
'''

intents = discord.Intents.all()
intents.message_content = True
intents.members = True


class WTSLBot(commands.Bot):
    async def setup_hook(self) -> None:
        self.add_view(WTSLVerificationRequestView())
        print("[setup_hook] WTSL verification request view registered")
        self.add_view(PredictionLinkRequestView())
        print("[setup_hook] prediction link request view registered")


client = WTSLBot(command_prefix="!", intents=intents)

# -------------------------
# RATE-LIMIT + NETWORK HARDENING PATCH
# (Drop-in replacements for live-score loops + helpers)
# -------------------------

import aiohttp
import asyncio
import time
import discord

# ---- Tuning knobs (safe defaults) ----
LIVE_POLL_INTERVAL = 2                 # keep your 2s polling if you want
MIN_SECONDS_BETWEEN_EDITS = 7.0        # IMPORTANT: raise this to avoid 429 (was too low)
HTTP_TIMEOUT_TOTAL = 15
HTTP_BACKOFF_MAX = 60


async def safe_edit(message, *, content=None, embed=None):
    while True:
        try:
            return await message.edit(content=content, embed=embed)
        except discord.NotFound:
            raise
        except discord.HTTPException as e:
            if getattr(e, "status", None) == 429:
                await asyncio.sleep(5)
            else:
                raise


async def fetch_poll_text_with_retry(session: aiohttp.ClientSession, url: str, *, tries: int = 3) -> str:
    backoff = 1
    last_exc = None
    for _ in range(max(1, tries)):
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status == 429:
                    ra = resp.headers.get("Retry-After")
                    if ra:
                        try:
                            await asyncio.sleep(float(ra))
                        except Exception:
                            await asyncio.sleep(backoff)
                    else:
                        await asyncio.sleep(backoff)
                    backoff = min(10, backoff * 2)
                    continue
                resp.raise_for_status()
                return (await resp.text()).strip()
        except Exception as e:
            last_exc = e
            await asyncio.sleep(backoff)
            backoff = min(10, backoff * 2)
    if last_exc:
        raise last_exc
    return ""

# -------------------------
# SET ANYONE LIVE SYSTEM — EVENT-BASED LIVE EMBED (Hosts + Live Scores)
# ✅ One message per active hosting cycle, replaced for each new host
# ✅ No role pings: the live embed is the hosting notification
# ✅ Recent Hosts list with "just now" + minutes ago
# ✅ Recent Hosts expire after 15 minutes (hard TTL) — no “hours ago” stuck entries
# ✅ Live matches show mode + best-of (BO1/BO3/BO5)
# ✅ Fixes KeyError('court')
# ✅ Signature includes embed.description + fields to ensure live score updates
# ✅ Footer removed (no "Fetch/Ping check/TTL" clutter)
# -------------------------

import re
import asyncio
import aiohttp
import discord
from datetime import datetime

TE4_SERVERLIST_URL = "https://www.managames.com/tennis/online/TE4_ServerList.php?Poll=1"

SET_ANYONE_CHANNEL_ID = 945356390942277652
WTSL_MASTER_MESSAGE_KEY = "wtsl_set_anyone_live"

ALERT_POLL_INTERVAL = 10   # how often we *evaluate* NEW hosts/matches for pinging
LIVE_POLL_INTERVAL  = 2    # how often we fetch TE4 server list

WTSL_EMBED_COLOR = 0x39FF14

# Recent Hosts settings
RECENT_HOST_TTL_SECONDS = 15 * 60     # 15 minutes

# State
_last_seen_hosts = set()      # (host_lower, court_short_lower)
_last_seen_matches = set()    # set of match pair keys
_wtsl_master_message_id = None

# Recent host tracking
_recent_hosts = {}            # host_lower -> {"host": str, "court": str, "court_short": str, "ts": float}

# Task handle
_wtsl_master_task = None


# ---------- Helpers: tokenization / block splitting ----------

def tokenize_poll_text(text: str):
    parts = re.findall(r'"([^"]*)"|(\S+)', text)
    tokens = []
    for q, n in parts:
        if q != "":
            tokens.append((q, True))
        else:
            tokens.append((n, False))
    return tokens

def split_into_blocks(tokens):
    hex_re = re.compile(r"^[0-9A-F]{2,6}$", re.IGNORECASE)
    ip_re  = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")

    blocks, cur = [], []
    i, n = 0, len(tokens)

    while i < n:
        val, is_q = tokens[i]
        starts_entry = False

        if not is_q and (i + 1) < n:
            nxt, nxt_q = tokens[i + 1]
            if not nxt_q and hex_re.match(nxt):
                if val == "0" or ip_re.match(val):
                    starts_entry = True

        if starts_entry:
            if cur:
                blocks.append(cur)
            cur = [(val, is_q)]
            i += 1
            continue

        cur.append((val, is_q))
        i += 1

    if cur:
        blocks.append(cur)

    return blocks


# ---------- Helpers: parsing / formatting / gameinfo ----------

def match_pair_key(name_field: str):
    parts = re.split(r"\s+vs\s+", name_field or "", flags=re.IGNORECASE)
    if len(parts) != 2:
        return None
    p1 = parts[0].strip().lower()
    p2 = parts[1].strip().lower()
    if not p1 or not p2:
        return None
    return tuple(sorted((p1, p2)))

def _short_court(court: str) -> str:
    return re.sub(r'^\s*\d+\s+', '', str(court)).strip() or "—"

def surface_icon(court):
    c = str(court).lower()
    if any(x in c for x in ["clay", "roland", "rg"]): return "🟧"
    if any(x in c for x in ["grass", "wimbledon"]): return "🟩"
    if any(x in c for x in ["indoor", "arena"]): return "🟪"
    if any(x in c for x in ["open", "ao", "us open"]): return "🟦"
    return "🎾"

def _pill(text: str) -> str:
    return f"`{text}`"

def _hex_to_int(x: str) -> int:
    try:
        return int(str(x), 16)
    except:
        return 0

def _bits(value: int, offset: int, width: int) -> int:
    return (value >> offset) & ((1 << width) - 1)

def decode_gameinfo(gameinfo_hex: str) -> dict:
    gi = int(str(gameinfo_hex), 16)

    player_cfg = _bits(gi, 2, 3)
    nb_set     = _bits(gi, 5, 2)

    mode = {
        0: "Singles",
        2: "Competitive Doubles",
        3: "Cooperative Doubles",
    }.get(player_cfg, f"Mode({player_cfg})")

    best_of = {
        0: "Best of 1",
        1: "Best of 1",   # seen in the wild
        2: "Best of 3",
        3: "Best of 5",
    }.get(nb_set, "Best of 1")

    return {"mode": mode, "best_of": best_of}


# ---------- Network ----------

async def fetch_poll_text_with_retry(session: aiohttp.ClientSession, url: str, *, tries: int = 3) -> str:
    backoff = 1
    last_exc = None
    for _ in range(max(1, tries)):
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status == 429:
                    ra = resp.headers.get("Retry-After")
                    if ra:
                        try:
                            await asyncio.sleep(float(ra))
                        except Exception:
                            await asyncio.sleep(backoff)
                    else:
                        await asyncio.sleep(backoff)
                    backoff = min(10, backoff * 2)
                    continue
                resp.raise_for_status()
                return (await resp.text()).strip()
        except Exception as e:
            last_exc = e
            await asyncio.sleep(backoff)
            backoff = min(10, backoff * 2)
    if last_exc:
        raise last_exc
    return ""


# ---------- Parser: STRICT XKT(WTSL) ----------

def parse_xkt_wtsl_hosts_and_matches(poll_text: str):
    if not poll_text:
        return [], []

    tokens = tokenize_poll_text(poll_text)
    blocks = split_into_blocks(tokens)

    hosts, matches = [], []

    for block in blocks:
        if len(block) < 14:
            continue

        i = 0
        _ip = block[i][0]; i += 1
        _port_hex = block[i][0]; i += 1

        if i >= len(block) or not block[i][1]:
            continue
        name_field = block[i][0]; i += 1

        if i + 3 >= len(block):
            continue
        gameinfo_hex = block[i][0]; i += 1
        _maxping_hex = block[i][0]; i += 1
        elo1_hex     = block[i][0]; i += 1
        _nbgame_hex  = block[i][0]; i += 1

        if i >= len(block) or not block[i][1]:
            continue
        tagline = (block[i][0] or "").strip(); i += 1

        if i >= len(block) or not block[i][1]:
            continue
        score_field = (block[i][0] or "").strip(); i += 1

        if i + 2 >= len(block):
            continue
        other_elo_hex = block[i][0]; i += 1
        _giveup_hex   = block[i][0]; i += 1
        _rep_hex      = block[i][0]; i += 1

        if i >= len(block) or not block[i][1]:
            continue
        court_field = (block[i][0] or "").strip(); i += 1

        # STRICT: must contain XKT(WTSL) in tagline
        if "XKT(WTSL)" not in str(tagline).upper():
            continue

        settings = decode_gameinfo(gameinfo_hex)
        elo1 = _hex_to_int(elo1_hex)
        elo2 = _hex_to_int(other_elo_hex)

        is_vs = bool(re.search(r"\bvs\b", str(name_field), re.IGNORECASE))
        court_short = _short_court(court_field)
        court_str = court_field if court_field else "—"  # ✅ prevents KeyError('court')

        # Hosting (score is "..." on server list)
        if (not is_vs) and score_field == "...":
            hosts.append({
                "host": str(name_field),
                "court": court_str,
                "court_short": court_short,
                "comment": str(tagline),
                "mode": settings.get("mode", "—"),
                "best_of": settings.get("best_of", "—"),
                "elo1": elo1,
            })
            continue

        # Match in progress
        if is_vs and score_field != "...":
            matches.append({
                "name": str(name_field),
                "court": court_str,
                "court_short": court_short,
                "comment": str(tagline),
                "score": str(score_field),
                "mode": settings.get("mode", "—"),
                "best_of": settings.get("best_of", "—"),
                "elo1": elo1,
                "elo2": elo2,
            })
            continue

    # Dedup exact items
    def dedup(items, key_fn):
        seen, out = set(), []
        for it in items:
            k = key_fn(it)
            if k in seen:
                continue
            seen.add(k)
            out.append(it)
        return out

    hosts = dedup(hosts, lambda h: (h["host"], h.get("court_short"), h.get("comment")))
    matches = dedup(matches, lambda m: (m["name"], m.get("court_short"), m.get("comment"), m.get("score")))

    return hosts, matches

def dedupe_matches_by_pair(matches):
    by_pair, order = {}, []
    for m in matches:
        k = match_pair_key(m.get("name", ""))
        if k is None:
            continue
        if k not in by_pair:
            order.append(k)
        by_pair[k] = m
    return [by_pair[k] for k in order]


# ---------- Safe edit ----------

async def safe_edit(message, *, content=None, embed=None):
    while True:
        try:
            return await message.edit(content=content, embed=embed)
        except discord.NotFound:
            raise
        except discord.HTTPException as e:
            if getattr(e, "status", None) == 429:
                await asyncio.sleep(5)
            else:
                raise

# ---------- Recent Hosts maintenance ----------

def _prune_recent_hosts(now_ts: float):
    """Remove recent hosts older than the configured retention window."""
    # prune recent hosts
    dead = []
    for hk, info in _recent_hosts.items():
        if (now_ts - float(info.get("ts", 0.0))) >= float(RECENT_HOST_TTL_SECONDS):
            dead.append(hk)
    for hk in dead:
        _recent_hosts.pop(hk, None)

def _update_recent_hosts(hosts_now, now_ts: float):
    """Upsert current hosts into recent hosts with latest timestamp."""
    for h in hosts_now:
        host = str(h.get("host", "")).strip()
        if not host:
            continue
        hk = host.lower()
        court = h.get("court", "—")
        court_short = h.get("court_short") or _short_court(court)
        _recent_hosts[hk] = {
            "host": host,
            "court": court,
            "court_short": court_short,
            "ts": now_ts,
        }


# ---------- ONE COMBINED EMBED ----------

def build_wtsl_master_embed(hosts_now, matches_now, *, now_ts: float, new_host_keys=None, new_match_keys=None):
    updated = datetime.utcnow().strftime("%H:%M:%S UTC")
    matches_now = dedupe_matches_by_pair(matches_now)

    new_match_keys = set(new_match_keys or [])
    new_host_keys  = set(new_host_keys or [])

    embed = discord.Embed(
        title="🎾 WTSL Live",
        color=WTSL_EMBED_COLOR
    )

    # Hosts (compact)
    if hosts_now:
        lines = []
        for h in hosts_now[:10]:
            court = h.get("court_short") or _short_court(h.get("court", "—"))
            host = h.get("host", "—")
            ingame_elo = h.get("elo1", 0)
            wtsl_elo = get_wtsl_elo_sync(host)  # Fetch WTSL Elo from rankings cache
            mode = h.get("mode", "—")
            bo   = h.get("best_of", "—")

            hk = (str(host).strip().lower(), str(court).strip().lower())
            new_tag = " **(NEW)**" if hk in new_host_keys else ""
            
            # Format: [Game: In-game Elo | Tour: WTSL Elo]
            if ingame_elo > 0 and wtsl_elo > 0:
                elo_display = f"[Game: {ingame_elo} | Tour: {wtsl_elo}]"
            elif ingame_elo > 0:
                elo_display = f"[Game: {ingame_elo}]"
            elif wtsl_elo > 0:
                elo_display = f"[Tour: {wtsl_elo}]"
            else:
                elo_display = ""
            
            lines.append(
                f"• {surface_icon(court)} **{host}** {elo_display} — `{court}`{new_tag}  {_pill(mode)} {_pill(bo)}"
            )
        if len(hosts_now) > 10:
            lines.append(f"• +{len(hosts_now)-10} more…")
        embed.add_field(name="🧑‍💻 Hosts", value="\n".join(lines), inline=False)
    else:
        embed.add_field(name="🧑‍💻 Hosts", value="• No WTSL hosts.", inline=False)

    # Recent Hosts (persisting up to TTL)
    _prune_recent_hosts(now_ts)
    if _recent_hosts:
        # order newest first
        recent_sorted = sorted(_recent_hosts.values(), key=lambda x: float(x.get("ts", 0.0)), reverse=True)
        recent_lines = []
        for info in recent_sorted[:12]:
            host = info.get("host", "—")
            court = info.get("court_short") or _short_court(info.get("court", "—"))
            mins = int((now_ts - float(info.get("ts", 0.0))) // 60)

            if mins <= 0:
                ago_text = "just now"
            elif mins == 1:
                ago_text = "1 min ago"
            else:
                ago_text = f"{mins} mins ago"

            recent_lines.append(f"• {surface_icon(court)} **{host}** — {ago_text}  `{court}`")

        embed.add_field(name="🕘 Recent Hosts", value="\n".join(recent_lines), inline=False)
    else:
        embed.add_field(name="🕘 Recent Hosts", value="• No recent hosts.", inline=False)

    # Live matches (compact)
    if matches_now:
        lines = []
        for m in matches_now[:12]:
            name  = m.get("name", "—")
            score = m.get("score", "—")
            court = m.get("court_short") or _short_court(m.get("court", "—"))
            mode  = m.get("mode", "—")
            bo    = m.get("best_of", "—")

            # Parse player names and get both in-game and WTSL Elo (for WTSL matches only)
            ingame_elo1 = m.get("elo1", 0)
            ingame_elo2 = m.get("elo2", 0)
            parts = re.split(r"\s+vs\s+", name, flags=re.IGNORECASE)
            if len(parts) == 2:
                p1, p2 = parts[0].strip(), parts[1].strip()
                wtsl_elo1 = get_wtsl_elo_sync(p1)
                wtsl_elo2 = get_wtsl_elo_sync(p2)
                
                # Format: [Game: X | Tour: Y] for each player
                if ingame_elo1 > 0 and wtsl_elo1 > 0:
                    elo1_str = f" [Game: {ingame_elo1} | Tour: {wtsl_elo1}]"
                elif ingame_elo1 > 0:
                    elo1_str = f" [Game: {ingame_elo1}]"
                elif wtsl_elo1 > 0:
                    elo1_str = f" [Tour: {wtsl_elo1}]"
                else:
                    elo1_str = ""
                
                if ingame_elo2 > 0 and wtsl_elo2 > 0:
                    elo2_str = f" [Game: {ingame_elo2} | Tour: {wtsl_elo2}]"
                elif ingame_elo2 > 0:
                    elo2_str = f" [Game: {ingame_elo2}]"
                elif wtsl_elo2 > 0:
                    elo2_str = f" [Tour: {wtsl_elo2}]"
                else:
                    elo2_str = ""
                
                name_with_elo = f"{p1}{elo1_str} vs {p2}{elo2_str}"
            else:
                name_with_elo = name

            mk = match_pair_key(name) or ("", "")
            new_tag = " **(NEW)**" if mk in new_match_keys else ""

            # Include mode + BO on the same line (requested)
            lines.append(
                f"• {surface_icon(court)} **{name_with_elo}**{new_tag} — `{score}`  `{court}`  {_pill(mode)} {_pill(bo)}"
            )

        if len(matches_now) > 12:
            lines.append(f"• +{len(matches_now)-12} more…")

        embed.add_field(name="🟢 Live Matches", value="\n".join(lines), inline=False)
    else:
        embed.add_field(name="🟢 Live Matches", value="• No WTSL matches in progress.", inline=False)

    embed.set_footer(text=f"Online  •  {len(hosts_now)} Hosts  •  {len(matches_now)} Matches  •  Updated {updated}")
    return embed


async def _adopt_existing_wtsl_live_message(channel):
    """Keep one existing live message during a bot-session handoff."""
    found = []
    channel_id = getattr(channel, "id", None)
    if channel_id is not None:
        stored = await asyncio.to_thread(
            load_bot_message,
            WTSL_MASTER_MESSAGE_KEY,
        )
        if stored and stored[0] == channel_id:
            try:
                stored_message = await channel.fetch_message(stored[1])
            except (discord.NotFound, discord.Forbidden):
                stored_message = None
            if (
                stored_message is not None
                and getattr(stored_message, "author", None) == client.user
                and any(
                    embed.title
                    and (
                        "Set Anyone Live" in embed.title
                        or "WTSL Live" in embed.title
                    )
                    for embed in getattr(stored_message, "embeds", [])
                )
            ):
                found.append(stored_message)

    async for old_msg in channel.history(limit=50):
        old_message_id = getattr(old_msg, "id", None)
        if (
            getattr(getattr(old_msg, "author", None), "id", None)
            != getattr(client.user, "id", None)
            or not old_msg.embeds
            or any(
                old_message_id is not None
                and getattr(existing, "id", None) == old_message_id
                for existing in found
            )
        ):
            continue
        if any(
            embed.title and (
                "Set Anyone Live" in embed.title
                or "WTSL Live" in embed.title
            )
            for embed in old_msg.embeds
        ):
            found.append(old_msg)

    if not found:
        return None

    # Keep the newest message and remove only older duplicates left by a
    # previous handoff. Sort explicitly because mocks and API wrappers do not
    # all preserve discord.py's usual newest-first history order.
    found.sort(
        key=lambda message: int(getattr(message, "id", 0) or 0),
        reverse=True,
    )
    message = found[0]
    for old_message in found[1:]:
        try:
            await old_message.delete()
        except Exception as exc:
            print(
                f"Set Anyone: failed to remove duplicate live message "
                f"{getattr(old_message, 'id', '?')}: {exc}",
                flush=True,
            )
    if channel_id is not None and getattr(message, "id", None) is not None:
        await asyncio.to_thread(
            save_bot_message,
            WTSL_MASTER_MESSAGE_KEY,
            channel_id,
            message.id,
        )
    return message


# ---------- EVENT-BASED LIVE EMBED LOOP ----------

async def wtsl_master_loop():
    """
    ✅ One live embed message per active hosting cycle.
    - Fetches often (LIVE_POLL_INTERVAL)
    - Only edits when signature changed AND min edit gap passed
    - Edits the existing embed when a new host is detected
    """
    global _last_seen_hosts, _last_seen_matches, _wtsl_master_message_id

    await client.wait_until_ready()
    channel = (
        client.get_channel(SET_ANYONE_CHANNEL_ID)
        or await client.fetch_channel(SET_ANYONE_CHANNEL_ID)
    )

    # Reuse an existing Set Anyone embed when another session already created
    # it. Deleting the existing message here would make both sessions race to
    # send a replacement.
    message = None
    try:
        message = await _adopt_existing_wtsl_live_message(channel)
        if message is not None:
            _wtsl_master_message_id = message.id
    except Exception:
        pass

    last_sig = None

    last_error_msg = None
    error_backoff = 2

    # Debounce edits (biggest lever to stop 429 + gateway lag)
    MIN_SECONDS_BETWEEN_EDITS = 10.0
    last_edit_ts = 0.0

    # Evaluate new host/new match markers every ALERT_POLL_INTERVAL.
    last_alert_eval_ts = 0.0

    async with aiohttp.ClientSession() as session:
        while not client.is_closed():
            try:
                poll_text = await fetch_poll_text_with_retry(session, TE4_SERVERLIST_URL)
                hosts, matches = parse_xkt_wtsl_hosts_and_matches(poll_text)

                # Refresh WTSL rankings cache (fetches every 5 min)
                await fetch_wtsl_rankings()

                now = asyncio.get_event_loop().time()

                # Update recent hosts + prune
                _update_recent_hosts(hosts, now)
                _prune_recent_hosts(now)

                # Compute keys (for "new" detection)
                current_host_keys = set(
                    (str(h.get("host", "")).strip().lower(), str(h.get("court_short", "")).strip().lower())
                    for h in hosts
                )

                current_match_keys = set()
                for m in matches:
                    k = match_pair_key(m.get("name", ""))
                    if k is not None:
                        current_match_keys.add(k)

                # Only compute NEW keys (and ping) every ALERT_POLL_INTERVAL seconds
                new_host_keys = set()
                new_match_keys = set()
                do_alert_eval = (now - last_alert_eval_ts) >= float(ALERT_POLL_INTERVAL)

                if do_alert_eval:
                    new_host_keys = current_host_keys - _last_seen_hosts
                    new_match_keys = current_match_keys - _last_seen_matches
                    last_alert_eval_ts = now

                # Build embed
                embed = build_wtsl_master_embed(
                    hosts_now=hosts,
                    matches_now=matches,
                    now_ts=now,
                    new_host_keys=new_host_keys if do_alert_eval else None,
                    new_match_keys=new_match_keys if do_alert_eval else None,
                )

                # ✅ FIX: signature MUST include description + fields so live scores update
                sig = (
                    embed.title,
                    embed.description,
                    embed.color.value if embed.color else None,
                    tuple((f.name, f.value, f.inline) for f in embed.fields),
                )

                # Keep the current embed during idle periods so its recent-host
                # history remains visible. Once live activity and the
                # RECENT_HOST_TTL_SECONDS window have both ended, remove it.
                activity_now = bool(hosts or matches or _recent_hosts)
                try:
                    if not activity_now:
                        if message is not None:
                            await message.delete()
                        message = None
                        _wtsl_master_message_id = None
                        last_sig = None
                    elif message is None:
                        message = await channel.send(embed=embed)
                        _wtsl_master_message_id = message.id
                        await asyncio.to_thread(
                            save_bot_message,
                            WTSL_MASTER_MESSAGE_KEY,
                            channel.id,
                            message.id,
                        )
                        last_sig = sig
                        last_edit_ts = now
                    else:
                        if sig != last_sig and (now - last_edit_ts) >= MIN_SECONDS_BETWEEN_EDITS:
                            await safe_edit(message, embed=embed)
                            last_sig = sig
                            last_edit_ts = now
                except discord.NotFound:
                    print(
                        "Set Anyone: embed message was deleted; "
                        "will create a new one next cycle"
                    )
                    message = None
                    _wtsl_master_message_id = None

                # Update stored “last seen” only during the alert eval window
                if do_alert_eval:
                    _last_seen_hosts = current_host_keys
                    _last_seen_matches = current_match_keys

                last_error_msg = None
                error_backoff = 2

            except Exception as e:
                msg = repr(e)
                if msg != last_error_msg:
                    print("WTSL MASTER LOOP ERROR:", msg)
                    last_error_msg = msg
                await asyncio.sleep(error_backoff)
                error_backoff = min(60, error_backoff * 2)
                continue

            await asyncio.sleep(LIVE_POLL_INTERVAL)


# ---------- ONE-TIME STARTER ----------

def start_wtsl_system_once():
    """
    Call this from your existing on_ready().
    Safe: does nothing if already started.
    """
    global _wtsl_master_task
    if _wtsl_master_task is None or _wtsl_master_task.done():
        _wtsl_master_task = asyncio.create_task(wtsl_master_loop())
        print("Started WTSL master loop (event-based embed)")


# -------------------------
# ADD THESE LINES INSIDE YOUR EXISTING on_ready() (DO NOT REPLACE THE WHOLE THING)
# -------------------------
#
#     try:
#         start_wtsl_system_once()
#     except Exception as e:
#         print("Failed to start WTSL system:", repr(e))
#
# -------------------------


# -------------------------
# ADD THESE LINES INSIDE YOUR EXISTING on_ready() (DO NOT REPLACE THE WHOLE THING)
# -------------------------
#
#     try:
#         start_wtsl_system_once()
#     except Exception as e:
#         print("Failed to start WTSL system:", repr(e))
#
# -------------------------


# -------------------------------------
# INTERVIEW IMAGE GENERATION
# -------------------------------------

PLAYER_APPEARANCES_FILE = "player_appearances.json"

def _load_player_appearances() -> dict:
    try:
        with open(PLAYER_APPEARANCES_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_player_appearances(data: dict):
    try:
        with open(PLAYER_APPEARANCES_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print(f"[Interview Image] Failed to save appearances: {e}")

def _get_player_appearance(player_name: str, ai_client) -> str:
    """Return saved appearance for this player, or generate and save a new one."""
    appearances = _load_player_appearances()
    key = player_name.strip().lower()
    if key in appearances:
        return appearances[key]
    try:
        resp = ai_client.chat.completions.create(
            model=AI_MODEL,
            messages=[{
                "role": "user",
                "content": (
                    f"Create a brief, specific physical description for a fictional male tennis player named '{player_name}'. "
                    "Include: approximate age (20s–40s), athletic male build, hair colour and style, skin tone, and one or two distinctive facial features. "
                    "2 sentences max. Do NOT mention clothing or location. "
                    "This description will be reused each time to generate a consistent-looking image of this man."
                )
            }],
            max_completion_tokens=256,
        )
        description = resp.choices[0].message.content.strip() if resp.choices else "An athletic man in his late 20s with short dark hair, a lean build, and a focused expression."
    except Exception as e:
        print(f"[Interview Image] Appearance gen error for {player_name}: {e}")
        description = "An athletic man in his late 20s with short dark hair, a lean build, and a focused expression."
    appearances[key] = description
    _save_player_appearances(appearances)
    return description

async def _generate_interview_image(player_names: list, round_hint: str, ai_client, loser: bool = False) -> bytes | None:
    """Generate a press conference photo for one or two players. Returns PNG bytes or None."""
    bg_map = {
        "Final":         (
            "an official grand-slam-style championship press conference room: a long table draped in tournament-branded cloth "
            "with cluster microphones, a tall sponsor-logo backdrop wall behind the player, TV cameras and photographers on tripods "
            "filling the back of the room, bright studio lighting overhead, trophy visible to one side"
        ),
        "Semi-Final":    (
            "a large official tournament press conference room: rows of journalists with notepads and cameras, "
            "a branded sponsor backdrop banner wall, cluster microphones on the press table, harsh TV lighting, "
            "ATP or tennis federation logos on the table cloth"
        ),
        "Quarter-Final": (
            "a professional indoor tournament press room: branded roller-banner backdrops, a press table with microphones, "
            "journalists and camera crews in the background, tournament signage visible"
        ),
    }
    background = bg_map.get(round_hint, (
        "a tournament press conference room: a microphone-equipped press table, a sponsor backdrop banner wall, "
        "camera flashes and journalists visible in the background"
    ))

    descriptions = [(name, _get_player_appearance(name, ai_client)) for name in player_names]

    if loser:
        demeanour = "visibly disappointed and emotionally drained — slumped slightly, eyes downcast, jaw tight, gutted after a painful loss"
    else:
        demeanour = "relaxed and composed, leaning slightly forward, calm confident expression, engaging with the press"

    clothing = (
        "wearing a tennis sport jacket (zip-up tracksuit top in team colours) over a moisture-wicking polo, "
        "athletic tennis attire — no suit, no casual clothes"
    )

    # Background description goes FIRST so the model renders the room correctly.
    # Subject and style tags follow. Appearance detail (AI-generated, variable length) last.
    bg_scene = {
        "Final": (
            "indoor press conference room, long rectangular table draped in tournament cloth, "
            "cluster of standing microphones on table, large sponsor logo backdrop banner wall, "
            "rows of seated journalists with notebooks, TV cameras on tripods, bright overhead studio lights, "
            "championship trophy visible on table, camera flashes from press pit"
        ),
        "Semi-Final": (
            "indoor press conference room, rectangular table with cluster microphones, "
            "branded sponsor backdrop banner wall, rows of journalists and cameras, "
            "ATP tournament signage, studio lighting"
        ),
        "Quarter-Final": (
            "indoor press conference room, table with microphones, sponsor banner backdrop, "
            "journalists seated in rows, camera flashes, tournament signage"
        ),
    }.get(round_hint, (
        "indoor press conference room, table with standing microphones, "
        "sponsor banner backdrop wall, journalists with cameras in background"
    ))

    if loser:
        mood_tags = "sad expression, downcast eyes, disappointed, slumped posture"
    else:
        mood_tags = "calm confident expression, leaning forward, engaged"

    if len(descriptions) == 1:
        name, desc = descriptions[0]
        appearance_tags = desc[:180] if desc else "dark hair, athletic build"
        subject_tags = "1boy, male, solo, young adult male athlete, tennis polo shirt, sport jacket, sitting at table"
    else:
        appearance_tags = "  ".join(f"{n}: {d[:80]}" for n, d in descriptions)
        subject_tags = "2boys, two males, young adult male athletes, tennis polo shirts, sport jackets, sitting side by side"

    prompt = (
        f"{bg_scene}, "
        f"anime style, studio ghibli, hand-painted watercolour, "
        f"{subject_tags}, {mood_tags}, "
        f"{appearance_tags}, "
        f"masterpiece, best quality, no extra limbs, correct anatomy, no text, no watermarks, no logos"
    )

    try:
        import urllib.parse
        encoded = urllib.parse.quote(prompt[:1200])
        img_url = f"https://image.pollinations.ai/prompt/{encoded}?width=1024&height=1024&nologo=true&model=sana&enhance=true"
        async with aiohttp.ClientSession() as session:
            async with session.get(img_url, timeout=aiohttp.ClientTimeout(total=60)) as r:
                if r.status == 200:
                    return await r.read()
                else:
                    print(f"[Interview Image] Pollinations returned status {r.status}")
    except Exception as e:
        print(f"[Interview Image] Generation error: {e}")
    return None


# -------------------------------------
# AI INTERVIEW STATE & HANDLER
# -------------------------------------
_active_interviews = {}
_pending_interviews = {}  # thread_id -> {"player_id", "first_question", "conversation_history", "created_at"}
_active_contact_threads = {}  # player_id -> {"thread_id": ..., "created_at": ...}


JOURNALIST_PERSONAS = [
    {
        "name": "Jake",
        "system": (
            "You are Jake, a sharp courtside journalist who focuses on the tactical side of matches. "
            "You ask short, specific questions about what happened during the match — serve patterns, key moments, shot selection. "
            "You stay grounded in what actually occurred today, not grand narratives."
        ),
        "angle": "Ask about specific tactical moments in today's match — a key break, a stat, a shift in momentum. Keep it about what happened on court.",
        "reaction_style": "React briefly to what they actually said, then ask a short follow-up that builds naturally on their answer — go where they take you, don't force it back to stats.",
    },
    {
        "name": "Sam",
        "system": (
            "You are Sam, a relaxed but sharp journalist who keeps interviews conversational and fun. "
            "You ask simple, direct questions about how the match felt and what the player did well. "
            "You're not deep or philosophical — just curious and easy to talk to."
        ),
        "angle": "Ask simple, natural questions about the match — what worked, what didn't, how the player felt during key moments. Nothing heavy.",
        "reaction_style": "React naturally and briefly to exactly what they said, like a real conversation. Follow their thread — if they go somewhere interesting, go with them.",
    },
    {
        "name": "Chris",
        "system": (
            "You are Chris, a no-nonsense journalist who asks direct questions about the match. "
            "You're fair and friendly but get straight to the point — short questions, no waffle. "
            "You focus on what actually happened in this match, today."
        ),
        "angle": "Ask direct questions about the result, specific moments in the match, and how the player handled the key points. Short and specific.",
        "reaction_style": "React in one short sentence to what they specifically said, then ask a direct follow-up that flows from their answer.",
    },
    {
        "name": "Luca",
        "system": (
            "You are Luca, a journalist who loves the details — stats, scores, specific moments. "
            "You pick up on something specific from the scoreline or the screenshot and ask about it directly. "
            "Short questions, present tense, about this match."
        ),
        "angle": "Reference a specific stat or score from the match and ask about it. Keep questions tight and about what happened today.",
        "reaction_style": "Pick up on one specific thing from their answer and ask a short natural follow-up on it — don't ignore what they said to chase a stat.",
    },
    {
        "name": "Maya",
        "system": (
            "You are Maya, a warm but focused journalist who asks about the feel of the match — "
            "the pressure moments, how the player stayed composed, what it was like in the key games. "
            "Short questions, present and honest, not philosophical."
        ),
        "angle": "Ask about specific pressure moments in the match — a tight set, a break point, how they felt at key stages. Keep it grounded.",
        "reaction_style": "React warmly to exactly what they said, then ask a short honest follow-up that continues naturally from their answer.",
    },
    {
        "name": "Tom",
        "system": (
            "You are Tom, a direct journalist who asks the honest questions about today's match — "
            "including the difficult moments. You're fair but you don't shy away from asking about errors or close calls. "
            "Short, present-focused questions only."
        ),
        "angle": "Ask about both the good and the tricky moments in the match. What went wrong, how they recovered, what nearly didn't work.",
        "reaction_style": "React directly to what they said, then ask a short honest follow-up building on their answer — including any tough moments they raised.",
    },
]


def _generate_interview_opening_question(
    ai_client,
    system_msg: str,
    user_content,
) -> str:
    response = ai_client.chat.completions.create(
        model=AI_MODEL,
        messages=[
            {"role": "system", "content": system_msg},
            {"role": "user", "content": user_content},
        ],
        max_completion_tokens=256,
    )
    if not response.choices:
        raise ValueError("AI returned no opening interview question")
    question = (response.choices[0].message.content or "").strip()
    if not question:
        raise ValueError("AI returned an empty opening interview question")
    return question.lstrip("123.").strip()


def _generate_interview_opening_for_pending(pending: dict) -> str:
    """Generate an accepted interview's first question outside the event loop."""
    ai_client = OpenAI(
        base_url=os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL"),
        api_key=os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY"),
        timeout=INTERVIEW_OPENAI_TIMEOUT_SECONDS,
    )
    return _generate_interview_opening_question(
        ai_client,
        pending["first_question_system"],
        pending["first_question_content"],
    )


async def _interview_completion(ai_client, **kwargs):
    """Run a blocking AI interview request without blocking Discord's event loop."""
    return await asyncio.wait_for(
        asyncio.to_thread(ai_client.chat.completions.create, **kwargs),
        timeout=INTERVIEW_OPENAI_TIMEOUT_SECONDS,
    )


class InterviewAcceptView(discord.ui.View):
    """Accept/Decline buttons posted in a private invite thread — only the player is added to it."""
    def __init__(self, private_thread_id: int, player_id: int = None, player_ids: list = None):
        super().__init__(timeout=None)
        self.private_thread_id = private_thread_id
        # Support both a single player_id and a list of player_ids
        if player_ids:
            self.player_ids = player_ids
        elif player_id:
            self.player_ids = [player_id]
        else:
            self.player_ids = []
        # Keep for backward compat
        self.player_id = player_id or (player_ids[0] if player_ids else None)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id not in self.player_ids:
            await interaction.response.send_message("This invite is not for you.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Accept", style=discord.ButtonStyle.success, emoji="🎤")
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        pending = _pending_interviews.pop(self.private_thread_id, None)
        if not pending:
            await interaction.edit_original_response(content="This interview invite has already expired.", view=None)
            return
        self.stop()
        for child in self.children:
            child.disabled = True
        await interaction.edit_original_response(content="✅ Interview accepted! The interview thread is opening now.", view=self)
        try:
            if not pending.get("first_question"):
                pending["first_question"] = await asyncio.wait_for(
                    asyncio.to_thread(
                        _generate_interview_opening_for_pending,
                        pending,
                    ),
                    timeout=INTERVIEW_OPENING_TIMEOUT_SECONDS,
                )
        except (AIBudgetExceeded, AIBudgetStateError) as exc:
            print(f"[AI Interview] Could not start accepted interview: {exc}")
            await interaction.edit_original_response(
                content=(
                    "⚠️ The interview could not start because the bot's monthly "
                    "AI budget is unavailable."
                ),
                view=self,
            )
            try:
                await interaction.channel.edit(archived=True)
            except Exception as archive_exc:
                print(f"[AI Interview] Error archiving unavailable interview invite: {archive_exc}")
            return
        except ValueError as exc:
            pending["first_question"] = INTERVIEW_FALLBACK_OPENING_QUESTION
            print(
                "[AI Interview] Opening question was empty or invalid; "
                f"using fallback: {exc}"
            )
        except asyncio.TimeoutError:
            print(
                "[AI Interview] Opening question generation timed out "
                f"after {INTERVIEW_OPENING_TIMEOUT_SECONDS}s"
            )
            await interaction.edit_original_response(
                content=(
                    "⚠️ The interview could not start because the opening question "
                    "timed out. Please try another interview later."
                ),
                view=self,
            )
            try:
                await interaction.channel.edit(archived=True)
            except Exception as archive_exc:
                print(f"[AI Interview] Error archiving timed-out interview invite: {archive_exc}")
            return
        except Exception as exc:
            print(
                "[AI Interview] Opening question generation failed after accept: "
                f"{type(exc).__name__}: {exc}"
            )
            await interaction.edit_original_response(
                content=(
                    "⚠️ The interview could not start because the AI interviewer "
                    "is temporarily unavailable. Please try another interview later."
                ),
                view=self,
            )
            try:
                await interaction.channel.edit(archived=True)
            except Exception as archive_exc:
                print(f"[AI Interview] Error archiving failed interview invite: {archive_exc}")
            return
        # Create the public interview thread from the original result message.
        # Losers use a standalone channel thread because Discord only allows one
        # message-attached thread per message (the winner already claims it).
        try:
            result_channel = client.get_channel(pending["result_channel_id"])
            if pending.get("is_loser"):
                public_thread = await result_channel.create_thread(
                    name=f"🎤 Post-{pending['round_hint']} Interview: {pending['player_name']}",
                    type=discord.ChannelType.public_thread,
                    auto_archive_duration=10080,
                )
            else:
                result_msg = await result_channel.fetch_message(pending["result_message_id"])
                public_thread = await result_msg.create_thread(
                    name=f"🎤 Post-{pending['round_hint']} Interview: {pending['player_name']}",
                    auto_archive_duration=10080,
                )
        except Exception as e:
            print(f"[AI Interview] Error creating public thread on accept: {e}")
            return
        journalist_name = pending.get("journalist_name", "your interviewer")
        pending_ids = pending.get("player_ids", [self.player_id])
        is_doubles_pending = len(pending_ids) > 1
        if is_doubles_pending:
            winner_mentions = " ".join(f"<@{pid}>" for pid in pending_ids)
            await public_thread.send(f"{winner_mentions} 🎤 **Post-Match Press Conference** — {pending['opener']}! I'm {journalist_name}, let's chat.")
        else:
            await public_thread.send(f"{interaction.user.mention} 🎤 **Post-Match Press Conference** — {pending['opener']}! I'm {journalist_name}, let's get into it.")
        await public_thread.send(f"🎙️ {pending['first_question']}")
        pending["conversation_history"].append({"role": "assistant", "content": pending["first_question"]})
        _active_interviews[public_thread.id] = {
            "player_ids": pending.get("player_ids", [self.player_id]),
            "conversation_history": pending["conversation_history"],
            "q_count": 1,
            "created_at": pending["created_at"],
            "reaction_style": pending.get("reaction_style", "React genuinely and specifically to what the player said."),
        }
        print(f"[AI Interview] Accepted — public thread {public_thread.id} created for {pending['player_name']}")
        try:
            await interaction.channel.edit(archived=True)
        except Exception as e:
            print(f"[AI Interview] Error archiving invite thread: {e}")

    @discord.ui.button(label="Decline", style=discord.ButtonStyle.danger, emoji="🚫")
    async def decline(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        pending = _pending_interviews.pop(self.private_thread_id, None)
        if not pending:
            await interaction.edit_original_response(content="This interview invite has already expired.", view=None)
            return
        self.stop()
        for child in self.children:
            child.disabled = True
        await interaction.edit_original_response(content="❌ Interview declined.", view=self)
        print(f"[AI Interview] {pending['player_name']} declined interview invite")
        try:
            await interaction.channel.edit(archived=True)
        except Exception as e:
            print(f"[AI Interview] Error archiving declined invite thread: {e}")


async def _handle_interview_reply(message, interview):
    """Serialize replies so a second message cannot race the first AI turn."""
    thread = message.channel
    reply_lock = interview.setdefault("_reply_lock", asyncio.Lock())
    if reply_lock.locked():
        await thread.send(
            f"{message.author.mention} I’m still catching up with your last answer — "
            "give me a moment and I’ll keep the questions coming."
        )
        return
    async with reply_lock:
        await _process_interview_reply(message, interview)


def _interview_answer_topic(player_text: str) -> str:
    """Find a concrete subject for a deterministic fallback follow-up."""
    text = str(player_text or "").casefold()
    topics = (
        (("return", "receiver", "receiving", "position"), "return position"),
        (("serve", "serving", "first ball", "double fault"), "serve"),
        (("forehand", "fh"), "forehand"),
        (("backhand", "bh"), "backhand"),
        (("volley", "net", "approach"), "net play"),
        (("break point", "pressure", "tight", "nervous"), "the pressure moment"),
        (("timing", "rhythm", "tempo"), "your timing"),
        (("wide", "direction", "down the line", "cross-court"), "shot direction"),
        (("move", "adjust", "change", "shift"), "that adjustment"),
    )
    for needles, topic in topics:
        if any(needle in text for needle in needles):
            return topic
    return "that part of the match"


def _contextual_interview_fallback(player_text: str, q_count: int) -> str:
    """Keep the interview specific when structured AI output is unavailable."""
    topic = _interview_answer_topic(player_text)
    options = (
        f"That {topic} sounds important — what did it change first in the match?",
        f"When you focused on {topic}, did it give you more time or change your shot selection?",
        f"Was that work on {topic} something you planned, or did you read it in the moment?",
    )
    return options[max(int(q_count) - 1, 0) % len(options)]


async def _send_interview_fallback_turn(message, interview):
    """Keep an interview moving with a specific, non-repeating fallback."""
    thread = message.channel
    player_mention = message.author.mention
    q_count = int(interview.get("q_count") or 1)
    if q_count >= 12:
        signoff = (
            "That gives us plenty to take away from this one — thanks for your time."
        )
        await thread.send(f"{player_mention} {signoff} 🏆")
        _active_interviews.pop(thread.id, None)
        try:
            await thread.edit(archived=True)
        except Exception as archive_exc:
            print(f"[AI Interview] Fallback archive failed: {archive_exc}")
        return

    fallback_text = _contextual_interview_fallback(message.content, q_count)
    interview["conversation_history"].append(
        {"role": "assistant", "content": fallback_text}
    )
    await thread.send(f"{player_mention} {fallback_text}")
    interview["q_count"] = q_count + 1


def _parse_interview_exchange(raw_content: str) -> tuple[str, bool]:
    """Accept strict JSON plus provider replies that contain plain text."""
    raw = str(raw_content or "").strip()
    if not raw:
        return "", False
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.IGNORECASE).strip()
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        # Some compatible providers ignore response_format and return the
        # requested reply directly. Keeping that reply is better than
        # replacing a relevant answer with a generic question.
        return raw, False
    if not isinstance(parsed, dict):
        return "", False
    exchange_text = str(parsed.get("text") or "").strip()
    close_value = parsed.get("close", False)
    if isinstance(close_value, str):
        close_value = close_value.casefold() == "true"
    return exchange_text, bool(close_value)


async def _process_interview_reply(message, interview):
    """Handle a player's reply in an active interview thread."""
    thread = message.channel
    player_mention = message.author.mention
    conv_history = interview["conversation_history"]
    q_count = interview["q_count"]

    ai_client = OpenAI(
        base_url=os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL"),
        api_key=os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY"),
        timeout=INTERVIEW_OPENAI_TIMEOUT_SECONDS,
    )

    INTERVIEW_SAFETY_CAP = 12   # absolute maximum exchanges
    MIN_BEFORE_CLOSE = 3        # AI cannot close before this many exchanges

    reaction_style = interview.get("reaction_style", "React genuinely and specifically to what the player said.")
    can_close = q_count >= MIN_BEFORE_CLOSE
    force_close = q_count >= INTERVIEW_SAFETY_CAP

    if force_close:
        close_guidance = (
            "The interview has reached its limit. Set close to true and write a warm sign-off sentence — no question."
        )
    elif can_close:
        close_guidance = (
            "If the conversation feels naturally complete, set close to true and write a warm sign-off — no question. "
            "If there are still good angles to explore, set close to false and ask one more follow-up."
        )
    else:
        close_guidance = (
            "The interview is just getting started. Set close to false. "
            "Write a brief reaction to what they said and ask one short follow-up question."
        )

    # Detect language of this reply and translate if non-English
    player_text = message.content
    player_translation_note = ""
    try:
        lang_resp = await _interview_completion(
            ai_client,
            model=AI_MODEL,
            messages=[{
                "role": "user",
                "content": (
                    f'Is this text in English? If not, identify the language and translate it to English. '
                    f'Reply with JSON only: {{"is_english": true}} if English, '
                    f'or {{"is_english": false, "language": "French", "translation": "..."}} if not.\n\nText: "{message.content}"'
                )
            }],
            max_completion_tokens=384,
            response_format={"type": "json_object"},
        )
        if lang_resp.choices:
            lang_parsed = json.loads(lang_resp.choices[0].message.content or "{}")
            if not lang_parsed.get("is_english", True) and lang_parsed.get("translation"):
                player_text = lang_parsed["translation"]
                player_translation_note = f"*🌐 Translation: \"{player_text}\"*"
                interview["language"] = lang_parsed.get("language", "")
            else:
                # Player switched back to English
                interview["language"] = ""
    except Exception as _te:
        print(f"[AI Interview] Translation check error: {_te}")

    if player_translation_note:
        await thread.send(player_translation_note)

    current_lang = interview.get("language", "")
    lang_instruction = (
        f"Reply in {current_lang} only — the player is speaking {current_lang}. "
        if current_lang else
        "Reply in English. "
    )

    conv_history.append({
        "role": "user",
        "content": (
            f'The participant {getattr(message.author, "display_name", "player")} '
            f'responded: "{player_text}"\n\n'
            f'You are the journalist. {lang_instruction}{reaction_style}\n\n'
            f'RULES: No long-term career questions. Be brief.\n\n'
            f'{close_guidance}\n\n'
            f'Respond with JSON only, using this exact format: {{"close": true, "text": "your reply"}} or {{"close": false, "text": "your reply"}}'
        )
    })

    try:
        r = await _interview_completion(
            ai_client,
            model=AI_MODEL,
            messages=conv_history,
            max_completion_tokens=INTERVIEW_REPLY_COMPLETION_TOKENS,
            response_format={"type": "json_object"},
        )
    except (AIBudgetExceeded, AIBudgetStateError) as exc:
        print(f"[AI Interview] Monthly AI budget reached; closing interview: {exc}")
        await thread.send(
            f"{player_mention} This press conference is closing because the "
            "bot's monthly AI budget has been reached."
        )
        _active_interviews.pop(thread.id, None)
        try:
            await thread.edit(archived=True)
        except Exception as archive_exc:
            print(f"[AI Interview] Error archiving budget-limited thread: {archive_exc}")
        return
    except asyncio.TimeoutError:
        print(
            "[AI Interview] Reply generation timed out "
            f"after {INTERVIEW_OPENAI_TIMEOUT_SECONDS}s"
        )
        await thread.send(
            f"{player_mention} The interviewer hit a brief timeout, but the "
            "press conference is still open. Please send your answer again and "
            "I’ll pick it up."
        )
        return
    except Exception as exc:
        print(
            "[AI Interview] Reply generation failed: "
            f"{type(exc).__name__}: {exc}"
        )
        await thread.send(
            f"{player_mention} The interviewer had a brief wobble, but the "
            "press conference is still open. Please send your answer again."
        )
        return
    if not r.choices:
        print("[AI Interview] No choices in AI response; using fallback follow-up")
        await _send_interview_fallback_turn(message, interview)
        return
    try:
        exchange_text, requested_close = _parse_interview_exchange(
            r.choices[0].message.content
        )
        is_closing = requested_close or force_close
    except Exception as e:
        print(
            f"[AI Interview] JSON parse error: {e} — "
            f"raw: {r.choices[0].message.content!r}"
        )
        await _send_interview_fallback_turn(message, interview)
        return

    if not exchange_text:
        print("[AI Interview] Empty text in JSON response; using fallback follow-up")
        await _send_interview_fallback_turn(message, interview)
        return

    conv_history.append({"role": "assistant", "content": exchange_text})

    # Translate journalist's question/reply to English if interview is in another language
    question_translation_note = ""
    if interview.get("language"):
        try:
            q_trans_resp = await _interview_completion(
                ai_client,
                model=AI_MODEL,
                messages=[{
                    "role": "user",
                    "content": (
                        f'Translate this text to English. '
                        f'Reply with JSON only: {{"translation": "..."}}\n\nText: "{exchange_text}"'
                    )
                }],
                max_completion_tokens=384,
                response_format={"type": "json_object"},
            )
            if q_trans_resp.choices:
                q_trans_parsed = json.loads(q_trans_resp.choices[0].message.content or "{}")
                q_translation = q_trans_parsed.get("translation", "").strip()
                if q_translation:
                    question_translation_note = f"*🌐 Translation: \"{q_translation}\"*"
        except Exception as _qte:
            print(f"[AI Interview] Question translation error: {_qte}")

    await asyncio.sleep(10)

    if is_closing:
        await thread.send(f"{player_mention} {exchange_text} 🏆")
        if question_translation_note:
            await thread.send(question_translation_note)
        del _active_interviews[thread.id]
        await thread.edit(archived=True)
    else:
        await thread.send(f"{player_mention} {exchange_text}")
        if question_translation_note:
            await thread.send(question_translation_note)
        interview["q_count"] = q_count + 1

async def _run_fictional_doubles_interview(thread, winner_names, persona, first_question, conv_history, ai_client, image_attachments=None, message_content=""):
    """Fully automated interview for fictional (non-Discord) doubles winners — bot plays both roles."""
    name1 = winner_names[0] if winner_names else "Player 1"
    name2 = winner_names[1] if len(winner_names) > 1 else name1

    await thread.send(f"🎙️ {first_question}")
    conv_history.append({"role": "assistant", "content": first_question})

    reaction_style = persona.get("reaction_style", "React genuinely and specifically to what the player said.")

    # Build image content block to include in answer prompts (so the player can reference real stats)
    image_blocks = []
    for img in (image_attachments or []):
        image_blocks.append({"type": "image_url", "image_url": {"url": img.url}})

    for q_num in range(1, 5):
        await asyncio.sleep(10)

        # Alternate which player answers — ensures both are heard
        answering_player = name1 if q_num % 2 == 1 else name2
        other_player = name2 if q_num % 2 == 1 else name1

        # Generate fictional player answer — include screenshot so answer references real stats
        last_q = conv_history[-1]["content"]
        answer_text_prompt = (
            f"You are roleplaying as {answering_player}, one half of a doubles tennis duo (partner: {other_player}) from the Tennis Elbow 4 video game. You just won a doubles match.\n"
            f"The match result posted was: \"{message_content}\"\n\n"
            f"The journalist just asked: \"{last_q}\"\n\n"
            f"IMPORTANT: Base your answer ONLY on what is visible in the screenshot stats and the result above. "
            f"Do NOT invent stats or events not shown. Reference actual numbers (e.g. serve %, winners, break points) from the image.\n\n"
            f"Respond in character as {answering_player} in 1-2 short, natural sentences. "
            f"Format your answer as \"{answering_player}: <answer>\" — always use this exact format."
        )
        answer_content = [{"type": "text", "text": answer_text_prompt}] + image_blocks if image_blocks else answer_text_prompt
        try:
            ans_r = ai_client.chat.completions.create(
                model=AI_MODEL,
                messages=[{"role": "user", "content": answer_content}],
                max_completion_tokens=256,
            )
        except (AIBudgetExceeded, AIBudgetStateError) as exc:
            print(
                "[AI Interview] Monthly AI budget reached during fictional "
                f"interview: {exc}"
            )
            await thread.send(
                "This press conference is closing because the bot's monthly "
                "AI budget has been reached."
            )
            break
        if not ans_r.choices:
            print("[AI Interview] No choices in AI response (fictional answer) — skipping")
            break
        fictional_answer = (ans_r.choices[0].message.content or "").strip()
        await thread.send(fictional_answer)
        conv_history.append({"role": "user", "content": fictional_answer})

        await asyncio.sleep(10)

        # Generate journalist follow-up or close
        FICT_SAFETY_CAP = 12
        FICT_MIN_BEFORE_CLOSE = 3
        fict_can_close = q_num >= FICT_MIN_BEFORE_CLOSE
        fict_force_close = q_num >= FICT_SAFETY_CAP

        if fict_force_close:
            fict_close_guidance = (
                "The interview has reached its limit. Set close to true and write a warm sign-off — no question."
            )
        elif fict_can_close:
            fict_close_guidance = (
                "If the conversation feels naturally complete, set close to true and write a warm sign-off — no question. "
                "Otherwise set close to false and ask one short follow-up. Do NOT invent stats not in the screenshot."
            )
        else:
            fict_close_guidance = (
                "Set close to false. Write a brief reaction and ask one short follow-up. "
                "Do NOT invent stats or moments not visible in the screenshot."
            )

        journalist_follow_text = (
            f'The player responded: "{fictional_answer}"\n\n'
            f'You are the journalist. {reaction_style}\n\n'
            f'{fict_close_guidance}\n\n'
            f'Respond with JSON only: {{"close": true, "text": "your reply"}} or {{"close": false, "text": "your reply"}}'
        )
        journalist_follow_content = (
            [{"type": "text", "text": journalist_follow_text}] + image_blocks
            if image_blocks else journalist_follow_text
        )
        conv_history.append({"role": "user", "content": journalist_follow_content})
        try:
            follow_r = ai_client.chat.completions.create(
                model=AI_MODEL,
                messages=conv_history,
                max_completion_tokens=384,
                response_format={"type": "json_object"},
            )
        except (AIBudgetExceeded, AIBudgetStateError) as exc:
            print(
                "[AI Interview] Monthly AI budget reached during fictional "
                f"interview: {exc}"
            )
            await thread.send(
                "This press conference is closing because the bot's monthly "
                "AI budget has been reached."
            )
            break
        if not follow_r.choices:
            print("[AI Interview] No choices in AI response (fictional follow-up) — ending interview")
            break
        try:
            fict_parsed = json.loads(follow_r.choices[0].message.content or "{}")
            exchange_text = fict_parsed.get("text", "").strip()
            is_fict_closing = bool(fict_parsed.get("close", False)) or fict_force_close
        except Exception as e:
            print(f"[AI Interview] Fictional JSON parse error: {e}")
            break

        if not exchange_text:
            break

        if is_fict_closing:
            conv_history.append({"role": "assistant", "content": exchange_text})
            await thread.send(f"{exchange_text} 🏆")
            break

        conv_history.append({"role": "assistant", "content": exchange_text})
        await thread.send(exchange_text)

    try:
        await thread.edit(archived=True)
    except Exception as e:
        print(f"[AI Interview] Error archiving fictional interview thread: {e}")


async def _close_expired_interviews():
    """Background task to close interview and contact threads older than 24 hours."""
    await client.wait_until_ready()
    while not client.is_closed():
        try:
            now = time.time()

            # Close expired interview threads
            expired_interviews = [tid for tid, iv in _active_interviews.items() if now - iv["created_at"] >= 86400]
            for tid in expired_interviews:
                try:
                    _active_interviews.pop(tid)
                    thread = client.get_channel(tid)
                    if thread:
                        await thread.send("🎤 This press conference is now closed — thanks for stopping by!")
                        await thread.edit(archived=True)
                except Exception as e:
                    print(f"[AI Interview] Error closing expired thread {tid}: {e}")

            # Close expired pending invite threads
            expired_pending = [ptid for ptid, p in _pending_interviews.items() if now - p["created_at"] >= 86400]
            for ptid in expired_pending:
                try:
                    _pending_interviews.pop(ptid)
                    invite_thread = client.get_channel(ptid)
                    if invite_thread:
                        await invite_thread.send("⏱️ This interview invite has expired.")
                        await invite_thread.edit(archived=True)
                except Exception as e:
                    print(f"[AI Interview] Error closing expired invite thread {ptid}: {e}")

            # Close expired contact threads
            expired_contacts = [pid for pid, ct in _active_contact_threads.items() if now - ct["created_at"] >= 86400]
            for pid in expired_contacts:
                try:
                    ct = _active_contact_threads.pop(pid)
                    thread = client.get_channel(ct["thread_id"])
                    if thread:
                        await thread.send("📩 This admin contact thread has been automatically closed after 24 hours.")
                        await thread.edit(archived=True)
                except Exception as e:
                    print(f"[ContactAdmins] Error closing expired thread for player {pid}: {e}")

        except Exception as e:
            print(f"[Expiry loop] Error: {e}")
        await asyncio.sleep(300)


def _is_public_interview_thread(thread) -> bool:
    name = str(getattr(thread, "name", "") or "")
    return name.startswith("🎤 Post-") and "Interview" in name


def _rebuild_interview_from_messages(thread, messages: list) -> tuple[dict, object] | None:
    """Recreate enough in-memory state to continue after a bot restart."""
    if not messages or getattr(messages[-1].author, "bot", False):
        return None
    created_at = getattr(thread, "created_at", None)
    if created_at is None:
        return None
    if time.time() - created_at.timestamp() > INTERVIEW_RECOVERY_LOOKBACK_SECONDS:
        return None

    player_ids: list[int] = []
    conversation_history = [
        {
            "role": "system",
            "content": (
                "You are a WTSL post-match journalist continuing an interview "
                "after a brief interruption. Be concise, warm, specific to the "
                "player's answer, and ask one short follow-up question."
            ),
        }
    ]
    player_message_count = 0
    for current in messages:
        content = str(getattr(current, "content", "") or "").strip()
        if not content:
            continue
        author = getattr(current, "author", None)
        if getattr(author, "bot", False):
            conversation_history.append({"role": "assistant", "content": content})
        else:
            player_id = getattr(author, "id", None)
            if player_id is not None and player_id not in player_ids:
                player_ids.append(player_id)
            player_message_count += 1
            conversation_history.append({"role": "user", "content": content})

    if not player_ids or player_message_count == 0:
        return None

    interview = {
        "player_ids": player_ids,
        "conversation_history": conversation_history,
        "q_count": max(1, player_message_count),
        "created_at": created_at.timestamp(),
        "reaction_style": (
            "React briefly and genuinely to exactly what the player said, "
            "then ask one short follow-up that builds naturally."
        ),
    }
    return interview, messages[-1]


async def _recover_interview_for_message(message):
    """Restore a public interview just in time for a reply after a restart."""
    thread = getattr(message, "channel", None)
    thread_id = getattr(thread, "id", None)
    if (
        thread is None
        or thread_id in _active_interviews
        or not _is_public_interview_thread(thread)
    ):
        return None

    try:
        messages = [
            current
            async for current in thread.history(
                limit=100,
                oldest_first=True,
            )
        ]
        # Discord can dispatch MESSAGE_CREATE before the history endpoint
        # includes that message. Include it explicitly so the rebuild still
        # has a player message to resume.
        if not any(
            getattr(current, "id", None) == getattr(message, "id", None)
            for current in messages
        ):
            messages.append(message)
        rebuilt = _rebuild_interview_from_messages(thread, messages)
        if rebuilt is None:
            return None
        interview, last_player_message = rebuilt
        if getattr(last_player_message, "id", None) != getattr(message, "id", None):
            return None
        _active_interviews[thread_id] = interview
        if getattr(thread, "archived", False):
            try:
                await thread.edit(archived=False)
            except Exception as exc:
                print(
                    f"[AI Interview] Could not unarchive resumed thread "
                    f"{thread_id}: {exc}"
                )
        print(
            f"[AI Interview] Recovered interview {thread_id} on demand "
            "for a delayed reply",
            flush=True,
        )
        return interview
    except Exception as exc:
        print(
            f"[AI Interview] On-demand recovery failed for thread "
            f"{thread_id}: {type(exc).__name__}: {exc}"
        )
        return None


async def _fetch_recent_interview_threads() -> list:
    """Find active and archived public interview threads from the last 48 hours."""
    result_channel = client.get_channel(TE4_RESULTS_CHANNEL_ID)
    if result_channel is None:
        try:
            result_channel = await client.fetch_channel(TE4_RESULTS_CHANNEL_ID)
        except Exception as exc:
            print(f"[AI Interview] Recovery could not fetch results channel: {exc}")
            return []

    found: dict[int, object] = {}

    def add_thread(thread) -> None:
        if (
            getattr(thread, "parent_id", None) == TE4_RESULTS_CHANNEL_ID
            and _is_public_interview_thread(thread)
        ):
            found[thread.id] = thread

    for thread in getattr(result_channel, "threads", []) or []:
        add_thread(thread)

    guild = getattr(result_channel, "guild", None)
    fetch_active_threads = getattr(guild, "fetch_active_threads", None)
    if fetch_active_threads is not None:
        try:
            active = await fetch_active_threads()
            active_threads = getattr(active, "threads", active)
            for thread in active_threads or []:
                add_thread(thread)
        except Exception as exc:
            print(f"[AI Interview] Active-thread recovery scan failed: {exc}")

    archived_threads = getattr(result_channel, "archived_threads", None)
    if archived_threads is not None:
        try:
            async for thread in archived_threads(
                limit=100,
                private=False,
                joined=False,
            ):
                add_thread(thread)
        except Exception as exc:
            print(f"[AI Interview] Archived-thread recovery scan failed: {exc}")

    return list(found.values())


async def _recover_interviews_after_restart() -> None:
    """Resume recent interviews whose last message came from a player."""
    await client.wait_until_ready()
    await asyncio.sleep(INTERVIEW_RECOVERY_DELAY_SECONDS)
    recovered_count = 0
    try:
        for thread in await _fetch_recent_interview_threads():
            if thread.id in _active_interviews:
                continue
            try:
                messages = [
                    message
                    async for message in thread.history(
                        limit=100,
                        oldest_first=True,
                    )
                ]
            except Exception as exc:
                print(
                    f"[AI Interview] Could not read recovery history "
                    f"for {thread.id}: {exc}"
                )
                continue

            rebuilt = _rebuild_interview_from_messages(thread, messages)
            if rebuilt is None:
                continue
            interview, last_player_message = rebuilt
            _active_interviews[thread.id] = interview
            try:
                if getattr(thread, "archived", False):
                    await thread.edit(archived=False)
                await _handle_interview_reply(last_player_message, interview)
                recovered_count += 1
            except Exception as exc:
                _active_interviews.pop(thread.id, None)
                print(
                    f"[AI Interview] Recovery failed for thread {thread.id}: "
                    f"{type(exc).__name__}: {exc}"
                )
    except Exception as exc:
        print(f"[AI Interview] Recovery scan failed: {type(exc).__name__}: {exc}")
    print(f"[AI Interview] Recovery resumed {recovered_count} recent interview(s)")


_interview_expiry_started = False
_interview_recovery_started = False


async def _ack_pending_interview_message(message) -> bool:
    """Acknowledge invite-thread messages without resolving the button choice."""
    pending = _pending_interviews.get(getattr(message.channel, "id", None))
    if not pending or getattr(message.author, "bot", False):
        return False
    allowed_ids = {
        int(user_id)
        for user_id in (pending.get("player_ids") or [])
        if str(user_id).isdigit()
    }
    if allowed_ids and message.author.id not in allowed_ids:
        return False
    await message.channel.send(
        f"{message.author.mention} I’ve received your message. "
        "This interview invite is still waiting for an explicit **Accept** "
        "or **Decline** button click, so your message has not changed its status.",
        allowed_mentions=discord.AllowedMentions(
            everyone=False,
            roles=False,
            users=True,
        ),
    )
    return True


async def _try_trigger_interview(message, ai_client, loser_only=False):
    """
    Core interview trigger logic. Called from on_message (live).
    Assumes message has 2+ mentions, an attachment, and contains 'def'.
    """
    image_attachments = [a for a in message.attachments if a.content_type and a.content_type.startswith("image/")]

    _mention_id_order = [int(m) for m in re.findall(r'<@!?(\d+)>', message.content)]
    _mention_map = {u.id: u for u in message.mentions}
    # Fallback: resolve any missing users via guild cache, then API
    if hasattr(message, 'guild') and message.guild:
        for uid in _mention_id_order:
            if uid not in _mention_map:
                member = message.guild.get_member(uid)
                if member is None:
                    try:
                        member = await message.guild.fetch_member(uid)
                    except Exception as _fe:
                        print(f"[AI Interview] fetch_member({uid}) failed: {_fe}")
                if member:
                    _mention_map[uid] = member
    # Last resort: fetch as User (works even if member left the guild)
    for uid in _mention_id_order:
        if uid not in _mention_map:
            try:
                user = await client.fetch_user(uid)
                if user:
                    _mention_map[uid] = user
            except Exception as _ue:
                print(f"[AI Interview] fetch_user({uid}) failed: {_ue}")
    ordered_mentions = [_mention_map[mid] for mid in _mention_id_order if mid in _mention_map]
    _seen = set()
    ordered_mentions = [u for u in ordered_mentions if not (u.id in _seen or _seen.add(u.id))]

    if len(ordered_mentions) < 2:
        print(f"[AI Interview] Could not resolve 2 mentioned users — content IDs: {_mention_id_order}, resolved: {list(_mention_map.keys())} — skipping interview")
        return

    _def_match_main = re.search(r'\bdef\b', message.content, re.IGNORECASE)
    _before_def_str = message.content[:_def_match_main.start()] if _def_match_main else message.content
    is_doubles = bool(re.search(r'<@!?\d+>\s*/\s*<@!?\d+>', _before_def_str))

    is_fictional_doubles = False
    fictional_winner_names = []
    if not is_doubles:
        _def_match = _def_match_main
        if _def_match:
            _before_def = message.content[:_def_match.start()]
            if '/' in _before_def and not re.search(r'<@!?\d+>', _before_def):
                is_fictional_doubles = True
                _raw_names = [n.strip() for n in _before_def.split('/')]
                _raw_names = [n for n in _raw_names if n][:2]
                def _extract_fictional_name(raw):
                    m = re.search(r'[A-Z]\.\s+[A-Z][a-z]+\s*$', raw)
                    if m:
                        return m.group(0).strip()
                    words = raw.split()
                    return ' '.join(words[-2:]) if len(words) > 2 else raw
                fictional_winner_names = [_extract_fictional_name(n) for n in _raw_names]

    if is_doubles:
        winner1 = ordered_mentions[0]
        winner2 = ordered_mentions[1]
        player_name = f"{winner1.display_name} & {winner2.display_name}"
        player_ids_list = [winner1.id, winner2.id]
        opponent_name = None
        raw_lower = message.content.lower()
        for word in ["def", "def.", "defeated", "beat"]:
            if word in raw_lower:
                parts = raw_lower.split(word, 1)
                if len(parts) > 1:
                    opponent_name = parts[1].strip().split("/")[0].strip(",. @") or None
                    break
        profile_context = ""
        profile_section = ""
        loser_user = None
        loser_name = None
        loser_profile_section = ""
        print(f"[AI Interview] Doubles match detected: {player_name}")
    elif is_fictional_doubles:
        player_name = " & ".join(fictional_winner_names) if fictional_winner_names else "Fictional Players"
        player_ids_list = []
        opponent_name = None
        profile_context = ""
        profile_section = ""
        loser_user = None
        loser_name = None
        loser_profile_section = ""
        print(f"[AI Interview] Fictional doubles detected: {player_name}")
    else:
        winner = ordered_mentions[0]
        player_name = winner.display_name
        player_ids_list = [winner.id]
        opponent_name = None
        for mentioned_user in message.mentions:
            if mentioned_user.id != winner.id:
                opponent_name = mentioned_user.display_name
                break
        if not opponent_name:
            msg_lower = message.content.lower()
            for word in ["def", "def.", "defeated", "beat", "vs", "vs."]:
                if word in msg_lower:
                    parts = msg_lower.split(word, 1)
                    if len(parts) > 1:
                        opp_part = parts[1].strip().split()[0] if parts[1].strip() else None
                        if opp_part:
                            opponent_name = opp_part.strip(",. @")
                            break

        profile_context = await fetch_player_profile_context(player_name, opponent_name)
        print(f"[AI Interview] Profile context for {player_name!r}: {profile_context[:300] if profile_context else 'NOT FOUND'}")
        profile_section = f"\n\nPLAYER PROFILE DATA FROM WTSL (verified facts — use these exact values, do not use screenshot values for ranking or Elo):\n{profile_context}" if profile_context else ""

        # Loser is the second mentioned player
        loser_user = ordered_mentions[1] if len(ordered_mentions) >= 2 else None
        loser_name = loser_user.display_name if loser_user else None
        if loser_user:
            loser_profile_context = await fetch_player_profile_context(loser_name, player_name)
            print(f"[AI Interview] Loser profile context for {loser_name!r}: {loser_profile_context[:300] if loser_profile_context else 'NOT FOUND'}")
            loser_profile_section = f"\n\nPLAYER PROFILE DATA FROM WTSL (verified facts):\n{loser_profile_context}" if loser_profile_context else ""
        else:
            loser_profile_section = ""

    persona = random.choice(JOURNALIST_PERSONAS)

    is_any_doubles = is_doubles or is_fictional_doubles
    interview_subject = (
        f"Doubles pair being interviewed: {player_name} (address them as a team — use 'you two', 'you both', 'your partnership' etc.)"
        if is_any_doubles else
        f"Player being interviewed: {player_name}"
    )

    questions_prompt = f"""You are {persona['name']}, a journalist conducting a short post-match interview for the WTSL (World Tennis Simulation League), a Tennis Elbow 4 gaming league.

{persona['system']}

The result just posted:
"{message.content}"

{interview_subject}{profile_section}

If there is an attached image, read EVERY stat label and value exactly as displayed — do NOT paraphrase or rename stats.

CONTEXT YOU MAY REFERENCE:
- Anything in the message text
- Stats and scores in the attached image — use EXACT label names
- WTSL profile data above (rank, Elo, recent results, H2H) — use these over screenshot values for rank/Elo

CRITICAL RULES:
- Do NOT invent anything not shown in the data
- Do NOT use screenshot values for ranking or Elo if WTSL profile data is provided
- Quote stat names from the screenshot verbatim

FOCUS FOR THIS INTERVIEW:
{persona['angle']}

Generate exactly 3 questions. Every question MUST:
- Be ONE short sentence. No preamble. No essay.
- Be about THIS match — what happened today, right now
- NOT ask about long-term goals, career plans, or the future beyond the next round
- NOT be philosophical or abstract
- Reference something specific and verifiable (a score, a stat, a moment)
- Cover a DIFFERENT topic from the other two questions
{"- Address both players together as a team (use 'you two', 'you both', 'your partnership')" if is_any_doubles else ""}

BAD: "How does this result fit into the broader tapestry of your WTSL journey and what does it mean for where you see yourself going?"
GOOD: "That second set was 6-1 — did you find a gear shift or did they drop off?"

IMPORTANT: Return ONLY the 3 questions, one per line, numbered 1. 2. 3. — nothing else."""

    user_content = []
    user_content.append({"type": "text", "text": questions_prompt})
    for img in image_attachments:
        user_content.append({"type": "image_url", "image_url": {"url": img.url}})

    doubles_system_note = (
        "You are interviewing a DOUBLES PAIR — address them as a team, use 'you two', 'you both', 'your partnership'. "
        if is_any_doubles else
        "You are interviewing a player in the WTSL gaming league. "
    )
    system_msg = (
        f"{persona['system']} "
        f"{doubles_system_note}"
        "Keep responses SHORT and punchy — maximum 2 short sentences per reply, no padding, no elaboration. "
        "Follow the player's lead — if they bring something up, go with it. Do not force the conversation back to stats if the player has moved on. "
        "Do not ask about long-term career goals or abstract future plans. "
        "Never say 'that's a great answer' or 'great question'. "
        "IMPORTANT: Quote stat labels exactly as shown in screenshots — never paraphrase them."
    )

    first_q_prompt = questions_prompt + "\n\nGenerate ONLY the opening question to start the interview. Return just the question text, nothing else — no numbering, no intro, no greeting."

    first_q_content = list(user_content) if image_attachments else first_q_prompt
    if image_attachments:
        first_q_content[0] = {"type": "text", "text": first_q_prompt}

    first_question = None
    if is_fictional_doubles:
        try:
            first_question = _generate_interview_opening_question(
                ai_client,
                system_msg,
                first_q_content,
            )
        except Exception as exc:
            print(f"[AI Interview] Opening question generation failed: {exc}")
            return

    # Generate loser interview materials (singles only)
    loser_first_question = None
    loser_conversation_history = None
    loser_system_msg = None
    if loser_user and loser_name:
        loser_system_msg = (
            f"{persona['system']} "
            "You are interviewing a player in the WTSL gaming league who just LOST their match. "
            "Keep responses SHORT and punchy — maximum 2 short sentences per reply, no padding, no elaboration. "
            "Follow the player's lead — if they bring something up, go with it. "
            "Be empathetic but direct — you are a journalist, not a counsellor. "
            "Do not ask about long-term career goals or abstract future plans. "
            "Never say 'that's a great answer' or 'great question'. "
            "IMPORTANT: Quote stat labels exactly as shown in screenshots — never paraphrase them."
        )
        loser_q_prompt = f"""You are {persona['name']}, a journalist conducting a short post-match interview for the WTSL (World Tennis Simulation League), a Tennis Elbow 4 gaming league.

{persona['system']}

The result just posted:
"{message.content}"

Player being interviewed: {loser_name} — THE LOSER of this match.
Opponent who beat them: {player_name}{loser_profile_section}

CONTEXT YOU MAY REFERENCE:
- Anything in the message text
- Stats and scores in the attached image — use EXACT label names
- WTSL profile data above — use these over screenshot values for rank/Elo

CRITICAL RULES:
- Do NOT invent anything not shown in the data
- You are interviewing the LOSER — every question must reflect losing
- Ask about what went wrong, key turning points, and their reaction to the defeat
- Be empathetic but direct — this is a press conference, not therapy
- Do NOT congratulate them on winning

Generate exactly 3 questions for the LOSER. Every question MUST:
- Be ONE short sentence. No preamble. No essay.
- Be about THIS match — what went wrong, turning points, reaction to defeat
- NOT ask about long-term goals, career plans, or the future beyond bouncing back
- NOT be philosophical or abstract
- Reference something specific and verifiable (a score, a stat, a moment)
- Cover a DIFFERENT topic from the other two questions

BAD: "How does this loss fit into your WTSL journey going forward?"
GOOD: "You lost the second set 6-1 — what changed after the first set?"

IMPORTANT: Return ONLY the 3 questions, one per line, numbered 1. 2. 3. — nothing else."""

        loser_user_content = [{"type": "text", "text": loser_q_prompt}]
        for img in image_attachments:
            loser_user_content.append({"type": "image_url", "image_url": {"url": img.url}})

        loser_first_q_prompt = loser_q_prompt + "\n\nGenerate ONLY the opening question to start the interview. Return just the question text, nothing else — no numbering, no intro, no greeting."
        loser_first_q_content = list(loser_user_content) if image_attachments else loser_first_q_prompt
        if image_attachments:
            loser_first_q_content[0] = {"type": "text", "text": loser_first_q_prompt}
        # The loser receives the same explicit acceptance gate as the winner.
        # Its opening question is generated only after that player accepts.
        loser_first_question = None
        loser_conversation_history = [
            {"role": "system", "content": loser_system_msg},
            {"role": "user", "content": loser_user_content if image_attachments else loser_q_prompt},
        ]
        print(f"[AI Interview] Loser invite prepared for {loser_name!r}")

    msg_lower = message.content.lower()

    # Extract tournament name — text before the round keyword (e.g. "Wimbledon Final", "Roland Garros F")
    _tn_match = re.search(r'^([A-Za-z][\w\s\-\'\.]*?)\s+(?:final|semi-final|sf|quarter-final|qf)\b',
                          message.content, re.IGNORECASE)
    tournament_name = _tn_match.group(1).strip() if _tn_match else None

    is_qf = (
        "quarter-final" in msg_lower or "quarter final" in msg_lower or
        " qf " in msg_lower or msg_lower.startswith("qf ") or
        msg_lower.endswith(" qf") or msg_lower == "qf"
    )
    is_sf = (
        "semi-final" in msg_lower or
        "semi final" in msg_lower or
        " sf " in msg_lower or msg_lower.startswith("sf ") or
        msg_lower.endswith(" sf") or msg_lower == "sf"
    )
    is_f = (
        " f " in msg_lower or msg_lower.startswith("f ") or
        msg_lower.endswith(" f") or msg_lower == "f"
    )
    is_final = ("final" in msg_lower or is_f) and not is_sf and not is_qf

    if is_final:
        round_hint = "Final"
        if tournament_name:
            opener = random.choice([
                f"congratulations on winning the {tournament_name}",
                f"what a performance to win the {tournament_name}",
                f"incredible — you've won the {tournament_name}",
                f"champion — you've taken the {tournament_name} title",
            ])
        else:
            opener = random.choice([
                "congratulations on winning the title",
                "what a performance to win the tournament",
                "incredible — you've taken the trophy",
                "champion — outstanding tennis to claim the title",
            ])
    elif is_sf:
        round_hint = "Semi-Final"
        opener = random.choice([
            "great run to the semi-final",
            "brilliant performance to reach the semis",
            "impressive tennis to make the semi-final",
            "well played in the semi-final",
        ])
    elif is_qf:
        round_hint = "Quarter-Final"
        opener = random.choice([
            "well played in the quarter-final",
            "solid performance in the QF today",
            "nice work coming through the quarter-final",
            "great result in the quarter-final",
        ])
    else:
        round_hint = "Match"
        opener = random.choice([
            "well played today",
            "nice result out there",
            "solid performance",
            "good match today",
            "great result",
        ])

    # Loser opener (mirrors the round, but empathetic)
    if loser_user:
        if is_final:
            if tournament_name:
                loser_opener = random.choice([
                    f"tough one to fall short in the {tournament_name} final",
                    f"so close — gutting to lose the {tournament_name} final",
                    f"a difficult day in the {tournament_name} final",
                ])
            else:
                loser_opener = random.choice([
                    "tough one to lose in the final",
                    "a difficult day at the office in the final",
                    "so close — gutting result in the final",
                ])
        elif is_sf:
            loser_opener = random.choice([
                "hard luck in the semi-final",
                "tough exit at the semi-final stage",
                "so close to the final — hard one to take",
            ])
        elif is_qf:
            loser_opener = random.choice([
                "hard luck in the quarter-final",
                "tough exit at the QF stage",
                "unlucky in the quarter-final today",
            ])
        else:
            loser_opener = random.choice([
                "tough result today",
                "hard one to take",
                "unlucky out there today",
                "that was a difficult match",
            ])
    else:
        loser_opener = "tough result today"

    if is_final:
        system_msg += " When signing off at the end of the interview, wish them luck in their next tournament — never say 'next round'."
        if loser_conversation_history:
            loser_conversation_history[0]["content"] += " When signing off at the end of the interview, wish them luck in their next tournament — never say 'next round'."

    conversation_history = [
        {"role": "system", "content": system_msg},
        {"role": "user", "content": user_content if image_attachments else questions_prompt},
    ]
    created_at = time.time()

    journalist_name = persona["name"]

    if is_fictional_doubles:
        thread = await message.create_thread(
            name=f"🎤 Post-Match Interview: {player_name}"[:100],
            auto_archive_duration=10080
        )
        journalist_name = persona["name"]
        await thread.send(f"🎤 **Post-Match Press Conference** — {opener}! I'm {journalist_name}, let's hear from {player_name}.")
        asyncio.create_task(_run_fictional_doubles_interview(
            thread, fictional_winner_names, persona, first_question, conversation_history, ai_client,
            image_attachments=image_attachments, message_content=message.content
        ))
        print(f"[AI Interview] Fictional doubles auto-interview started in thread {thread.id} for {player_name}")
    else:
        if not loser_only:
            invite_thread = await message.channel.create_thread(
                name=f"📩 Interview Invite – {player_name}"[:100],
                type=discord.ChannelType.private_thread,
                invitable=False,
                auto_archive_duration=1440
            )
            try:
                await invite_thread.add_user(ordered_mentions[0])
                if is_doubles:
                    try:
                        await invite_thread.add_user(ordered_mentions[1])
                    except Exception as e:
                        print(f"[AI Interview] Could not add second doubles player to invite thread: {e}")
            except Exception as e:
                print(f"[AI Interview] Could not add player to invite thread: {e}")

            _pending_interviews[invite_thread.id] = {
                "player_ids": player_ids_list,
                "player_id": ordered_mentions[0].id,
                "player_name": player_name,
                "first_question": first_question,
                "first_question_system": system_msg,
                "first_question_content": first_q_content,
                "opener": opener,
                "journalist_name": journalist_name,
                "round_hint": "Doubles" if is_doubles else round_hint,
                "conversation_history": conversation_history,
                "result_channel_id": message.channel.id,
                "result_message_id": message.id,
                "created_at": created_at,
                "reaction_style": persona["reaction_style"],
                "player_names_for_image": (
                    [ordered_mentions[0].display_name, ordered_mentions[1].display_name]
                    if is_doubles else [winner.display_name]
                ),
                "round_hint_for_image": round_hint,
            }
            view = InterviewAcceptView(private_thread_id=invite_thread.id, player_ids=player_ids_list)
            if is_doubles:
                winner1_mention = ordered_mentions[0].mention
                winner2_mention = ordered_mentions[1].mention
                await invite_thread.send(
                    f"🎤 {winner1_mention} {winner2_mention} — you've both been selected for a post-match press conference! "
                    f"Either of you can accept or decline.",
                    view=view
                )
            else:
                await invite_thread.send(
                    f"🎤 {ordered_mentions[0].mention} — you've been selected for a post-match press conference! "
                    f"Would you like to participate?",
                    view=view
                )
            print(f"[AI Interview] Private invite thread {invite_thread.id} created for {player_name}")
        # Send loser invite for singles matches
        if loser_user and loser_conversation_history:
            try:
                loser_invite_thread = await message.channel.create_thread(
                    name=f"📩 Interview Invite – {loser_name}"[:100],
                    type=discord.ChannelType.private_thread,
                    invitable=False,
                    auto_archive_duration=1440
                )
                try:
                    await loser_invite_thread.add_user(loser_user)
                except Exception as _ladd:
                    print(f"[AI Interview] Could not add loser to invite thread: {_ladd}")
                _pending_interviews[loser_invite_thread.id] = {
                    "player_ids": [loser_user.id],
                    "player_id": loser_user.id,
                    "player_name": loser_name,
                    "first_question": loser_first_question,
                    "first_question_system": loser_system_msg,
                    "first_question_content": loser_first_q_content,
                    "opener": loser_opener,
                    "journalist_name": journalist_name,
                    "round_hint": round_hint,
                    "conversation_history": loser_conversation_history,
                    "result_channel_id": message.channel.id,
                    "result_message_id": message.id,
                    "created_at": created_at,
                    "reaction_style": persona["reaction_style"],
                    "player_names_for_image": [loser_name],
                    "round_hint_for_image": round_hint,
                    "is_loser": True,
                }
                loser_view = InterviewAcceptView(private_thread_id=loser_invite_thread.id, player_ids=[loser_user.id])
                await loser_invite_thread.send(
                    f"🎤 {loser_user.mention} — you've been invited for a post-match press conference. "
                    f"Would you like to participate?",
                    view=loser_view
                )
                print(f"[AI Interview] Loser invite thread {loser_invite_thread.id} created for {loser_name}")
            except Exception as _linv:
                print(f"[AI Interview] Loser invite error: {_linv}")

async def _save_processed_screenshot_receipts(keys: set[str]) -> None:
    """Write the local ledger, then persist its receipts to PostgreSQL."""
    await asyncio.to_thread(save_processed_stats, keys)
    await asyncio.to_thread(persist_screenshot_receipts, keys)
def _merge_matchlog_raw_coverage(
    coverage: typing.Iterable[dict[str, typing.Any]],
) -> None:
    for entry in coverage:
        tour = str(entry.get("tour") or "").casefold()
        player = normalize_matchlog_name(entry.get("player"))
        first_record = str(entry.get("first_record") or "")[:10]
        if (
            tour not in {"atp", "wta"}
            or not player
            or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", first_record)
        ):
            continue
        key = (tour, player)
        current = _matchlog_raw_coverage_index.get(key)
        if current is None or first_record < current:
            _matchlog_raw_coverage_index[key] = first_record


TE4_RESULTS_CHANNEL_ID = 801918765226917988
MATCHLOG_SUBMISSIONS_CHANNEL_ID = 1546326289013543043
MATCHLOG_UPLOAD_TEMPLATE = Path(
    "attached_assets/player_stats_upload_sheet_TE4_0609_FINAL_AK_1788744336645.csv"
)
SCREENSHOT_STATS_UPLOAD_TEMPLATE = Path(
    "attached_assets/player_stats_upload_sheet_TE4_(1)_1790370794635.csv"
)
STATS_TEST_FLAG = ".stats_workbook_test_done"
ATP_CSV_RECIPIENT_ID = 131069457031233536
ATP_CSV_RECIPIENT_FILE = Path("Master TE Hub Stats.csv")
PERIODIC_ATP_CSV_DELIVERY_ENABLED = False
STATS_DELIVERY_STATE_FILE = Path("stats_workbook_delivery.json")
STATS_TIMEZONE = ZoneInfo("Europe/London")
STATS_EOD_HOUR = 0
STATS_EOD_MINUTE = 0
PLAYER_STATS_UPLOAD_RECEIPT_PREFIX = (
    "Screenshot ATP/WTA player stats upload receipt:"
)
SCREENSHOT_REVIEW_CSV_FILENAME = "screenshot_match_records_needing_review.csv"
SCREENSHOT_REVIEW_RECEIPT_PREFIX = "Screenshot review receipt:"
_stats_scrape_lock = asyncio.Lock()
_stats_rankings_cache = None
_stats_rankings_cache_time = 0.0
_pending_stats_result_posts = {}
_stats_workbook_promotion_started = False
_matchlog_official_cache = None
_matchlog_official_cache_time = 0.0
_matchlog_official_refresh_lock = asyncio.Lock()
_matchlog_player_results_cache = {}
_matchlog_player_results_cache_time = {}
_matchlog_player_results_lock = asyncio.Lock()
_matchlog_public_history_task: asyncio.Task | None = None
_matchlog_owner_history_task: asyncio.Task | None = None
_matchlog_public_messages_scanned = 0
_matchlog_owner_messages_scanned = 0
_matchlog_rebuild_state = "not_started"
_matchlog_rebuild_done = 0
_matchlog_rebuild_total = None
_matchlog_raw_coverage_index: dict[tuple[str, str], str] = {}
_matchlog_identity_index: dict[int, dict[str, str]] = {}
_matchlog_status_subscribers: set[int] = set()
_matchlog_owner_progress_message = None
_matchlog_owner_progress_updated_at = 0.0
_matchlog_owner_progress_lock = asyncio.Lock()
_matchlog_player_ids_cache = {}
_matchlog_player_ids_cache_time = 0.0
MATCHLOG_MAX_ATTACHMENT_BYTES = 5 * 1024 * 1024
MATCHLOG_RECEIPT_RE = re.compile(
    r"MatchLog receipt: `([0-9a-f]{64})(?:\|(\d+))?`"
)
MATCHLOG_ADMIN_IDENTITY_RE = re.compile(
    r"MatchLog admin identity: `(\d+)\|([0-9a-f]+)`"
)
MATCHLOG_ARCHIVE_RE = re.compile(
    r"MatchLog archive: `([0-9a-f]{64})\|(\d+)\|(\d+)\|(\d+)`"
)
MATCHLOG_RETAINED_SOURCE_RE = re.compile(
    r"MatchLog retained source: `([0-9a-f]{64})\|(\d+)\|(\d+)\|(\d+)`"
)


def _newer_statistics_workbook_candidate() -> Path | None:
    """Return the newest uploaded TE4_HUB workbook newer than the active file."""
    if not MATCH_STATS_WORKBOOK.exists():
        return None
    active = MATCH_STATS_WORKBOOK.resolve()
    candidates = [
        path for path in Path("attached_assets").glob("*")
        if path.is_file()
        and path.suffix.casefold() == ".xlsx"
        and "te4_hub" in path.name.casefold()
        and path.resolve() != active
        and ".backup-" not in path.name
        and path.stat().st_mtime_ns > MATCH_STATS_WORKBOOK.stat().st_mtime_ns
    ]
    return max(candidates, key=lambda path: path.stat().st_mtime_ns, default=None)


async def _activate_newer_statistics_workbook() -> dict | None:
    """Promote one newer upload while all workbook readers/writers are excluded."""
    candidate = _newer_statistics_workbook_candidate()
    if candidate is None:
        return None
    async with _stats_scrape_lock:
        # Recheck after waiting for the lock in case another startup path won.
        candidate = _newer_statistics_workbook_candidate()
        if candidate is None:
            return None
        result = await asyncio.to_thread(
            promote_statistics_workbook, candidate, MATCH_STATS_WORKBOOK
        )
        try:
            await asyncio.to_thread(
                persist_screenshot_workbook,
                MATCH_STATS_WORKBOOK,
                MATCH_STATS_RECEIPTS_FILE,
            )
        except Exception:
            await asyncio.to_thread(
                restore_screenshot_workbook_from_store,
                MATCH_STATS_WORKBOOK,
                MATCH_STATS_RECEIPTS_FILE,
            )
            raise
        _mystats_insight_cache.clear()
        _leaderboard_rankings_cache.clear()
        _leaderboard_rankings_cache_time.clear()
        global _stats_rankings_cache, _stats_rankings_cache_time
        _stats_rankings_cache = None
        _stats_rankings_cache_time = 0.0
        return result


def _matchlog_attachments(message):
    return [
        attachment for attachment in getattr(message, "attachments", [])
        if (
            str(getattr(attachment, "content_type", "") or "").split(";")[0]
            in {"text/html", "application/xhtml+xml"}
            or str(getattr(attachment, "filename", "")).lower().endswith(
                (".html", ".htm")
            )
        )
    ][:10]


def _matchlog_page_count(page: str) -> int:
    soup = BeautifulSoup(page, "html.parser")
    page_numbers = []
    for link in soup.select(".pagination a[href]"):
        match = re.search(
            r"(?:[?&])pagination=(\d+)",
            str(link.get("href", "")),
        )
        if match:
            page_numbers.append(int(match.group(1)))
    return min(max(page_numbers or [1]), 100)


def _matchlog_player_ids(rankings: dict) -> dict[str, set[tuple[str, str]]]:
    ids_by_name = {}
    for tour, tour_players in rankings.items():
        for key, info in tour_players.items():
            ids_by_name.setdefault(key, set()).add(
                (str(tour), str(info["id"]))
            )
    return ids_by_name


async def _get_matchlog_official_results():
    global _matchlog_official_cache, _matchlog_official_cache_time
    now = time.time()
    if (
        _matchlog_official_cache is not None
        and now - _matchlog_official_cache_time < 15 * 60
    ):
        return _matchlog_official_cache
    async with _matchlog_official_refresh_lock:
        now = time.time()
        if (
            _matchlog_official_cache is not None
            and now - _matchlog_official_cache_time < 15 * 60
        ):
            return _matchlog_official_cache

        try:
            parsed = await asyncio.wait_for(
                get_all_results(allow_stale=True),
                timeout=MYSTATS_OFFICIAL_RESULTS_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError as exc:
            raise RuntimeError(
                "The official WTSL results cache could not be loaded quickly enough"
            ) from exc
        if not parsed:
            raise RuntimeError(
                "The official WTSL all-results page returned no matches"
            )
        _matchlog_official_cache = parsed
        _matchlog_official_cache_time = now
        return parsed


async def _get_matchlog_player_official_results(
    player_names: set[str],
    *,
    require_complete: bool = False,
) -> list[dict]:
    wanted = {
        normalize_matchlog_name(name)
        for name in player_names
        if normalize_matchlog_name(name)
    }
    if not wanted:
        return []

    lookup_started = time.monotonic()
    all_results = await get_all_results()
    found = {
        normalize_matchlog_name(result.get("player1") or result.get("p1"))
        for result in all_results
    } | {
        normalize_matchlog_name(result.get("player2") or result.get("p2"))
        for result in all_results
    }
    if require_complete and not wanted.issubset(found):
        raise RuntimeError(
            "Targeted official-history cleanup is incomplete; unresolved players: "
            + ", ".join(sorted(wanted - found))
        )
    results = [
        result for result in all_results
        if wanted.intersection({
            normalize_matchlog_name(result.get("player1") or result.get("p1")),
            normalize_matchlog_name(result.get("player2") or result.get("p2")),
        })
    ]
    print(
        f"[MatchLog Stats] targeted full-cache lookup returned {len(results)} "
        f"result(s) in {time.monotonic() - lookup_started:.1f}s",
        flush=True,
    )
    return results


def _matchlog_user_names(user) -> list[str]:
    return list(dict.fromkeys(
        str(value).strip()
        for value in (
            getattr(user, "display_name", None),
            getattr(user, "global_name", None),
            getattr(user, "name", None),
        )
        if str(value or "").strip()
    ))


def _matchlog_receipts_by_message(messages, bot_user_id: int) -> dict[int, set[str]]:
    trusted = {}
    for message in messages:
        if getattr(message.author, "id", None) != bot_user_id:
            continue
        legacy_source_id = getattr(
            getattr(message, "reference", None), "message_id", None
        )
        for source_hash, embedded_source_id in MATCHLOG_RECEIPT_RE.findall(
            message.content or ""
        ):
            source_id = (
                int(embedded_source_id)
                if embedded_source_id else legacy_source_id
            )
            if source_id:
                trusted.setdefault(source_id, set()).add(source_hash)
    return trusted


def _matchlog_private_receipts_by_message(
    messages, bot_user_id: int
) -> dict[int, set[str]]:
    trusted = {}
    for message in messages:
        if getattr(message.author, "id", None) != bot_user_id:
            continue
        for source_hash, _, source_message_id, _ in (
            MATCHLOG_RETAINED_SOURCE_RE.findall(message.content or "")
        ):
            trusted.setdefault(int(source_message_id), set()).add(source_hash)
    return trusted


def _matchlog_admin_identities(messages, bot_user_id: int) -> dict[int, dict[str, str]]:
    identities = {}
    for message in messages:
        if getattr(message.author, "id", None) != bot_user_id:
            continue
        for user_id, encoded_player in MATCHLOG_ADMIN_IDENTITY_RE.findall(
            message.content or ""
        ):
            try:
                player = bytes.fromhex(encoded_player).decode("utf8")
            except (ValueError, UnicodeDecodeError):
                continue
            prefix, separator, name = player.partition(":")
            tour = normalize_matchlog_name(prefix) if separator else "atp"
            if tour in {"atp", "wta"}:
                identities.setdefault(int(user_id), {})[tour] = (
                    name.strip() if separator else player
                )
    return identities


def _matchlog_identity_label(links: dict[str, str]) -> str:
    return ", ".join(
        f"{tour.upper()}: {player}" for tour, player in sorted(links.items())
    )


def _matchlog_links(user_id: int) -> dict[str, str]:
    """Read legacy in-memory single links as an ATP link during upgrades."""
    links = _matchlog_identity_index.get(user_id, {})
    if isinstance(links, str):
        prefix, separator, player = links.partition(":")
        tour = normalize_matchlog_name(prefix) if separator else "atp"
        links = {
            tour if tour in {"atp", "wta"} else "atp":
            player.strip() if separator else links
        }
        _matchlog_identity_index[user_id] = links
    return links


async def _notify_matchlog_owner_for_verification(message, players) -> None:
    owner = await client.fetch_user(OWNER_ID)
    player_list = ", ".join(f"`{player}`" for player in sorted(
        set(players), key=normalize_matchlog_name
    ))
    await owner.send(
        f"<@{OWNER_ID}> 🔐 **MatchLog identity verification needed**\n"
        f"Discord member: {message.author.mention} "
        f"(`{message.author.id}`)\n"
        f"Accepted match players: {player_list}\n"
        "The accepted HTML has been archived privately in this DM; processing "
        "details and files were not posted publicly.\n\n"
        "In the WTSL server, run `/linkmatchlogplayer`, select this member, "
        "and enter the verified player's exact WTSL name.",
        allowed_mentions=discord.AllowedMentions(
            everyone=False,
            roles=False,
            users=True,
        ),
        silent=False,
    )


async def _archive_matchlog_attachment(
    *,
    source_hash: str,
    submitter_id: int,
    message_id: int,
    attachment_id: int,
    filename: str,
    raw: bytes,
) -> None:
    owner = await client.fetch_user(OWNER_ID)
    metadata = (
        f"{source_hash}|{submitter_id}|{message_id}|{attachment_id}"
    )
    try:
        await owner.send(
            f"MatchLog archive: `{metadata}`",
            file=discord.File(io.BytesIO(raw), filename=filename),
        )
    except Exception:
        await owner.send(f"MatchLog retained source: `{metadata}`")
        raise


async def _send_matchlog_status(message, content: str, *, file=None) -> None:
    """Send MatchLog processing details privately to the submitter."""
    kwargs = {"file": file} if file is not None else {}
    return await message.author.send(content, **kwargs)


async def _send_matchlog_owner_submission_progress(
    message, attachment_count: int
):
    """Tell the owner immediately that a private MatchLog job has started."""
    owner = await client.fetch_user(OWNER_ID)
    return await owner.send(
        "⏳ **MatchLog submission processing started**\n"
        f"Discord member: {message.author.mention} "
        f"(`{message.author.id}`)\n"
        f"Files: **{attachment_count}**\n"
        f"Source message: `{message.id}`\n"
        "Official-result verification is running. A separate identity "
        "verification message will follow only if matches are accepted and "
        "this member is not already linked."
    )


async def _send_matchlog_owner_csv(
    message, upload_csv: bytes, composite_csv: bytes
) -> None:
    owner = await client.fetch_user(OWNER_ID)
    await owner.send(
        f"Private cumulative MatchLog files refreshed after an upload from "
        f"{message.author.mention} (`{message.author.id}`).",
        files=[
            discord.File(
                io.BytesIO(upload_csv),
                filename="player_stats_upload_matchlog.csv",
            ),
            discord.File(
                io.BytesIO(composite_csv),
                filename="composite_matchlog.csv",
            ),
        ],
    )


async def _process_matchlog_submission(
    message,
    *,
    announce=True,
    trusted_hashes=frozenset(),
    submitter_id_override=None,
    source_message_id_override=None,
    status_sender=None,
    delete_source=True,
) -> int:
    attachments = _matchlog_attachments(message)
    if not attachments:
        return 0
    replies = []
    eligible_count = sum(
        1 for attachment in getattr(message, "attachments", [])
        if (
            str(getattr(attachment, "content_type", "") or "").split(";")[0]
            in {"text/html", "application/xhtml+xml"}
            or str(getattr(attachment, "filename", "")).lower().endswith(
                (".html", ".htm")
            )
        )
    )
    if eligible_count > len(attachments):
        replies.append(
            "Only the first 10 HTML attachments were processed; upload any "
            "remaining MatchLogs in a new message."
        )
    receipts = []
    added_total = 0
    verification_players = set()
    successful_source_hashes = set()
    delete_original = False
    archive_failed = False
    processing_failed = False
    progress_message = None
    owner_progress_message = None
    submitter_status_failed = False
    submitter_id = (
        int(submitter_id_override)
        if submitter_id_override is not None else message.author.id
    )
    source_message_id = (
        int(source_message_id_override)
        if source_message_id_override is not None else message.id
    )

    async def send_status(content: str, *, file=None) -> None:
        nonlocal submitter_status_failed
        try:
            if status_sender is not None:
                return await status_sender(content, file=file)
            return await _send_matchlog_status(message, content, file=file)
        except Exception as status_exc:
            submitter_status_failed = True
            print(
                "[MatchLog Stats] submitter status DM failed for "
                f"{submitter_id}: {status_exc}",
                flush=True,
            )
            return None

    async def update_progress(content: str) -> None:
        for recipient, current_message in (
            ("submitter", progress_message),
            ("owner", owner_progress_message),
        ):
            if current_message is None:
                continue
            edit = getattr(current_message, "edit", None)
            if not callable(edit):
                continue
            try:
                await edit(content=content)
            except Exception as progress_exc:
                print(
                    f"[MatchLog Stats] {recipient} progress update failed for "
                    f"{source_message_id}: {progress_exc}",
                    flush=True,
                )

    try:
        if announce:
            try:
                owner_progress_message = (
                    await _send_matchlog_owner_submission_progress(
                        message, len(attachments)
                    )
                )
            except Exception as owner_progress_exc:
                print(
                    "[MatchLog Stats] owner submission progress DM failed for "
                    f"{source_message_id}: {owner_progress_exc}",
                    flush=True,
                )
            progress_message = await send_status(
                f"Processing **{len(attachments)}** MatchLog "
                f"file{'s' if len(attachments) != 1 else ''}…\n"
                "Stage 1/3: loading official WTSL results.",
            )
        rankings, official = await asyncio.gather(
            _get_stats_rankings(),
            _get_matchlog_official_results(),
        )
        if announce:
            await update_progress(
                f"Processing **{len(attachments)}** MatchLog "
                f"file{'s' if len(attachments) != 1 else ''}…\n"
                "Stage 2/3: official results loaded; checking file 1 of "
                f"{len(attachments)}."
            )
        for attachment_number, attachment in enumerate(attachments, start=1):
            try:
                if announce:
                    await update_progress(
                        f"Processing **{len(attachments)}** MatchLog "
                        f"file{'s' if len(attachments) != 1 else ''}…\n"
                        f"Stage 2/3: checking file {attachment_number} of "
                        f"{len(attachments)} (`{attachment.filename}`)."
                    )
                if int(getattr(attachment, "size", 0) or 0) > MATCHLOG_MAX_ATTACHMENT_BYTES:
                    replies.append(
                        f"Rejected `{attachment.filename}`: file exceeds the "
                        "5 MB MatchLog limit."
                    )
                    continue
                raw = await attachment.read()
                if len(raw) > MATCHLOG_MAX_ATTACHMENT_BYTES:
                    replies.append(
                        f"Rejected `{attachment.filename}`: file exceeds the "
                        "5 MB MatchLog limit."
                    )
                    continue
                source_hash = hashlib.sha256(raw).hexdigest()
                parsed = await asyncio.to_thread(
                    parse_matchlog_html, raw, attachment.filename
                )
                try:
                    require_complete_targeted = source_hash in trusted_hashes
                    targeted_official = await _get_matchlog_player_official_results(
                        {
                            str(row.get("player", ""))
                            for match in parsed
                            for row in match.get("rows", [])
                        },
                        require_complete=require_complete_targeted,
                    )
                    targeted_complete = require_complete_targeted
                except Exception as targeted_exc:
                    targeted_complete = False
                    print(
                        "[MatchLog Stats] optional targeted official lookup "
                        f"failed; using full results feed: {targeted_exc}",
                        flush=True,
                    )
                    targeted_official = []
                official_for_file = {
                    tuple(sorted(result.items())): result
                    for result in (*official, *targeted_official)
                }
                raw_coverage = await asyncio.to_thread(
                    get_identifiable_raw_coverage,
                    parsed,
                    list(official_for_file.values()),
                )
                try:
                    verified = await asyncio.to_thread(
                        select_official_matches,
                        parsed,
                        rankings,
                        list(official_for_file.values()),
                        previously_verified=source_hash in trusted_hashes,
                    )
                except ValueError:
                    verified = []
                verification_summary = (
                    f" Verification summary: **{len(verified)}** accepted as "
                    "official. Player dashboards show the number of official "
                    "played matches without verified MatchLog statistics."
                )
                verification_complete = targeted_complete
                if source_hash in trusted_hashes and verification_complete:
                    async with _stats_scrape_lock:
                        cleanup = await asyncio.to_thread(
                            reconcile_matchlog_source,
                            MATCH_STATS_WORKBOOK,
                            source_hash,
                            verified,
                        )
                        await _refresh_stats_autocomplete_cache()
                    if cleanup["removed_matches"]:
                        print(
                            "[MatchLog Stats] removed "
                            f"{cleanup['removed_matches']} unofficial MatchLog "
                            f"match(es) ({cleanup['removed_rows']} rows) from "
                            f"trusted source {source_hash[:12]}",
                            flush=True,
                        )
                if not verified:
                    raise ValueError(
                        "No official WTSL matches with matching players and "
                        "scores were found in this MatchLog history."
                        + verification_summary
                    )
                await asyncio.to_thread(
                    save_matchlog_source,
                    source_hash=source_hash,
                    submitter_id=submitter_id,
                    source_message_id=source_message_id,
                    attachment_id=attachment.id,
                    filename=attachment.filename,
                    raw_html=raw,
                    verified_matches=verified,
                    raw_coverage=raw_coverage,
                )
                _merge_matchlog_raw_coverage(raw_coverage)
                if announce:
                    await _archive_matchlog_attachment(
                        source_hash=source_hash,
                        submitter_id=submitter_id,
                        message_id=source_message_id,
                        attachment_id=attachment.id,
                        filename=attachment.filename,
                        raw=raw,
                    )
                async with _stats_scrape_lock:
                    result = await asyncio.to_thread(
                        append_matchlog_submission,
                        MATCH_STATS_WORKBOOK,
                        verified,
                        message_id=source_message_id,
                        attachment_id=attachment.id,
                        submitter_id=submitter_id,
                        source_hash=source_hash,
                    )
                    await _refresh_stats_autocomplete_cache()
                if result.get("duplicate"):
                    successful_source_hashes.add(source_hash)
                    verification_players.update(
                        row["player"]
                        for match in verified
                        for row in match["rows"]
                    )
                    replies.append(
                        f"`{attachment.filename}` was already recorded "
                        f"({result['duplicate']} duplicate); no data changed."
                        + verification_summary
                    )
                    continue
                added = int(result.get("added") or 0)
                successful_source_hashes.add(source_hash)
                added_total += added
                verification_players.update(result.get("players") or [])
                text = (
                    f"Accepted `{attachment.filename}`: **{added}** official "
                    f"match{'es' if added != 1 else ''} added for "
                    f"{', '.join(result.get('players') or [])}."
                    + verification_summary
                )
                if result.get("warnings"):
                    text += " Warnings: " + "; ".join(result["warnings"])
                replies.append(text)
                receipts.append(
                    f"MatchLog receipt: `{source_hash}|{source_message_id}`"
                )
            except ValueError as exc:
                replies.append(
                    f"Rejected `{attachment.filename}`: {str(exc)[:700]}"
                )
            except Exception as exc:
                processing_failed = True
                replies.append(
                    f"Could not process `{attachment.filename}` safely; the "
                    f"file was not accepted. Please retry: {str(exc)[:650]}"
                )
            if announce:
                await update_progress(
                    f"Processing **{len(attachments)}** MatchLog "
                    f"file{'s' if len(attachments) != 1 else ''}…\n"
                    f"Stage 2/3: checked {attachment_number} of "
                    f"{len(attachments)}."
                )
        summary_text = None
        upload_csv = None
        composite_csv = None
        if announce and verification_players:
            summary = await asyncio.to_thread(
                get_matchlog_player_summary,
                MATCH_STATS_WORKBOOK,
                submitter_id,
            )
            summary_text = (
                format_matchlog_player_summary(summary)
                if summary else
                "Your MatchLog was accepted. Your Discord account is now "
                "pending admin verification. You will be able to use "
                "`/mystats` after it is approved."
            )
            if submitter_id not in _matchlog_identity_index:
                try:
                    await _notify_matchlog_owner_for_verification(
                        message, verification_players
                    )
                except Exception as notify_exc:
                    print(
                        "[MatchLog Stats] owner verification notification "
                        f"failed for {message.author.id}: {notify_exc}",
                        flush=True,
                    )
            upload_csv = await asyncio.to_thread(
                build_matchlog_upload_csv,
                MATCH_STATS_WORKBOOK,
                MATCHLOG_UPLOAD_TEMPLATE,
            )
            composite_csv = await asyncio.to_thread(
                build_matchlog_composite_csv,
                MATCH_STATS_WORKBOOK,
            )
        if announce:
            await update_progress(
                f"Processing **{len(attachments)}** MatchLog "
                f"file{'s' if len(attachments) != 1 else ''}…\n"
                "Stage 3/3: preparing the private results and cumulative CSVs."
            )
            receipt_text = "\n".join(receipts)
            body_limit = 2000 - len(receipt_text) - (2 if receipt_text else 0)
            response = "\n\n".join(replies)[:max(0, body_limit)]
            if receipt_text:
                response += "\n\n" + receipt_text
            await send_status(response)
            if (
                summary_text is not None
                and upload_csv is not None
                and composite_csv is not None
            ):
                await send_status(summary_text[:2000])
                await _send_matchlog_owner_csv(
                    message, upload_csv, composite_csv
                )
        delete_original = (
            announce and not archive_failed and not processing_failed
        )
        if submitter_status_failed:
            print(
                "[MatchLog Stats] processing completed without one or more "
                f"submitter DMs for {source_message_id}",
                flush=True,
            )
    except Exception as exc:
        if announce:
            try:
                await send_status(
                    f"MatchLog processing failed safely; the upload was "
                    f"retained for retry: {str(exc)[:1200]}",
                )
            except Exception as send_exc:
                print(
                    f"[MatchLog Stats] could not send failure status for "
                    f"{message.id}: {send_exc}",
                    flush=True,
                )
        else:
            print(
                f"[MatchLog Stats] startup submission {message.id} failed: {exc}",
                flush=True,
            )
    finally:
        if delete_original and delete_source:
            try:
                await message.delete()
            except Exception as delete_exc:
                print(
                    f"[MatchLog Stats] could not delete submission "
                    f"{message.id}: {delete_exc}",
                    flush=True,
                )
            try:
                retained_message_ids = await asyncio.to_thread(
                    load_matchlog_source_message_ids,
                    successful_source_hashes,
                )
                fetch_message = getattr(message.channel, "fetch_message", None)
                if callable(fetch_message):
                    for retained_message_id in retained_message_ids:
                        if retained_message_id == message.id:
                            continue
                        try:
                            retained_message = await fetch_message(
                                retained_message_id
                            )
                            await retained_message.delete()
                        except discord.NotFound:
                            pass
                        except Exception as retained_delete_exc:
                            print(
                                "[MatchLog Stats] could not delete retained "
                                f"submission {retained_message_id}: "
                                f"{retained_delete_exc}",
                                flush=True,
                            )
            except Exception as retained_lookup_exc:
                print(
                    "[MatchLog Stats] could not look up retained submissions "
                    f"for {message.id}: {retained_lookup_exc}",
                    flush=True,
                )
    return added_total


async def _scan_matchlog_public_history() -> list:
    """Build one shared receipt index without parallel Discord history scans."""
    global _matchlog_public_messages_scanned
    _matchlog_public_messages_scanned = 0
    channel = (
        client.get_channel(MATCHLOG_SUBMISSIONS_CHANNEL_ID)
        or await client.fetch_channel(MATCHLOG_SUBMISSIONS_CHANNEL_ID)
    )
    messages = []
    restored_identity_ids = set(_matchlog_identity_index)
    async for message in channel.history(limit=None):
        messages.append(message)
        _matchlog_public_messages_scanned += 1
        for user_id, links in _matchlog_admin_identities(
            [message], client.user.id
        ).items():
            if isinstance(links, str):
                links = {"atp": links}
            for tour, player in links.items():
                if tour in _matchlog_links(user_id):
                    continue
                try:
                    await _bind_restored_matchlog_identity(
                        user_id, player, tour=tour, private=False
                    )
                except Exception as exc:
                    print(
                        f"[MatchLog Stats] identity restore failed for {user_id}: "
                        f"{exc}",
                        flush=True,
                    )
            restored_identity_ids.add(user_id)
        if len(messages) % 100 == 0:
            await _update_matchlog_owner_progress()
            await asyncio.sleep(0.25)
    messages.reverse()
    return messages


def _matchlog_public_history_scan_task() -> asyncio.Task:
    global _matchlog_public_history_task
    if (
        _matchlog_public_history_task is None
        or (
            _matchlog_public_history_task.done()
            and _matchlog_public_history_task.exception() is not None
        )
    ):
        _matchlog_public_history_task = asyncio.create_task(
            _scan_matchlog_public_history()
        )
    return _matchlog_public_history_task


async def _scan_matchlog_owner_history() -> list:
    """Index private archives and identity receipts through one paced DM scan."""
    global _matchlog_owner_messages_scanned
    _matchlog_owner_messages_scanned = 0
    owner = await client.fetch_user(OWNER_ID)
    owner_dm = owner.dm_channel or await owner.create_dm()
    messages = []
    # Track only receipts seen in this newest-first private scan. A legacy
    # public binding already in the shared index must never suppress the newer
    # private owner-DM receipt.
    restored_identity_ids = set()
    async for message in owner_dm.history(limit=None):
        messages.append(message)
        _matchlog_owner_messages_scanned += 1
        for user_id, links in _matchlog_admin_identities(
            [message], client.user.id
        ).items():
            if isinstance(links, str):
                links = {"atp": links}
            for tour, player in links.items():
                if tour in _matchlog_links(user_id) and user_id in restored_identity_ids:
                    continue
                try:
                    await _bind_restored_matchlog_identity(
                        user_id, player, tour=tour, private=True
                    )
                except Exception as exc:
                    print(
                        f"[MatchLog Stats] private identity restore failed for "
                        f"{user_id}: {exc}",
                        flush=True,
                    )
            restored_identity_ids.add(user_id)
        if len(messages) % 100 == 0:
            await _update_matchlog_owner_progress()
            await asyncio.sleep(0.5)
    messages.reverse()
    return messages


async def _bind_restored_matchlog_identity(
    user_id: int, player: str, *, private: bool, tour: str | None = None
) -> bool:
    """Bind deterministically: private owner-DM receipts supersede legacy public ones."""
    async with _stats_scrape_lock:
        prefix, separator, name = player.partition(":")
        tour = (tour or (prefix if separator else "atp")).casefold()
        player = (name if separator else player).strip()
        existing = _matchlog_links(user_id)
        if not private and tour in existing:
            return False
        receipt_source = (
            "Private Discord admin receipt"
            if private else "Legacy public Discord admin receipt"
        )
        await asyncio.to_thread(
            save_matchlog_identity,
            user_id,
            player,
            receipt_source,
            tour,
        )
        await asyncio.to_thread(
            bind_matchlog_player_identity,
            MATCH_STATS_WORKBOOK,
            user_id,
            player,
            receipt_source,
            tour,
        )
        existing[tour] = player
        _matchlog_identity_index[user_id] = existing
    return True


def _matchlog_owner_history_scan_task() -> asyncio.Task:
    global _matchlog_owner_history_task
    if (
        _matchlog_owner_history_task is None
        or (
            _matchlog_owner_history_task.done()
            and _matchlog_owner_history_task.exception() is not None
        )
    ):
        _matchlog_owner_history_task = asyncio.create_task(
            _scan_matchlog_owner_history()
        )
    return _matchlog_owner_history_task


def _reverify_persisted_matchlog_sources(
    sources: list[dict[str, typing.Any]],
    rankings: dict[str, dict[str, str]],
    official_results: list[dict[str, str]],
) -> tuple[list[dict[str, typing.Any]], int]:
    verified_sources = []
    preserved_without_refresh = 0
    for source in sources:
        verified_matches = []
        raw_coverage = list(source.get("raw_coverage") or [])
        raw_html = source.get("raw_html")
        if raw_html:
            try:
                parsed = parse_matchlog_html(
                    bytes(raw_html),
                    str(source.get("filename") or "retained-matchlog.html"),
                )
                raw_coverage = get_identifiable_raw_coverage(
                    parsed, official_results
                )
                verified_matches = select_official_matches(
                    parsed,
                    rankings,
                    official_results,
                    previously_verified=True,
                )
            except (ValueError, KeyError, TypeError, IndexError):
                verified_matches = []
        refreshed_ids = {
            (match.get("tour"), match.get("match_id"))
            for match in verified_matches
        }
        for stored_match in source.get("verified_matches") or []:
            stored_id = (
                stored_match.get("tour"),
                stored_match.get("match_id"),
            )
            if stored_id in refreshed_ids:
                continue
            try:
                refreshed = verify_matchlog_matches(
                    [copy.deepcopy(stored_match)],
                    rankings,
                    official_results,
                )
                verified_matches.extend(refreshed)
                refreshed_ids.update(
                    (match.get("tour"), match.get("match_id"))
                    for match in refreshed
                )
            except (ValueError, KeyError, TypeError, IndexError):
                verified_matches.append(copy.deepcopy(stored_match))
                refreshed_ids.add(stored_id)
                preserved_without_refresh += 1
        if verified_matches:
            verified_sources.append({
                **source,
                "verified_matches": verified_matches,
                "raw_coverage": raw_coverage,
                "verification_version": MATCHLOG_VERIFICATION_VERSION,
            })
    return verified_sources, preserved_without_refresh


def _load_matchlog_startup_state(
    attempts: int = 4,
) -> tuple[list[dict], dict]:
    """Load critical startup records sequentially with transient DB retries."""
    last_error = None
    for attempt in range(1, attempts + 1):
        try:
            return load_matchlog_sources(), load_matchlog_identities()
        except Exception as exc:
            last_error = exc
            if attempt == attempts:
                break
            delay = 2 ** (attempt - 1)
            print(
                "[MatchLog Stats] transient startup database read failed "
                f"(attempt {attempt}/{attempts}); retrying in {delay}s: "
                f"{type(exc).__name__}: {exc}",
                flush=True,
            )
            time.sleep(delay)
    raise last_error


async def _matchlog_startup_rebuild():
    """Reconcile all retained submissions so VM replacement cannot lose rows."""
    global _matchlog_rebuild_state, _matchlog_rebuild_done
    global _matchlog_rebuild_total, _matchlog_raw_coverage_index
    _matchlog_rebuild_state = "running"
    _matchlog_rebuild_done = 0
    _matchlog_rebuild_total = None
    rebuild_started = time.monotonic()
    await _update_matchlog_owner_progress(force=True)
    try:
        async with _stats_scrape_lock:
            sources, identities = await asyncio.to_thread(
                _load_matchlog_startup_state
            )
        _matchlog_rebuild_total = len(sources)
        verification_upgrade_needed = any(
            int(source.get("verification_version") or 0)
            < MATCHLOG_VERIFICATION_VERSION
            for source in sources
        )
        rankings = official_results = None
        live_refresh_error = None
        if verification_upgrade_needed:
            print(
                "[MatchLog Stats] verification rules changed; reparsing retained "
                "MatchLog source HTML once before rebuilding",
                flush=True,
            )
            try:
                official_refresh = asyncio.create_task(
                    _get_matchlog_official_results()
                )
                rankings, official_results = await asyncio.wait_for(
                    asyncio.gather(
                        _get_stats_rankings(),
                        asyncio.shield(official_refresh),
                    ),
                    timeout=60,
                )
            except Exception as exc:
                live_refresh_error = exc
                print(
                    "[MatchLog Stats] live WTSL refresh unavailable during "
                    "verification upgrade; rebuilding from previously verified "
                    f"PostgreSQL records: {type(exc).__name__}: {exc}",
                    flush=True,
                )
        async with _stats_scrape_lock:
            if (
                verification_upgrade_needed
                and rankings is not None
                and official_results is not None
            ):
                sources, preserved_without_refresh = await asyncio.to_thread(
                    _reverify_persisted_matchlog_sources,
                    sources,
                    rankings,
                    official_results,
                )
                await asyncio.to_thread(
                    save_reverified_matchlog_sources,
                    sources,
                )
            elif verification_upgrade_needed:
                preserved_without_refresh = sum(
                    len(source.get("verified_matches") or [])
                    for source in sources
                )
            else:
                preserved_without_refresh = 0
            _matchlog_raw_coverage_index = {}
            for source in sources:
                _merge_matchlog_raw_coverage(
                    source.get("raw_coverage") or []
                )
            added = await asyncio.to_thread(
                rebuild_matchlog_from_sources,
                MATCH_STATS_WORKBOOK,
                sources,
                identities,
            )
            for user_id, links in identities.items():
                current_links = _matchlog_links(user_id)
                current_links.update(links)
                _matchlog_identity_index[user_id] = current_links
        _matchlog_rebuild_done = len(sources)
        await _update_matchlog_owner_progress()
        print(
            f"[MatchLog Stats] database sync loaded {len(sources)} "
            f"source(s), {len(identities)} identity binding(s), and "
            f"{added} official match(es) in "
            f"{time.monotonic() - rebuild_started:.1f}s",
            flush=True,
        )
        if preserved_without_refresh:
            print(
                f"[MatchLog Stats] preserved {preserved_without_refresh} "
                "previously verified historical match(es) that the current "
                "WTSL feed could not uniquely refresh",
                flush=True,
            )
        if live_refresh_error is not None:
            print(
                "[MatchLog Stats] startup database sync completed with persisted "
                "verification because live WTSL refresh was unavailable",
                flush=True,
            )
        try:
            await asyncio.wait_for(
                asyncio.gather(
                    asyncio.to_thread(_get_stats_autocomplete_names),
                    _get_screenshot_statistics_exclusions(),
                ),
                timeout=45,
            )
            print("[MatchLog Stats] command caches warmed", flush=True)
        except Exception as cache_exc:
            print(
                f"[MatchLog Stats] command cache warm-up failed: "
                f"{type(cache_exc).__name__}: {cache_exc}",
                flush=True,
            )
        _matchlog_rebuild_state = "complete"
        await _update_matchlog_owner_progress(force=True)
        try:
            owner = await client.fetch_user(OWNER_ID)
            await owner.send(
                "MatchLog database sync is complete. "
                f"Loaded **{len(sources)}** persistent source"
                f"{'s' if len(sources) != 1 else ''}, "
                f"**{len(identities)}** identity binding"
                f"{'s' if len(identities) != 1 else ''}, and **{added}** "
                f"official match{'es' if added != 1 else ''}. "
                "`/mystats` results are now definitive for this deployment."
            )
        except Exception as notify_exc:
            print(
                f"[MatchLog Stats] could not send database sync completion "
                f"notice: {notify_exc}",
                flush=True,
            )
        for user_id in tuple(_matchlog_status_subscribers):
            try:
                summary = await asyncio.to_thread(
                    get_matchlog_player_summary,
                    MATCH_STATS_WORKBOOK,
                    user_id,
                )
                user = await client.fetch_user(user_id)
                if summary is None:
                    notice = (
                        "MatchLog database sync is complete, but no verified "
                        "statistics were found for your approved player identity. "
                        "You may need to resubmit your original MatchLog HTML files."
                    )
                else:
                    notice = (
                        "MatchLog database sync is complete and your verified "
                        "statistics are available. Run `/mystats` to view them."
                    )
                await user.send(notice)
            except Exception as notify_exc:
                print(
                    f"[MatchLog Stats] could not notify subscribed user "
                    f"{user_id}: {notify_exc}",
                    flush=True,
                )
        _matchlog_status_subscribers.clear()
    except Exception as exc:
        _matchlog_rebuild_state = "failed"
        await _update_matchlog_owner_progress(force=True)
        print(f"[MatchLog Stats] startup reconciliation failed: {exc}", flush=True)
        try:
            owner = await client.fetch_user(OWNER_ID)
            await owner.send(
                "MatchLog database sync failed, so `/mystats` may be incomplete. "
                f"Failure: {str(exc)[:1200]}"
            )
        except Exception:
            pass
        for user_id in tuple(_matchlog_status_subscribers):
            try:
                user = await client.fetch_user(user_id)
                await user.send(
                    "MatchLog database sync failed, so your statistics could not "
                    "be confirmed. The bot owner has also been notified."
                )
            except Exception as notify_exc:
                print(
                    f"[MatchLog Stats] could not notify subscribed user "
                    f"{user_id} of database sync failure: {notify_exc}",
                    flush=True,
                )
        _matchlog_status_subscribers.clear()


async def _restore_matchlog_identity_for_user(user_id: int) -> bool:
    """Refresh one identity from PostgreSQL, then briefly await startup sync."""
    if user_id in _matchlog_identity_index:
        return True
    player = await asyncio.to_thread(load_matchlog_identity, user_id)
    if player:
        if isinstance(player, str):
            prefix, separator, name = player.partition(":")
            player = {
                normalize_matchlog_name(prefix) if separator else "atp":
                name.strip() if separator else player,
            }
        async with _stats_scrape_lock:
            for tour, linked_player in player.items():
                await asyncio.to_thread(
                    bind_matchlog_player_identity, MATCH_STATS_WORKBOOK,
                    user_id, linked_player, "Persistent MatchLog identity", tour,
                )
        _matchlog_identity_index[user_id] = player
        return True
    for _ in range(10):
        if user_id in _matchlog_identity_index:
            return True
        if _matchlog_rebuild_state in {"complete", "failed"}:
            return user_id in _matchlog_identity_index
        await asyncio.sleep(0.1)
    return user_id in _matchlog_identity_index


def _matchlog_restoration_progress() -> tuple[int, str]:
    """Return a bounded progress estimate and its current concrete phase."""
    if _matchlog_rebuild_state == "complete":
        return 100, "Database sync complete"
    if _matchlog_rebuild_state == "failed":
        return 100, "Database sync failed"
    if _matchlog_rebuild_total is None:
        return 10, "Loading persistent MatchLog records"
    if _matchlog_rebuild_total == 0:
        return 95, "Finalizing workbook rebuild"
    percent = 10 + int(
        85 * min(_matchlog_rebuild_done, _matchlog_rebuild_total)
        / _matchlog_rebuild_total
    )
    return percent, (
        f"Rebuilding saved sources "
        f"({_matchlog_rebuild_done}/{_matchlog_rebuild_total})"
    )


def _format_matchlog_progress() -> str:
    percent, phase = _matchlog_restoration_progress()
    filled = min(10, max(0, percent // 10))
    bar = "█" * filled + "░" * (10 - filled)
    return f"`[{bar}] {percent}%` — {phase}"


async def _update_matchlog_owner_progress(*, force: bool = False) -> None:
    """Create or edit the owner's private database-sync progress message."""
    global _matchlog_owner_progress_message
    global _matchlog_owner_progress_updated_at
    now = time.monotonic()
    if (
        not force
        and now - _matchlog_owner_progress_updated_at < 30
    ):
        return
    async with _matchlog_owner_progress_lock:
        now = time.monotonic()
        if (
            not force
            and now - _matchlog_owner_progress_updated_at < 30
        ):
            return
        content = (
            "📊 **MatchLog database sync progress**\n"
            f"{_format_matchlog_progress()}\n"
            "This rebuilds the temporary workbook from PostgreSQL; "
            "Discord history is not scanned."
        )
        try:
            if _matchlog_owner_progress_message is None:
                owner = await client.fetch_user(OWNER_ID)
                _matchlog_owner_progress_message = await owner.send(content)
            else:
                await _matchlog_owner_progress_message.edit(content=content)
            _matchlog_owner_progress_updated_at = now
        except Exception as exc:
            print(
                f"[MatchLog Stats] owner progress DM failed: {exc}",
                flush=True,
            )


_mystats_insight_cache: dict[str, dict[str, typing.Any]] = {}
_mystats_summary_lock = asyncio.Semaphore(2)
_mystats_summary_executor = ThreadPoolExecutor(
    max_workers=2,
    thread_name_prefix="mystats-summary",
)
_askstats_executor = ThreadPoolExecutor(
    max_workers=2,
    thread_name_prefix="askstats-query",
)
_screenshot_exclusions_cache: tuple[
    int,
    list[dict[str, typing.Any]],
    dict[str, dict[str, set[str]]],
] | None = None
_screenshot_exclusions_lock = asyncio.Lock()
MYSTATS_SUMMARY_TIMEOUT_SECONDS = 25
MYSTATS_COMPARISON_TIMEOUT_SECONDS = 120
MYSTATS_PROFILE_TIMEOUT_SECONDS = 8
MYSTATS_OFFICIAL_RESULTS_TIMEOUT_SECONDS = 20
MYSTATS_LIVE_RESULTS_TIMEOUT_SECONDS = 6
# Recommendation ranking is optional enrichment, but the first roster-vector
# build is a cold-cache operation.  Keep it off the event loop while allowing
# enough bounded time for the selected ATP/WTA roster to finish.
MYSTATS_CHARACTER_RECOMMENDATION_TIMEOUT_SECONDS = 8


async def _run_mystats_summary_worker(
    function: typing.Callable[..., typing.Any],
    *args: typing.Any,
    **kwargs: typing.Any,
) -> typing.Any:
    loop = asyncio.get_running_loop()
    call = functools.partial(function, *args, **kwargs)
    return await loop.run_in_executor(_mystats_summary_executor, call)


async def _run_askstats_worker(
    function: typing.Callable[..., typing.Any],
    *args: typing.Any,
    **kwargs: typing.Any,
) -> typing.Any:
    loop = asyncio.get_running_loop()
    call = functools.partial(function, *args, **kwargs)
    return await loop.run_in_executor(_askstats_executor, call)


async def _get_mystats_summaries(
    discord_user_id: int,
    screenshot_identity: str,
    tour: str,
    period: str,
    as_of: datetime.date,
    selected_source: str,
) -> tuple[dict | None, dict | None]:
    async with _mystats_summary_lock:
        started = time.monotonic()
        if selected_source == "screenshots":
            exclusions_started = time.monotonic()
            exclusions = await _get_screenshot_statistics_exclusions()
            print(
                "[MatchLog Stats] screenshot exclusions loaded in "
                f"{time.monotonic() - exclusions_started:.1f}s",
                flush=True,
            )
            screenshot_summary = await _run_mystats_summary_worker(
                get_screenshot_player_summary,
                MATCH_STATS_WORKBOOK,
                screenshot_identity,
                tour,
                period,
                as_of,
                excluded_match_keys_by_player=exclusions.get(tour, {}),
            )
            matchlog_summary = None
        else:
            screenshot_summary = None
            matchlog_summary = await _run_mystats_summary_worker(
                get_matchlog_player_summary,
                MATCH_STATS_WORKBOOK,
                discord_user_id,
                tour,
                period,
                as_of,
            )
        print(
            f"[MatchLog Stats] selected {selected_source} summary loaded in "
            f"{time.monotonic() - started:.1f}s",
            flush=True,
        )
        return screenshot_summary, matchlog_summary


async def _fetch_mystats_ranking(
    player_name: str,
    tour: str,
) -> dict[str, typing.Any]:
    tour_slug = "TE4_(F)" if tour == "wta" else "TE4"
    wanted = normalize_matchlog_name(player_name)
    fallback = {
        "category": f"{tour.upper()} Singles",
        "rank": None,
        "wtsl_elo": None,
        "movement": None,
        "previous_rank": None,
        "ytd_wins": None,
        "ytd_losses": None,
        "ytd_win_pct": None,
        "career_wins": None,
        "career_losses": None,
        "career_win_pct": None,
        "form": None,
        "official_results": [],
        "rankings": {},
        "player_name": player_name,
    }
    try:
                official_results = await asyncio.wait_for(
                    fetch_player_results(
                        None,
                        player_name,
                        allow_stale=True,
                    ),
                    timeout=2,
                )
    except Exception as exc:
        print(
            f"[MatchLog Stats] live official results refresh unavailable for "
            f"{player_name}: {type(exc).__name__}: {exc}",
            flush=True,
        )
        try:
            official_results = await asyncio.wait_for(
                fetch_player_results(
                    None,
                    player_name,
                    allow_stale=True,
                ),
                timeout=2,
            )
        except Exception as cached_exc:
            print(
                f"[MatchLog Stats] cached official results unavailable for "
                f"{player_name}: {type(cached_exc).__name__}: {cached_exc}",
                flush=True,
            )
            official_results = []
    if not official_results:
        official_results = await asyncio.to_thread(
            _persisted_matchlog_results_for_player,
            player_name,
            tour,
        )
    fallback["official_results"] = official_results
    fallback = _apply_official_dashboard_records(
        fallback,
        player_name,
        tour,
        official_results,
    )
    rankings_url = (
        "https://www.playwtsl.com/TE4/pages/"
        f"rankings_fetch_list.php?tour={tour_slug}"
    )
    try:
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=45)
        ) as session:
            async with session.get(
                rankings_url,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as response:
                if response.status != 200:
                    return fallback
                rankings_html = await response.text()
            try:
                rankings = _parse_ranking_table(rankings_html, tour)
            except Exception:
                rankings = {}
            fallback["rankings"] = rankings
            rankings_soup = BeautifulSoup(rankings_html, "html.parser")
            player_id = None
            for link in rankings_soup.find_all("a", href=True):
                if (
                    normalize_matchlog_name(link.get_text(" ", strip=True))
                    != wanted
                ):
                    continue
                match = re.search(r"[?&]player=(\d+)", link["href"])
                if match:
                    player_id = match.group(1)
                    break
            if player_id is None:
                return fallback
            async with session.get(
                "https://www.playwtsl.com/TE4/pages/"
                f"player_page.php?player={player_id}",
                timeout=aiohttp.ClientTimeout(total=30),
            ) as response:
                if response.status != 200:
                    return fallback
                profile_html = await response.text()
    except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
        print(
            f"[MatchLog Stats] live WTSL profile unavailable for "
            f"{player_name}; using cached results: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        return fallback
    profile = {
        **fallback,
        **_parse_mystats_player_profile(profile_html),
        "player_id": player_id,
        "player_name": player_name,
        "official_results": official_results,
        "rankings": rankings,
    }
    if profile.get("recent_matches"):
        asyncio.create_task(
            merge_player_recent_results(
                player_name,
                tour,
                profile["recent_matches"],
            )
        )
    return _apply_official_dashboard_records(
        profile,
        player_name,
        tour,
        official_results,
    )


def _persisted_matchlog_results_for_player(
    player_name: str,
    tour: str,
) -> list[dict[str, typing.Any]]:
    """Build an outage-safe result view from retained verified MatchLogs."""
    wanted = normalize_matchlog_name(player_name)
    results: dict[tuple[str, ...], dict[str, typing.Any]] = {}
    try:
        sources = load_matchlog_sources()
    except Exception as exc:
        print(
            f"[MatchLog Stats] persisted result fallback unavailable: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        return []

    def display_date(match_datetime: str, fallback: typing.Any) -> typing.Any:
        if not match_datetime:
            return fallback
        try:
            return _dt.datetime.fromisoformat(match_datetime).strftime("%d.%m.%Y")
        except ValueError:
            return fallback

    for source in sources:
        for match in source.get("verified_matches") or []:
            if str(match.get("tour") or "").casefold() != tour.casefold():
                continue
            rows = match.get("rows") or []
            row = next(
                (
                    candidate for candidate in rows
                    if normalize_matchlog_name(candidate.get("player")) == wanted
                ),
                None,
            )
            if row is None:
                continue
            opponent = str(row.get("opponent") or "")
            match_datetime = str(row.get("match_datetime") or "")
            result = {
                "tour": tour.casefold(),
                "tournament": row.get("tournament"),
                "round": row.get("round"),
                "p1": player_name,
                "p2": opponent,
                "player1": player_name,
                "player2": opponent,
                "p1_character": row.get("character"),
                "p2_character": row.get("opponent_character"),
                "player1_character": row.get("character"),
                "player2_character": row.get("opponent_character"),
                "date": display_date(match_datetime, row.get("date")),
                "result": row.get("result"),
                "source_url": "persisted-matchlog",
            }
            key = tuple(str(result.get(field) or "") for field in (
                "tournament", "p1", "p2", "date", "result",
            ))
            results[key] = result
    return list(results.values())


def _parse_mystats_player_profile(html_text: str) -> dict[str, typing.Any]:
    soup = BeautifulSoup(html_text, "html.parser")
    values: dict[str, str] = {}
    for row in soup.find_all("tr"):
        cells = row.find_all(["th", "td"])
        if len(cells) < 2:
            continue
        label = " ".join(cells[0].get_text(" ", strip=True).split())
        value = " ".join(cells[1].get_text(" ", strip=True).split())
        if label and value:
            values[label.casefold()] = value

    def integer(label: str) -> int | None:
        match = re.search(r"-?\d+", values.get(label.casefold(), ""))
        return int(match.group()) if match else None

    def record(label: str) -> tuple[int | None, int | None]:
        match = re.search(
            r"(\d+)\s*/\s*(\d+)",
            values.get(label.casefold(), ""),
        )
        return (
            (int(match.group(1)), int(match.group(2)))
            if match else (None, None)
        )

    elo_text = values.get("tour elo", "")
    elo_match = re.search(r"(\d+)", elo_text)
    category_match = re.search(r"\(([^)]+)\)", elo_text)
    rank = integer("Rank")
    previous_rank = integer("Last Week Rank")
    ytd_wins, ytd_losses = record("YTD Wins/Losses")
    career_wins, career_losses = record("Career Wins/Losses")
    recent_matches = []
    for table in soup.find_all("table"):
        headers = [
            " ".join(cell.get_text(" ", strip=True).split())
            for cell in table.find_all("th")
        ]
        normalized_headers = [header.casefold() for header in headers]
        required = {"tournament", "round", "opponent", "date", "result"}
        if not required.issubset(normalized_headers):
            continue
        positions = {
            label: normalized_headers.index(label)
            for label in required
        }
        for row in table.find_all("tr"):
            cells = [
                " ".join(cell.get_text(" ", strip=True).split())
                for cell in row.find_all("td")
            ]
            if len(cells) < len(headers):
                continue
            offset = len(cells) - len(headers)
            recent_matches.append({
                label: cells[index + offset]
                for label, index in positions.items()
            })
            if len(recent_matches) == 5:
                break
        if recent_matches:
            break
    return {
        "rank": rank,
        "previous_rank": previous_rank,
        "movement": (
            previous_rank - rank
            if rank is not None and previous_rank is not None else None
        ),
        "wtsl_elo": int(elo_match.group(1)) if elo_match else None,
        "category": (
            category_match.group(1).strip()
            if category_match else None
        ),
        "ytd_wins": ytd_wins,
        "ytd_losses": ytd_losses,
        "ytd_win_pct": integer("YTD Win Percentage"),
        "career_wins": career_wins,
        "career_losses": career_losses,
        "career_win_pct": integer("Career Win Percentage"),
        "form": values.get("form (last 10 matches)"),
        "recent_matches": recent_matches,
    }


def _ordinal(value: typing.Any) -> str:
    try:
        number = int(round(float(value)))
    except (TypeError, ValueError):
        return str(value)
    suffix = (
        "th"
        if 10 < number % 100 < 14
        else {1: "st", 2: "nd", 3: "rd"}.get(number % 10, "th")
    )
    return f"{number}{suffix}"


def _generate_mystats_insights_sync(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> dict[str, typing.Any] | None:
    raw_metrics = {
        str(label): value
        for label, value, _count in summary.get("metrics") or []
    }
    profiles = summary.get("relative_profile") or {}
    ranked = sorted(
        (
            (group, values)
            for group, values in profiles.items()
            if isinstance(values.get("percentile"), (int, float))
        ),
        key=lambda item: item[1]["percentile"],
        reverse=True,
    )
    if len(ranked) < 2:
        return None

    def describe(item, *, strength: bool):
        group, values = item
        indicators = sorted(
            values.get("metrics") or [],
            key=lambda metric: metric["percentile"],
            reverse=strength,
        )
        descriptions = []
        for metric in indicators[:2]:
            raw_value = raw_metrics.get(str(metric["metric"]))
            measured = (
                f" at {_dashboard_stat_value(metric['metric'], raw_value)}"
                if raw_value is not None else ""
            )
            descriptions.append(
                f"Your {metric['metric']}{measured} ranks in the "
                f"{_ordinal(metric['percentile'])} percentile among "
                f"{metric['players']} players. "
                f"{metric_insight(metric['metric'], strength=strength, subject='You')}"
            )
        return descriptions or [
            f"Your {group} profile is at the "
            f"{_ordinal(values['percentile'])} percentile."
        ]
    strongest = ranked[0]
    weakest = ranked[-1]
    development_metrics = sorted(
        weakest[1].get("metrics") or [],
        key=lambda metric: metric["percentile"],
    )
    if development_metrics:
        primary = development_metrics[0]
        secondary = development_metrics[1] if len(development_metrics) > 1 else None
        raw_value = raw_metrics.get(str(primary["metric"]))
        focus = (training_focus(weakest[0]) or "") + (
                f" Centre your work on "
            f"{primary['metric']}"
            + (
                f" ({_dashboard_stat_value(primary['metric'], raw_value)})"
                if raw_value is not None else ""
            )
            + f", currently at the {_ordinal(primary['percentile'])} percentile. "
            + metric_insight(primary["metric"], strength=False)
        ).strip()
        if secondary:
            focus += (
                f" Pair that work with {secondary['metric']} so the improvement "
                f"supports your whole {weakest[0]} pattern rather than one isolated stat."
            )
    else:
        focus = training_focus(weakest[0]) or (
            f"Prioritise the {weakest[0]} profile in the next training block."
        )
    return {
        "strengths": describe(strongest, strength=True),
        "weaknesses": describe(weakest, strength=False),
        "focus": focus,
        "strength_group": strongest[0],
        "development_group": weakest[0],
        "training_group": weakest[0],
    }


def _mystats_movement_text(profile: dict[str, typing.Any]) -> str:
    movement = profile.get("movement")
    previous = profile.get("previous_rank")
    if movement is None:
        return "Baseline unavailable"
    if movement > 0:
        return f"▲ {movement} place{'s' if movement != 1 else ''} (was #{previous})"
    if movement < 0:
        return f"▼ {abs(movement)} place{'s' if movement != -1 else ''} (was #{previous})"
    return f"— No change (#{previous})"


def _mystats_year_summary(profile: dict[str, typing.Any]) -> str:
    official_results = [
        result
        for result in profile.get("official_results") or []
        if not is_exhibition_tournament(
            result.get("tournament"),
            result.get("event_category"),
        )
    ]
    player_name = str(profile.get("player_name") or "")
    if official_results and player_name:
        return season_summary_text(
            official_results,
            player_name,
            profile.get("rankings") or {},
        )
    wins = profile.get("ytd_wins")
    losses = profile.get("ytd_losses")
    if not isinstance(wins, int) or not isinstance(losses, int):
        return "Not currently available"
    percentage = profile.get("ytd_win_pct")
    if not isinstance(percentage, int):
        total = wins + losses
        percentage = round(wins * 100 / total) if total else 0
    if wins > losses:
        assessment = "Winning record this year"
    elif wins == losses:
        assessment = "Even record this year"
    else:
        assessment = "More losses than wins this year"
    return f"{wins}-{losses} ({percentage}%) • {assessment}"


def _filtered_official_player_matches(
    results: typing.Iterable[dict[str, typing.Any]],
    player_name: typing.Any,
    tour: typing.Any,
    period: str,
    as_of: typing.Any,
) -> list[dict[str, typing.Any]]:
    """Return one played official row per player match for dashboard counts."""
    player = _dashboard_player_key(player_name)
    selected_tour = str(tour or "").casefold()
    filtered: list[dict[str, typing.Any]] = []
    seen: set[tuple[typing.Any, ...]] = set()
    for result in enrich_event_metadata(list(results)):
        if selected_tour and str(result.get("tour") or "").casefold() != selected_tour:
            continue
        if player not in {
            _dashboard_player_key(result.get("p1") or result.get("player1")),
            _dashboard_player_key(result.get("p2") or result.get("player2")),
        }:
            continue
        if not _official_result_in_summary_period(result, period, as_of):
            continue
        if not _dashboard_result_counts_as_played(result):
            continue
        result_key = (
            _dashboard_date_key(result.get("date")),
            _dashboard_event_identity(result.get("tournament")),
            _dashboard_event_category(
                result.get("tournament"),
                result.get("event_category"),
            ),
            _dashboard_score_key(result.get("result")),
            *_dashboard_pair_key(
                result.get("p1") or result.get("player1"),
                result.get("p2") or result.get("player2"),
            ),
        )
        if result_key in seen:
            continue
        seen.add(result_key)
        filtered.append(result)
    return filtered


def _official_dashboard_record(
    results: list[dict[str, typing.Any]],
    player_name: str,
    tour: str,
    period: str,
    as_of: typing.Any,
) -> tuple[int, int] | None:
    """Return the canonical W/L record from filtered official results."""
    played = _filtered_official_player_matches(
        results,
        player_name,
        tour,
        period,
        as_of,
    )
    player = _dashboard_player_key(player_name)
    wins = losses = 0
    for result in played:
        winner = winner_for_result(result)
        if winner is None:
            continue
        if _dashboard_player_key(winner) == player:
            wins += 1
        else:
            losses += 1
    return (wins, losses) if wins + losses else None


def _apply_official_dashboard_records(
    profile: dict[str, typing.Any],
    player_name: str,
    tour: str,
    results: list[dict[str, typing.Any]],
) -> dict[str, typing.Any]:
    """Use one filtered all-results source for both dashboard record displays."""
    if not isinstance(results, list) or not results:
        return profile
    updated = dict(profile)
    as_of = _dt.datetime.now(_dt.timezone.utc).date()
    for period, wins_key, losses_key, percentage_key in (
        ("career", "career_wins", "career_losses", "career_win_pct"),
        ("year", "ytd_wins", "ytd_losses", "ytd_win_pct"),
    ):
        record = _official_dashboard_record(
            results,
            player_name,
            tour,
            period,
            as_of,
        )
        if record is None:
            continue
        wins, losses = record
        updated[wins_key] = wins
        updated[losses_key] = losses
        updated[percentage_key] = round(wins * 100 / (wins + losses))
    return updated


def _most_picked_characters_for_summary(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> list[dict[str, typing.Any]]:
    """Return up to three period-filtered character picks, highest count first."""
    period = str(summary.get("period") or "career")
    as_of = summary.get("as_of")
    filtered = _filtered_official_player_matches(
        profile.get("official_results") or [],
        summary.get("player") or profile.get("player_name"),
        summary.get("tour"),
        period,
        as_of,
    )
    player = _dashboard_player_key(
        summary.get("player") or profile.get("player_name")
    )
    selected_tour = str(summary.get("tour") or "").casefold()
    counts: dict[str, int] = {}
    labels: dict[str, str] = {}
    for result in filtered:
        if selected_tour and result.get("tour") != selected_tour:
            continue
        if normalize_matchlog_name(result.get("p1")) == player:
            character = str(result.get("p1_character") or "").strip()
        elif normalize_matchlog_name(result.get("p2")) == player:
            character = str(result.get("p2_character") or "").strip()
        else:
            continue
        if character:
            key = character.casefold()
            counts[key] = counts.get(key, 0) + 1
            labels.setdefault(key, character)
    if counts:
        total = sum(counts.values())
        return [
            {
                "character": labels[key],
                "count": counts[key],
                "percentage": counts[key] / total,
            }
            for key in sorted(
                counts,
                key=lambda item: (-counts[item], labels[item].casefold()),
            )[:3]
        ]
    # Older screenshot summaries may contain only the persisted top pick.
    stored = summary.get("favorite_character")
    return [stored] if stored and stored.get("character") else []


def _official_result_in_summary_period(
    result: dict[str, typing.Any],
    period: str,
    as_of: typing.Any,
) -> bool:
    if is_exhibition_tournament(
        result.get("tournament"),
        result.get("event_category"),
    ):
        return False
    if period == "career":
        return True
    try:
        reference = _dt.date.fromisoformat(str(as_of or "")[:10])
    except ValueError:
        reference = _dt.datetime.now(_dt.timezone.utc).date()
    date_key = _dashboard_date_key(result.get("date"))
    if date_key == (0, 0, 0):
        return False
    match_date = _dt.date(*date_key)
    start = {
        "30d": reference - _dt.timedelta(days=29),
        "90d": reference - _dt.timedelta(days=89),
        "year": _dt.date(reference.year, 1, 1),
        "52w": reference - _dt.timedelta(days=363),
    }.get(period)
    return start is not None and start <= match_date <= reference


def _dashboard_score_is_exhibition_only(value: typing.Any) -> bool:
    """Recognize Year End Holiday Cup's one-point tiebreak score format."""
    text = str(value or "")
    score = _dashboard_score_key(text)
    if not score or "(" not in text:
        return False
    sets = re.findall(r"([01])\s*[-/]\s*([01])\s*\(\s*\d+\s*\)", text)
    return len(sets) == len(score) and all(
        (int(first), int(second)) in {(0, 1), (1, 0)}
        for first, second in sets
    )


def _dashboard_score_is_short_set_format(value: typing.Any) -> bool:
    """Recognize TE4's short-set format used by created-character events."""
    score = _dashboard_score_key(value)
    return (
        len(score) >= 2
        and all(max(first, second) <= 5 for first, second in score)
        and any(max(first, second) == 4 for first, second in score)
    )


def _dashboard_is_next_gen_finals(record: dict[str, typing.Any]) -> bool:
    tournament = normalize_matchlog_name(record.get("tournament"))
    return "next gen" in tournament and "final" in tournament


def _dashboard_record_is_exhibition(record: dict[str, typing.Any]) -> bool:
    return is_exhibition_tournament(
        record.get("tournament"),
        record.get("event_category") or record.get("category"),
    ) or _dashboard_score_is_exhibition_only(record.get("result")) or (
        _dashboard_score_is_short_set_format(record.get("result"))
        and not _dashboard_is_next_gen_finals(record)
    )


def _dashboard_record_is_davis_cup(record: dict[str, typing.Any]) -> bool:
    return "davis cup" in normalize_matchlog_name(record.get("tournament"))


def _dashboard_record_is_atp_cup(record: dict[str, typing.Any]) -> bool:
    """ATP Cup screenshots are trusted official evidence outside WTSL feeds."""
    return "atp cup" in normalize_matchlog_name(record.get("tournament"))


def _dashboard_squeaky_verified_override(
    summary: dict[str, typing.Any],
    record: dict[str, typing.Any],
) -> str | None:
    """Return a narrowly-scoped manual source decision for Squeaky's gaps."""
    if _dashboard_player_key(
        summary.get("player")
    ) != _dashboard_player_key("Squeaky"):
        return None

    date_key = _dashboard_date_key(record.get("date"))
    tournament = _dashboard_tournament_key(record.get("tournament"))
    opponent = _dashboard_player_key(record.get("opponent"))
    score = _dashboard_score_key(record.get("result"))
    common = (date_key, tournament, opponent, score)

    if common == (
        (2022, 7, 11),
        "wimbledon",
        _dashboard_player_key("Lampjavel"),
        _dashboard_score_key("7-6(1) 7-6(4) 6-1"),
    ):
        return "manual Squeaky verification"
    if common == (
        (2025, 1, 24),
        "australian open",
        _dashboard_player_key("Tennis_Star"),
        _dashboard_score_key("6/4 6/4"),
    ):
        return "manual Squeaky verification"
    if common == (
        (2025, 10, 25),
        "wimbledon",
        _dashboard_player_key("Madferit"),
        _dashboard_score_key("6-1 7-5"),
    ):
        return "manual Squeaky Davis Cup verification"
    return None


def _dashboard_date_is_placeholder(value: typing.Any) -> bool:
    date_key = _dashboard_date_key(value)
    return date_key[0] and date_key[1:] == (1, 1)


def _dashboard_tournament_is_generic(value: typing.Any) -> bool:
    key = _dashboard_tournament_key(value)
    return key in {"", "masters", "finals"} or key.startswith("atp ")


def _dashboard_special_competition_reason(
    record: dict[str, typing.Any],
) -> str | None:
    """Explain why a special event needs review outside routine WTSL matching."""
    tournament = normalize_matchlog_name(record.get("tournament"))
    if "laver cup" in tournament:
        return (
            "Laver Cup team exhibition — review separately from the "
            "individual WTSL tournament feed."
        )
    if _dashboard_record_is_exhibition(record):
        return (
            "Exhibition match — excluded from routine WTSL verification "
            "and coverage totals."
        )
    return None


def _official_result_is_all_results_row(
    result: dict[str, typing.Any],
) -> bool:
    source_url = str(result.get("source_url") or "").strip()
    return not source_url or source_url == MATCHLOG_ALL_RESULTS_URL


def _official_played_match_count(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> int:
    player = normalize_matchlog_name(
        summary.get("player") or profile.get("player_name")
    )
    tour = str(summary.get("tour") or "").casefold()
    period = str(summary.get("period") or "career")
    seen: set[tuple[typing.Any, ...]] = set()
    played = 0
    official_results = profile.get("official_results") or []
    for result in official_results:
        if not _official_result_is_all_results_row(result):
            continue
        if is_exhibition_tournament(
            result.get("tournament"),
            result.get("event_category"),
        ):
            continue
        if tour and str(result.get("tour") or "").casefold() != tour:
            continue
        if player not in {
            normalize_matchlog_name(
                result.get("p1") or result.get("player1")
            ),
            normalize_matchlog_name(
                result.get("p2") or result.get("player2")
            ),
        }:
            continue
        if not _official_result_in_summary_period(
            result, period, summary.get("as_of")
        ):
            continue
        result_text = str(result.get("result") or "")
        if re.search(
            r"\b(?:walkover|coin\s*toss|bct)\b",
            result_text,
            re.I,
        ):
            continue
        if not re.search(r"\d+\s*[-–]\s*\d+", result_text):
            continue
        result_key = (
            _dashboard_date_key(result.get("date")),
            _dashboard_event_identity(result.get("tournament")),
            _dashboard_pair_key(
                result.get("p1") or result.get("player1"),
                result.get("p2") or result.get("player2"),
            ),
            _dashboard_score_key(result_text),
        )
        if result_key in seen:
            continue
        seen.add(result_key)
        played += 1
    return played


def _unverified_official_matchlog_count(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> int | None:
    if not isinstance(profile.get("official_results"), list):
        return None
    played = _official_played_match_count(summary, profile)
    return max(0, played - int(summary.get("matches") or 0))


def _matchlog_coverage_description(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> str:
    rejected = _unverified_official_matchlog_count(summary, profile)
    if rejected is None:
        return ""
    official_played = _official_played_match_count(summary, profile)
    return (
        f" • **{official_played}** official played matches total"
        f" • **{rejected}** without verified MatchLog stats"
    )


def _screenshot_coverage_lines(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
    match_details: list[dict[str, typing.Any]] | None = None,
    *,
    include_unavailable_official_scores: bool = False,
) -> list[str]:
    """Explain screenshot match coverage and populated statistic fields."""
    if match_details is not None:
        match_details.clear()
    official_result_metrics = {
        "Tie-breaks Won %",
        "Deciding Sets Won %",
    }
    screenshot_matches = int(summary.get("matches") or 0)
    records = summary.get("match_records")
    records_available = isinstance(records, list) and bool(records)
    unique_records: list[dict[str, typing.Any]] = []
    excluded_special_records: list[dict[str, typing.Any]] = []
    review_pending = 0
    davis_cup_matches = 0
    if records_available:
        seen_record_keys: set[tuple[typing.Any, ...]] = set()
        for record in records:
            if _dashboard_record_is_exhibition(record):
                excluded_special_records.append(record)
                if match_details is not None:
                    match_details.append({
                        "status": "excluded",
                        "screenshot": record,
                        "review_reason": _dashboard_special_competition_reason(
                            record
                        ),
                    })
                continue
            record_category = _dashboard_event_category(
                record.get("tournament"),
                record.get("event_category") or record.get("category"),
            )
            record_key = (
                _dashboard_year_key(record.get("date")),
                _dashboard_event_identity(record.get("tournament")),
                record_category,
                _dashboard_score_key(record.get("result")),
                *_dashboard_pair_key(
                    summary.get("player") or profile.get("player_name"),
                    record.get("opponent"),
                ),
            )
            if record_key in seen_record_keys:
                continue
            seen_record_keys.add(record_key)
            unique_records.append(record)
        screenshot_matches = len(unique_records)

    player = _dashboard_player_key(
        summary.get("player") or profile.get("player_name")
    )
    tour = str(summary.get("tour") or "").casefold()
    official_results = profile.get("official_results")
    official_on_record: list[dict[str, typing.Any]] = []
    official_played: list[dict[str, typing.Any]] = []
    if isinstance(official_results, list):
        official_on_record = _filtered_official_player_matches(
            official_results,
            summary.get("player") or profile.get("player_name"),
            tour,
            str(summary.get("period") or "career"),
            summary.get("as_of"),
        )
        for result in official_on_record:
            result_text = str(result.get("result") or "")
            official_score = _dashboard_score_key(result_text)
            if not official_score and not include_unavailable_official_scores:
                continue
            official_played.append(result)

    lines = [f"**Unique matches from screenshots:** {screenshot_matches}"]
    if official_played and records_available:
        used_official: set[int] = set()
        matched = 0
        score_agreements = 0
        score_mismatches = 0
        score_partials = 0
        score_unavailable = 0
        inferred_tournament_matches = 0
        duplicate_screenshot_matches = 0
        trusted_source_matches = 0

        def exact_event_score_available(record):
            record_year = _dashboard_year_key(record.get("date"))
            record_pair = _dashboard_pair_key(
                summary.get("player") or profile.get("player_name"),
                record.get("opponent"),
            )
            record_score = _dashboard_score_key(record.get("result"))
            return not record_score or not any(
                record_year
                and record_year == _dashboard_year_key(result.get("date"))
                and record_pair == _dashboard_pair_key(
                    result.get("p1") or result.get("player1"),
                    result.get("p2") or result.get("player2"),
                )
                and _dashboard_event_identity_compatible(
                    record.get("tournament"),
                    result.get("tournament"),
                    screenshot_date=record.get("date"),
                    official_date=result.get("date"),
                )
                and record_score == _dashboard_score_key(result.get("result"))
                for result in official_played
            )

        def matching_priority(record):
            record_year = _dashboard_year_key(record.get("date"))
            date_is_placeholder = _dashboard_date_is_placeholder(
                record.get("date")
            )
            record_pair = _dashboard_pair_key(
                summary.get("player") or profile.get("player_name"),
                record.get("opponent"),
            )
            record_score = _dashboard_score_key(record.get("result"))
            best = 99
            for result in official_played:
                if record_pair != _dashboard_pair_key(
                    result.get("p1") or result.get("player1"),
                    result.get("p2") or result.get("player2"),
                ):
                    continue
                official_year = _dashboard_year_key(result.get("date"))
                record_event_year = _dashboard_year_key(
                    record.get("tournament")
                )
                official_event_year = _dashboard_year_key(
                    result.get("tournament")
                )
                if record_year and record_year != official_year:
                    if not (
                        (
                            record_event_year
                            and record_event_year == official_event_year
                        )
                        or record_year == official_event_year
                    ):
                        continue
                event_match = _dashboard_event_identity_compatible(
                    record.get("tournament"),
                    result.get("tournament"),
                    screenshot_date=record.get("date"),
                    official_date=result.get("date"),
                )
                score_match = bool(
                    record_score
                    and record_score == _dashboard_score_key(result.get("result"))
                )
                distance = _dashboard_date_distance_days(
                    record.get("date"),
                    result.get("date"),
                )
                if event_match and score_match:
                    best = min(best, 0)
                elif score_match and (
                    date_is_placeholder
                    or (distance is not None and 1 <= distance <= 31)
                ):
                    best = min(best, 1)
                elif event_match:
                    best = min(best, 2)
            return best

        # Prefer rows with an exact event/score candidate before consuming an
        # official result for a less-specific screenshot row. This prevents a
        # generic legacy label from stealing the result belonging to a later
        # ground/court-labelled row.
        records_for_matching = sorted(
            unique_records,
            key=lambda record: (
                matching_priority(record),
                exact_event_score_available(record),
            ),
        )
        for record in records_for_matching:
            trusted_source = (
                "trusted ATP Cup result"
                if _dashboard_record_is_atp_cup(record)
                else _dashboard_squeaky_verified_override(summary, record)
            )
            if trusted_source == "manual Squeaky Davis Cup verification":
                davis_cup_matches += 1
                if match_details is not None:
                    match_details.append({
                        "status": "davis_cup",
                        "screenshot": record,
                        "review_reason": (
                            "Davis Cup — manually verified for Squeaky; "
                            "results are hosted separately."
                        ),
                    })
                continue
            if trusted_source:
                matched += 1
                trusted_source_matches += 1
                if match_details is not None:
                    match_details.append({
                        "status": "matched",
                        "score_status": "verified",
                        "match_method": trusted_source,
                        "screenshot": record,
                    })
                continue
            if _dashboard_record_is_davis_cup(record):
                davis_cup_matches += 1
                if match_details is not None:
                    match_details.append({
                        "status": "davis_cup",
                        "screenshot": record,
                        "review_reason": (
                            "Davis Cup — included in screenshot statistics; "
                            "results are hosted separately from the WTSL "
                            "tournament feed."
                        ),
                    })
                continue
            screenshot_year = _dashboard_year_key(record.get("date"))
            screenshot_tournament = _dashboard_tournament_key(
                record.get("tournament")
            )
            screenshot_category = _dashboard_event_category(
                record.get("tournament"),
                record.get("event_category") or record.get("category"),
            )
            screenshot_start = _dashboard_event_start(
                record.get("event_start_date")
                or record.get("tournament_start_date"),
                record.get("date"),
            )
            # A screenshot workbook normally has match dates only.  For the
            # shared-court fallback, use the earliest screenshot date for the
            # same event label when an explicit start date was not persisted.
            if not record.get("event_start_date") and not record.get(
                "tournament_start_date"
            ):
                event_dates = [
                    _dashboard_date_key(candidate.get("date"))
                    for candidate in unique_records
                    if _dashboard_tournament_key(candidate.get("tournament"))
                    == screenshot_tournament
                    and _dashboard_event_category(
                        candidate.get("tournament"),
                        candidate.get("event_category") or candidate.get("category"),
                    ) == screenshot_category
                ]
                event_dates = [
                    date_key for date_key in event_dates if date_key != (0, 0, 0)
                ]
                if event_dates:
                    screenshot_start = min(event_dates)
            screenshot_score = _dashboard_score_key(record.get("result"))
            screenshot_pair = _dashboard_pair_key(
                summary.get("player") or profile.get("player_name"),
                record.get("opponent"),
            )
            candidate_indexes: list[int] = []
            for index, result in enumerate(official_played):
                if index in used_official:
                    continue
                official_pair = _dashboard_pair_key(
                    result.get("p1") or result.get("player1"),
                    result.get("p2") or result.get("player2"),
                )
                if screenshot_pair != official_pair:
                    continue
                official_year = _dashboard_year_key(result.get("date"))
                official_tournament = _dashboard_tournament_key(
                    result.get("tournament")
                )
                official_category = _dashboard_event_category(
                    result.get("tournament"),
                    result.get("event_category"),
                )
                official_start = _dashboard_event_start(
                    result.get("event_start_date")
                    or result.get("tournament_start_date"),
                    result.get("date"),
                )
                official_score = _dashboard_score_key(result.get("result"))
                if (
                    screenshot_year
                    and official_year
                    and screenshot_year == official_year
                    and screenshot_tournament
                    and _dashboard_event_identity_compatible(
                        record.get("tournament"),
                        result.get("tournament"),
                        screenshot_date=record.get("date"),
                        official_date=result.get("date"),
                    )
                ):
                    candidate_indexes.append(index)
                elif (
                    screenshot_year
                    and official_year
                    and screenshot_year == official_year
                    and _dashboard_cross_category_court_match(
                        screenshot_category,
                        official_category,
                        screenshot_start,
                        official_start,
                    )
                ):
                    candidate_indexes.append(index)
                elif (
                    screenshot_year
                    and official_year
                    and screenshot_year == official_year
                    and screenshot_score
                    and screenshot_score == official_score
                    and (
                        date_distance := _dashboard_date_distance_days(
                            record.get("date"),
                            result.get("date"),
                        )
                    ) == 0
                    and not (
                        screenshot_category
                        and official_category
                        and screenshot_category == official_category
                    )
                ):
                    # A wrong court/event label is safe to correct when the
                    # canonical pair, complete score, and calendar date
                    # identify this exact official result.
                    candidate_indexes.append(index)
                elif (
                    screenshot_year
                    and official_year
                    and screenshot_year == official_year
                    and screenshot_score
                    and screenshot_score == official_score
                    and (
                        date_distance := _dashboard_date_distance_days(
                            record.get("date"),
                            result.get("date"),
                        )
                    ) is not None
                    and 1 <= date_distance <= 31
                ):
                    # Some screenshot labels describe a stadium/session
                    # incorrectly, while the pair, score, year, and nearby
                    # date still identify one official result. Do not use
                    # same-day matches or broad year-only guesses.
                    candidate_indexes.append(index)
                elif (
                    screenshot_score
                    and screenshot_score == official_score
                    and (
                        not screenshot_tournament
                        or _dashboard_tournament_is_generic(
                            record.get("tournament")
                        )
                    )
                    and (
                        not screenshot_year
                        or _dashboard_date_is_placeholder(record.get("date"))
                    )
                ):
                    # A few legacy workbook rows lost both their event and
                    # date.  An exact score remains safe only when the pair
                    # has one unique official result with that score.
                    candidate_indexes.append(index)
                elif (
                    screenshot_score
                    and _dashboard_tournament_is_generic(
                        record.get("tournament")
                    )
                    and _dashboard_date_is_placeholder(record.get("date"))
                    and len(screenshot_score) == len(official_score)
                ):
                    # Placeholder-date generic rows can still be tied to a
                    # unique same-length official score for the pair.
                    candidate_indexes.append(index)
            match_index = None
            match_method = "player-pair"
            if len(candidate_indexes) == 1:
                match_index = candidate_indexes[0]
            elif screenshot_score:
                score_matches = [
                    index
                    for index in candidate_indexes
                    if screenshot_score == _dashboard_score_key(
                        official_played[index].get("result")
                    )
                ]
                if len(score_matches) == 1:
                    match_index = score_matches[0]
                elif score_matches:
                    exact_date_matches = [
                        index
                        for index in score_matches
                        if _dashboard_date_key(record.get("date"))
                        == _dashboard_date_key(
                            official_played[index].get("date")
                        )
                    ]
                    if len(exact_date_matches) == 1:
                        match_index = exact_date_matches[0]
            if match_index is None and screenshot_score:
                # Historical screenshot rows sometimes retain a real-world
                # opponent label or an incorrect year while preserving the
                # unique official event and exact score.  Apply the same
                # evidence-backed inference used for older Dani21 records:
                # the selected player, event, and score must identify one
                # official result, or one clearly closest dated result.
                screenshot_player = _dashboard_player_key(
                    summary.get("player") or profile.get("player_name")
                )
                inferred_indexes = [
                    index
                    for index, result in enumerate(official_played)
                    if index not in used_official
                    and screenshot_player in {
                        _dashboard_player_key(
                            result.get("p1") or result.get("player1")
                        ),
                        _dashboard_player_key(
                            result.get("p2") or result.get("player2")
                        ),
                    }
                    and _dashboard_event_identity_compatible(
                        record.get("tournament"),
                        result.get("tournament"),
                        screenshot_date=record.get("date"),
                        official_date=result.get("date"),
                    )
                    and screenshot_score == _dashboard_score_key(
                        result.get("result")
                    )
                ]
                if len(inferred_indexes) == 1:
                    inferred_distance = _dashboard_date_distance_days(
                        record.get("date"),
                        official_played[inferred_indexes[0]].get("date"),
                    )
                    inferred_event_year = _dashboard_year_key(
                        official_played[inferred_indexes[0]].get("tournament")
                    )
                    screenshot_date_year = _dashboard_year_key(record.get("date"))
                    screenshot_event_year = _dashboard_year_key(
                        record.get("tournament")
                    )
                    if (
                        (
                            inferred_distance is None
                            and not screenshot_date_year
                        )
                        or (
                            inferred_distance is not None
                            and (
                                inferred_distance <= 31
                                or _dashboard_date_is_placeholder(
                                    record.get("date")
                                )
                                or (
                                    screenshot_date_year
                                    and screenshot_date_year == inferred_event_year
                                )
                                or (
                                    screenshot_event_year
                                    and screenshot_event_year == inferred_event_year
                                )
                            )
                        )
                    ):
                        match_index = inferred_indexes[0]
                        match_method = "unique event/score inference"
                elif len(inferred_indexes) > 1:
                    dated_candidates = [
                        (
                            index,
                            _dashboard_date_distance_days(
                                record.get("date"),
                                official_played[index].get("date"),
                            ),
                        )
                        for index in inferred_indexes
                    ]
                    dated_candidates = [
                        item for item in dated_candidates if item[1] is not None
                    ]
                    if dated_candidates:
                        closest_distance = min(
                            distance for _index, distance in dated_candidates
                        )
                        closest = [
                            index
                            for index, distance in dated_candidates
                            if distance == closest_distance
                        ]
                        if len(closest) == 1 and closest_distance <= 31:
                            match_index = closest[0]
                            match_method = "closest event/score inference"
            if match_index is not None:
                used_official.add(match_index)
                matched += 1
                matched_official = official_played[match_index]
                if (
                    screenshot_score
                    and screenshot_score == _dashboard_score_key(
                        matched_official.get("result")
                    )
                    and _dashboard_date_key(record.get("date"))
                    == _dashboard_date_key(matched_official.get("date"))
                    and not _dashboard_event_identity_compatible(
                        record.get("tournament"),
                        matched_official.get("tournament"),
                        screenshot_date=record.get("date"),
                        official_date=matched_official.get("date"),
                    )
                ):
                    match_method = "exact pair/score/date inference"
                if (
                    screenshot_score
                    and screenshot_score == _dashboard_score_key(
                        matched_official.get("result")
                    )
                    and not _dashboard_event_identity_compatible(
                        record.get("tournament"),
                        matched_official.get("tournament"),
                        screenshot_date=record.get("date"),
                        official_date=matched_official.get("date"),
                    )
                ):
                    inferred_tournament_matches += 1
                if match_details is not None:
                    match_details.append({
                        "status": "matched",
                        "score_status": (
                            "unavailable"
                            if not screenshot_score
                            else "verified"
                            if screenshot_score == _dashboard_score_key(
                                matched_official.get("result")
                            )
                            else "partial"
                            if _dashboard_score_is_partial(
                                screenshot_score,
                                _dashboard_score_key(
                                    matched_official.get("result")
                                ),
                                record.get("result"),
                            )
                            else "mismatch"
                        ),
                        "match_method": match_method,
                        "screenshot": record,
                        "official": matched_official,
                    })
                if not screenshot_score:
                    score_unavailable += 1
                elif screenshot_score == _dashboard_score_key(
                    official_played[match_index].get("result")
                ):
                    score_agreements += 1
                elif _dashboard_score_is_partial(
                    screenshot_score,
                    _dashboard_score_key(
                        official_played[match_index].get("result")
                    ),
                    record.get("result"),
                ):
                    score_partials += 1
                else:
                    score_mismatches += 1
            else:
                duplicate_indexes = [
                    index
                    for index in used_official
                    if (
                        screenshot_pair == _dashboard_pair_key(
                            official_played[index].get("p1")
                            or official_played[index].get("player1"),
                            official_played[index].get("p2")
                            or official_played[index].get("player2"),
                        )
                        and (
                            (
                                screenshot_year
                                and screenshot_year == _dashboard_year_key(
                                    official_played[index].get("date")
                                )
                                and _dashboard_event_identity_compatible(
                                    record.get("tournament"),
                                    official_played[index].get("tournament"),
                                    screenshot_date=record.get("date"),
                                    official_date=official_played[index].get("date"),
                                )
                            )
                            or (
                                screenshot_score
                                and _dashboard_tournament_is_generic(
                                    record.get("tournament")
                                )
                                and _dashboard_date_is_placeholder(
                                    record.get("date")
                                )
                                and (
                                    screenshot_score == _dashboard_score_key(
                                        official_played[index].get("result")
                                    )
                                    or len(screenshot_score)
                                    == len(_dashboard_score_key(
                                        official_played[index].get("result")
                                    ))
                                )
                            )
                        )
                    )
                ]
                if len(duplicate_indexes) == 1:
                    duplicate_screenshot_matches += 1
                    if match_details is not None:
                        match_details.append({
                            "status": "duplicate",
                            "screenshot": record,
                            "official": official_played[duplicate_indexes[0]],
                        })
                else:
                    review_pending += 1
                    if match_details is not None:
                        match_details.append({
                            "status": "unmatched",
                            "screenshot": record,
                            "review_reason": (
                                _dashboard_special_competition_reason(record)
                                or "No compatible official WTSL result."
                            ),
                            "official_candidates": [
                                official_played[index]
                                for index in candidate_indexes
                            ],
                        })
        expected = len(official_on_record)
        summary["_dashboard_verified_matches"] = matched
        summary["_dashboard_trusted_source_matches"] = trusted_source_matches
        summary["_dashboard_unmatched_matches"] = review_pending
        summary["_dashboard_score_exceptions"] = (
            score_mismatches + score_unavailable
        )
        summary["_dashboard_duplicate_matches"] = duplicate_screenshot_matches
        summary["_dashboard_davis_cup_matches"] = davis_cup_matches
        verified_screenshot_matches = max(0, matched - trusted_source_matches)
        matches_used = max(0, int(summary.get("matches") or 0))
        used_verified_matches = min(matches_used, verified_screenshot_matches)
        verified_percentage = (
            f"{used_verified_matches / verified_screenshot_matches:.0%}"
            if verified_screenshot_matches
            else "0%"
        )
        lines.append(f"**Official matches on record:** {expected}")
        lines.append(
            f"**Verified screenshots available:** "
            f"{verified_screenshot_matches}"
        )
        lines.append(
            f"**Verified matches used:** "
            f"{used_verified_matches} of {verified_screenshot_matches} "
            f"({verified_percentage})"
        )
        if trusted_source_matches:
            lines.append(
                "**Trusted official screenshots accepted outside the WTSL "
                f"feed:** {trusted_source_matches} "
                "(included in the used total)"
            )
        score_exception_count = score_mismatches + score_unavailable
        for_review = review_pending + score_exception_count + duplicate_screenshot_matches
        lines.append(
            f"**For Review:** {for_review} overlapping flag"
            f"{'s' if for_review != 1 else ''} "
            f"(unmatched: {review_pending} • score checks: "
            f"{score_exception_count} • duplicates: "
            f"{duplicate_screenshot_matches})"
        )
        if davis_cup_matches:
            lines.append(
                f"**Davis Cup:** {davis_cup_matches} match"
                f"{'es' if davis_cup_matches != 1 else ''} included in "
                "screenshot calculations; results are hosted separately."
            )
        if score_partials:
            partial_percentage = (
                f"{score_partials / verified_screenshot_matches:.0%}"
                if verified_screenshot_matches
                else "0%"
            )
            lines.append(
                f"**Verified matches with partial scores:** "
                f"{score_partials}/{verified_screenshot_matches} "
                f"({partial_percentage})"
            )
        special_reasons = [
            _dashboard_special_competition_reason(record)
            for record in unique_records
        ] + [
            _dashboard_special_competition_reason(record)
            for record in excluded_special_records
        ]
        special_reasons = [reason for reason in special_reasons if reason]
        if special_reasons:
            exhibition_count = len(excluded_special_records)
            lines.append(
                f"**Exhibitions excluded:** {exhibition_count} match"
                f"{'es' if exhibition_count != 1 else ''} from screenshot "
                "calculations."
            )
    elif isinstance(official_results, list):
        lines.extend([
            f"**Official matches on record:** {len(official_on_record)}",
            "**Verified screenshots available:** 0",
            "**Verified matches used:** 0 of 0 (0%)",
        ])
        if not records_available:
            lines.append(
                "Detailed screenshot matching is unavailable for this workbook."
            )
    else:
        lines.append(
            "**Official match coverage:** unavailable while the official "
            "result feed is unavailable"
        )

    metric_counts = {
        label: int(count or 0)
        for label, _value, count in summary.get("metrics") or []
    }
    tracked_metrics = [
        label
        for label in SCREENSHOT_LEADERBOARD_METRICS
        if label not in official_result_metrics
    ]
    statistics_matches = max(0, int(summary.get("matches") or 0))
    if statistics_matches and tracked_metrics:
        observed = sum(
            min(metric_counts.get(label, 0), statistics_matches)
            for label in tracked_metrics
        )
        possible = statistics_matches * len(tracked_metrics)
        lines.append(
            f"**Data completeness:** {observed}/{possible} tracked fields "
            f"populated ({observed / possible:.0%})"
        )
        weakest = sorted(
            (
                (
                    label,
                    min(metric_counts.get(label, 0), statistics_matches),
                )
                for label in tracked_metrics
            ),
            key=lambda item: (item[1] / statistics_matches, item[0]),
        )[:3]
        lines.append(
            "**Lowest-covered fields:** "
            + ", ".join(
                f"{label} {count}/{statistics_matches}"
                for label, count in weakest
            )
            + "."
        )
        lines.append(
            "_Opportunity-based fields are only counted when a measurable "
            "value is present._"
        )
    else:
        lines.append("**Data completeness:** no screenshot match fields available")
    return lines


def _screenshot_official_results_by_player(
    official_results: list[dict[str, typing.Any]],
) -> dict[tuple[str, str], list[dict[str, typing.Any]]]:
    """Index results by the same tour/player filters used by coverage matching."""
    indexed: dict[
        tuple[str, str],
        list[dict[str, typing.Any]],
    ] = {}
    for result in enrich_event_metadata(official_results):
        tour = str(result.get("tour") or "").casefold()
        if tour not in {"atp", "wta"}:
            continue
        players = {
            _dashboard_player_key(result.get("p1") or result.get("player1")),
            _dashboard_player_key(result.get("p2") or result.get("player2")),
        }
        for player in players:
            if player:
                indexed.setdefault((tour, player), []).append(result)
    return indexed


def _screenshot_statistics_exclusion_keys(
    summaries: list[dict[str, typing.Any]],
    official_results: list[dict[str, typing.Any]],
) -> dict[str, dict[str, set[str]]]:
    """Return screenshot match keys that must not affect calculated statistics."""
    exclusions: dict[str, dict[str, set[str]]] = {"atp": {}, "wta": {}}
    official_by_player = _screenshot_official_results_by_player(official_results)
    for summary in summaries:
        player = str(summary.get("player") or "").strip()
        tour = str(summary.get("tour") or "").casefold()
        if not player or tour not in exclusions or not summary.get("match_records"):
            continue
        details: list[dict[str, typing.Any]] = []
        _screenshot_coverage_lines(
            summary,
            {
                "player_name": player,
                "official_results": official_by_player.get(
                    (tour, _dashboard_player_key(player)),
                    [],
                ),
            },
            details,
        )
        player_exclusions = exclusions[tour].setdefault(player, set())
        for detail in details:
            if (
                detail.get("status") not in {"unmatched", "excluded"}
                and detail.get("score_status")
                not in {"mismatch", "unavailable"}
            ):
                continue
            match_key = str(
                (detail.get("screenshot") or {}).get("match_key") or ""
            ).strip()
            if match_key:
                player_exclusions.add(match_key.casefold())
        if not player_exclusions:
            exclusions[tour].pop(player, None)
    return exclusions


async def _get_screenshot_statistics_exclusions(
    official_results: list[dict[str, typing.Any]] | None = None,
) -> dict[str, dict[str, set[str]]]:
    """Reconcile retained screenshot evidence before using it in statistics."""
    global _screenshot_exclusions_cache
    if official_results is None:
        official_results = await _get_matchlog_official_results()
    workbook_mtime_ns = MATCH_STATS_WORKBOOK.stat().st_mtime_ns
    cached = _screenshot_exclusions_cache
    if (
        cached is not None
        and cached[0] == workbook_mtime_ns
        and cached[1] is official_results
    ):
        return cached[2]

    async with _screenshot_exclusions_lock:
        cached = _screenshot_exclusions_cache
        if (
            cached is not None
            and cached[0] == workbook_mtime_ns
            and cached[1] is official_results
        ):
            return cached[2]
        summaries = await _run_mystats_summary_worker(
            get_screenshot_match_record_summaries, MATCH_STATS_WORKBOOK
        )
        exclusions = await _run_mystats_summary_worker(
            _screenshot_statistics_exclusion_keys, summaries, official_results
        )
        _screenshot_exclusions_cache = (
            workbook_mtime_ns,
            official_results,
            exclusions,
        )
        return exclusions


def _screenshot_review_date(value: typing.Any) -> str:
    year, month, day = _dashboard_date_key(value)
    if year:
        return _dt.date(year, month, day).isoformat()
    return str(value or "").strip()
def _official_playing_since(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
):
    player = normalize_matchlog_name(
        summary.get("player") or profile.get("player_name")
    )
    tour = str(summary.get("tour") or "").casefold()
    dates = []
    for result in profile.get("official_results") or []:
        if is_exhibition_tournament(
            result.get("tournament"),
            result.get("event_category"),
        ):
            continue
        if tour and str(result.get("tour") or "").casefold() != tour:
            continue
        if player not in {
            normalize_matchlog_name(
                result.get("p1") or result.get("player1")
            ),
            normalize_matchlog_name(
                result.get("p2") or result.get("player2")
            ),
        }:
            continue
        result_text = str(result.get("result") or "")
        if re.search(
            r"\b(?:walkover|coin\s*toss|bct)\b",
            result_text,
            re.I,
        ):
            continue
        if not re.search(r"\d+\s*[-–]\s*\d+", result_text):
            continue
        date_key = _dashboard_date_key(result.get("date"))
        if date_key != (0, 0, 0):
            dates.append(_dt.date(*date_key))
    return min(dates) if dates else None


def _matchlog_coverage_span_text(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> str | None:
    start = str(summary.get("coverage_start") or "")
    end = str(summary.get("coverage_end") or "")
    if not start or not end:
        return None

    def display(value: str) -> str:
        try:
            return _dt.date.fromisoformat(value[:10]).strftime("%d %b %Y")
        except ValueError:
            return value[:10]

    playing_since = _official_playing_since(summary, profile)
    raw_start = _matchlog_raw_coverage_index.get((
        str(summary.get("tour") or "").casefold(),
        normalize_matchlog_name(summary.get("player")),
    )) or start
    playing_line = (
        f"**Playing Since:** {playing_since.strftime('%d %b %Y')}\n"
        if playing_since else ""
    )
    return (
        playing_line
        + f"**First MatchLog Record:** {display(raw_start)}\n"
        f"**First Verified MatchLog Match:** {display(start)}\n"
        f"**Last Verified MatchLog Match:** {display(end)}\n"
        "Raw and verified spans may contain missing matches."
    )


def _official_deciding_set_metric(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> tuple[float, int] | None:
    player = normalize_matchlog_name(
        summary.get("player") or profile.get("player_name")
    )
    tour = str(summary.get("tour") or "").casefold()
    period = str(summary.get("period") or "career")
    outcomes = []
    for result in profile.get("official_results") or []:
        if not _official_result_is_all_results_row(result):
            continue
        if tour and str(result.get("tour") or "").casefold() != tour:
            continue
        if player not in {
            normalize_matchlog_name(result.get("p1")),
            normalize_matchlog_name(result.get("p2")),
        }:
            continue
        if not _official_result_in_summary_period(
            result, period, summary.get("as_of")
        ):
            continue
        score = re.sub(r"\([^)]*\)", "", str(result.get("result") or ""))
        sets = [
            (int(first), int(second))
            for first, second in re.findall(r"(\d+)\s*[-–]\s*(\d+)", score)
        ]
        if len(sets) < 3:
            continue
        prior_first = sum(first > second for first, second in sets[:-1])
        prior_second = sum(second > first for first, second in sets[:-1])
        final_first, final_second = sets[-1]
        if prior_first != prior_second or final_first == final_second:
            continue
        # The WTSL all-results feed is winner-oriented: Player 1 is always the
        # winner and Player 2 is always the loser. Use the score only to decide
        # whether the final set was a deciding set.
        winner = normalize_matchlog_name(result.get("p1"))
        outcomes.append(float(winner == player))
    if not outcomes:
        return None
    return sum(outcomes) / len(outcomes), len(outcomes)


def _official_tiebreak_metric(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> tuple[float, int] | None:
    player = normalize_matchlog_name(
        summary.get("player") or profile.get("player_name")
    )
    tour = str(summary.get("tour") or "").casefold()
    period = str(summary.get("period") or "career")
    outcomes = []
    for result in profile.get("official_results") or []:
        if not _official_result_is_all_results_row(result):
            continue
        if tour and str(result.get("tour") or "").casefold() != tour:
            continue
        first = normalize_matchlog_name(result.get("p1"))
        second = normalize_matchlog_name(result.get("p2"))
        if player not in {first, second}:
            continue
        if not _official_result_in_summary_period(
            result, period, summary.get("as_of")
        ):
            continue
        score = re.sub(r"\([^)]*\)", "", str(result.get("result") or ""))
        sets = [
            (int(left), int(right))
            for left, right in re.findall(r"(\d+)\s*[-–]\s*(\d+)", score)
        ]
        for left, right in sets:
            if (left, right) not in {(7, 6), (6, 7), (4, 3), (3, 4)}:
                continue
            player_won = (
                (player == first and left > right)
                or (player == second and right > left)
            )
            outcomes.append(float(player_won))
    if not outcomes:
        return None
    return sum(outcomes) / len(outcomes), len(outcomes)


def _with_official_result_metrics(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> dict[str, typing.Any]:
    official_metrics = {
        "Tie-breaks Won %": _official_tiebreak_metric(summary, profile),
        "Deciding Sets Won %": _official_deciding_set_metric(summary, profile),
    }
    available = {
        label: metric
        for label, metric in official_metrics.items()
        if metric is not None
    }
    if not available:
        return summary
    updated = dict(summary)
    metrics = [
        item for item in (summary.get("metrics") or [])
        if item[0] not in available
    ]
    metrics.extend(
        (label, value, count)
        for label, (value, count) in available.items()
    )
    updated["metrics"] = metrics
    values = {label: metric_value for label, metric_value, _ in metrics}
    recalculated = calculate_partial_overall_ratings(values)
    ratings = [
        item for item in (summary.get("ratings") or [])
        if item[0] != "Under Pressure"
    ]
    if recalculated.get("Under Pressure") is not None:
        ratings.append(("Under Pressure", recalculated["Under Pressure"]))
    updated["ratings"] = ratings
    return updated


def _with_official_result_metrics_leaderboard_row(
    row: dict[str, typing.Any],
    results: list[dict[str, typing.Any]],
) -> dict[str, typing.Any]:
    metrics = row.get("metrics") or {}
    summary = {
        **row,
        "period": "career",
        "metrics": [
            (label, value, 1)
            for label, value in metrics.items()
        ],
        "ratings": list((row.get("ratings") or {}).items()),
    }
    updated = _with_official_result_metrics(
        summary,
        {
            "player_name": row.get("player"),
            "official_results": results,
        },
    )
    return {
        **row,
        "metrics": {
            label: value
            for label, value, _count in updated.get("metrics") or []
        },
        "ratings": dict(updated.get("ratings") or []),
    }


def _most_picked_characters_text(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> str:
    picks = _most_picked_characters_for_summary(summary, profile)
    if not picks:
        return "No known character picks in this period"
    lines = []
    for index, pick in enumerate(picks, start=1):
        count = int(pick.get("count") or 0)
        percentage = pick.get("percentage")
        shown_percentage = (
            f"{float(percentage):.1%}"
            if isinstance(percentage, (int, float))
            else "percentage unavailable"
        )
        lines.append(
            f"**#{index} {pick['character']}** • {count} "
            f"pick{'s' if count != 1 else ''} ({shown_percentage})"
        )
    known, total = _character_pick_coverage(summary, profile)
    if total:
        lines.append(
            f"Character recorded in **{known} of {total}** official "
            f"match{'es' if total != 1 else ''}"
            + (f" • {total - known} unavailable" if known < total else "")
        )
    return "\n".join(lines)


def _character_pick_coverage(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> tuple[int, int]:
    period = str(summary.get("period") or "career")
    known = total = 0
    player = _dashboard_player_key(
        summary.get("player") or profile.get("player_name")
    )
    filtered = _filtered_official_player_matches(
        profile.get("official_results") or [],
        player,
        summary.get("tour"),
        period,
        summary.get("as_of"),
    )
    for result in filtered:
        if _dashboard_player_key(result.get("p1")) == player:
            character = result.get("p1_character")
        elif _dashboard_player_key(result.get("p2")) == player:
            character = result.get("p2_character")
        else:
            continue
        total += 1
        if str(character or "").strip():
            known += 1
    return known, total


def _dashboard_result_counts_as_played(
    result: dict[str, typing.Any],
) -> bool:
    """Exclude non-played outcomes from official match denominators."""
    result_text = str(result.get("result") or "").strip()
    if re.search(
        r"\b(?:walkover|w\s*/?\s*o|coin\s*toss|toss|bct)\b",
        result_text,
        re.I,
    ):
        return False
    return True


def _mystats_period_summary(
    profile: dict[str, typing.Any],
    summary: dict[str, typing.Any],
) -> str:
    official_results = [
        result
        for result in profile.get("official_results") or []
        if not is_exhibition_tournament(
            result.get("tournament"),
            result.get("event_category"),
        )
    ]
    player_name = str(profile.get("player_name") or summary.get("player") or "")
    period = str(summary.get("period") or "career")
    if official_results and player_name:
        return result_period_summary_text(
            official_results,
            player_name,
            profile.get("rankings") or {},
            period=period,
            as_of=summary.get("as_of"),
        )
    if period in {"year", "career"}:
        return _mystats_year_summary(profile)
    return f"No official results available for {summary.get('period_label', period)}."


@functools.lru_cache(maxsize=16384)
def _dashboard_date_text_key(text: str) -> tuple[int, int, int]:
    text = text.strip()
    if "T" in text or " " in text:
        text = re.split(r"[T ]", text, maxsplit=1)[0]
    for format_string in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            parsed = _dt.datetime.strptime(text, format_string)
            return parsed.year, parsed.month, parsed.day
        except ValueError:
            continue
    return 0, 0, 0


def _dashboard_date_key(value: typing.Any) -> tuple[int, int, int]:
    if isinstance(value, _dt.datetime):
        return value.year, value.month, value.day
    if isinstance(value, _dt.date):
        return value.year, value.month, value.day
    return _dashboard_date_text_key(str(value or ""))


def _dashboard_year_key(value: typing.Any) -> int:
    date_key = _dashboard_date_key(value)
    if date_key[0]:
        return date_key[0]
    match = re.search(r"\b(20\d{2})\b", str(value or ""))
    return int(match.group(1)) if match else 0


@functools.lru_cache(maxsize=16384)
def _dashboard_player_text_key(text: str) -> str:
    normalized = normalize_matchlog_name(text)
    return normalize_matchlog_name(
        SCREENSHOT_NAME_ALIASES.get(normalized, normalized)
    )


def _dashboard_player_key(value: typing.Any) -> str:
    return _dashboard_player_text_key(str(value or ""))


@functools.lru_cache(maxsize=16384)
def _dashboard_tournament_text_key(value: str) -> str:
    """Normalize screenshot/feed tournament labels to a stable event name."""
    text = normalize_matchlog_name(value)
    text = re.sub(
        r"^tennis elbow 4(?:\s*\([^)]*\))?\s*[-:]\s*",
        "",
        text,
    )
    text = re.sub(r"\s*\([^)]*\)", "", text)
    text = re.sub(r"\b20\d{2}\b", "", text)
    text = re.sub(r"\bground[_\s-]*\d+\b", " ", text)
    aliases = (
        ("australian open", ("australian open", "ao rod laver", "ao margaret court")),
        ("roland garros", (
            "roland garros",
            "rg philippe chartier",
            "rg philippe chatrier",
            "rg philippe chattrier",
            "rg philippe chartrier",
        )),
        ("wimbledon", ("wimbledon",)),
        ("us open", ("us open",)),
        ("indian wells", ("indian wells",)),
        ("monte carlo", ("monte carlo",)),
        ("washington", ("washington",)),
        ("montreal", ("montreal",)),
        ("toronto", ("toronto",)),
        ("rome", ("rome", "roma")),
        ("madrid", ("madrid",)),
        ("barcelona", ("barcelona",)),
        ("halle", ("halle",)),
        ("hamburg", ("hamburg",)),
        ("shanghai", ("shanghai",)),
        ("tokyo", ("tokyo",)),
        ("rotterdam", ("rotterdam",)),
        ("rio", ("rio",)),
        ("dubai", ("dubai",)),
        ("miami", ("miami",)),
        ("cincinnati", ("cincinnati",)),
        ("basel", ("basel",)),
        ("acapulco", ("acapulco",)),
        ("eastbourne", ("eastbourne",)),
        ("queens", ("queen's", "queens")),
        ("finals", ("wtsl finals", "atp finals")),
        ("china open", ("china open", "beijing lotus", "beijing")),
        ("atlanta open", ("atlanta open", "atlanta")),
        ("zhengzhou", ("zhengzhou",)),
        ("almaty", ("almaty", "astana")),
        ("wuhan", ("wuhan",)),
        ("brisbane", ("brisbane",)),
        ("adelaide", ("adelaide",)),
        ("auckland", ("auckland",)),
        ("stuttgart", ("stuttgart", "boss open")),
        ("montpellier", ("montpellier",)),
        ("marseille", ("marseille",)),
        ("vienna", ("vienna",)),
        ("mallorca", ("mallorca",)),
        ("tokyo", ("tokyo",)),
    )
    for canonical, candidates in aliases:
        if any(candidate in text for candidate in candidates):
            return canonical
    text = re.sub(r"\b(?:atp|wta)\s+(?:250|500|1000)\b", " ", text)
    text = re.sub(
        r"\b(?:day|night|center|centre|court|no\.?\s*1|arthur ashe|"
        r"louis armstrong|manolo santana|rod laver|margaret court)\b",
        " ",
        text,
    )
    return re.sub(r"\s+", " ", text).strip()


def _dashboard_tournament_key(value: typing.Any) -> str:
    return _dashboard_tournament_text_key(str(value or ""))


def _dashboard_pair_key(
    first: typing.Any,
    second: typing.Any,
) -> tuple[str, str]:
    return tuple(sorted((
        _dashboard_player_key(first),
        _dashboard_player_key(second),
    )))

@functools.lru_cache(maxsize=16384)
def _dashboard_event_identity_text(value: str) -> tuple[str, str]:
    """Keep explicit ground/court identifiers while normalizing event names."""
    text = normalize_matchlog_name(value)
    ground = re.search(r"\bground[\s_-]*(\d+)\b", text)
    return (
        ground.group(1) if ground else "",
        _dashboard_tournament_key(value),
    )


def _dashboard_event_identity(value: typing.Any) -> tuple[str, str]:
    return _dashboard_event_identity_text(str(value or ""))


def _dashboard_event_identity_compatible(
    screenshot_value: typing.Any,
    official_value: typing.Any,
    *,
    screenshot_date: typing.Any = None,
    official_date: typing.Any = None,
) -> bool:
    """Allow official feeds that omit a screenshot's ground identifier."""
    screenshot_ground, screenshot_event = _dashboard_event_identity(
        screenshot_value
    )
    official_ground, official_event = _dashboard_event_identity(official_value)
    if {screenshot_event, official_event} == {"roland garros", "olympics"}:
        screenshot_year = _dashboard_year_key(
            screenshot_date if screenshot_date is not None else screenshot_value
        )
        official_year = _dashboard_year_key(
            official_date if official_date is not None else official_value
        )
        if screenshot_year == official_year == 2024:
            return True
    if not screenshot_event or screenshot_event != official_event:
        return False
    return (
        not screenshot_ground
        or not official_ground
        or screenshot_ground == official_ground
    )


def _dashboard_date_distance_days(
    first: typing.Any,
    second: typing.Any,
) -> int | None:
    first_key = _dashboard_date_key(first)
    second_key = _dashboard_date_key(second)
    if first_key == (0, 0, 0) or second_key == (0, 0, 0):
        return None
    first_date = _dt.date(*first_key)
    second_date = _dt.date(*second_key)
    return abs((first_date - second_date).days)
@functools.lru_cache(maxsize=16384)
def _dashboard_score_text_signature(text: str) -> tuple[tuple[int, int], ...]:
    text = text.strip()
    # Excel can return a malformed score cell as a calendar date.  Never
    # interpret an ISO date as two tennis sets.
    if re.match(r"^\d{4}[-/]\d{1,2}[-/]\d{1,2}\b", text):
        return ()
    signatures = []
    # Some screenshot OCR drops the separator in a score such as 6-0.
    # Restrict compact scores to standalone two-digit tokens so dates and
    # tie-break annotations are not interpreted as sets.  A combined pattern
    # preserves the order when compact and separated scores are mixed.
    token_pattern = re.compile(
        r"(?P<separated>\d{1,2}\s*[-/–]\s*\d{1,2})"
        r"|(?P<compact>(?<![\d-])\d\d(?!\d))"
    )
    for match in token_pattern.finditer(text):
        token = match.group(0)
        if match.group("separated"):
            left, right = re.split(r"\s*[-/–]\s*", token, maxsplit=1)
            signatures.append((int(left), int(right)))
        else:
            signatures.append((int(token[0]), int(token[1])))
    return tuple(signatures)


def _dashboard_score_signature(
    value: typing.Any,
) -> tuple[tuple[int, int], ...]:
    if isinstance(value, (date, datetime)):
        return ()
    return _dashboard_score_text_signature(str(value or ""))


def _dashboard_score_key(
    value: typing.Any,
) -> tuple[tuple[int, int], ...]:
    """Compare a score without relying on each set's player orientation."""
    signature = _dashboard_score_signature(value)
    if not signature:
        return ()
    return tuple(
        (min(left, right), max(left, right))
        for left, right in signature
    )


def _dashboard_score_completed(value: typing.Any) -> bool:
    score = str(value or "").strip()
    if score.casefold() in {"", "scheduled", "tbd", "pending", "to be played"}:
        return False
    sets = re.findall(r"(\d+)\s*[-–]\s*(\d+)", score)
    return bool(sets) and any(left != right for left, right in sets)


def _dashboard_score_is_partial(
    screenshot_score: tuple[tuple[int, int], ...],
    official_score: tuple[tuple[int, int], ...],
    screenshot_text: typing.Any = None,
) -> bool:
    """Identify a score fragment that is not a true score discrepancy.

    Screenshots may capture only part of a match, especially around a
    retirement.  They can therefore contain a suffix or gapped subsequence of
    the official sets, a placeholder ``0-0``, or an unfinished final set.
    Best-of-five screenshots also commonly contain several completed sets
    without the rest of the match.
    """
    if not screenshot_score or not official_score:
        return False
    if screenshot_score == official_score:
        return False

    screenshot_text_lower = str(screenshot_text or "").casefold()
    has_retirement = bool(
        re.search(r"\bret(?:ired)?\.?\b", screenshot_text_lower)
    )
    placeholders = {(0, 0)}
    observed = [
        score for score in screenshot_score if score not in placeholders
    ]

    def is_completed_set(score: tuple[int, int]) -> bool:
        low, high = score
        return high >= 6 and (high - low >= 2 or high == 7)

    def is_subsequence(
        shorter: list[tuple[int, int]],
        longer: tuple[tuple[int, int], ...],
    ) -> bool:
        if not shorter:
            return False
        position = 0
        for score in longer:
            if score == shorter[position]:
                position += 1
                if position == len(shorter):
                    return True
        return False

    has_placeholder = len(observed) != len(screenshot_score)
    has_unfinished_set = any(
        not is_completed_set(score) for score in screenshot_score
        if score not in placeholders
    )
    subsequence = is_subsequence(observed, official_score)
    unfinished_near_official = any(
        not is_completed_set(score)
        and any(
            (
                left == official_left
                or right == official_right
            )
            and abs(left - official_left) <= 1
            and abs(right - official_right) <= 1
            for official_left, official_right in official_score
        )
        for score in screenshot_score
        if score not in placeholders
        for left, right in (score,)
    )

    # Retirement and a visible placeholder are strong evidence that the
    # screenshot is only a fragment.  A single unfinished score such as 5-1
    # is also useful evidence even when it has not reached an official set
    # boundary.
    if has_retirement and (
        subsequence
        or (has_placeholder and bool(observed))
        or (has_unfinished_set and unfinished_near_official)
    ):
        return True
    if has_placeholder and subsequence:
        return True

    # A best-of-five result may be represented by several sets captured from
    # the middle of the match, without a retirement marker.
    return (
        len(official_score) >= 4
        and len(observed) < len(official_score)
        and len(observed) >= 2
        and subsequence
    )


def _dashboard_recent_results(
    profile: dict[str, typing.Any],
    player_name: str,
    period: str = "career",
    as_of: str | None = None,
) -> list[dict[str, typing.Any]]:
    def in_selected_period(result: dict[str, typing.Any]) -> bool:
        if period == "career":
            return True
        try:
            reference = _dt.date.fromisoformat(str(as_of or "")[:10])
        except ValueError:
            reference = _dt.datetime.now(_dt.timezone.utc).date()
        match_date_key = _dashboard_date_key(result.get("date"))
        if match_date_key == (0, 0, 0):
            return False
        match_date = _dt.date(*match_date_key)
        start = {
            "30d": reference - _dt.timedelta(days=29),
            "90d": reference - _dt.timedelta(days=89),
            "year": _dt.date(reference.year, 1, 1),
            "52w": reference - _dt.timedelta(days=363),
        }.get(period)
        return start is not None and start <= match_date <= reference

    profile_recent = profile.get("recent_matches") or []
    if profile_recent:
        official = [
            {
                **match,
                "p1": player_name,
                "p2": match.get("opponent"),
            }
            for match in profile_recent
            if isinstance(match, dict)
        ]
    else:
        official = profile.get("official_results") or []
    normalized_player = normalize_matchlog_name(player_name)
    if official:
        recent = []
        seen: set[tuple[typing.Any, ...]] = set()
        for result in official:
            winner = winner_for_result(result)
            if (
                is_exhibition_tournament(
                    result.get("tournament"),
                    result.get("event_category"),
                )
                or not _dashboard_result_counts_as_played(result)
            ):
                continue
            if not in_selected_period(result):
                continue
            names = {
                normalize_matchlog_name(result.get("p1")),
                normalize_matchlog_name(result.get("p2")),
            }
            if winner is None or normalized_player not in names:
                continue
            result_key = (
                _dashboard_date_key(result.get("date")),
                _dashboard_event_identity(result.get("tournament")),
                _dashboard_pair_key(
                    result.get("p1"),
                    result.get("p2"),
                ),
                _dashboard_score_key(result.get("result")),
            )
            if result_key in seen:
                continue
            seen.add(result_key)
            opponent = (
                result.get("p2")
                if normalize_matchlog_name(result.get("p1")) == normalized_player
                else result.get("p1")
            )
            recent.append({
                "date": result.get("date"),
                "opponent": opponent,
                "result": f"{'W' if winner == normalized_player else 'L'} "
                f"{result.get('result') or ''}".strip(),
                "tournament": result.get("tournament"),
                "round": result.get("round"),
            })
        return sorted(
            recent,
            key=lambda match: _dashboard_date_key(match.get("date")),
            reverse=True,
        )[:5]
    return [
        match
        for match in profile.get("recent_matches") or []
        if _dashboard_score_completed(match.get("result"))
        and in_selected_period(match)
    ][:5]


def _dashboard_upcoming_fixture(
    fixture: dict[str, typing.Any] | None,
) -> str:
    if not fixture:
        return "No matching upcoming fixture found."
    first = str(fixture.get("first_name") or "Player 1")
    second = str(fixture.get("second_name") or "Player 2")
    odds = fixture.get("odds") or []
    odds_text = (
        f" • Odds: **{first} {float(odds[0]):.2f}** | "
        f"**{second} {float(odds[1]):.2f}**"
        if len(odds) >= 2
        else " • Odds unavailable"
    )
    scheduled = str(fixture.get("scheduled_at") or "")
    try:
        scheduled_at = _dt.datetime.fromisoformat(scheduled.replace("Z", "+00:00"))
        if scheduled_at.tzinfo is None:
            scheduled_at = scheduled_at.replace(tzinfo=_dt.timezone.utc)
        when = scheduled_at.astimezone(STATS_TIMEZONE).strftime(
            "%d %b %Y, %H:%M %Z"
        )
    except ValueError:
        when = scheduled or "Time TBC"
    tournament = str(fixture.get("tournament") or "WTSL fixture")
    return f"**{first} vs {second}** • {tournament} • {when}{odds_text}"[:1024]


def _add_dashboard_line_fields(
    embed: discord.Embed,
    name: str,
    lines: list[str],
    *,
    inline: bool = False,
) -> None:
    chunks: list[str] = []
    current: list[str] = []
    for line in lines or ["Not enough data"]:
        candidate = "\n\n".join([*current, line])
        if current and len(candidate) > 1024:
            chunks.append("\n\n".join(current))
            current = [line[:1024]]
        else:
            current.append(line[:1024])
    if current:
        chunks.append("\n\n".join(current))
    for index, chunk in enumerate(chunks):
        embed.add_field(
            name=name if index == 0 else f"{name} (continued)",
            value=chunk,
            inline=inline,
        )


def _add_rating_formula_footnote(
    embed: discord.Embed,
    source: str,
) -> None:
    lines = rating_formula_footnote(source).splitlines()
    labels = {
        "Serve:": "🎾 **Serve Rating**",
        "Return:": "↩️ **Return Rating**",
        "Under Pressure:": "🔥 **Under Pressure**",
    }
    formatted = []
    for line in lines:
        for prefix, heading in labels.items():
            if line.startswith(prefix):
                formatted.append(f"{heading}\n{line[len(prefix):].strip()}")
                break
        else:
            formatted.append(f"_{line}_")
    embed.add_field(
        name="🧮 Rating Formulas",
        value="\n\n".join(formatted)[:1024],
        inline=False,
    )


def _mystats_source_comparison_lines(
    screenshot_summary: dict[str, typing.Any] | None,
    matchlog_summary: dict[str, typing.Any] | None,
) -> list[str]:
    """Render every available value as Screenshots | MatchLog | difference."""
    screenshot_summary = screenshot_summary or {}
    matchlog_summary = matchlog_summary or {}
    screenshot_ratings = dict(screenshot_summary.get("ratings") or [])
    matchlog_ratings = dict(matchlog_summary.get("ratings") or [])
    screenshot_metrics = {
        label: value
        for label, value, _count in screenshot_summary.get("metrics") or []
    }
    matchlog_metrics = {
        label: value
        for label, value, _count in matchlog_summary.get("metrics") or []
    }

    def difference(label: str, first: typing.Any, second: typing.Any) -> str:
        if not isinstance(first, (int, float)) or not isinstance(second, (int, float)):
            return "N/A"
        delta = abs(float(first) - float(second))
        if label.endswith("%"):
            return f"{delta:.1%} pts"
        if "Speed" in label or label == "Fastest Serve":
            return f"{delta:.1f} km/h"
        return f"{delta:.2f}".rstrip("0").rstrip(".")

    lines = ["`Screenshots | MatchLog | Difference`"]
    rating_order = ("Serve Rating", "Return Rating", "Under Pressure")
    for label in rating_order:
        first, second = screenshot_ratings.get(label), matchlog_ratings.get(label)
        if first is None and second is None:
            continue
        lines.append(
            f"**{label}:** "
            f"{_dashboard_stat_value(label, first)} | "
            f"{_dashboard_stat_value(label, second)} | "
            f"Δ {difference(label, first, second)}"
        )
    metric_order = list(dict.fromkeys([
        *(label for label, _value, _count in screenshot_summary.get("metrics") or []),
        *(label for label, _value, _count in matchlog_summary.get("metrics") or []),
    ]))
    for label in metric_order:
        first, second = screenshot_metrics.get(label), matchlog_metrics.get(label)
        lines.append(
            f"**{label}:** "
            f"{_dashboard_stat_value(label, first)} | "
            f"{_dashboard_stat_value(label, second)} | "
            f"Δ {difference(label, first, second)}"
        )
    return lines


def _mystats_character_recommendation_lines(
    recommendations: list[dict[str, typing.Any]],
) -> list[str]:
    def route_phrase(value: typing.Any) -> str:
        text = str(value or "").strip()
        if " is " in text:
            text = text.split(" is ", 1)[1]
        if ": " in text:
            text = text.rsplit(": ", 1)[1]
        return text.rstrip(".")

    def first_sentence(value: typing.Any) -> str:
        text = str(value or "").strip()
        return text.split(". ", 1)[0].rstrip(".")

    lines = []
    for index, recommendation in enumerate(recommendations):
        strength_group = str(recommendation["strength_group"]).title()
        development_group = str(recommendation["development_group"]).title()
        if strength_group == development_group:
            fit = f"fits your {strength_group} profile and training focus"
        else:
            fit = (
                f"amplifies your {strength_group} strength and supports "
                f"{development_group} development"
            )
        edge_details = recommendation.get("edge_details") or []
        edges = ", ".join(
            f"{item['attribute']} {format_character_value(item['value'])}"
            for item in edge_details[:2]
        ) or ", ".join(recommendation["edge_attributes"]) or "overall balance"
        label = "Best overall fit" if index == 0 else "Alternative"
        player_strength = recommendation.get("player_strength_metric") or {}
        player_development = recommendation.get("player_development_metric") or {}
        player_link = []
        if player_strength:
            player_link.append(
                f"**{player_strength.get('metric')}** "
                f"({float(player_strength.get('percentile', 0)):.0f}th percentile)"
            )
        if player_development:
            player_link.append(
                f"**{player_development.get('metric')}** "
                f"({float(player_development.get('percentile', 0)):.0f}th percentile)"
            )
        route = route_phrase(recommendation.get("development_route"))
        tradeoff = first_sentence(recommendation.get("tradeoff"))
        lines.append(
            f"**{recommendation['character']}** — {label}\n"
            f"{fit[0].upper()}{fit[1:]}.\n"
            + (
                f"Your evidence: {'; '.join(player_link)}.\n"
                if player_link else ""
            )
            + f"Edges: **{edges}**."
            + (f" Route: {route}." if route else "")
            + (f" Trade-off: {tradeoff}." if tradeoff else "")
        )
    return lines


MYSTATS_EMBED_SAFE_CHARACTER_LIMIT = 5900
MYSTATS_EMBED_FIELD_LIMIT = 25


def _fit_mystats_embed_to_discord_limit(
    embed: discord.Embed,
) -> discord.Embed:
    """Keep optional dashboard detail from invalidating the entire response."""
    optional_prefixes = (
        "🔍 ",
        "🗓️ Last 5 Official Matches",
        "🖼️ Screenshot Coverage",
        "⏭️ Upcoming Match & Odds",
        "🎭 Character recommendations",
    )
    def exceeds_limit() -> bool:
        return (
            len(embed) > MYSTATS_EMBED_SAFE_CHARACTER_LIMIT
            or len(embed.fields) > MYSTATS_EMBED_FIELD_LIMIT
        )

    for prefix in optional_prefixes:
        if not exceeds_limit():
            break
        for index in range(len(embed.fields) - 1, -1, -1):
            if embed.fields[index].name.startswith(prefix):
                embed.remove_field(index)
                if not exceeds_limit():
                    break
    while len(embed.fields) > MYSTATS_EMBED_FIELD_LIMIT:
        embed.remove_field(len(embed.fields) - 1)
    while len(embed) > MYSTATS_EMBED_SAFE_CHARACTER_LIMIT and embed.fields:
        index = max(
            range(len(embed.fields)),
            key=lambda item: len(embed.fields[item].value),
        )
        field = embed.fields[index]
        overflow = len(embed) - MYSTATS_EMBED_SAFE_CHARACTER_LIMIT
        keep = len(field.value) - overflow - 20
        if keep < 80:
            embed.remove_field(index)
            continue
        value = field.value[:keep].rstrip() + "\n…"
        embed.set_field_at(
            index,
            name=field.name,
            value=value,
            inline=field.inline,
        )
    return embed


def _build_mystats_source_comparison_embeds(
    screenshot_summary: dict[str, typing.Any],
    matchlog_summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
) -> list[discord.Embed]:
    screenshot_summary = _with_official_result_metrics(
        screenshot_summary, profile
    )
    matchlog_summary = _with_official_result_metrics(
        matchlog_summary, profile
    )
    period_label = str(
        screenshot_summary.get("period_label")
        or matchlog_summary.get("period_label")
        or "Career"
    )
    lines = _mystats_source_comparison_lines(
        screenshot_summary,
        matchlog_summary,
    )[1:]
    chunks: list[str] = []
    current: list[str] = []
    for line in lines or ["Not enough comparable data"]:
        candidate = "\n\n".join([*current, line])
        if current and len(candidate) > 950:
            chunks.append("\n\n".join(current))
            current = [line]
        else:
            current.append(line)
    if current:
        chunks.append("\n\n".join(current))
    chunk_pages = [
        chunks[index:index + 5]
        for index in range(0, len(chunks), 5)
    ] or [["Not enough comparable data"]]
    embeds = []
    page_count = len(chunk_pages)
    for page_index, page_chunks in enumerate(chunk_pages, start=1):
        title = f"🔍 {period_label}: Screenshots vs MatchLog"
        if page_count > 1:
            title += f" ({page_index}/{page_count})"
        embed = discord.Embed(
            title=title,
            description=(
                "Private comparison of every statistic available from either "
                "verified source."
            ),
            color=0x3498DB,
        )
        for index, chunk in enumerate(page_chunks):
            embed.add_field(
                name=(
                    "Screenshots | MatchLog | Difference"
                    if index == 0
                    else "Comparison continued"
                ),
                value=chunk[:1024],
                inline=False,
            )
        embed.set_footer(
            text=(
                "Official-result metrics use the same reporting period on both sides"
            )
        )
        embeds.append(embed)
    return embeds


def _build_mystats_dashboard(
    summary: dict[str, typing.Any],
    profile: dict[str, typing.Any],
    insights: dict[str, typing.Any] | None,
    fixture: dict[str, typing.Any] | None = None,
    *,
    screenshot_summary: dict[str, typing.Any] | None = None,
    matchlog_summary: dict[str, typing.Any] | None = None,
    character_recommendations: list[dict[str, typing.Any]] | None = None,
) -> discord.Embed:
    summary = _with_official_result_metrics(summary, profile)
    if screenshot_summary:
        screenshot_summary = _with_official_result_metrics(
            screenshot_summary, profile
        )
    if matchlog_summary:
        matchlog_summary = _with_official_result_metrics(
            matchlog_summary, profile
        )
    tour = str(summary.get("tour") or "").upper()
    source = summary.get("source") or "matchlog"
    source_label = "Screenshot stats" if source == "screenshots" else "MatchLog"
    match_count_label = (
        "verified matches used"
        if source == "screenshots"
        else "verified MatchLog matches"
    )
    period_label = str(summary.get("period_label") or "Career")
    embed = discord.Embed(
        title=f"🎾 {summary['player']} — My WTSL Dashboard",
        description=(
            f"**Source: {source_label}** • Private {tour} performance view • "
            f"**Period: {period_label}** • "
            f"{summary.get('matches', 0)} {match_count_label}"
            + (
                _matchlog_coverage_description(summary, profile)
                if source == "matchlog" else ""
            )
        ),
        color=0x9B59B6 if source == "screenshots" else 0x2ECC71,
    )
    embed.add_field(
        name="🏆 Ranking",
        value=(
            f"#{profile['rank']}"
            if profile.get("rank") is not None else "Not currently available"
        ),
        inline=True,
    )
    embed.add_field(
        name="📈 Weekly movement",
        value=_mystats_movement_text(profile),
        inline=True,
    )
    embed.add_field(
        name="🎯 Tour Elo",
        value=(
            str(profile["wtsl_elo"])
            if profile.get("wtsl_elo") is not None else "Not currently available"
        ),
        inline=True,
    )
    embed.add_field(
        name="Category",
        value=profile.get("category") or f"{tour} Singles",
        inline=True,
    )
    coverage_span = (
        _matchlog_coverage_span_text(summary, profile)
        if source == "matchlog" else None
    )
    if coverage_span:
        embed.add_field(
            name="🗓️ MatchLog Coverage",
            value=coverage_span,
            inline=False,
        )
    career_record = (
        f"{profile['career_wins']}-{profile['career_losses']} "
        + (
            f"({profile['career_win_pct']}%)"
            if profile.get("career_win_pct") is not None else ""
        )
        if profile.get("career_wins") is not None
        and profile.get("career_losses") is not None
        else "Not currently available"
    )
    embed.add_field(name="🗂️ Career record", value=career_record, inline=True)
    embed.add_field(
        name="🎮 Most Picked Characters",
        value=_most_picked_characters_text(summary, profile),
        inline=True,
    )
    ratings = "\n".join(
        f"**{label}:** "
        + (
            f"{value:.2f}".rstrip("0").rstrip(".")
            if isinstance(value, (int, float)) else "N/A"
        )
        for label, value in summary.get("ratings") or []
    ) or "Not enough data"
    embed.add_field(
        name="⚡ WTSL ratings",
        value=ratings[:1024],
        inline=False,
    )
    embed.add_field(
        name="🔥 Recent Form",
        value=str(profile.get("form") or "Not currently available")[:100],
        inline=True,
    )
    embed.add_field(
        name=f"📅 {_dt.datetime.now(_dt.timezone.utc).year} Season Highlights",
        value=_mystats_year_summary(profile),
        inline=True,
    )
    if insights:
        embed.add_field(
            name="✅ Strengths",
            value="\n".join(f"• {item}" for item in insights["strengths"])[:1024],
            inline=False,
        )
        embed.add_field(
            name="🔧 Development areas",
            value="\n".join(f"• {item}" for item in insights["weaknesses"])[:1024],
            inline=False,
        )
        embed.add_field(
            name="🧭 Training focus",
            value=insights["focus"][:1024],
            inline=False,
        )
    else:
        embed.add_field(
            name="Comparative profile",
            value=(
                "Unavailable for this request; verified statistics and rankings "
                "are still shown."
            ),
            inline=False,
        )
    if character_recommendations:
        _add_dashboard_line_fields(
            embed,
            "🎭 Character recommendations",
            _mystats_character_recommendation_lines(
                character_recommendations
            ),
        )
    key_metrics = []
    verified_screenshot_matches = None
    if source == "screenshots" and screenshot_summary:
        verified_screenshot_matches = screenshot_summary.get(
            "_dashboard_verified_matches"
        )
    for label, value, count in summary.get("metrics") or []:
        if not isinstance(value, (int, float)):
            continue
        shown = (
            f"{value:.1%}"
            if label.endswith("%")
            else f"{value:.1f} km/h"
            if "Speed" in label or label == "Fastest Serve"
            else f"{value:.2f}".rstrip("0").rstrip(".")
        )
        matches_used = int(count or 0)
        if isinstance(verified_screenshot_matches, int):
            matches_used = min(matches_used, verified_screenshot_matches)
        key_metrics.append(
            f"**{label}:** {shown} ({matches_used} matches used)"
        )
    _add_dashboard_line_fields(
        embed,
        f"📊 {period_label} Stats",
        key_metrics,
    )
    recent = _dashboard_recent_results(
        profile,
        summary["player"],
        str(summary.get("period") or "career"),
        summary.get("as_of"),
    )
    if recent:
        embed.add_field(
            name="🗓️ Last 5 Official Matches",
            value="\n".join(
                f"• {str(match.get('date') or match.get('match_datetime') or '?')[:10]}"
                f" vs {str(match.get('opponent') or '?')[:20]} — "
                f"{str(match.get('result') or 'No score')[:25]}"
                for match in recent
            )[:1024],
            inline=False,
        )
    embed.add_field(
        name="⏭️ Upcoming Match & Odds",
        value=_dashboard_upcoming_fixture(fixture),
        inline=False,
    )
    _add_rating_formula_footnote(embed, source)
    if screenshot_summary:
        _add_dashboard_line_fields(
            embed,
            "🖼️ Screenshot Coverage",
            _screenshot_coverage_lines(screenshot_summary, profile),
        )
    embed.set_footer(
        text=(
            f"Source: {'Screenshots' if source == 'screenshots' else 'MatchLog'} "
            "• Official WTSL profile and recent matches • Speeds use km/h"
        )
    )
    return _fit_mystats_embed_to_discord_limit(embed)


WTSL_VERIFICATION_CHANNEL_ID = 1466606299079774461
WTSL_VERIFICATION_PANEL_TITLE = "🔐 Request WTSL Player Verification"
WTSL_VERIFICATION_BUTTON_CUSTOM_ID = "wtsl_identity:request:v1"
WTSL_VERIFICATION_PANEL_KEY = "wtsl_verification_request_panel"
_wtsl_verification_panel_lock = asyncio.Lock()


async def _submit_wtsl_verification_request(
    interaction: discord.Interaction,
    tour_text: str,
    player_text: str,
) -> None:
    await interaction.response.defer(ephemeral=True, thinking=True)
    tour = normalize_matchlog_name(tour_text)
    requested = player_text.strip()
    if tour not in {"atp", "wta"}:
        await interaction.followup.send(
            "Enter either **ATP** or **WTA** for the tour.",
            ephemeral=True,
        )
        return
    if not requested:
        await interaction.followup.send(
            "Enter your exact WTSL player name.",
            ephemeral=True,
        )
        return
    try:
        reserved = await asyncio.to_thread(
            reserve_verification_request,
            interaction.user.id,
            300,
        )
    except Exception as exc:
        print(
            f"[WTSL Verification] Cooldown store unavailable: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        await interaction.followup.send(
            "Your verification request could not be recorded safely right now. "
            "Please try again later.",
            ephemeral=True,
        )
        return
    if not reserved:
        await interaction.followup.send(
            "Your verification request was already sent recently. "
            "Please wait a few minutes before trying again.",
            ephemeral=True,
        )
        return
    try:
        rankings = await asyncio.wait_for(_get_stats_rankings(), timeout=30)
        canonical = rankings.get(tour, {}).get(normalize_matchlog_name(requested))
        if not canonical:
            await asyncio.to_thread(
                release_verification_request,
                interaction.user.id,
            )
            await interaction.followup.send(
                f"I couldn't find **{requested}** in the WTSL {tour.upper()} "
                "player records. Check the spelling and try again.",
                ephemeral=True,
            )
            return
        links = _matchlog_links(interaction.user.id)
        if normalize_matchlog_name(links.get(tour)) == normalize_matchlog_name(
            canonical
        ):
            await asyncio.to_thread(
                release_verification_request,
                interaction.user.id,
            )
            await interaction.followup.send(
                f"You are already verified as **{tour.upper()}: {canonical}**.",
                ephemeral=True,
            )
            return
        owner = await client.fetch_user(OWNER_ID)
        current_link = (
            f"\nCurrent verified identities: {_matchlog_identity_label(links)}"
            if links else ""
        )
        await owner.send(
            f"<@{OWNER_ID}> 🔐 **WTSL player verification requested**\n"
            f"Discord member: {interaction.user.mention} "
            f"(`{interaction.user.id}`)\n"
            f"Requested identity: **{tour.upper()}: {canonical}**"
            f"{current_link}\n\n"
            "After confirming the identity, run `/linkmatchlogplayer`, select "
            "this Discord member, and enter "
            f"`{tour.upper()}: {canonical}`.",
            allowed_mentions=discord.AllowedMentions(
                everyone=False,
                roles=False,
                users=True,
            ),
        )
        await interaction.followup.send(
            f"Your request for **{tour.upper()}: {canonical}** was sent privately "
            "to the verification admin. You will receive a DM after it is approved.",
            ephemeral=True,
        )
    except asyncio.TimeoutError:
        await asyncio.to_thread(
            release_verification_request,
            interaction.user.id,
        )
        await interaction.followup.send(
            "The WTSL player list took too long to load. Please try again shortly.",
            ephemeral=True,
        )
    except Exception as exc:
        try:
            await asyncio.to_thread(
                release_verification_request,
                interaction.user.id,
            )
        except Exception as release_exc:
            print(
                f"[WTSL Verification] Cooldown release failed: "
                f"{type(release_exc).__name__}: {release_exc}",
                flush=True,
            )
        print(
            f"[WTSL Verification] Request failed: {type(exc).__name__}: {exc}",
            flush=True,
        )
        await interaction.followup.send(
            "Your verification request could not be sent right now. "
            "Please try again later.",
            ephemeral=True,
        )


class WTSLVerificationRequestModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(
            title="Request WTSL Verification",
            custom_id="wtsl_identity:request_modal:v1",
        )
        self.tour = discord.ui.TextInput(
            label="Tour",
            placeholder="ATP or WTA",
            min_length=3,
            max_length=3,
            required=True,
        )
        self.player_name = discord.ui.TextInput(
            label="Exact WTSL player name",
            placeholder="Enter your name exactly as shown on WTSL",
            min_length=2,
            max_length=100,
            required=True,
        )
        self.add_item(self.tour)
        self.add_item(self.player_name)

    async def on_submit(self, interaction: discord.Interaction):
        await _submit_wtsl_verification_request(
            interaction,
            str(self.tour.value),
            str(self.player_name.value),
        )


class WTSLVerificationRequestView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Request WTSL Verification",
        style=discord.ButtonStyle.primary,
        emoji="🔐",
        custom_id=WTSL_VERIFICATION_BUTTON_CUSTOM_ID,
    )
    async def request_verification(
        self,
        interaction: discord.Interaction,
        _button: discord.ui.Button,
    ):
        await interaction.response.send_modal(WTSLVerificationRequestModal())


class PredictionLinkRequestModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(
            title="Link Challonge Account",
            custom_id="wtsl_prediction_identity:request_modal:v1",
        )
        self.challonge_name = discord.ui.TextInput(
            label="Challonge username or prediction name",
            placeholder="Enter it exactly as shown on the leaderboard",
            min_length=2,
            max_length=100,
            required=True,
        )
        self.add_item(self.challonge_name)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            request_id = await asyncio.to_thread(
                create_prediction_link_request,
                interaction.user.id,
                str(self.challonge_name.value),
            )
            await interaction.response.send_message(
                f"Your Challonge link request is **#{request_id}**. "
                "An administrator will review it before linking your Discord account.",
                ephemeral=True,
            )
        except Exception as exc:
            await interaction.response.send_message(
                f"The Challonge link request could not be saved: {str(exc)[:800]}",
                ephemeral=True,
            )


class PredictionLinkRequestView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Link my Challonge account",
        style=discord.ButtonStyle.primary,
        emoji="🔗",
        custom_id="wtsl_prediction_identity:request_button:v1",
    )
    async def request_prediction_link(
        self,
        interaction: discord.Interaction,
        _button: discord.ui.Button,
    ):
        await interaction.response.send_modal(PredictionLinkRequestModal())


def _build_wtsl_verification_panel() -> discord.Embed:
    embed = discord.Embed(
        title=WTSL_VERIFICATION_PANEL_TITLE,
        description=(
            "Link your Discord account to your WTSL player identity so you can "
            "access player-specific WTSL features across the server, including "
            "private statistics, match scheduling, and other actions that "
            "require a verified player identity.\n\n"
            "**How it works**\n"
            "1. Select the button below.\n"
            "2. Enter ATP or WTA and your exact WTSL player name.\n"
            "3. An admin verifies the request and links your account.\n"
            "4. The bot sends you a DM when verification is complete, and "
            "your linked identity unlocks the supported WTSL features."
        ),
        color=0x5865F2,
    )
    embed.set_footer(
        text="Requests are reviewed manually. Submitting does not verify an account automatically."
    )
    return embed


async def _upsert_wtsl_verification_panel() -> None:
    await client.wait_until_ready()
    async with _wtsl_verification_panel_lock:
        try:
            channel = client.get_channel(WTSL_VERIFICATION_CHANNEL_ID)
            if channel is None:
                channel = await client.fetch_channel(WTSL_VERIFICATION_CHANNEL_ID)
            existing = None
            stored = await asyncio.to_thread(
                load_bot_message,
                WTSL_VERIFICATION_PANEL_KEY,
            )
            if stored and stored[0] == WTSL_VERIFICATION_CHANNEL_ID:
                try:
                    existing = await channel.fetch_message(stored[1])
                except discord.NotFound:
                    existing = None
            bot_user_id = getattr(getattr(client, "user", None), "id", None)
            duplicates = []
            async for message in channel.history(limit=None):
                if (
                    bot_user_id is not None
                    and getattr(message.author, "id", None) != bot_user_id
                ):
                    continue
                if not any(
                    embed.title == WTSL_VERIFICATION_PANEL_TITLE
                    for embed in getattr(message, "embeds", [])
                ):
                    continue
                if existing is None:
                    existing = message
                elif message.id != existing.id:
                    duplicates.append(message)
            embed = _build_wtsl_verification_panel()
            view = WTSLVerificationRequestView()
            if existing is None:
                existing = await channel.send(embed=embed, view=view)
                print("[WTSL Verification] Request panel posted", flush=True)
            else:
                await existing.edit(embed=embed, view=view)
                print("[WTSL Verification] Request panel updated", flush=True)
            await asyncio.to_thread(
                save_bot_message,
                WTSL_VERIFICATION_PANEL_KEY,
                WTSL_VERIFICATION_CHANNEL_ID,
                existing.id,
            )
            for duplicate in duplicates:
                try:
                    await duplicate.delete()
                    print(
                        f"[WTSL Verification] Removed duplicate panel "
                        f"{duplicate.id}",
                        flush=True,
                    )
                except Exception as duplicate_exc:
                    print(
                        f"[WTSL Verification] Could not remove duplicate panel "
                        f"{duplicate.id}: {duplicate_exc}",
                        flush=True,
                    )
        except Exception as exc:
            print(
                f"[WTSL Verification] Panel update failed: "
                f"{type(exc).__name__}: {exc}",
                flush=True,
            )


WTSL_BETTING_GUILD_ID = 786583939028090881
# This is the existing fixtures channel. Do not create or migrate betting
# messages to another channel when the guild cache or stored layout is cold.
WTSL_BETTING_CHANNEL_ID = 1550152646638174308
WTSL_BETTING_CHANNEL_NAME = "fixtures"
WTSL_BETTING_FIXTURE_MESSAGE_PREFIX = "wtsl_betting_fixtures:"
WTSL_BETTING_CONTROL_MESSAGE_PREFIX = "wtsl_betting_controls:"
WTSL_BETTING_ACTION_MESSAGE_KEY = "wtsl_betting_actions"
WTSL_BETTING_LEADERBOARD_MESSAGE_KEY = "wtsl_betting_leaderboard"
WTSL_BETTING_RESULTS_MESSAGE_KEY = "wtsl_betting_results"
WTSL_BETTING_LAYOUT_MESSAGE_KEY = "wtsl_betting_layout_v2"
WTSL_BETTING_WEEKLY_MESSAGE_KEY = "wtsl_betting_weekly_earner"
WTSL_BETTING_REFRESH_SECONDS = 5 * 60
WTSL_REFERRAL_REMINDER_SECONDS = 5 * 60
WTSL_BETTING_LEDGER_PAGE_SIZE = 8
WTSL_BETTING_TITLE = "Upcoming Fixtures & Odds"
WTSL_BETTING_LEGACY_PAGE_PREFIX = "🎾 WTSL Fixtures & Odds • Page "
WTSL_BETTING_RESULTS_TITLE = "✅ Completed Matches"
WTSL_BETTING_LEADERBOARD_TITLE = "🏆 Earnings Leaderboard"
WTSL_BETTING_LEGACY_RESULTS_TITLE = "✅ Recent WTSL Results"
WTSL_BETTING_LEGACY_LEADERBOARD_TITLE = "🏆 WTSL Dollar Earnings Leaderboard"
WTSL_BETTING_SUMMARY_TITLES = {
    WTSL_BETTING_RESULTS_TITLE,
    WTSL_BETTING_LEADERBOARD_TITLE,
    WTSL_BETTING_LEGACY_RESULTS_TITLE,
    WTSL_BETTING_LEGACY_LEADERBOARD_TITLE,
}
WTSL_BETTING_WEEKLY_LEGACY_TITLE = "🎉 Weekly Betting Congratulations"
WTSL_BETTING_FOOTER = (
    "Virtual WTSL Currency • 5% house vig • "
    "Pool settlement with guaranteed minimum returns"
)
WTSL_BETTING_DESCRIPTION = (
    "Choose a player to place a bet in Virtual WTSL Currency.\n"
    "**Settlement:** if at least one bet backs the official winner, "
    "winner-side bets win and bets on the other player lose. If no "
    "bet backs the official winner, every bet on that fixture is "
    "refunded and the full stake is returned."
)
WTSL_DEFAULT_AVATAR_URL = (
    "https://playwtsl.com/files/img/avatars/wtsl_default_player_avatar.svg"
)
_betting_fixture_tokens: dict[str, str] = {}
_betting_fixtures_by_token: dict[str, dict[str, typing.Any]] = {}
_betting_channel_lock = asyncio.Lock()
_betting_target_refresh_lock = asyncio.Lock()
_betting_message_update_lock = asyncio.Lock()
_wtsl_weekly_message_lock = asyncio.Lock()
_wtsl_completed_draw_matches: list[dict[str, typing.Any]] = []
_wtsl_tournament_page_results: list[dict[str, typing.Any]] = []


def _wtsl_dollars(value: typing.Any) -> str:
    amount = Decimal(str(value or 0)).quantize(Decimal("0.01"))
    return f"W${amount:,.2f}"


def _wtsl_odds(value: typing.Any) -> str:
    """Format stored odds as decimal odds for the Discord betting UI."""
    return _wtsl_decimal_odds(value)


def _wtsl_decimal_odds(value: typing.Any) -> str:
    return f"{Decimal(str(value)).quantize(Decimal('0.01')):.2f}"


def _wtsl_pool_decimal_odds(
    fixture: dict[str, typing.Any],
    side: str,
) -> Decimal | None:
    total = Decimal(str(fixture.get("pool_total") or 0))
    side_pool = Decimal(str(fixture.get(f"pool_{side}") or 0))
    if total <= 0 or side_pool <= 0:
        return None
    return pool_decimal_odds(total, side_pool)


def _wtsl_guaranteed_decimal_odds(
    fixture: dict[str, typing.Any],
    side: str,
    official_odds: typing.Any,
) -> Decimal:
    return hybrid_guaranteed_odds(
        Decimal(str(official_odds)),
        _wtsl_pool_decimal_odds(fixture, side),
    )


def _wtsl_house_odds_label(
    fixture: dict[str, typing.Any],
    side: str,
    official_odds: typing.Any,
) -> str:
    return _wtsl_odds(
        _wtsl_guaranteed_decimal_odds(fixture, side, official_odds)
    )


def _wtsl_pool_return_label(
    fixture: dict[str, typing.Any],
    side: str,
    official_odds: typing.Any,
) -> str:
    """Show the current guaranteed minimum return for a W$100 stake."""
    odds = _wtsl_guaranteed_decimal_odds(fixture, side, official_odds)
    return _wtsl_dollars(Decimal("100.00") * odds)


def _wtsl_pool_odds_label(
    fixture: dict[str, typing.Any],
    side: str,
    official_odds: typing.Any | None = None,
) -> str:
    """Show the live pool quote, falling back to the official WTSL odds."""
    odds = _wtsl_pool_decimal_odds(fixture, side)
    if odds is not None:
        return _wtsl_odds(odds)
    if official_odds is not None:
        return _wtsl_odds(official_odds)
    return "—"


def _wtsl_parlay_decimal_odds(value: typing.Any) -> Decimal:
    return (
        Decimal(str(value)) / (Decimal("1") + POOL_TAKEOUT)
    ).quantize(Decimal("0.001"))


def _wtsl_display_avatar(value: typing.Any) -> str:
    """Return an official avatar URL, falling back to WTSL's stock avatar."""
    text = str(value or "").strip()
    return text if text.startswith(("http://", "https://")) else WTSL_DEFAULT_AVATAR_URL


def _betting_fixture_token(fixture_key: str) -> str:
    return hashlib.sha256(fixture_key.encode("utf8")).hexdigest()[:16]


def _wtsl_betting_fixture_page_title(page_number: int) -> str | None:
    """Give the fixture collection one heading instead of numbered headings."""
    return WTSL_BETTING_TITLE if page_number == 1 else None


PREDICTION_LEADERBOARD_CHANNEL_ID = 1550826588415860806
PREDICTION_LEADERBOARD_MESSAGE_KEY = "wtsl_prediction_leaderboard"
PREDICTION_LEADERBOARD_REFRESH_SECONDS = 15 * 60
PREDICTION_DISPLAY_NAME_ALIASES = {
    "squeaky94": "Squeaky",
}
PREDICTION_IDENTITY_MATCHLOG_ALIASES = {
    "squeaky94": "squeaky",
}
# Historical IDs are fetched with a concurrency limiter below. Process the
# whole discoverable archive in one refresh so production does not expose a
# partial leaderboard for multiple 15-minute cycles.
PREDICTION_HISTORY_BATCH_SIZE = 1000
PREDICTION_HISTORY_SEED_TOURNAMENTS = (
    {
        "id": "Australian_Open_2026_TE4",
        "name": "Australian Open 2026",
        "tour": "TE4",
    },
    {
        "id": "Roland_Garros_2026_TE4",
        "name": "Roland-Garros 2026",
        "tour": "TE4",
    },
    {
        "id": "Wimbledon_2026_TE4",
        "name": "Wimbledon 2026",
        "tour": "TE4",
    },
    {
        "id": "US_Open_2026_TE4",
        "name": "US Open 2026",
        "tour": "TE4",
    },
    {
        "id": "Australian_Open_2026_TE4_F",
        "name": "Australian Open 2026",
        "tour": "TE4_(F)",
    },
    {
        "id": "Roland_Garros_2026_TE4_F",
        "name": "Roland-Garros 2026",
        "tour": "TE4_(F)",
    },
    {
        "id": "Wimbledon_2026_TE4_F",
        "name": "Wimbledon 2026",
        "tour": "TE4_(F)",
    },
    {
        "id": "US_Open_2026_TE4_F",
        "name": "US Open 2026",
        "tour": "TE4_(F)",
    },
)
_prediction_leaderboard_lock = asyncio.Lock()


def _reconcile_prediction_identity_aliases() -> int:
    """Keep approved prediction aliases aligned with verified MatchLog identities."""
    identities = load_matchlog_identities()
    repaired = 0
    for prediction_name, matchlog_name in PREDICTION_IDENTITY_MATCHLOG_ALIASES.items():
        candidates = [
            user_id
            for user_id, links in identities.items()
            if any(
                normalize_matchlog_name(value) == normalize_matchlog_name(matchlog_name)
                for value in links.values()
            )
        ]
        if len(candidates) != 1:
            continue
        before = load_prediction_identity_links()
        current_id = next(
            (
                discord_user_id
                for discord_user_id in before.values()
                if int(discord_user_id) == int(candidates[0])
            ),
            None,
        )
        relink_prediction_identity(
            candidates[0],
            prediction_name,
            OWNER_ID,
        )
        if current_id is None:
            repaired += 1
    return repaired


def _prediction_leaderboard_name(row: dict[str, typing.Any]) -> str:
    discord_user_id = row.get("discord_user_id")
    challonge_username = str(
        row.get("challonge_username")
        or row.get("prediction_name")
        or "Unknown predictor"
    )
    display_name = PREDICTION_DISPLAY_NAME_ALIASES.get(
        challonge_username.casefold()
    )
    if display_name:
        if discord_user_id:
            return f"<@{int(discord_user_id)}> (`{challonge_username}`)"
        return f"**{display_name}** (`{challonge_username}`)"
    if discord_user_id:
        return f"<@{int(discord_user_id)}> (`{challonge_username}`)"
    return f"`{challonge_username}`"


def _prediction_discord_avatar_url(discord_user_id: typing.Any) -> str | None:
    """Use a cached Discord avatar when the linked member is available."""
    try:
        user_id = int(discord_user_id or 0)
    except (TypeError, ValueError):
        return None
    if not user_id:
        return None
    user = client.get_user(user_id)
    if user is None:
        guild = client.get_guild(WTSL_BETTING_GUILD_ID)
        user = guild.get_member(user_id) if guild is not None else None
    avatar = getattr(user, "display_avatar", None)
    url = getattr(avatar, "url", None)
    return str(url) if url else None


def _build_prediction_leaderboard_embed(
    rows: list[dict[str, typing.Any]],
    *,
    ongoing_tournaments: int,
    fetched_entries: int,
) -> discord.Embed:
    embed = discord.Embed(
        title="🏆 WTSL Prediction Leaderboard",
        color=0xD4AF37,
    )
    history_total = int(getattr(client, "_prediction_history_total", 0) or 0)
    history_scanned = int(getattr(client, "_prediction_history_scanned", 0) or 0)
    history_status = (
        f"Discoverable archive: {history_scanned}/{history_total} scanned"
        if history_total
        else "Discoverable archive: scan starting"
    )
    if rows:
        medals = ["🥇", "🥈", "🥉"]
        lines = []
        for index, row in enumerate(rows[:25], 1):
            medal = medals[index - 1] if index <= len(medals) else f"**{index}.**"
            total_picks = int(row.get("total_picks") or 0)
            total_picks_potential = int(row.get("total_picks_potential") or 0)
            pick_percentage = (
                total_picks / total_picks_potential * 100
                if total_picks_potential
                else 0.0
            )
            lines.append(
                f"{medal} {_prediction_leaderboard_name(row)} — "
                f"**{int(row.get('total_score') or 0)} pts** • "
                f"{total_picks}/{total_picks_potential} correct picks "
                f"({pick_percentage:.1f}%) • "
                f"{int(row.get('tournaments') or 0)} tournaments • "
                f"{int(row.get('tournaments_won') or 0)} won • "
                f"{float(row.get('average_score') or 0):.1f} avg"
            )
        for chunk_index in range(0, len(lines), 7):
            embed.add_field(
                name="\u200b",
                value="\n".join(lines[chunk_index : chunk_index + 7]),
                inline=False,
            )
    else:
        embed.add_field(
            name="\u200b",
            value="No prediction standings have been fetched yet.",
            inline=False,
        )
    avatar_url = next(
        (
            str(row.get("avatar_url"))
            for row in rows
            if row.get("avatar_url")
        ),
        None,
    )
    if avatar_url:
        # Discord supports one embed-level avatar, not an icon per text line.
        embed.set_thumbnail(url=avatar_url)
    embed.set_footer(
        text=(
            f"Scanning {ongoing_tournaments} ongoing tournament(s) • "
            f"{fetched_entries} prediction row(s) fetched this refresh • "
            f"{history_status} • "
            f"Updates every {PREDICTION_LEADERBOARD_REFRESH_SECONDS // 60} minutes"
        )
    )
    return embed


async def _fetch_prediction_entries() -> tuple[int, int]:
    """Fetch current modules plus every tournament exposed by the archive."""
    async def discover_historical() -> tuple[list[dict[str, str]], bool]:
        schedules: list[list[dict[str, typing.Any]]] = []
        discovery_failed = False
        current_year = datetime.now(timezone.utc).year

        async def load_schedule(
            year: int,
            tour: str,
        ) -> list[dict[str, typing.Any]]:
            nonlocal discovery_failed
            if (
                tour == "wta"
                and year < 2025
                and not Path(f"wtsl_tournaments_cache_{tour}_{year}.json").exists()
            ):
                return []
            try:
                return await get_tournament_schedule(
                    year=year,
                    tour=tour,
                    allow_stale=True,
                )
            except Exception as exc:
                discovery_failed = True
                print(
                    f"[Prediction leaderboard] historical schedule unavailable "
                    f"for {tour} {year}: {type(exc).__name__}: {exc}",
                    flush=True,
                )
                return []

        schedule_results = await asyncio.gather(
            *(
                load_schedule(year, tour)
                for year in range(2022, current_year + 1)
                for tour in ("atp", "wta")
            )
        )
        schedules.extend(schedule_results)

        found: dict[str, dict[str, str]] = {}
        for schedule in schedules:
            for row in schedule:
                source_url = str(row.get("source_url") or "")
                tournament_id = (
                    parse_qs(urlparse(source_url).query).get("tournament") or [""]
                )[0].strip()
                if not tournament_id:
                    continue
                is_wta = (
                    str(row.get("tour") or "").casefold() == "wta"
                    or re.search(r"_F(?:_|$)", tournament_id, re.IGNORECASE)
                )
                found.setdefault(
                    tournament_id,
                    {
                        "id": tournament_id,
                        "name": str(row.get("tournament") or tournament_id),
                        "tour": "TE4_(F)" if is_wta else "TE4",
                    },
                )
        ordered = [dict(tournament) for tournament in PREDICTION_HISTORY_SEED_TOURNAMENTS]
        seed_ids = {str(tournament["id"]) for tournament in ordered}
        ordered.extend(
            tournament
            for tournament_id, tournament in found.items()
            if tournament_id not in seed_ids
        )
        print(
            f"[Prediction leaderboard] discovered {len(ordered)} tournament "
            "ID(s) exposed by WTSL schedules",
            flush=True,
        )
        return ordered, discovery_failed

    tournaments: list[dict[str, str]] = []
    seen_ids: set[str] = set()
    historical_tournaments, history_discovery_failed = await discover_historical()
    successful_scan_ids = await asyncio.to_thread(
        load_successful_prediction_scan_ids
    )
    timeout = aiohttp.ClientTimeout(total=45)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        for tournaments_url, tour in (
            (ONGOING_TOURNAMENTS_URL, "TE4"),
            (ONGOING_TOURNAMENTS_WTA_URL, "TE4_(F)"),
        ):
            try:
                async with session.get(tournaments_url) as response:
                    response.raise_for_status()
                    page_tournaments = parse_ongoing_tournaments(
                        await response.text(),
                        tour=tour,
                    )
            except Exception as exc:
                print(
                    f"[Prediction leaderboard] tournament list unavailable for "
                    f"{tour}: {type(exc).__name__}: {exc}",
                    flush=True,
                )
                continue
            for tournament in page_tournaments:
                tournament_id = str(tournament.get("id") or "").strip()
                if tournament_id and tournament_id not in seen_ids:
                    seen_ids.add(tournament_id)
                    tournaments.append(tournament)
        ongoing_count = len(tournaments)
        historical_ids = {str(tournament["id"]) for tournament in historical_tournaments}
        pending_historical = [
            tournament
            for tournament in historical_tournaments
            if str(tournament["id"]) not in successful_scan_ids
        ][:PREDICTION_HISTORY_BATCH_SIZE]
        pending_historical_ids = {
            str(tournament["id"]) for tournament in pending_historical
        }
        for tournament in historical_tournaments:
            tournament_id = str(tournament["id"])
            if (
                tournament_id not in seen_ids
                and tournament_id in pending_historical_ids
            ):
                seen_ids.add(tournament_id)
                tournaments.append(tournament)
        scan_records: list[dict[str, typing.Any]] = []
        request_limiter = asyncio.Semaphore(4)
        print(
            f"[Prediction leaderboard] fetching {len(tournaments)} module(s): "
            f"{ongoing_count} ongoing and {len(pending_historical_ids)} "
            "historical in this batch",
            flush=True,
        )

        async def fetch_one(
            tournament: dict[str, str],
        ) -> tuple[list[dict[str, typing.Any]], dict[str, typing.Any]]:
            tournament_id = str(tournament["id"])
            try:
                async with request_limiter:
                    async with session.get(
                        prediction_module_url(tournament_id)
                    ) as response:
                        response.raise_for_status()
                        parsed = parse_prediction_module(
                            await response.text(),
                            tournament_id,
                            str(tournament.get("name") or tournament_id),
                            str(tournament.get("tour") or "TE4"),
                        )
                return parsed, {
                    "tournament_id": tournament_id,
                    "tournament_name": tournament.get("name"),
                    "tour": tournament.get("tour"),
                    "rows_fetched": len(parsed),
                }
            except Exception as exc:
                if isinstance(exc, aiohttp.ClientResponseError) and exc.status == 404:
                    print(
                        f"[Prediction leaderboard] no prediction module for "
                        f"{tournament_id}; recording empty history",
                        flush=True,
                    )
                    return [], {
                        "tournament_id": tournament_id,
                        "tournament_name": tournament.get("name"),
                        "tour": tournament.get("tour"),
                        "rows_fetched": 0,
                    }
                print(
                    f"[Prediction leaderboard] predictions unavailable for "
                    f"{tournament_id}: {type(exc).__name__}: {exc}",
                    flush=True,
                )
                return [], {"tournament_id": tournament_id, "failed": True}

        result_sets = await asyncio.gather(
            *(fetch_one(tournament) for tournament in tournaments)
        )

    entries = [entry for result, _ in result_sets for entry in result]
    scan_records = [
        record
        for _, record in result_sets
        if not record.get("failed")
    ]
    if entries:
        await asyncio.to_thread(upsert_prediction_entries, entries)
    if scan_records:
        await asyncio.to_thread(record_prediction_tournament_scans, scan_records)
    successful_scan_ids.update(
        str(record["tournament_id"]) for record in scan_records
    )
    client._prediction_history_total = len(historical_ids)
    client._prediction_history_scanned = len(
        historical_ids.intersection(successful_scan_ids)
    )
    if (
        historical_ids
        and not history_discovery_failed
        and historical_ids.issubset(successful_scan_ids)
        and not getattr(client, "_prediction_history_backfilled", False)
    ):
        client._prediction_history_backfilled = True
        print(
            f"[Prediction leaderboard] historical backfill complete across "
            f"{len(historical_ids)} discoverable tournament(s), with {len(entries)} "
            "prediction row(s) fetched this pass",
            flush=True,
        )
    elif historical_ids and not history_discovery_failed:
        print(
            f"[Prediction leaderboard] historical backfill progress: "
            f"{len(successful_scan_ids)}/{len(historical_ids)} tournament(s) "
            "scanned successfully",
            flush=True,
        )

    guild = client.get_guild(WTSL_BETTING_GUILD_ID)
    if guild is not None and guild.members:
        members = [
            {
                "id": member.id,
                "names": [
                    value
                    for value in (
                        getattr(member, "name", None),
                        getattr(member, "global_name", None),
                        getattr(member, "display_name", None),
                    )
                    if value
                ],
            }
            for member in guild.members
            if not getattr(member, "bot", False)
        ]
        try:
            auto_linked = await asyncio.to_thread(
                auto_link_prediction_identities,
                members,
            )
            if auto_linked:
                print(
                    f"[Prediction leaderboard] auto-linked {auto_linked} "
                    "exact Discord/Challonge identity match(es)",
                    flush=True,
                )
        except Exception as exc:
            print(
                f"[Prediction leaderboard] identity auto-link unavailable: "
                f"{type(exc).__name__}: {exc}",
                flush=True,
            )

    try:
        repaired_aliases = await asyncio.to_thread(
            _reconcile_prediction_identity_aliases
        )
        if repaired_aliases:
            print(
                f"[Prediction leaderboard] reconciled {repaired_aliases} "
                "verified prediction identity alias(es)",
                flush=True,
            )
    except Exception as exc:
        print(
            f"[Prediction leaderboard] canonical identity reconciliation unavailable: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )

    return ongoing_count, len(entries)


async def _refresh_prediction_leaderboard() -> None:
    async with _prediction_leaderboard_lock:
        ongoing_tournaments, fetched_entries = await _fetch_prediction_entries()
        rows = await asyncio.to_thread(load_prediction_leaderboard, 25)
        for row in rows:
            avatar_url = _prediction_discord_avatar_url(row.get("discord_user_id"))
            if avatar_url:
                row["avatar_url"] = avatar_url
        embed = _build_prediction_leaderboard_embed(
            rows,
            ongoing_tournaments=ongoing_tournaments,
            fetched_entries=fetched_entries,
        )
        channel = client.get_channel(PREDICTION_LEADERBOARD_CHANNEL_ID)
        if channel is None:
            channel = await client.fetch_channel(PREDICTION_LEADERBOARD_CHANNEL_ID)
        stored = await asyncio.to_thread(
            load_bot_message,
            PREDICTION_LEADERBOARD_MESSAGE_KEY,
        )
        message = None
        if stored and stored[0] == PREDICTION_LEADERBOARD_CHANNEL_ID:
            try:
                message = await channel.fetch_message(stored[1])
            except discord.NotFound:
                message = None
        if message is None:
            async for candidate in channel.history(limit=100):
                if (
                    getattr(getattr(candidate, "author", None), "id", None)
                    == getattr(client.user, "id", None)
                    and any(
                        getattr(candidate_embed, "title", None)
                        == "🏆 WTSL Prediction Leaderboard"
                        for candidate_embed in getattr(candidate, "embeds", [])
                    )
                ):
                    message = candidate
                    break
        if message is None:
            message = await channel.send(
                embed=embed,
                view=PredictionLinkRequestView(),
                allowed_mentions=discord.AllowedMentions.none(),
            )
        else:
            await message.edit(embed=embed, view=PredictionLinkRequestView())
        await asyncio.to_thread(
            save_bot_message,
            PREDICTION_LEADERBOARD_MESSAGE_KEY,
            PREDICTION_LEADERBOARD_CHANNEL_ID,
            message.id,
        )
        print(
            f"[Prediction leaderboard] updated {len(rows)} user(s) from "
            f"{ongoing_tournaments} ongoing tournament(s)",
            flush=True,
        )


async def _prediction_leaderboard_loop() -> None:
    await client.wait_until_ready()
    await asyncio.sleep(20)
    while not client.is_closed():
        try:
            await _refresh_prediction_leaderboard()
        except Exception as exc:
            print(
                f"[Prediction leaderboard] refresh failed: "
                f"{type(exc).__name__}: {exc}",
                flush=True,
            )
        await asyncio.sleep(PREDICTION_LEADERBOARD_REFRESH_SECONDS)


def _prediction_admin_allowed(interaction: discord.Interaction) -> bool:
    if interaction.user.id == OWNER_ID:
        return True
    if getattr(getattr(interaction.user, "guild_permissions", None), "administrator", False):
        return True
    return any(
        getattr(role, "id", None) == ADMIN_ROLE_ID
        for role in getattr(interaction.user, "roles", [])
    )


@client.tree.command(
    name="linkprediction",
    description="Request a link between your Discord and Challonge prediction identity",
)
@app_commands.describe(
    challonge_name="Your exact Challonge username or prediction name",
)
async def linkprediction(interaction: discord.Interaction, challonge_name: str):
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        request_id = await asyncio.to_thread(
            create_prediction_link_request,
            interaction.user.id,
            challonge_name,
        )
        await interaction.followup.send(
            f"Your prediction identity request is **#{request_id}**. "
            "An administrator will review it before linking your Discord account.",
            ephemeral=True,
        )
    except Exception as exc:
        await interaction.followup.send(
            f"The prediction identity request could not be saved: {str(exc)[:800]}",
            ephemeral=True,
        )


@client.tree.command(
    name="predictionrequests",
    description="List pending prediction identity requests",
)
async def predictionrequests(interaction: discord.Interaction):
    if not _prediction_admin_allowed(interaction):
        await interaction.response.send_message(
            "Only the bot owner, server administrators, or WTSL admins can review "
            "prediction identity requests.",
            ephemeral=True,
        )
        return
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        requests = await asyncio.to_thread(list_pending_prediction_link_requests)
        if not requests:
            content = "There are no pending prediction identity requests."
        else:
            content = "\n".join(
                f"**#{row['request_id']}** <@{int(row['discord_user_id'])}> — "
                f"`{row['requested_name']}`"
                for row in requests[:25]
            )
        await interaction.followup.send(content, ephemeral=True)
    except Exception as exc:
        await interaction.followup.send(
            f"Pending requests could not be loaded: {str(exc)[:800]}",
            ephemeral=True,
        )


@client.tree.command(
    name="predictionapprove",
    description="Approve a pending prediction identity request",
)
@app_commands.describe(request_id="The request number shown by /predictionrequests")
async def predictionapprove(interaction: discord.Interaction, request_id: int):
    if not _prediction_admin_allowed(interaction):
        await interaction.response.send_message(
            "Only the bot owner, server administrators, or WTSL admins can approve "
            "prediction identity requests.",
            ephemeral=True,
        )
        return
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        discord_user_id, challonge_username = await asyncio.to_thread(
            approve_prediction_link_request,
            request_id,
            interaction.user.id,
        )
        await interaction.followup.send(
            f"Approved `<@{discord_user_id}>` as Challonge identity "
            f"`{challonge_username}`.",
            ephemeral=True,
        )
    except Exception as exc:
        await interaction.followup.send(
            f"The prediction identity request was not approved: {str(exc)[:800]}",
            ephemeral=True,
        )


@client.tree.command(
    name="predictionreject",
    description="Reject a pending prediction identity request",
)
@app_commands.describe(request_id="The request number shown by /predictionrequests")
async def predictionreject(interaction: discord.Interaction, request_id: int):
    if not _prediction_admin_allowed(interaction):
        await interaction.response.send_message(
            "Only the bot owner, server administrators, or WTSL admins can reject "
            "prediction identity requests.",
            ephemeral=True,
        )
        return
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        await asyncio.to_thread(
            reject_prediction_link_request,
            request_id,
            interaction.user.id,
        )
        await interaction.followup.send(
            f"Rejected prediction identity request **#{request_id}**.",
            ephemeral=True,
        )
    except Exception as exc:
        await interaction.followup.send(
            f"The prediction identity request was not rejected: {str(exc)[:800]}",
            ephemeral=True,
        )


@client.tree.command(
    name="predictionlinkadmin",
    description="Directly link a Discord member to a fetched Challonge identity",
)
@app_commands.describe(
    member="Discord member to link",
    challonge_name=(
        "Exact fetched Challonge username or prediction name; aliases are supported"
    ),
)
async def predictionlinkadmin(
    interaction: discord.Interaction,
    member: discord.Member,
    challonge_name: str,
):
    if not _prediction_admin_allowed(interaction):
        await interaction.response.send_message(
            "Only the bot owner, server administrators, or WTSL admins can link "
            "prediction identities.",
            ephemeral=True,
        )
        return
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        challonge_username = await asyncio.to_thread(
            link_prediction_identity_direct,
            member.id,
            challonge_name,
            interaction.user.id,
        )
        await interaction.followup.send(
            f"Linked {member.mention} to Challonge identity "
            f"`{challonge_username}`.",
            ephemeral=True,
        )
    except Exception as exc:
        await interaction.followup.send(
            f"The prediction identity was not linked: {str(exc)[:800]}",
            ephemeral=True,
        )


def _wtsl_is_managed_fixture_embed(embed: typing.Any) -> bool:
    """Recognize current and legacy fixture embeds, including untitled pages."""
    title = getattr(embed, "title", None)
    if (
        title == WTSL_BETTING_TITLE
        or (
            isinstance(title, str)
            and (
                title.startswith(f"{WTSL_BETTING_TITLE} • Page ")
                or title.startswith(WTSL_BETTING_LEGACY_PAGE_PREFIX)
            )
        )
    ):
        return True
    # Older pages 2+ had no title; use their stable betting description/footer.
    return (
        not title
        and getattr(embed, "description", None) in {
            "Choose a player to place a bet in Virtual WTSL Currency",
            WTSL_BETTING_DESCRIPTION,
        }
        and getattr(getattr(embed, "footer", None), "text", None)
        == WTSL_BETTING_FOOTER
    )


def _wtsl_message_has_managed_fixture_embed(message: typing.Any) -> bool:
    return any(
        _wtsl_is_managed_fixture_embed(embed)
        for embed in getattr(message, "embeds", [])
    )


def _remember_betting_fixtures(fixtures: list[dict]) -> None:
    _betting_fixture_tokens.clear()
    _betting_fixtures_by_token.clear()
    for fixture in fixtures:
        if fixture.get("betting_enabled") is False:
            continue
        key = str(fixture.get("key") or fixture.get("fixture_key") or "")
        if key:
            token = _betting_fixture_token(key)
            _betting_fixture_tokens[token] = key
            _betting_fixtures_by_token[token] = dict(fixture)


async def _get_wtsl_betting_channel():
    guild = client.get_guild(WTSL_BETTING_GUILD_ID)
    if guild is None:
        try:
            guild = await client.fetch_guild(WTSL_BETTING_GUILD_ID)
        except Exception as exc:
            print(f"[WTSL Betting] guild unavailable: {exc}", flush=True)
            return None

    async def fetch_channel(channel_id: int):
        channel = client.get_channel(channel_id)
        if channel is None:
            try:
                channel = await client.fetch_channel(channel_id)
            except Exception:
                return None
        channel_guild = getattr(channel, "guild", None)
        if channel_guild is not None and channel_guild.id != guild.id:
            return None
        return channel

    channel = await fetch_channel(WTSL_BETTING_CHANNEL_ID)
    if channel is None:
        print(
            f"[WTSL Betting] fixed betting channel "
            f"{WTSL_BETTING_CHANNEL_ID} is unavailable; refusing to create "
            f"another #{WTSL_BETTING_CHANNEL_NAME} channel",
            flush=True,
        )
    return channel


async def _is_wtsl_betting_verified(user_id: int) -> bool:
    links = _matchlog_links(user_id)
    if not links:
        try:
            await asyncio.wait_for(
                _restore_matchlog_identity_for_user(user_id),
                timeout=10,
            )
        except Exception as exc:
            print(
                f"[WTSL Betting] identity lookup failed for {user_id}: "
                f"{type(exc).__name__}: {exc}",
                flush=True,
            )
        links = _matchlog_links(user_id)
    return bool(links)


async def _wtsl_verified_player_links(user_id: int) -> dict[str, str]:
    """Load the durable ATP/WTA identities used by betting safeguards."""
    links = _matchlog_links(user_id)
    if not links:
        try:
            await asyncio.wait_for(
                _restore_matchlog_identity_for_user(user_id),
                timeout=10,
            )
        except Exception as exc:
            print(
                f"[WTSL Betting] identity lookup failed for {user_id}: "
                f"{type(exc).__name__}: {exc}",
                flush=True,
            )
        links = _matchlog_links(user_id)
    return {
        str(tour).casefold(): str(player)
        for tour, player in links.items()
        if str(tour).casefold() in {"atp", "wta"} and str(player).strip()
    }


def _betting_result_for_fixture(
    fixture: dict[str, typing.Any],
    results: list[dict[str, typing.Any]],
) -> tuple[str | None, str] | None:
    def betting_tour_key(value: typing.Any) -> str:
        normalized = normalize_matchlog_name(value)
        if (
            "wta" in normalized
            or "female" in normalized
            or normalized.endswith("(f)")
            or normalized.endswith("_f")
            or normalized.endswith(" f")
        ):
            return "wta"
        if "atp" in normalized or "te4" in normalized:
            return "atp"
        return normalized

    def betting_event_key(value: typing.Any) -> str:
        # Homepage fixtures include the draw round in parentheses, while the
        # official all-results feed uses the full event name and year.
        without_round = re.sub(r"\s*\([^)]*\)\s*$", "", str(value or ""))
        return normalize_matchlog_name(without_round)

    first_name = normalize_matchlog_name(fixture.get("first_name"))
    second_name = normalize_matchlog_name(fixture.get("second_name"))
    if not first_name or not second_name:
        return None
    pair = sorted((first_name, second_name))
    fixture_tournament = betting_event_key(fixture.get("tournament"))
    fixture_tour = betting_tour_key(fixture.get("tour"))
    for result in results:
        result_first = normalize_matchlog_name(
            result.get("p1") or result.get("player1")
        )
        result_second = normalize_matchlog_name(
            result.get("p2") or result.get("player2")
        )
        if sorted((result_first, result_second)) != pair:
            continue
        result_tour = betting_tour_key(result.get("tour"))
        if fixture_tour and result_tour and fixture_tour != result_tour:
            continue
        result_tournament = betting_event_key(result.get("tournament"))
        if fixture_tournament and result_tournament:
            if not (
                fixture_tournament == result_tournament
                or fixture_tournament in result_tournament
                or result_tournament in fixture_tournament
            ):
                continue
        note = " ".join(
            str(result.get(field) or "").strip()
            for field in ("result", "round", "date")
        ).strip()
        if re.search(r"\bscheduled\b", note, re.I):
            return None
        if re.search(
            r"\b(cancelled?|postponed?|abandoned|void)\b",
            note,
            re.I,
        ):
            return None, note or "Official result marked as not played"
        winner_name = normalize_matchlog_name(
            result.get("p1") or result.get("player1")
        )
        if winner_name == first_name:
            winner_id = str(fixture.get("first_id"))
        elif winner_name == second_name:
            winner_id = str(fixture.get("second_id"))
        else:
            continue
        return winner_id, note or "Official WTSL result"
    return None


def _completed_draw_matches_fixture(
    fixture: dict[str, typing.Any],
    completed_draw_matches: list[dict[str, typing.Any]],
) -> bool:
    """Require Challonge to mark the same fixture complete before settlement."""
    first_name = normalize_matchlog_name(fixture.get("first_name"))
    second_name = normalize_matchlog_name(fixture.get("second_name"))
    if not first_name or not second_name:
        return False
    wanted_players = {first_name, second_name}
    fixture_event = normalize_matchlog_name(
        re.sub(
            r"\s*\([^)]*\)\s*$",
            "",
            str(fixture.get("tournament") or ""),
        )
    )
    for completed in completed_draw_matches:
        players = {
            normalize_matchlog_name(player)
            for player in completed.get("players") or []
        }
        if players != wanted_players:
            continue
        completed_event = normalize_matchlog_name(
            re.sub(
                r"\s*\([^)]*\)\s*$",
                "",
                str(completed.get("tournament") or ""),
            )
        )
        if fixture_event and completed_event and not (
            fixture_event == completed_event
            or fixture_event in completed_event
            or completed_event in fixture_event
        ):
            continue
        return True
    return False


async def _seed_verified_wtsl_accounts() -> None:
    verified_ids = set(_matchlog_identity_index)
    try:
        stored = await asyncio.to_thread(load_matchlog_identities)
        verified_ids.update(int(user_id) for user_id in stored)
    except Exception as exc:
        print(f"[WTSL Betting] could not load verified accounts: {exc}", flush=True)
    for user_id in verified_ids:
        try:
            await asyncio.to_thread(seed_wtsl_account, int(user_id))
        except Exception as exc:
            print(
                f"[WTSL Betting] could not seed account {user_id}: {exc}",
                flush=True,
            )


def _wtsl_fixture_scheduler_record(
    fixture: dict[str, typing.Any],
) -> dict[str, typing.Any] | None:
    """Return the active real-player scheduler record for one fixture."""
    tournament_id = str(fixture.get("tournament_id") or "")
    wanted_players = {
        normalize_matchlog_name(fixture.get("first_name")),
        normalize_matchlog_name(fixture.get("second_name")),
    }
    if not tournament_id or "" in wanted_players:
        return None
    for record in _match_scheduler_records.values():
        if (
            record.get("status") == "active"
            and not record.get("is_test")
            and str(record.get("tournament_id") or "") == tournament_id
            and {
                normalize_matchlog_name(record.get("player_one", "")),
                normalize_matchlog_name(record.get("player_two", "")),
            } == wanted_players
        ):
            return record
    return None


def _wtsl_fixture_round_deadline_text(
    fixture: dict[str, typing.Any],
) -> str | None:
    deadline = fixture.get("round_deadline")
    if not isinstance(deadline, datetime):
        return None
    timestamp = int(deadline.timestamp())
    return f"Round deadline: <t:{timestamp}:F> (<t:{timestamp}:R>)"


def _build_wtsl_betting_page(
    fixtures: list[dict[str, typing.Any]],
    page_number: int,
    page_count: int,
    *,
    leaderboard_rows: list[dict[str, typing.Any]] | None = None,
    loser_rows: list[dict[str, typing.Any]] | None = None,
    result_rows: list[dict[str, typing.Any]] | None = None,
    include_fixture_buttons: bool = True,
    include_account_controls: bool = True,
) -> tuple[list[discord.Embed], discord.ui.View | None]:
    view = (
        discord.ui.View(timeout=None)
        if fixtures and include_fixture_buttons
        else None
    )
    embed = discord.Embed(
        title=_wtsl_betting_fixture_page_title(page_number),
        description=WTSL_BETTING_DESCRIPTION,
        color=0xD4AF37,
    )
    # A single embed cannot show a separate large image for every fixture.
    # Use the official WTSL stock avatar as a consistent page image instead.
    embed.set_thumbnail(url=WTSL_DEFAULT_AVATAR_URL)
    embed.set_footer(text=WTSL_BETTING_FOOTER)
    for fixture_index, fixture in enumerate(fixtures):
        fixture = _repair_wtsl_fixture_player_fields(fixture)
        first_name = str(fixture.get("first_name") or "Player 1")
        second_name = str(fixture.get("second_name") or "Player 2")
        tournament = str(fixture.get("tournament") or "WTSL fixture")
        raw_odds = fixture.get("odds")
        if raw_odds is None:
            raw_odds = [fixture.get("odds_one"), fixture.get("odds_two")]
        valid_odds = (
            isinstance(raw_odds, (list, tuple))
            and len(raw_odds) >= 2
            and raw_odds[0] is not None
            and raw_odds[1] is not None
        )
        if valid_odds:
            fixture_value = (
                f"WTSL odds: **{first_name} "
                f"{_wtsl_decimal_odds(raw_odds[0])}** • "
                f"**{second_name} {_wtsl_decimal_odds(raw_odds[1])}**\n"
                f"House-adjusted live odds: **{first_name} "
                f"{_wtsl_pool_odds_label(fixture, 'one', raw_odds[0])}** • "
                f"**{second_name} "
                f"{_wtsl_pool_odds_label(fixture, 'two', raw_odds[1])}**\n"
                f"Guaranteed minimum odds: **{first_name} "
                f"{_wtsl_house_odds_label(fixture, 'one', raw_odds[0])}** • "
                f"**{second_name} "
                f"{_wtsl_house_odds_label(fixture, 'two', raw_odds[1])}**\n"
            )
        else:
            fixture_value = (
                f"**{first_name}** — odds pending\n"
                f"**{second_name}** — odds pending"
            )
        round_deadline = _wtsl_fixture_round_deadline_text(fixture)
        if round_deadline:
            fixture_value += f"\n{round_deadline}"
        if _wtsl_fixture_scheduler_record(fixture):
            fixture_value += "\nCurrently scheduling this match."
        embed.add_field(
            name=f"🎾 {tournament}",
            value=fixture_value,
            inline=False,
        )
        if view is not None and valid_odds:
            token = _betting_fixture_token(str(fixture["key"]))
            view.add_item(
                discord.ui.Button(
                    label=f"{first_name} · "
                    f"{_wtsl_house_odds_label(fixture, 'one', raw_odds[0])}"[:80],
                    style=discord.ButtonStyle.primary,
                    row=fixture_index,
                    custom_id=f"wtsl_bet:v1:{token}:one",
                )
            )
            view.add_item(
                discord.ui.Button(
                    label="vs.",
                    style=discord.ButtonStyle.secondary,
                    disabled=True,
                    row=fixture_index,
                )
            )
            view.add_item(
                discord.ui.Button(
                    label=f"{second_name} · "
                    f"{_wtsl_house_odds_label(fixture, 'two', raw_odds[1])}"[:80],
                    style=discord.ButtonStyle.primary,
                    row=fixture_index,
                    custom_id=f"wtsl_bet:v1:{token}:two",
                )
            )
    if leaderboard_rows is not None:
        if leaderboard_rows:
            leaderboard_lines = [
                (
                    f"**{index}.** <@{int(row['discord_user_id'])}> — "
                    f"{_wtsl_dollars(row['total_profit'])} earnings "
                    f"({int(row.get('successful_bets') or 0)}W/"
                    f"{int(row.get('failed_bets') or 0)}L"
                    + (
                        f"/{int(row.get('refunded_bets') or 0)}R"
                        if int(row.get("refunded_bets") or 0)
                        else ""
                    )
                    + ")"
                )
                for index, row in enumerate(leaderboard_rows[:10], 1)
            ]
            leaderboard_value = "\n".join(leaderboard_lines)
        else:
            leaderboard_value = "No settled betting results yet."
        embed.add_field(
            name="🏆 Top Earners",
            value=leaderboard_value[:1024],
            inline=False,
        )
        if loser_rows:
            loser_lines = [
                (
                    f"**{index}.** <@{int(row['discord_user_id'])}> — "
                    f"{_wtsl_dollars(row['total_profit'])} net "
                    f"({int(row.get('successful_bets') or 0)}W/"
                    f"{int(row.get('failed_bets') or 0)}L"
                    + (
                        f"/{int(row.get('refunded_bets') or 0)}R"
                        if int(row.get("refunded_bets") or 0)
                        else ""
                    )
                    + ")"
                )
                for index, row in enumerate(loser_rows[:10], 1)
            ]
            loser_value = "\n".join(loser_lines)
        else:
            loser_value = "No net losses yet."
        embed.add_field(
            name="📉 Biggest Losers",
            value=loser_value[:1024],
            inline=False,
        )
    if result_rows is not None:
        if result_rows:
            result_lines = []
            for row in result_rows[:10]:
                repaired = _repair_wtsl_fixture_player_fields(row)
                first_name = str(repaired.get("first_name") or "Player 1")
                second_name = str(repaired.get("second_name") or "Player 2")
                winner_id = str(repaired.get("winner_id") or "")
                first_id = str(repaired.get("first_id") or "")
                second_id = str(repaired.get("second_id") or "")
                total_bets = int(repaired.get("total_bets") or 0)
                first_bets = int(repaired.get("first_bets") or 0)
                second_bets = int(repaired.get("second_bets") or 0)
                winning_bets = (
                    first_bets if winner_id == first_id
                    else second_bets if winner_id == second_id
                    else 0
                )
                if winner_id and total_bets and not winning_bets:
                    result_line = (
                        "↩️ **Refunded — no bets backed the official winner**\n"
                        f"{first_name} vs {second_name}"
                    )
                elif winner_id == first_id:
                    result_line = f"✅ **{first_name}** over {second_name}"
                elif winner_id == second_id:
                    result_line = f"✅ **{second_name}** over {first_name}"
                else:
                    result_line = f"↩️ Refunded: {first_name} vs {second_name}"
                if total_bets:
                    bet_line = (
                        f"Bets: **{first_name} {first_bets / total_bets:.0%}** "
                        f"({first_bets}) • **{second_name} "
                        f"{second_bets / total_bets:.0%}** ({second_bets})"
                    )
                else:
                    bet_line = "No bets were placed on this fixture."
                note = str(
                    repaired.get("result_note") or "Official WTSL result"
                ).strip()
                result_lines.append(
                    f"{result_line}\n{bet_line}\n`{note[:180]}`"
                )
            result_value = "\n".join(result_lines)
        else:
            result_value = "No completed matches yet."
        embed.add_field(
            name=WTSL_BETTING_RESULTS_TITLE,
            value=result_value[:1024],
            inline=False,
        )
    embed.set_footer(text=WTSL_BETTING_FOOTER)
    if (
        view is not None
        and include_account_controls
        and page_number == page_count
    ):
        view.add_item(
            discord.ui.Button(
                label="➕ Build Parlay",
                style=discord.ButtonStyle.primary,
                row=4,
                custom_id="wtsl_bet:v1:parlay",
            )
        )
        view.add_item(
            discord.ui.Button(
                label="🪙  My W$ Balance",
                style=discord.ButtonStyle.success,
                row=4,
                custom_id="wtsl_bet:v1:balance",
            )
        )
        view.add_item(
            discord.ui.Button(
                label="📒  My Bet Ledger",
                style=discord.ButtonStyle.secondary,
                row=4,
                custom_id="wtsl_bet:v1:ledger",
            )
        )
    return [embed], view


def _add_wtsl_account_controls(view: discord.ui.View) -> None:
    view.add_item(
        discord.ui.Button(
            label="➕ Build Parlay",
            style=discord.ButtonStyle.primary,
            row=4,
            custom_id="wtsl_bet:v1:parlay",
        )
    )
    view.add_item(
        discord.ui.Button(
            label="🪙  My W$ Balance",
            style=discord.ButtonStyle.success,
            row=4,
            custom_id="wtsl_bet:v1:balance",
        )
    )
    view.add_item(
        discord.ui.Button(
            label="📒  My Bet Ledger",
            style=discord.ButtonStyle.secondary,
            row=4,
            custom_id="wtsl_bet:v1:ledger",
        )
    )
    view.add_item(
        discord.ui.Button(
            label="🔗 Refer a friend",
            style=discord.ButtonStyle.secondary,
            row=4,
            custom_id="wtsl_bet:v1:refer",
        )
    )


def _build_wtsl_betting_controls(
    fixtures: list[dict[str, typing.Any]],
    *,
    include_account_controls: bool,
) -> discord.ui.View:
    view = discord.ui.View(timeout=None)
    for fixture_index, fixture in enumerate(fixtures):
        fixture = _repair_wtsl_fixture_player_fields(fixture)
        first_name = str(fixture.get("first_name") or "Player 1")
        second_name = str(fixture.get("second_name") or "Player 2")
        raw_odds = fixture.get("odds")
        if raw_odds is None:
            raw_odds = [fixture.get("odds_one"), fixture.get("odds_two")]
        valid_odds = (
            isinstance(raw_odds, (list, tuple))
            and len(raw_odds) >= 2
            and raw_odds[0] is not None
            and raw_odds[1] is not None
        )
        if not valid_odds:
            continue
        token = _betting_fixture_token(str(fixture["key"]))
        view.add_item(
            discord.ui.Button(
                label=f"{first_name} · "
                f"{_wtsl_house_odds_label(fixture, 'one', raw_odds[0])}"[:80],
                style=discord.ButtonStyle.primary,
                row=fixture_index,
                custom_id=f"wtsl_bet:v1:{token}:one",
            )
        )
        view.add_item(
            discord.ui.Button(
                label="vs.",
                style=discord.ButtonStyle.secondary,
                disabled=True,
                row=fixture_index,
            )
        )
        view.add_item(
            discord.ui.Button(
                label=f"{second_name} · "
                f"{_wtsl_house_odds_label(fixture, 'two', raw_odds[1])}"[:80],
                style=discord.ButtonStyle.primary,
                row=fixture_index,
                custom_id=f"wtsl_bet:v1:{token}:two",
            )
        )
    if include_account_controls:
        _add_wtsl_account_controls(view)
    return view


def _wtsl_bet_status_label(status: typing.Any) -> str:
    return {
        "open": "🟡 Open",
        "won": "✅ Won",
        "lost": "❌ Lost",
        "refunded": "↩️ Refunded",
    }.get(str(status or "").lower(), str(status or "Unknown").title())


def _wtsl_bet_timestamp(value: typing.Any) -> str:
    if not value:
        return "—"
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).strftime("%d %b %Y %H:%M UTC")
    return str(value)


def _build_wtsl_bet_ledger_pages(
    rows: list[dict[str, typing.Any]],
) -> list[discord.Embed]:
    if not rows:
        embed = discord.Embed(
            title="📒 My Bet Ledger",
            description="No bets have been placed from your account yet.",
            color=0xD4AF37,
        )
        embed.set_footer(text=WTSL_BETTING_FOOTER)
        return [embed]

    pages: list[discord.Embed] = []
    page_count = max(1, math.ceil(len(rows) / WTSL_BETTING_LEDGER_PAGE_SIZE))
    for page_index in range(page_count):
        start = page_index * WTSL_BETTING_LEDGER_PAGE_SIZE
        page_rows = rows[start:start + WTSL_BETTING_LEDGER_PAGE_SIZE]
        embed = discord.Embed(
            title=f"📒 My Bet Ledger • Page {page_index + 1}/{page_count}",
            description=(
                "Your singles and parlays, newest first. "
                "Singles lock a guaranteed minimum at placement; the closing "
                "pool can increase the return."
            ),
            color=0xD4AF37,
        )
        for row in page_rows:
            kind = str(row.get("kind") or "single")
            bet_id = int(row.get("id") or 0)
            if kind == "parlay":
                field_name = f"🎟️ Parlay #{bet_id}"
                selection = str(row.get("selection") or "No legs recorded")
            else:
                field_name = (
                    f"🎾 {str(row.get('fixture') or 'WTSL fixture')[:220]}"
                    f" • Bet #{bet_id}"
                )
                selection = str(row.get("selection") or "Unknown outcome")
            field_value = (
                f"**Selection:** {selection[:500]}\n"
                f"**Stake:** {_wtsl_dollars(row.get('stake'))} • "
                f"**Odds:** {_wtsl_decimal_odds(row.get('odds'))}\n"
                f"**Guaranteed minimum:** "
                f"{_wtsl_dollars(row.get('potential_return'))} • "
                f"**Returned:** {_wtsl_dollars(row.get('return_amount'))}\n"
                f"**Status:** {_wtsl_bet_status_label(row.get('status'))} • "
                f"Placed: {_wtsl_bet_timestamp(row.get('placed_at'))}"
            )
            if str(row.get("status") or "").lower() == "refunded":
                field_value += (
                    "\n**Refund reason:** no eligible winner-side pool; "
                    "your full stake was returned."
                )
            embed.add_field(name=field_name, value=field_value[:1024], inline=False)
        embed.set_footer(text=WTSL_BETTING_FOOTER)
        pages.append(embed)
    return pages


class WTSLLedgerView(discord.ui.View):
    def __init__(
        self,
        user_id: int,
        pages: list[discord.Embed],
    ):
        super().__init__(timeout=900)
        self.user_id = int(user_id)
        self.pages = pages
        self.page_index = 0
        self.previous_button = discord.ui.Button(
            label="◀ Previous",
            style=discord.ButtonStyle.secondary,
            custom_id="wtsl_bet_ledger_previous:v1",
            row=0,
            disabled=True,
        )
        self.next_button = discord.ui.Button(
            label="Next ▶",
            style=discord.ButtonStyle.secondary,
            custom_id="wtsl_bet_ledger_next:v1",
            row=0,
            disabled=len(pages) <= 1,
        )
        self.previous_button.callback = self._previous_callback
        self.next_button.callback = self._next_callback
        self.add_item(self.previous_button)
        self.add_item(self.next_button)

    async def _move(
        self,
        interaction: discord.Interaction,
        offset: int,
    ) -> None:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message(
                "This bet ledger belongs to another user.",
                ephemeral=True,
            )
            return
        self.page_index = max(
            0,
            min(self.page_index + offset, len(self.pages) - 1),
        )
        self.previous_button.disabled = self.page_index == 0
        self.next_button.disabled = self.page_index == len(self.pages) - 1
        await interaction.response.edit_message(
            embed=self.pages[self.page_index],
            view=self,
        )

    async def _previous_callback(self, interaction: discord.Interaction):
        await self._move(interaction, -1)

    async def _next_callback(self, interaction: discord.Interaction):
        await self._move(interaction, 1)


def _build_wtsl_betting_leaderboard(
    rows: list[dict[str, typing.Any]],
) -> discord.Embed:
    embed = discord.Embed(
        title=WTSL_BETTING_LEADERBOARD_TITLE,
        color=0xD4AF37,
    )
    if client.user:
        embed.set_author(
            name=str(client.user),
            icon_url=client.user.display_avatar.url,
        )
    if rows:
        lines = []
        for index, row in enumerate(rows, 1):
            refunded_bets = int(row.get("refunded_bets") or 0)
            record = (
                f"{int(row.get('successful_bets') or 0)}/"
                f"{int(row.get('failed_bets') or 0)}"
            )
            if refunded_bets:
                record += f"/{refunded_bets}"
            lines.append(
                f"**{index}.** <@{int(row['discord_user_id'])}> — "
                f"Earnings: **{_wtsl_dollars(row['total_profit'])}** "
                f"• Won/Lost"
                f"{'/Refunded' if refunded_bets else ''}: **{record}** "
                f"• Total bets: **{int(row.get('total_bets') or 0)}**"
            )
        embed.description += "\n\n" + "\n".join(lines)
    else:
        embed.description += "\n\nNo settled betting results yet."
    embed.set_footer(text=WTSL_BETTING_FOOTER)
    return embed


def _build_wtsl_betting_results(
    rows: list[dict[str, typing.Any]],
) -> discord.Embed:
    embed = discord.Embed(
        title=WTSL_BETTING_RESULTS_TITLE,
        color=0x57F287,
    )
    embed.set_footer(text=WTSL_BETTING_FOOTER)
    if not rows:
        return embed
    for row in rows:
        first_name = str(row.get("first_name") or "Player 1")
        second_name = str(row.get("second_name") or "Player 2")
        winner_id = str(row.get("winner_id") or "")
        first_id = str(row.get("first_id") or "")
        second_id = str(row.get("second_id") or "")
        total_bets = int(row.get("total_bets") or 0)
        first_bets = int(row.get("first_bets") or 0)
        second_bets = int(row.get("second_bets") or 0)
        winning_bets = (
            first_bets if winner_id == first_id
            else second_bets if winner_id == second_id
            else 0
        )
        if winner_id and total_bets and not winning_bets:
            result_line = (
                "↩️ **Refunded — no bets backed the official winner**\n"
                f"{first_name} vs {second_name}"
            )
        elif winner_id == first_id:
            result_line = f"✅ **{first_name}**\n{second_name}"
        elif winner_id == second_id:
            result_line = f"{first_name}\n✅ **{second_name}**"
        else:
            result_line = "↩️ **Refunded — no official winner**\n" f"{first_name} vs {second_name}"
        tournament = str(row.get("tournament") or "WTSL fixture")
        note = str(row.get("result_note") or "Official WTSL result").strip()
        if total_bets:
            bet_split = (
                f"Bets placed: **{first_name} {first_bets / total_bets:.0%}** "
                f"({first_bets}/{total_bets}) • "
                f"**{second_name} {second_bets / total_bets:.0%}** "
                f"({second_bets}/{total_bets})"
            )
        else:
            bet_split = "No bets were placed on this fixture."
        final_pool_one = _wtsl_pool_decimal_odds(row, "one")
        final_pool_two = _wtsl_pool_decimal_odds(row, "two")
        if final_pool_one is not None and final_pool_two is not None:
            final_line = (
                f"Final closing pool odds: **{first_name} "
                f"{_wtsl_odds(final_pool_one)}** • **{second_name} "
                f"{_wtsl_odds(final_pool_two)}**\n"
                "These closing odds were used for the pool portion of settlement; "
                "placement guarantees remain protected."
            )
        else:
            final_line = "No closing pool odds were available."
        embed.add_field(
            name=tournament,
            value=f"{result_line}\n{bet_split}\n{final_line}\n`{note[:700]}`",
            inline=False,
        )
    return embed


async def _apply_h2h_odds(
    session: aiohttp.ClientSession,
    fixture: dict[str, typing.Any],
) -> None:
    tour = tour_from_tournament_id(
        fixture.get("tournament_id"),
        default=(
            "TE4_(F)"
            if "wta" in normalize_matchlog_name(fixture.get("tour"))
            else "TE4"
        ),
    )
    url = (
        "https://playwtsl.com/TE4/pages/h2h.php"
        f"?tour={tour}&pl_one={fixture['first_id']}&pl_two={fixture['second_id']}"
    )
    try:
        async with session.get(url) as response:
            response.raise_for_status()
            odds = parse_h2h_percentage_odds(
                await response.text(),
                first_id=str(fixture["first_id"]),
                second_id=str(fixture["second_id"]),
            )
    except Exception as exc:
        print(
            f"[WTSL Betting] H2H odds unavailable for "
            f"{fixture.get('first_name')} vs {fixture.get('second_name')}: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        return
    if odds is not None:
        fixture["odds"] = odds
        fixture["odds_source"] = "WTSL H2H win percentages"
        fixture["betting_enabled"] = True


async def _fetch_and_sync_betting_fixtures() -> list[dict]:
    global _wtsl_completed_draw_matches, _wtsl_tournament_page_results
    parsed: list[dict] = []
    completed_draw_matches: list[dict[str, typing.Any]] = []
    tournament_page_results: list[dict[str, typing.Any]] = []
    try:
        previous_open_fixtures = await asyncio.to_thread(
            list_open_betting_fixtures
        )
    except Exception as exc:
        previous_open_fixtures = []
        print(
            f"[WTSL Betting] could not preload open fixtures for "
            f"finished-tournament settlement: {type(exc).__name__}: {exc}",
            flush=True,
        )

    def tournament_event_key(value: typing.Any) -> str:
        return normalize_matchlog_name(
            re.sub(r"\s*\([^)]*\)\s*$", "", str(value or ""))
        )

    stored_tournament_ids = {
        str(fixture.get("tournament_id") or "").strip()
        for fixture in previous_open_fixtures
        if str(fixture.get("tournament_id") or "").strip()
    }
    stored_tournament_events = {
        tournament_event_key(fixture.get("tournament"))
        for fixture in previous_open_fixtures
        if tournament_event_key(fixture.get("tournament"))
    }
    try:
        season = str(datetime.now(timezone.utc).year)
        timeout = aiohttp.ClientTimeout(total=45)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get("https://playwtsl.com/TE4") as response:
                response.raise_for_status()
                homepage = await response.text()
            parsed = parse_upcoming_fixtures(homepage, season=season)
            known_keys = {str(fixture["key"]) for fixture in parsed}

            try:
                tournament_sources = []
                async with session.get(ONGOING_TOURNAMENTS_URL) as atp_response:
                    atp_response.raise_for_status()
                    tournament_sources.append(
                        (await atp_response.text(), "TE4")
                    )
                async with session.get(ONGOING_TOURNAMENTS_WTA_URL) as wta_response:
                    wta_response.raise_for_status()
                    tournament_sources.append(
                        (await wta_response.text(), "TE4_(F)")
                    )
                tournaments = []
                seen_tournaments: set[str] = set()
                for tournament_page, tour in tournament_sources:
                    for tournament in parse_ongoing_tournaments(
                        tournament_page,
                        tour=tour,
                    ):
                        if tournament["id"] in seen_tournaments:
                            continue
                        seen_tournaments.add(tournament["id"])
                        tournaments.append(tournament)
                    for tournament in parse_tournament_directory(
                        tournament_page,
                        tour=tour,
                    ):
                        tournament_id = str(tournament.get("id") or "")
                        if tournament_id in seen_tournaments:
                            continue
                        if (
                            tournament_id not in stored_tournament_ids
                            and tournament_event_key(tournament.get("name"))
                            not in stored_tournament_events
                        ):
                            continue
                        seen_tournaments.add(tournament_id)
                        tournaments.append(tournament)
                for tournament in tournaments:
                    tournament_id = str(tournament.get("id") or "")
                    if not tournament_id:
                        continue
                    try:
                        draw_source = await _fetch_exact_draw_source(
                            session,
                            tournament,
                        )
                        if draw_source is not None:
                            draw_html, source_tournament = draw_source
                            draw_matches = parse_draw_matches(
                                draw_html,
                                source_tournament,
                            )
                            tournament["_open_draw_matches"] = draw_matches
                            completed_draw_matches.extend(
                                parse_completed_draw_matches(
                                    draw_html,
                                    source_tournament,
                                )
                            )
                    except Exception as exc:
                        print(
                            f"[WTSL Betting] Challonge deadline source unavailable "
                            f"for {tournament_id}: {type(exc).__name__}: {exc}",
                            flush=True,
                        )
                    page_url = TOURNAMENT_PAGE_URL.format(
                        tournament_id=tournament_id
                    )
                    try:
                        async with session.get(page_url) as page_response:
                            page_response.raise_for_status()
                            page_html = await page_response.text()
                            tournament_page_results.extend(
                                parse_reported_tournament_results(
                                    page_html,
                                    str(tournament.get("name") or tournament_id),
                                    str(tournament.get("tour") or "TE4"),
                                )
                            )
                            scheduled = parse_scheduled_tournament_fixtures(
                                page_html,
                                tournament_id,
                                str(tournament.get("name") or tournament_id),
                                season=season,
                                tour=str(tournament.get("tour") or "TE4"),
                            )
                    except Exception as exc:
                        print(
                            f"[WTSL Betting] scheduled fixture source unavailable "
                            f"for {tournament_id}: {type(exc).__name__}: {exc}",
                            flush=True,
                        )
                        continue
                    for fixture in scheduled:
                        if fixture["key"] not in known_keys:
                            parsed.append(fixture)
                            known_keys.add(fixture["key"])

                for fixture in parsed:
                    tournament_id = str(fixture.get("tournament_id") or "")
                    tournament = next(
                        (
                            item for item in tournaments
                            if str(item.get("id") or "") == tournament_id
                        ),
                        None,
                    )
                    deadline = _outreach_draw_deadline(
                        fixture,
                        (tournament or {}).get("_open_draw_matches") or [],
                    )
                    if deadline is None:
                        deadline = _wtsl_round_deadline(
                            fixture,
                            (tournament or {}).get("_open_draw_matches") or [],
                        )
                    if deadline is not None:
                        fixture["round_deadline"] = deadline
            except Exception as exc:
                print(
                    f"[WTSL Betting] ongoing tournament scan unavailable: "
                    f"{type(exc).__name__}: {exc}",
                    flush=True,
                )
            if completed_draw_matches:
                _wtsl_completed_draw_matches = completed_draw_matches
            if tournament_page_results:
                _wtsl_tournament_page_results = tournament_page_results

            avatar_cache: dict[str, str | None] = {}
            for fixture in parsed:
                for side in ("first", "second"):
                    avatar_key = f"{side}_avatar"
                    player_id = str(fixture.get(f"{side}_id") or "")
                    if fixture.get(avatar_key) or not player_id:
                        continue
                    if player_id not in avatar_cache:
                        avatar_url = (
                            "https://playwtsl.com/TE4/pages/player_page.php"
                            f"?player={player_id}"
                        )
                        try:
                            async with session.get(avatar_url) as avatar_response:
                                avatar_response.raise_for_status()
                                avatar_cache[player_id] = parse_official_player_avatar(
                                    await avatar_response.text(),
                                    str(fixture.get(f"{side}_name") or ""),
                                )
                        except Exception as exc:
                            avatar_cache[player_id] = None
                            print(
                                f"[WTSL Betting] avatar unavailable for "
                                f"{fixture.get(f'{side}_name')}: "
                                f"{type(exc).__name__}: {exc}",
                                flush=True,
                            )
                    fixture[avatar_key] = avatar_cache[player_id]

            for fixture in parsed:
                if fixture.get("odds") is None:
                    await _apply_h2h_odds(session, fixture)
                fixture.setdefault(
                    "betting_enabled",
                    fixture.get("odds") is not None,
                )

        for fixture in parsed:
            if fixture.get("betting_enabled") and fixture.get("odds"):
                await asyncio.to_thread(sync_betting_fixture, fixture)
    except Exception as exc:
        print(
            f"[WTSL Betting] upcoming fixture refresh unavailable: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
    try:
        stored_fixtures = await asyncio.to_thread(list_open_betting_fixtures)
    except Exception as exc:
        print(f"[WTSL Betting] open fixture read failed: {exc}", flush=True)
        return parsed
    stored_by_key = {str(item["key"]): item for item in stored_fixtures}
    if not parsed:
        parsed = stored_fixtures
    else:
        for fixture in parsed:
            stored = stored_by_key.get(str(fixture["key"]))
            if stored is None:
                continue
            for field in ("pool_total", "pool_one", "pool_two"):
                fixture[field] = stored.get(field, 0)
            if fixture.get("round_deadline") is None:
                stored_deadline = stored.get("round_deadline")
                if stored_deadline is not None:
                    fixture["round_deadline"] = stored_deadline
        for item in stored_fixtures:
            parsed_by_key = {str(fixture["key"]) for fixture in parsed}
            if str(item["key"]) not in parsed_by_key:
                parsed.append(item)
    _remember_betting_fixtures(stored_fixtures)
    return parsed


async def _settle_open_wtsl_bets() -> int:
    completed_draw_matches = list(_wtsl_completed_draw_matches)
    if not completed_draw_matches:
        print(
            "[WTSL Betting] no Challonge-complete draw matches available; "
            "skipping settlement",
            flush=True,
        )
        return 0
    try:
        fixtures = await asyncio.to_thread(list_open_betting_fixtures)
        results = await asyncio.wait_for(
            get_all_results(allow_stale=True),
            timeout=45,
        )
    except Exception as exc:
        print(f"[WTSL Betting] settlement source unavailable: {exc}", flush=True)
        return 0
    settled = 0
    results = results + list(_wtsl_tournament_page_results)
    for fixture in fixtures:
        if not _completed_draw_matches_fixture(
            fixture,
            completed_draw_matches,
        ):
            continue
        matched = _betting_result_for_fixture(fixture, results)
        if matched is None:
            continue
        winner_id, note = matched
        try:
            changed = await asyncio.to_thread(
                settle_betting_fixture,
                str(fixture["key"]),
                winner_id=winner_id,
                result_note=note,
            )
            settled += int(bool(changed))
        except Exception as exc:
            print(
                f"[WTSL Betting] could not settle {fixture.get('key')}: {exc}",
                flush=True,
            )
    return settled


async def _process_wtsl_winner_notifications() -> None:
    """Deliver catch-up-safe winner and first-win DMs."""
    try:
        rows = await asyncio.to_thread(list_unnotified_winning_bets, 100)
    except Exception as exc:
        print(f"[WTSL Betting] winner notification query failed: {exc}", flush=True)
        return
    for row in rows:
        user_id = int(row["discord_user_id"])
        first_win = int(row.get("win_number") or 0) == 1
        receipt_key = f"winner:{row['kind']}:{int(row['ticket_id'])}"
        referral_receipt_key = (
            f"winner-referral-prompt:v1:{row['kind']}:{int(row['ticket_id'])}"
        )
        referral_prompt_claimed = False
        if first_win:
            referral_prompt_claimed = await asyncio.to_thread(
                claim_notification_receipt,
                referral_receipt_key,
                recipient_user_id=user_id,
                notification_type="winner_referral_prompt",
            )
        claimed = await asyncio.to_thread(
            claim_notification_receipt,
            receipt_key,
            recipient_user_id=user_id,
            notification_type="winner",
        )
        if not claimed:
            if first_win and referral_prompt_claimed:
                try:
                    user = await client.fetch_user(user_id)
                    await user.send(
                        _wtsl_referral_prompt_text(),
                        view=WTSLReferralPromptView(),
                    )
                except Exception as exc:
                    await asyncio.to_thread(
                        release_notification_receipt,
                        referral_receipt_key,
                        str(exc),
                    )
                    print(
                        f"[WTSL Betting] referral prompt DM failed for "
                        f"{user_id}: {exc}",
                        flush=True,
                    )
                else:
                    await asyncio.to_thread(
                        mark_notification_sent,
                        referral_receipt_key,
                    )
            continue
        profit = Decimal(row["return_amount"]) - Decimal(row["stake"])
        if row["kind"] == "single":
            match_text = (
                f"{row.get('player_one')} vs {row.get('player_two')} "
                f"({row.get('tournament')})"
            )
        else:
            match_text = str(row.get("selection_name") or "Parlay")
        opening = (
            "🎉 **Congratulations on your first WTSL betting win!**"
            if first_win
            else "🎉 **Your WTSL bet won!**"
        )
        content = (
            f"{opening}\n"
            f"Ticket: **{match_text}**\n"
            f"Stake: **{_wtsl_dollars(row['stake'])}**\n"
            f"Return: **{_wtsl_dollars(row['return_amount'])}** "
            f"(profit **{_wtsl_dollars(profit)}**)\n"
            f"Your balance is now **{_wtsl_dollars(row['balance'])}**."
        )
        if first_win:
            content += f"\n\n{_wtsl_referral_prompt_text()}"
        try:
            user = await client.fetch_user(user_id)
            if first_win:
                await user.send(content, view=WTSLReferralPromptView())
            else:
                await user.send(content)
        except Exception as exc:
            await asyncio.to_thread(
                release_notification_receipt,
                receipt_key,
                str(exc),
            )
            if first_win and referral_prompt_claimed:
                await asyncio.to_thread(
                    release_notification_receipt,
                    referral_receipt_key,
                    str(exc),
                )
            print(
                f"[WTSL Betting] winner DM failed for {user_id}: {exc}",
                flush=True,
            )
        else:
            await asyncio.to_thread(mark_notification_sent, receipt_key)
            if first_win and referral_prompt_claimed:
                await asyncio.to_thread(
                    mark_notification_sent,
                    referral_receipt_key,
                )


async def _process_wtsl_refund_notifications() -> None:
    """Deliver catch-up-safe DMs explaining refunded WTSL tickets."""
    try:
        rows = await asyncio.to_thread(list_unnotified_refunded_bets, 100)
    except Exception as exc:
        print(
            f"[WTSL Betting] refund notification query failed: {exc}",
            flush=True,
        )
        return
    for row in rows:
        user_id = int(row["discord_user_id"])
        receipt_key = f"refund:{row['kind']}:{int(row['ticket_id'])}"
        claimed = await asyncio.to_thread(
            claim_notification_receipt,
            receipt_key,
            recipient_user_id=user_id,
            notification_type="refund",
        )
        if not claimed:
            continue
        if row["kind"] == "single":
            match_text = (
                f"{row.get('player_one')} vs {row.get('player_two')} "
                f"({row.get('tournament')})"
            )
            if row.get("winner_id"):
                reason = (
                    "No bet backed the official winner, so the fixture had "
                    "no eligible winner-side pool."
                )
            else:
                reason = (
                    "The fixture had no official winner, so the stake was "
                    "returned rather than settled as a win or loss."
                )
        else:
            match_text = str(row.get("selection_name") or "Parlay")
            reason = (
                "At least one parlay leg had no official winner, so the "
                "parlay stake was returned."
            )
        content = (
            "↩️ **Your WTSL bet was refunded.**\n"
            f"Ticket: **{match_text}**\n"
            f"Reason: {reason}\n"
            f"Stake returned: **{_wtsl_dollars(row['return_amount'])}**\n"
            f"Your balance is now **{_wtsl_dollars(row['balance'])}**."
        )
        try:
            user = await client.fetch_user(user_id)
            await user.send(content)
        except Exception as exc:
            await asyncio.to_thread(
                release_notification_receipt,
                receipt_key,
                str(exc),
            )
            print(
                f"[WTSL Betting] refund DM failed for {user_id}: {exc}",
                flush=True,
            )
        else:
            await asyncio.to_thread(mark_notification_sent, receipt_key)


async def _process_wtsl_referral_rewards() -> None:
    try:
        await asyncio.to_thread(settle_referral_rewards)
        rows = await asyncio.to_thread(list_unnotified_referral_rewards, 50)
    except Exception as exc:
        print(f"[WTSL Betting] referral reward processing failed: {exc}", flush=True)
        return
    for row in rows:
        receipt_key = f"referral-reward:{int(row['reward_id'])}"
        user_id = int(row["referrer_user_id"])
        claimed = await asyncio.to_thread(
            claim_notification_receipt,
            receipt_key,
            recipient_user_id=user_id,
            notification_type="referral_reward",
        )
        if not claimed:
            continue
        try:
            user = await client.fetch_user(user_id)
            await user.send(
                "🎁 **WTSL referral reward credited!**\n"
                f"Your referral of **{row['player_name']}** completed their "
                f"first qualifying winning bet. **{_wtsl_dollars(row['amount'])}** "
                "has been added to your W$ balance."
            )
        except Exception as exc:
            await asyncio.to_thread(
                release_notification_receipt,
                receipt_key,
                str(exc),
            )
            print(
                f"[WTSL Betting] referral reward DM failed for {user_id}: {exc}",
                flush=True,
            )
        else:
            await asyncio.to_thread(mark_notification_sent, receipt_key)


async def _process_wtsl_referral_reminders() -> None:
    try:
        rows = await asyncio.to_thread(claim_pending_referral_reminders, 25)
    except Exception as exc:
        print(
            f"[WTSL Betting] referral reminder query failed: {exc}",
            flush=True,
        )
        return
    if not rows:
        return
    try:
        owner = await client.fetch_user(OWNER_ID)
    except Exception as exc:
        print(f"[WTSL Betting] referral reminder owner lookup failed: {exc}", flush=True)
        return
    for row in rows:
        await owner.send(
            f"<@{OWNER_ID}> 🔗 **WTSL referral verification reminder**\n"
            f"Referrer: <@{int(row['referrer_user_id'])}>\n"
            f"Exact ranked player: **{str(row['tour']).upper()}: "
            f"{row['player_name']}**\n"
            "This referral is waiting for an admin-approved Discord identity. "
            "Run `/linkmatchlogplayer`, select the member, and enter the exact "
            "ATP/WTA player name. The reminder will repeat every three hours "
            "until the identity is linked.",
            allowed_mentions=discord.AllowedMentions(
                users=True,
                roles=False,
                everyone=False,
            ),
        )


async def _wtsl_previous_week_bounds() -> tuple[datetime, datetime]:
    """Return the completed Monday-to-Monday UTC reporting window."""
    now = datetime.now(timezone.utc)
    current_start = (now - timedelta(days=now.weekday())).replace(
        hour=0, minute=0, second=0, microsecond=0
    )
    return current_start - timedelta(days=7), current_start


def _wtsl_weekly_message_content(
    weekly: dict[str, typing.Any] | None,
    period_label: str,
) -> str:
    if weekly:
        record = (
            f"{int(weekly['successful_bets'])}W / "
            f"{int(weekly['failed_bets'])}L"
        )
        refunded_bets = int(weekly.get("refunded_bets") or 0)
        if refunded_bets:
            record += f" / {refunded_bets}R"
        return (
            f"🎉 Congratulations <@{int(weekly['discord_user_id'])}> — "
            f"you topped {period_label} betting leaderboard with "
            f"**{_wtsl_dollars(weekly['total_profit'])} profit**!\n"
            f"Record: **{record}**."
        )
    return "No positive betting earnings were recorded for this period."


async def _upsert_wtsl_weekly_message(
    channel,
    *,
    publish: bool,
) -> None:
    """Keep the weekly message below the layout without announcing early."""
    async with _wtsl_weekly_message_lock:
        weekly = None
        weekly_content = ""
        if publish:
            period_start, period_end = await _wtsl_previous_week_bounds()
            weekly = await asyncio.to_thread(
                weekly_betting_earner,
                period_start,
                period_end,
            )
            weekly_content = _wtsl_weekly_message_content(
                weekly,
                "last week's",
            )

        weekly_stored = await asyncio.to_thread(
            load_bot_message,
            WTSL_BETTING_WEEKLY_MESSAGE_KEY,
        )
        weekly_message = None
        if weekly_stored and weekly_stored[0] == channel.id:
            try:
                weekly_message = await channel.fetch_message(weekly_stored[1])
            except discord.NotFound:
                weekly_message = None

        if weekly_message is None:
            async for message in channel.history(limit=100):
                if (
                    getattr(getattr(message, "author", None), "id", None)
                    != getattr(client.user, "id", None)
                ):
                    continue
                if any(
                    embed.title == WTSL_BETTING_WEEKLY_LEGACY_TITLE
                    for embed in getattr(message, "embeds", [])
                ):
                    weekly_message = message
                    break

        if weekly_message is None and not publish:
            return

        layout_ids: list[int] = []
        async for message in channel.history(limit=None):
            if (
                getattr(getattr(message, "author", None), "id", None)
                != getattr(client.user, "id", None)
            ):
                continue
            titles = {
                getattr(embed, "title", None)
                for embed in getattr(message, "embeds", [])
            }
            if (
                _wtsl_message_has_managed_fixture_embed(message)
                or titles & WTSL_BETTING_SUMMARY_TITLES
                or _wtsl_has_managed_components(
                    getattr(message, "components", None)
                )
            ):
                layout_ids.append(int(message.id))

        if weekly_message is not None and layout_ids:
            if int(weekly_message.id) <= max(layout_ids):
                old_content = str(
                    getattr(weekly_message, "content", "") or ""
                ).strip()
                if not old_content:
                    old_content = next(
                        (
                            str(getattr(embed, "description", "") or "").strip()
                            for embed in getattr(weekly_message, "embeds", [])
                            if getattr(embed, "description", None)
                        ),
                        "",
                    )
                try:
                    await weekly_message.delete()
                except discord.NotFound:
                    pass
                weekly_message = None
                if old_content and not publish:
                    weekly_content = old_content

        if weekly_message is None:
            if not publish and not weekly_content:
                return
            weekly_message = await channel.send(
                content=weekly_content,
                allowed_mentions=discord.AllowedMentions(
                    users=True,
                    roles=False,
                    everyone=False,
                ),
            )
        elif (
            publish
            and (
                str(getattr(weekly_message, "content", "") or "")
                != weekly_content
                or bool(getattr(weekly_message, "embeds", []) or [])
            )
        ):
            await weekly_message.edit(
                content=weekly_content,
                embed=None,
                allowed_mentions=discord.AllowedMentions(
                    users=True,
                    roles=False,
                    everyone=False,
                ),
            )
        elif (
            not publish
            and bool(getattr(weekly_message, "embeds", []) or [])
        ):
            await weekly_message.edit(
                content=str(
                    getattr(weekly_message, "content", "") or ""
                ).strip()
                or next(
                    (
                        str(getattr(embed, "description", "") or "").strip()
                        for embed in getattr(weekly_message, "embeds", [])
                        if getattr(embed, "description", None)
                    ),
                    "No positive betting earnings were recorded last week.",
                ),
                embed=None,
                allowed_mentions=discord.AllowedMentions(
                    users=True,
                    roles=False,
                    everyone=False,
                ),
            )

        await asyncio.to_thread(
            save_bot_message,
            WTSL_BETTING_WEEKLY_MESSAGE_KEY,
            channel.id,
            weekly_message.id,
        )


async def _post_wtsl_weekly_message_now() -> None:
    """Publish the completed prior week's betting winner on the weekly schedule."""
    await client.wait_until_ready()
    try:
        channel = await _get_wtsl_betting_channel()
        if channel is not None:
            await _upsert_wtsl_weekly_message(
                channel,
                publish=True,
            )
    except Exception as exc:
        print(
            f"[WTSL Betting] Scheduled weekly message failed: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )


def _wtsl_embed_signature(embeds: typing.Iterable[typing.Any]) -> tuple[str, ...]:
    return tuple(
        json.dumps(
            embed.to_dict(),
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        )
        for embed in embeds
    )


def _wtsl_component_signature(
    components_or_view: typing.Any,
) -> tuple[tuple[str, str, bool], ...]:
    if components_or_view is None:
        return ()
    if hasattr(components_or_view, "children"):
        children = list(getattr(components_or_view, "children", []) or [])
    else:
        children = []
        for row in components_or_view or []:
            children.extend(
                getattr(row, "children", None)
                or getattr(row, "components", None)
                or [row]
            )
    return tuple(
        (
            str(getattr(child, "custom_id", "") or ""),
            str(getattr(child, "label", "") or ""),
            bool(getattr(child, "disabled", False)),
        )
        for child in children
    )


def _wtsl_component_ids(components_or_view: typing.Any) -> tuple[str, ...]:
    """Flatten Discord action rows without relying on one library shape."""
    if components_or_view is None:
        return ()
    if hasattr(components_or_view, "children"):
        rows = [components_or_view]
    else:
        rows = list(components_or_view or [])
    ids: list[str] = []
    for row in rows:
        children = getattr(row, "children", None)
        if not children:
            children = getattr(row, "components", None)
        if not children:
            children = [row]
        for child in children:
            custom_id = str(getattr(child, "custom_id", "") or "")
            if custom_id:
                ids.append(custom_id)
    return tuple(ids)


def _wtsl_has_managed_components(message: typing.Any) -> bool:
    return any(
        custom_id.startswith(("wtsl_bet:v1:", "wtsl_bet_parlay_"))
        for custom_id in _wtsl_component_ids(
            getattr(message, "components", None)
        )
    )


def _wtsl_message_needs_embed_update(
    message: typing.Any,
    embeds: typing.Iterable[typing.Any],
) -> bool:
    return _wtsl_embed_signature(getattr(message, "embeds", []) or []) != (
        _wtsl_embed_signature(embeds)
    )


def _wtsl_message_needs_component_update(
    message: typing.Any,
    view: typing.Any,
) -> bool:
    return _wtsl_component_signature(
        getattr(message, "components", []) or []
    ) != _wtsl_component_signature(view)


async def _upsert_wtsl_betting_messages(
    channel,
    fixtures: list[dict],
) -> None:
    """Serialize complete betting-layout edits with targeted stake refreshes."""
    async with _betting_message_update_lock:
        await _upsert_wtsl_betting_messages_unlocked(channel, fixtures)


async def _upsert_wtsl_betting_messages_unlocked(
    channel,
    fixtures: list[dict],
) -> None:
    layout = await asyncio.to_thread(
        load_bot_message,
        WTSL_BETTING_LAYOUT_MESSAGE_KEY,
    )
    if not layout or layout[0] != channel.id:
        async for message in channel.history(limit=None):
            if getattr(getattr(message, "author", None), "id", None) != getattr(
                client.user, "id", None
            ):
                continue
            managed = (
                _wtsl_message_has_managed_fixture_embed(message)
                or bool(
                    {
                        getattr(embed, "title", None)
                        for embed in message.embeds
                    }
                    & WTSL_BETTING_SUMMARY_TITLES
                )
            )
            if managed:
                try:
                    await message.delete()
                except discord.NotFound:
                    pass
        await asyncio.to_thread(
            save_bot_message,
            WTSL_BETTING_LAYOUT_MESSAGE_KEY,
            channel.id,
            channel.id,
        )

    # Older versions posted the leaderboard and results as separate embeds.
    # Remove those legacy messages now that both sections live on page 1.
    async for message in channel.history(limit=None):
        if getattr(getattr(message, "author", None), "id", None) != getattr(
            client.user, "id", None
        ):
            continue
        titles = {
            getattr(embed, "title", None)
            for embed in message.embeds
        }
        if titles & WTSL_BETTING_SUMMARY_TITLES:
            try:
                await message.delete()
            except discord.NotFound:
                pass

    leaderboard_rows = await asyncio.to_thread(get_betting_leaderboard, 10)
    loser_rows = await asyncio.to_thread(
        get_betting_leaderboard,
        10,
        losers_only=True,
    )
    result_rows = await asyncio.to_thread(list_recent_settled_fixtures, 10)

    # Keep fixture embeds together at the top of the channel. Their buttons
    # are posted afterward so a later fixture page never appears below an
    # earlier page's controls.
    page_size = 4
    pages = [
        fixtures[index:index + page_size]
        for index in range(0, len(fixtures), page_size)
    ] or [[]]
    page_count = len(pages)
    kept_fixture_message_ids: set[int] = set()
    for page_index, page in enumerate(pages):
        page_number = page_index + 1
        key = f"{WTSL_BETTING_FIXTURE_MESSAGE_PREFIX}{page_index}"
        title = _wtsl_betting_fixture_page_title(page_number)
        stored = await asyncio.to_thread(load_bot_message, key)
        existing = None
        if stored and stored[0] == channel.id:
            try:
                existing = await channel.fetch_message(stored[1])
            except discord.NotFound:
                existing = None
        if existing is None:
            async for message in channel.history(limit=100):
                if (
                    getattr(getattr(message, "author", None), "id", None)
                    == getattr(client.user, "id", None)
                    and title is not None
                    and any(embed.title == title for embed in message.embeds)
                ):
                    existing = message
                    break
        embeds, view = _build_wtsl_betting_page(
            page,
            page_number,
            page_count,
            leaderboard_rows=(
                leaderboard_rows if page_index == page_count - 1 else None
            ),
            loser_rows=(
                loser_rows if page_index == page_count - 1 else None
            ),
            result_rows=(
                result_rows if page_index == page_count - 1 else None
            ),
            include_fixture_buttons=False,
            include_account_controls=False,
        )
        if existing is None:
            existing = await channel.send(
                embeds=embeds,
                view=view,
                allowed_mentions=discord.AllowedMentions.none(),
            )
        elif (
            _wtsl_message_needs_embed_update(existing, embeds)
            or _wtsl_message_needs_component_update(existing, view)
        ):
            await existing.edit(embeds=embeds, view=view)
        kept_fixture_message_ids.add(int(existing.id))
        await asyncio.to_thread(
            save_bot_message,
            key,
            channel.id,
            existing.id,
        )

    async for message in channel.history(limit=None):
        if getattr(getattr(message, "author", None), "id", None) != getattr(
            client.user, "id", None
        ):
            continue
        if (
            int(getattr(message, "id", 0) or 0) not in kept_fixture_message_ids
            and _wtsl_message_has_managed_fixture_embed(message)
        ):
            try:
                await message.delete()
            except discord.NotFound:
                pass

    # Editing an existing control message does not move it in the channel.
    # When new fixture pages are appended, or older pages are repaired in
    # place, controls can therefore end up between fixture embeds. If the
    # current message IDs no longer form one fixture block followed by one
    # control block, delete all managed controls and repost them below every
    # kept fixture page.
    existing_control_messages: list[typing.Any] = []
    async for message in channel.history(limit=None):
        if (
            getattr(getattr(message, "author", None), "id", None)
            == getattr(client.user, "id", None)
            and _wtsl_has_managed_components(message)
        ):
            existing_control_messages.append(message)
    rebuild_control_messages = bool(
        existing_control_messages
        and kept_fixture_message_ids
        and min(int(message.id) for message in existing_control_messages)
        <= max(kept_fixture_message_ids)
    )
    if rebuild_control_messages:
        print(
            "[WTSL Betting] rebuilding controls after fixture pages",
            flush=True,
        )

    kept_control_message_ids: set[int] = set()
    fixture_control_message_ids: set[int] = set()

    async def upsert_control_message(
        key: str,
        view: discord.ui.View,
    ) -> typing.Any:
        stored = await asyncio.to_thread(load_bot_message, key)
        existing = None
        if not rebuild_control_messages and stored and stored[0] == channel.id:
            try:
                existing = await channel.fetch_message(stored[1])
            except discord.NotFound:
                existing = None
        if existing is None:
            existing = await channel.send(
                view=view,
                allowed_mentions=discord.AllowedMentions.none(),
            )
        elif _wtsl_message_needs_component_update(existing, view):
            await existing.edit(view=view)
        kept_control_message_ids.add(int(existing.id))
        await asyncio.to_thread(
            save_bot_message,
            key,
            channel.id,
            existing.id,
        )
        return existing

    async def remove_stored_message(key: str) -> None:
        stored = await asyncio.to_thread(load_bot_message, key)
        if not stored or stored[0] != channel.id:
            return
        try:
            message = await channel.fetch_message(stored[1])
        except discord.NotFound:
            return
        try:
            await message.delete()
        except discord.NotFound:
            pass

    # Discord allows five component rows per message. Put all fixture
    # buttons into control messages after every fixture embed, then append
    # account-level controls after the final fixture button row.
    control_chunks = [
        fixtures[index:index + 5]
        for index in range(0, len(fixtures), 5)
    ]
    for control_index, control_chunk in enumerate(control_chunks):
        is_last_chunk = control_index == len(control_chunks) - 1
        include_account_controls = is_last_chunk and len(control_chunk) < 5
        view = _build_wtsl_betting_controls(
            control_chunk,
            include_account_controls=include_account_controls,
        )
        control_message = await upsert_control_message(
            f"{WTSL_BETTING_CONTROL_MESSAGE_PREFIX}{control_index}",
            view,
        )
        fixture_control_message_ids.add(int(control_message.id))

    if control_chunks and len(control_chunks[-1]) == 5:
        action_view = discord.ui.View(timeout=None)
        _add_wtsl_account_controls(action_view)
        action_message = await upsert_control_message(
            WTSL_BETTING_ACTION_MESSAGE_KEY,
            action_view,
        )
        if (
            fixture_control_message_ids
            and int(action_message.id)
            <= max(fixture_control_message_ids)
        ):
            # Editing a message does not change its channel position. Move
            # the account actions after the final fixture-control message so
            # odds refreshes cannot leave them stranded in the middle.
            old_action_id = int(action_message.id)
            try:
                await action_message.delete()
            except (discord.NotFound, discord.Forbidden):
                pass
            else:
                action_message = await channel.send(
                    view=action_view,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                kept_control_message_ids.discard(old_action_id)
                kept_control_message_ids.add(int(action_message.id))
                await asyncio.to_thread(
                    save_bot_message,
                    WTSL_BETTING_ACTION_MESSAGE_KEY,
                    channel.id,
                    action_message.id,
                )
    else:
        await remove_stored_message(WTSL_BETTING_ACTION_MESSAGE_KEY)

    for stale_index in range(len(control_chunks), 20):
        await remove_stored_message(
            f"{WTSL_BETTING_CONTROL_MESSAGE_PREFIX}{stale_index}"
        )

    # A prior deployment may have posted the same controls under a different
    # stored-message key. Keep only the controls created or edited above.
    async for message in channel.history(limit=None):
        if (
            getattr(getattr(message, "author", None), "id", None)
            != getattr(client.user, "id", None)
            or int(getattr(message, "id", 0) or 0) in kept_control_message_ids
        ):
            continue
        if _wtsl_has_managed_components(message):
            try:
                await message.delete()
            except (discord.NotFound, discord.Forbidden):
                pass

    # Keep an existing weekly message below every betting embed and control.
    # Its content is published only by the Monday weekly update.
    await _upsert_wtsl_weekly_message(channel, publish=False)

async def _refresh_wtsl_betting() -> None:
    async with _betting_channel_lock:
        await _refresh_wtsl_betting_unlocked()


async def _refresh_wtsl_betting_messages_only() -> None:
    """Refresh betting messages from the latest persisted pool totals."""
    async with _betting_channel_lock:
        try:
            fixtures = await asyncio.to_thread(list_open_betting_fixtures)
            _remember_betting_fixtures(fixtures)
            channel = await _get_wtsl_betting_channel()
            if channel is None:
                return
            await _upsert_wtsl_betting_messages(channel, fixtures)
        except Exception as exc:
            print(
                f"[WTSL Betting] immediate pool refresh failed: "
                f"{type(exc).__name__}: {exc}",
                flush=True,
            )


async def _refresh_wtsl_fixture_messages_unlocked(fixture_key: str) -> None:
    """Update the affected fixture, then reconcile the complete betting layout."""
    try:
        fixtures = await asyncio.to_thread(list_open_betting_fixtures)
        _remember_betting_fixtures(fixtures)
        target_index = next(
            (
                index
                for index, fixture in enumerate(fixtures)
                if str(fixture.get("key")) == str(fixture_key)
            ),
            None,
        )
        if target_index is None:
            print(
                f"[WTSL Betting] targeted pool refresh skipped; "
                f"fixture {fixture_key} is no longer open",
                flush=True,
            )
            return
        channel = await _get_wtsl_betting_channel()
        if channel is None:
            print(
                "[WTSL Betting] targeted pool refresh skipped; betting "
                "channel unavailable",
                flush=True,
            )
            return

        page_size = 4
        page_index = target_index // page_size
        page = fixtures[page_index * page_size:(page_index + 1) * page_size]
        page_count = max(1, math.ceil(len(fixtures) / page_size))
        leaderboard_rows = None
        loser_rows = None
        result_rows = None
        if page_index == page_count - 1:
            leaderboard_rows = await asyncio.to_thread(
                get_betting_leaderboard,
                10,
            )
            loser_rows = await asyncio.to_thread(
                get_betting_leaderboard,
                10,
                losers_only=True,
            )
            result_rows = await asyncio.to_thread(
                list_recent_settled_fixtures,
                10,
            )
        embeds, _ = _build_wtsl_betting_page(
            page,
            page_index + 1,
            page_count,
            leaderboard_rows=leaderboard_rows,
            loser_rows=loser_rows,
            result_rows=result_rows,
            include_fixture_buttons=False,
            include_account_controls=False,
        )

        history_messages: list[typing.Any] | None = None

        async def load_history_messages() -> list[typing.Any]:
            nonlocal history_messages
            if history_messages is None:
                history_messages = [
                    message async for message in channel.history(limit=None)
                ]
            return history_messages

        async def find_fixture_page_message() -> typing.Any | None:
            target = _repair_wtsl_fixture_player_fields(
                fixtures[target_index]
            )
            first_name = str(target.get("first_name") or "").casefold()
            second_name = str(target.get("second_name") or "").casefold()
            tournament = str(target.get("tournament") or "").casefold()
            if not first_name or not second_name:
                return None
            bot_user_id = getattr(client.user, "id", None)
            for candidate in await load_history_messages():
                if (
                    getattr(getattr(candidate, "author", None), "id", None)
                    != bot_user_id
                ):
                    continue
                embed_text = " ".join(
                    str(value or "")
                    for embed in getattr(candidate, "embeds", [])
                    for value in (
                        getattr(embed, "title", None),
                        getattr(embed, "description", None),
                        *[
                            field_value
                            for field in getattr(embed, "fields", [])
                            for field_value in (
                                getattr(field, "name", None),
                                getattr(field, "value", None),
                            )
                        ],
                    )
                ).casefold()
                if (
                    first_name in embed_text
                    and second_name in embed_text
                    and (not tournament or tournament in embed_text)
                ):
                    return candidate
            return None

        page_stored = await asyncio.to_thread(
            load_bot_message,
            f"{WTSL_BETTING_FIXTURE_MESSAGE_PREFIX}{page_index}",
        )
        page_message = None
        if page_stored and page_stored[0] == channel.id:
            try:
                page_message = await channel.fetch_message(page_stored[1])
            except (discord.NotFound, discord.Forbidden):
                page_message = None
        if page_message is None:
            page_message = await find_fixture_page_message()
        if page_message is not None:
            try:
                await asyncio.wait_for(
                    page_message.edit(embeds=embeds),
                    timeout=12,
                )
                await asyncio.to_thread(
                    save_bot_message,
                    f"{WTSL_BETTING_FIXTURE_MESSAGE_PREFIX}{page_index}",
                    channel.id,
                    page_message.id,
                )
                print(
                    f"[WTSL Betting] targeted fixture page refreshed "
                    f"for {fixture_key}",
                    flush=True,
                )
            except (discord.NotFound, discord.Forbidden):
                print(
                    "[WTSL Betting] targeted fixture page message "
                    "missing or inaccessible",
                    flush=True,
                )
            except asyncio.TimeoutError:
                print(
                    "[WTSL Betting] targeted fixture page edit timed out",
                    flush=True,
                )
        else:
            print(
                "[WTSL Betting] targeted fixture page could not be found "
                "in the fixed channel",
                flush=True,
            )

        control_chunks = [
            fixtures[index:index + 5]
            for index in range(0, len(fixtures), 5)
        ]
        control_index = next(
            (
                index
                for index, chunk in enumerate(control_chunks)
                if any(
                    str(item.get("key")) == str(fixture_key)
                    for item in chunk
                )
            ),
            None,
        )
        if control_index is None:
            return
        is_last_chunk = control_index == len(control_chunks) - 1
        include_account_controls = is_last_chunk and len(
            control_chunks[control_index]
        ) < 5
        view = _build_wtsl_betting_controls(
            control_chunks[control_index],
            include_account_controls=include_account_controls,
        )
        control_stored = await asyncio.to_thread(
            load_bot_message,
            f"{WTSL_BETTING_CONTROL_MESSAGE_PREFIX}{control_index}",
        )
        control_message = None
        if control_stored and control_stored[0] == channel.id:
            try:
                control_message = await channel.fetch_message(control_stored[1])
            except (discord.NotFound, discord.Forbidden):
                control_message = None
        if control_message is None:
            target_custom_id = (
                f"wtsl_bet:v1:{_betting_fixture_token(str(fixture_key))}:"
            )
            for candidate in await load_history_messages():
                if (
                    getattr(getattr(candidate, "author", None), "id", None)
                    != getattr(client.user, "id", None)
                ):
                    continue
                custom_ids = _wtsl_component_ids(
                    getattr(candidate, "components", None)
                )
                if any(
                    custom_id.startswith(target_custom_id)
                    for custom_id in custom_ids
                ):
                    control_message = candidate
                    break
        if control_message is not None:
            try:
                await asyncio.wait_for(
                    control_message.edit(view=view),
                    timeout=12,
                )
                await asyncio.to_thread(
                    save_bot_message,
                    f"{WTSL_BETTING_CONTROL_MESSAGE_PREFIX}{control_index}",
                    channel.id,
                    control_message.id,
                )
                print(
                    f"[WTSL Betting] targeted fixture buttons refreshed "
                    f"for {fixture_key}",
                    flush=True,
                )
            except (discord.NotFound, discord.Forbidden):
                print(
                    "[WTSL Betting] targeted fixture buttons message "
                    "missing or inaccessible",
                    flush=True,
                )
            except asyncio.TimeoutError:
                print(
                    "[WTSL Betting] targeted fixture buttons edit timed out",
                    flush=True,
                )
        else:
            print(
                "[WTSL Betting] targeted fixture buttons have no stored "
                "message for the active channel",
                flush=True,
            )

        # The targeted edit above is fast, but it cannot remove duplicate
        # control messages left by an older deployment or a stale message
        # reference. Reconcile the complete persisted layout before releasing
        # the message-update lock so the odds embed and every button group
        # agree on the same pool totals.
        await _upsert_wtsl_betting_messages_unlocked(channel, fixtures)
        print(
            f"[WTSL Betting] complete betting layout reconciled after "
            f"fixture {fixture_key} bet",
            flush=True,
        )
    except Exception as exc:
        print(
            f"[WTSL Betting] targeted pool refresh failed: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )


async def _refresh_wtsl_fixture_messages(fixture_key: str) -> None:
    """Serialize targeted edits so concurrent accepted bets cannot overwrite them."""
    async with _betting_target_refresh_lock:
        async with _betting_message_update_lock:
            await _refresh_wtsl_fixture_messages_unlocked(fixture_key)


async def _refresh_wtsl_betting_unlocked() -> None:
    await _seed_verified_wtsl_accounts()
    fixtures = await _fetch_and_sync_betting_fixtures()
    settled = await _settle_open_wtsl_bets()
    await _process_wtsl_referral_rewards()
    await _process_wtsl_refund_notifications()
    await _process_wtsl_winner_notifications()
    await _process_wtsl_referral_reminders()
    if settled:
        try:
            fixtures = await asyncio.to_thread(list_open_betting_fixtures)
            _remember_betting_fixtures(fixtures)
        except Exception as exc:
            print(
                f"[WTSL Betting] refreshed open fixtures after settlement failed: "
                f"{exc}",
                flush=True,
            )
    channel = await _get_wtsl_betting_channel()
    if channel is None:
        return
    await _upsert_wtsl_betting_messages(channel, fixtures)
    print(
        f"[WTSL Betting] refreshed {len(fixtures)} open fixture(s) "
        f"in #{channel.name}",
        flush=True,
    )
    if settled:
        print(f"[WTSL Betting] settled {settled} fixture(s)", flush=True)


async def _clear_wtsl_betting_messages_for_reset() -> int:
    """Delete bot-managed betting messages before a one-shot test reset."""
    channel = await _get_wtsl_betting_channel()
    if channel is None:
        raise RuntimeError("fixed WTSL betting channel is unavailable")
    bot_user_id = getattr(client.user, "id", None)
    deleted = 0
    async for message in channel.history(limit=None):
        if getattr(getattr(message, "author", None), "id", None) != bot_user_id:
            continue
        titles = {
            getattr(embed, "title", None)
            for embed in getattr(message, "embeds", [])
        }
        managed_embed = (
            _wtsl_message_has_managed_fixture_embed(message)
            or bool(titles & WTSL_BETTING_SUMMARY_TITLES)
        )
        if not managed_embed and not _wtsl_has_managed_components(message):
            continue
        try:
            await message.delete()
            deleted += 1
        except discord.NotFound:
            pass
    return deleted


async def _wtsl_betting_loop() -> None:
    await client.wait_until_ready()
    if not getattr(client, "_wtsl_betting_reset_checked", False):
        client._wtsl_betting_reset_checked = True
        if os.environ.get("WTSL_BETTING_RESET_ON_STARTUP"):
            print(
                "[WTSL Betting] ignored startup reset request; "
                "automatic restarts must never clear betting history. "
                "Use /wtslreset confirm:true for an explicit reset.",
                flush=True,
            )
        if os.environ.get("WTSL_BETTING_REBUILD_MESSAGES_ON_STARTUP") == "1":
            try:
                deleted_messages = await _clear_wtsl_betting_messages_for_reset()
                print(
                    "[WTSL Betting] one-time message rebuild cleanup completed; "
                    f"deleted {deleted_messages} old betting message(s)",
                    flush=True,
                )
            except Exception as exc:
                print(
                    f"[WTSL Betting] one-time message rebuild cleanup failed: "
                    f"{type(exc).__name__}: {exc}",
                    flush=True,
                )
    first_refresh = True
    while not client.is_closed():
        try:
            await _refresh_wtsl_betting()
            if first_refresh:
                print(
                    "[WTSL Betting] startup layout refresh completed once "
                    "in the fixed betting channel",
                    flush=True,
                )
                first_refresh = False
        except Exception as exc:
            print(
                f"[WTSL Betting] refresh failed: {type(exc).__name__}: {exc}",
                flush=True,
            )
        await asyncio.sleep(WTSL_BETTING_REFRESH_SECONDS)


def _parlay_combined_odds(legs: list[dict[str, typing.Any]]) -> Decimal:
    combined = Decimal("1")
    for leg in legs:
        combined *= Decimal(str(leg["odds"]))
    return combined.quantize(Decimal("0.001"))


WTSL_LIVE_BETTING_BLOCK_MESSAGE = (
    "That official WTSL match is currently ongoing and cannot be bet on."
)
WTSL_LIVE_BETTING_UNAVAILABLE_MESSAGE = (
    "The official live feed could not be checked, so this bet was not placed. "
    "Please try again in a moment."
)
WTSL_PLAYED_BETTING_BLOCK_MESSAGE = (
    "That WTSL match has already been reported as played in "
    "#te4-results, so betting is closed. Settlement will wait for the "
    "official WTSL/Challonge result."
)
WTSL_BETTING_SAFEGUARD_UNAVAILABLE_MESSAGE = (
    "The official live feed or TE4 results channel could not be checked, "
    "so this bet was not placed. Please try again in a moment."
)
WTSL_RESULT_LOOKBACK_HOURS = 7 * 24


def _wtsl_live_player_key(value: typing.Any) -> str:
    return " ".join(str(value or "").casefold().split())


def _wtsl_fixture_is_currently_live(
    fixture: dict[str, typing.Any],
    live_matches: list[dict[str, typing.Any]],
) -> bool:
    """Match a betting fixture to an official current WTSL BO3/BO5 match."""
    fixture_players = {
        _wtsl_live_player_key(fixture.get("first_name")),
        _wtsl_live_player_key(fixture.get("second_name")),
    }
    if len(fixture_players) != 2 or "" in fixture_players:
        return False
    for match in live_matches:
        if match.get("best_of") not in {"Best of 3", "Best of 5"}:
            continue
        if "xkt(wtsl)" not in str(match.get("message", "")).casefold():
            continue
        players = match.get("players") or []
        if len(players) < 2:
            continue
        match_players = {
            _wtsl_live_player_key(players[0]),
            _wtsl_live_player_key(players[1]),
        }
        if match_players == fixture_players:
            return True
    return False


def _wtsl_betting_tour_key(value: typing.Any) -> str:
    normalized = normalize_matchlog_name(value)
    raw = str(value or "").strip().casefold()
    if (
        "wta" in normalized
        or "female" in normalized
        or raw.endswith("(f)")
        or raw.endswith("_f")
        or raw.endswith(" f")
    ):
        return "wta"
    return "atp"


def _wtsl_result_name_matches(left: typing.Any, right: typing.Any) -> bool:
    left_key = normalize_matchlog_name(left)
    right_key = normalize_matchlog_name(right)
    if not left_key or not right_key:
        return False
    return (
        left_key == right_key
        or left_key in right_key
        or right_key in left_key
    )


def _wtsl_result_message_is_match(message: typing.Any) -> bool:
    if getattr(getattr(message, "author", None), "bot", False):
        return False
    mentions = [
        mention for mention in getattr(message, "mentions", [])
        if not getattr(mention, "bot", False)
    ]
    if len(mentions) < 2:
        return False
    content = str(getattr(message, "content", "") or "")
    if re.search(r"\b(?:heads|tails)\b", content, re.IGNORECASE):
        return False
    return bool(
        getattr(message, "attachments", None)
        or re.search(r"\bdef(?:eated)?\.?\b", content, re.IGNORECASE)
    )


def _wtsl_result_message_tour(message: typing.Any) -> str | None:
    content = str(getattr(message, "content", "") or "")
    if re.search(r"\bwta\b", content, re.IGNORECASE):
        return "wta"
    if re.search(r"\batp\b", content, re.IGNORECASE):
        return "atp"
    return None


def _wtsl_result_message_matches_fixture(
    message: typing.Any,
    fixture: dict[str, typing.Any],
    verified_links_by_user: dict[int, dict[str, str]],
) -> bool:
    """Match a TE4 result post to a fixture without settling it.

    Verified tour-scoped identities are authoritative. Discord display names
    and usernames are only used as a fallback for users without a verified
    identity, which supports legacy aliases such as Kumi/Iakumi.
    """
    tour = _wtsl_betting_tour_key(fixture.get("tour"))
    message_tour = _wtsl_result_message_tour(message)
    if message_tour is not None and message_tour != tour:
        return False
    fixture_players = (
        str(fixture.get("first_name") or ""),
        str(fixture.get("second_name") or ""),
    )
    mentions = [
        mention for mention in getattr(message, "mentions", [])
        if not getattr(mention, "bot", False)
    ]
    if len(mentions) < 2 or not all(fixture_players):
        return False

    mention_candidates: list[set[str]] = []
    for mention in mentions:
        user_id = int(getattr(mention, "id", 0) or 0)
        verified = (verified_links_by_user.get(user_id) or {}).get(tour)
        if verified:
            candidates = {str(verified)}
        else:
            candidates = {
                str(getattr(mention, attr, "") or "")
                for attr in ("name", "global_name", "display_name")
            }
            candidates.discard("")
        mention_candidates.append(candidates)

    first_matches = [
        index for index, candidates in enumerate(mention_candidates)
        if any(
            _wtsl_result_name_matches(candidate, fixture_players[0])
            for candidate in candidates
        )
    ]
    second_matches = [
        index for index, candidates in enumerate(mention_candidates)
        if any(
            _wtsl_result_name_matches(candidate, fixture_players[1])
            for candidate in candidates
        )
    ]
    return any(first != second for first in first_matches for second in second_matches)


async def _wtsl_recent_te4_result_posts() -> list[dict[str, typing.Any]]:
    channel = client.get_channel(TE4_RESULTS_CHANNEL_ID)
    if channel is None:
        channel = await client.fetch_channel(TE4_RESULTS_CHANNEL_ID)
    cutoff = datetime.now(timezone.utc) - timedelta(
        hours=WTSL_RESULT_LOOKBACK_HOURS
    )
    candidates = []
    async for message in channel.history(
        limit=None,
        after=cutoff,
        oldest_first=True,
    ):
        if _wtsl_result_message_is_match(message):
            candidates.append(message)

    verified_links_by_user: dict[int, dict[str, str]] = {}
    for message in candidates:
        for mention in getattr(message, "mentions", []):
            if getattr(mention, "bot", False):
                continue
            user_id = int(getattr(mention, "id", 0) or 0)
            if not user_id or user_id in verified_links_by_user:
                continue
            links = dict(_matchlog_links(user_id))
            if not links:
                try:
                    links = await asyncio.to_thread(
                        load_matchlog_identity,
                        user_id,
                    )
                except Exception as exc:
                    print(
                        f"[WTSL Betting] result identity lookup failed for "
                        f"{user_id}: {type(exc).__name__}: {exc}",
                        flush=True,
                    )
                    links = {}
                if links:
                    _matchlog_identity_index[user_id] = links
            verified_links_by_user[user_id] = links

    return [
        {
            "message": message,
            "verified_links_by_user": verified_links_by_user,
        }
        for message in candidates
    ]


def _wtsl_fixture_has_recent_result(
    fixture: dict[str, typing.Any],
    result_posts: list[dict[str, typing.Any]],
) -> bool:
    return any(
        _wtsl_result_message_matches_fixture(
            post["message"],
            fixture,
            post["verified_links_by_user"],
        )
        for post in result_posts
    )


async def _wtsl_current_live_matches_for_betting() -> list[dict[str, typing.Any]]:
    """Fetch and parse the current official feed for a betting decision."""
    timeout = aiohttp.ClientTimeout(total=10)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        poll_text = await fetch_poll_text_with_retry(
            session,
            TE4_SERVERLIST_URL,
            tries=2,
        )
    return parse_all_live_matches_livescore(poll_text)


async def _wtsl_live_betting_block_reason(
    fixture: dict[str, typing.Any],
    *,
    live_matches: list[dict[str, typing.Any]] | None = None,
    result_posts: list[dict[str, typing.Any]] | None = None,
) -> str | None:
    if live_matches is None:
        live_matches = await _wtsl_current_live_matches_for_betting()
    if _wtsl_fixture_is_currently_live(fixture, live_matches):
        return WTSL_LIVE_BETTING_BLOCK_MESSAGE
    if result_posts is None:
        result_posts = await _wtsl_recent_te4_result_posts()
    if _wtsl_fixture_has_recent_result(fixture, result_posts):
        return WTSL_PLAYED_BETTING_BLOCK_MESSAGE
    return None


def _wtsl_avatar_url(value: typing.Any) -> bool:
    """Identify an avatar URL accidentally occupying a player-name field."""
    text = str(value or "").strip().casefold()
    return text.startswith(("http://", "https://")) and "/avatars/" in text


def _repair_wtsl_fixture_player_fields(
    fixture: dict[str, typing.Any],
) -> dict[str, typing.Any]:
    """Repair the legacy player/avatar column-order shape.

    Older betting readers returned player_one_avatar as second_name and the
    actual second player name as first_avatar. Keep the repair at the UI
    boundary so existing stored fixtures remain readable and URLs never leak
    into player-facing labels.
    """
    repaired = dict(fixture)
    second_name = repaired.get("second_name")
    first_avatar = repaired.get("first_avatar")
    if _wtsl_avatar_url(second_name) and not _wtsl_avatar_url(first_avatar):
        repaired["second_name"] = first_avatar
        repaired["first_avatar"] = second_name
    return repaired


def _wtsl_referral_prompt_text() -> str:
    return (
        "🎁 **Win W$25 for referring a friend!**\n"
        "If their first bet after your referral is **W$25 or more** and wins, "
        "you’ll pocket **W$25**. Tap **Refer a friend** to start."
    )


class WTSLReferralPromptView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(
            discord.ui.Button(
                label="Refer a friend",
                style=discord.ButtonStyle.success,
                custom_id="wtsl_bet:v1:referral_modal",
            )
        )


class WTSLReferralModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title="Refer a WTSL friend")
        self.tour = discord.ui.TextInput(
            label="Tour: ATP or WTA",
            placeholder="Enter ATP or WTA",
            min_length=3,
            max_length=3,
            required=True,
        )
        self.player_name = discord.ui.TextInput(
            label="Exact canonical ranked player name",
            placeholder="Use the exact current ATP/WTA ranking name",
            min_length=1,
            max_length=100,
            required=True,
        )
        self.add_item(self.tour)
        self.add_item(self.player_name)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        tour = str(self.tour.value or "").strip().casefold()
        if tour not in {"atp", "wta"}:
            await interaction.followup.send(
                "Tour must be exactly **ATP** or **WTA**.",
                ephemeral=True,
            )
            return
        await _record_wtsl_referral(
            interaction,
            tour,
            str(self.player_name.value or "").strip(),
        )


class WTSLParlayStakeModal(discord.ui.Modal):
    def __init__(
        self,
        user_id: int,
        legs: list[dict[str, typing.Any]],
    ):
        super().__init__(title="Place WTSL Parlay")
        self.user_id = int(user_id)
        self.legs = legs
        self.stake = discord.ui.TextInput(
            label="Parlay stake in WTSL Dollars",
            placeholder="For example: 100 or 25.50",
            min_length=1,
            max_length=20,
            required=True,
        )
        self.add_item(self.stake)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        if interaction.user.id != self.user_id:
            await interaction.followup.send(
                "This parlay slip belongs to another user.",
                ephemeral=True,
            )
            return
        try:
            raw_stake = str(self.stake.value).strip().replace(",", ".")
            if not re.fullmatch(r"\d+(?:\.\d{1,2})?", raw_stake):
                raise ValueError
            stake = Decimal(raw_stake).quantize(Decimal("0.01"))
            if stake < Decimal("0.01"):
                raise ValueError
        except (InvalidOperation, ValueError):
            await interaction.followup.send(
                "Enter a valid stake from **W$0.01** upward, using at most two decimals.",
                ephemeral=True,
            )
            return
        try:
            live_matches = await _wtsl_current_live_matches_for_betting()
        except Exception:
            await interaction.followup.send(
                WTSL_BETTING_SAFEGUARD_UNAVAILABLE_MESSAGE,
                ephemeral=True,
            )
            return
        for leg in self.legs:
            leg_fixture = {
                "first_name": leg.get("first_name"),
                "second_name": leg.get("second_name"),
            }
            if _wtsl_fixture_is_currently_live(
                leg_fixture,
                live_matches,
            ):
                await interaction.followup.send(
                    f"{WTSL_LIVE_BETTING_BLOCK_MESSAGE} "
                    "It cannot be included in a parlay.",
                    ephemeral=True,
                )
                return
        try:
            result_posts = await _wtsl_recent_te4_result_posts()
        except Exception:
            await interaction.followup.send(
                WTSL_BETTING_SAFEGUARD_UNAVAILABLE_MESSAGE,
                ephemeral=True,
            )
            return
        for leg in self.legs:
            leg_fixture = {
                "first_name": leg.get("first_name"),
                "second_name": leg.get("second_name"),
                "tour": leg.get("tour"),
            }
            if _wtsl_fixture_has_recent_result(
                leg_fixture,
                result_posts,
            ):
                await interaction.followup.send(
                    f"{WTSL_PLAYED_BETTING_BLOCK_MESSAGE} "
                    "It cannot be included in a parlay.",
                    ephemeral=True,
                )
                return
        try:
            verified_links = await _wtsl_verified_player_links(self.user_id)
            placed = await asyncio.to_thread(
                place_wtsl_parlay,
                discord_user_id=self.user_id,
                legs=self.legs,
                stake=stake,
                verified_player_links=verified_links,
            )
        except Exception as exc:
            await interaction.followup.send(
                f"Parlay not placed: {str(exc)[:800]}",
                ephemeral=True,
            )
            return
        await interaction.followup.send(
            f"✅ Parlay placed across **{len(self.legs)} fixtures**.\n"
            f"Combined fixed WTSL odds: **{_wtsl_odds(placed['combined_odds'])}**\n"
            f"Stake: **{_wtsl_dollars(placed['stake'])}**\n"
            f"Potential return: **{_wtsl_dollars(placed['potential_return'])}**\n"
            f"Remaining balance: **{_wtsl_dollars(placed['balance'])}**",
            ephemeral=True,
        )


class WTSLParlayView(discord.ui.View):
    def __init__(
        self,
        user_id: int,
        fixtures: list[dict[str, typing.Any]],
    ):
        super().__init__(timeout=900)
        self.user_id = int(user_id)
        self.fixtures_by_token: dict[str, dict[str, typing.Any]] = {}
        self.selected_legs: list[dict[str, typing.Any]] = []
        options: list[discord.SelectOption] = []
        for fixture in fixtures:
            fixture = _repair_wtsl_fixture_player_fields(fixture)
            raw_odds = fixture.get("odds")
            if raw_odds is None:
                raw_odds = [fixture.get("odds_one"), fixture.get("odds_two")]
            if (
                not raw_odds
                or len(raw_odds) < 2
                or raw_odds[0] is None
                or raw_odds[1] is None
            ):
                continue
            token = _betting_fixture_token(str(fixture["key"]))
            self.fixtures_by_token[token] = fixture
            tournament = str(fixture.get("tournament") or "WTSL fixture")
            for side, name, odds in (
                ("one", fixture.get("first_name"), raw_odds[0]),
                ("two", fixture.get("second_name"), raw_odds[1]),
            ):
                options.append(
                    discord.SelectOption(
                        label=str(name or "Player")[:100],
                        description=(
                            f"{tournament[:38]} • fixed WTSL odds "
                            f"{_wtsl_odds(_wtsl_parlay_decimal_odds(odds))}"
                        ),
                        value=f"{token}:{side}",
                    )
                )
        self.selector = discord.ui.Select(
            placeholder="Choose one player from each fixture",
            min_values=1,
            max_values=max(1, min(len(options), 25)),
            options=options[:25],
            custom_id="wtsl_bet_parlay_select:v1",
            row=0,
        )
        self.selector.callback = self._select_callback
        self.add_item(self.selector)
        self.place_button = discord.ui.Button(
            label="Place Parlay",
            style=discord.ButtonStyle.success,
            custom_id="wtsl_bet_parlay_place:v1",
            row=1,
            disabled=True,
        )
        self.place_button.callback = self._place_callback
        self.add_item(self.place_button)

    def _summary(self) -> str:
        if not self.selected_legs:
            return (
                "Select at least two outcomes below. You can choose only one "
                "player from each fixture."
            )
        lines = [
            f"• {leg['selection_name']} — {_wtsl_odds(leg['odds'])}"
            for leg in self.selected_legs
        ]
        return (
            "Select outcomes for your fixed WTSL odds parlay, then place one stake.\n"
            "Fixed WTSL odds include the 5% house adjustment.\n\n"
            + "\n".join(lines)
            + (
                "\n\nCombined fixed WTSL odds: "
                f"**{_wtsl_odds(_parlay_combined_odds(self.selected_legs))}**"
            )
        )

    async def _select_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message(
                "This parlay slip belongs to another user.",
                ephemeral=True,
            )
            return
        legs: list[dict[str, typing.Any]] = []
        fixture_keys: set[str] = set()
        for value in self.selector.values:
            token, side = str(value).split(":", 1)
            fixture = self.fixtures_by_token.get(token)
            if fixture is None:
                continue
            fixture_key_value = str(fixture["key"])
            if fixture_key_value in fixture_keys:
                await interaction.response.send_message(
                    "Choose only one player from each fixture.",
                    ephemeral=True,
                )
                return
            fixture_keys.add(fixture_key_value)
            raw_odds = fixture.get("odds")
            if raw_odds is None:
                raw_odds = [fixture.get("odds_one"), fixture.get("odds_two")]
            if side == "one":
                selection_id = str(fixture["first_id"])
                selection_name = str(fixture["first_name"])
                odds = _wtsl_parlay_decimal_odds(raw_odds[0])
            else:
                selection_id = str(fixture["second_id"])
                selection_name = str(fixture["second_name"])
                odds = _wtsl_parlay_decimal_odds(raw_odds[1])
            legs.append({
                "fixture_key": fixture_key_value,
                "selection_id": selection_id,
                "selection_name": selection_name,
                "odds": odds,
                "first_name": str(fixture["first_name"]),
                "second_name": str(fixture["second_name"]),
                "tour": fixture.get("tour"),
            })
        try:
            live_matches = await _wtsl_current_live_matches_for_betting()
        except Exception:
            await interaction.response.send_message(
                WTSL_LIVE_BETTING_UNAVAILABLE_MESSAGE,
                ephemeral=True,
            )
            return
        for leg in legs:
            if _wtsl_fixture_is_currently_live(
                {
                    "first_name": leg["first_name"],
                    "second_name": leg["second_name"],
                },
                live_matches,
            ):
                await interaction.response.send_message(
                    f"{WTSL_LIVE_BETTING_BLOCK_MESSAGE} "
                    "It cannot be included in a parlay.",
                    ephemeral=True,
                )
                return
        self.selected_legs = legs
        self.place_button.disabled = len(legs) < 2
        await interaction.response.edit_message(
            content=self._summary(),
            view=self,
        )

    async def _place_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message(
                "This parlay slip belongs to another user.",
                ephemeral=True,
            )
            return
        if len(self.selected_legs) < 2:
            await interaction.response.send_message(
                "Choose at least two outcomes first.",
                ephemeral=True,
            )
            return
        await interaction.response.send_modal(
            WTSLParlayStakeModal(self.user_id, list(self.selected_legs))
        )


async def _show_wtsl_parlay_builder(interaction: discord.Interaction) -> None:
    await interaction.response.defer(ephemeral=True, thinking=True)
    if not await _is_wtsl_betting_verified(interaction.user.id):
        await interaction.followup.send(
            "You need an admin-approved WTSL identity before you can build a parlay.",
            ephemeral=True,
        )
        return
    try:
        fixtures = await asyncio.to_thread(list_open_betting_fixtures)
    except Exception as exc:
        await interaction.followup.send(
            f"Parlay fixtures could not be loaded: {str(exc)[:600]}",
            ephemeral=True,
        )
        return
    fixtures = [
        fixture for fixture in fixtures
        if (
            fixture.get("odds_one") is not None
            and fixture.get("odds_two") is not None
        )
    ][:12]
    if len(fixtures) < 2:
        await interaction.followup.send(
            "At least two fixtures with official odds are needed to build a parlay.",
            ephemeral=True,
        )
        return
    view = WTSLParlayView(interaction.user.id, fixtures)
    await interaction.followup.send(
        content=view._summary(),
        view=view,
        ephemeral=True,
    )


class WTSLBetModal(discord.ui.Modal):
    def __init__(
        self,
        fixture: dict[str, typing.Any],
        selection_id: str,
    ):
        first_name = str(fixture.get("first_name") or "Player 1")
        second_name = str(fixture.get("second_name") or "Player 2")
        selection_name = (
            first_name if selection_id == "one"
            else second_name
        )
        opponent_name = second_name if selection_id == "one" else first_name
        match_label = f"{first_name} vs {second_name}"
        side = "one" if selection_id == "one" else "two"
        official_odds = (
            fixture["odds_one"] if selection_id == "one"
            else fixture["odds_two"]
        )
        displayed_odds = _wtsl_guaranteed_decimal_odds(
            fixture,
            side,
            official_odds,
        )
        return_example = _wtsl_dollars(
            Decimal("100.00") * displayed_odds
        )
        super().__init__(
            title=f"Bet: {match_label}"[:45],
            custom_id=f"wtsl_bet_modal:v1:{_betting_fixture_token(str(fixture['key']))}:{selection_id}",
        )
        self.fixture = fixture
        self.selection_id = selection_id
        self.stake = discord.ui.TextInput(
            label=(
                f"Stake | W$100→{return_example}"
            ),
            placeholder=(
                f"For {match_label} — e.g. 100 or 25.50"
            )[:100],
            min_length=1,
            max_length=20,
            required=True,
        )
        self.add_item(self.stake)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        if not await _is_wtsl_betting_verified(interaction.user.id):
            await interaction.followup.send(
                "You need an admin-approved WTSL identity before you can bet.",
                ephemeral=True,
            )
            return
        try:
            raw_stake = str(self.stake.value).strip().replace(",", ".")
            if not re.fullmatch(r"\d+(?:\.\d{1,2})?", raw_stake):
                raise ValueError
            stake = Decimal(raw_stake).quantize(Decimal("0.01"))
            if stake < Decimal("0.01"):
                raise ValueError
        except (InvalidOperation, ValueError):
            await interaction.followup.send(
                "Enter a valid stake from **W$0.01** upward, using at most two decimals.",
                ephemeral=True,
            )
            return
        try:
            live_betting_reason = await _wtsl_live_betting_block_reason(self.fixture)
        except Exception:
            await interaction.followup.send(
                WTSL_BETTING_SAFEGUARD_UNAVAILABLE_MESSAGE,
                ephemeral=True,
            )
            return
        if live_betting_reason:
            await interaction.followup.send(
                live_betting_reason,
                ephemeral=True,
            )
            return
        selection_name = (
            self.fixture["first_name"] if self.selection_id == "one"
            else self.fixture["second_name"]
        )
        selection_id = (
            self.fixture["first_id"] if self.selection_id == "one"
            else self.fixture["second_id"]
        )
        official_odds = (
            self.fixture["odds_one"] if self.selection_id == "one"
            else self.fixture["odds_two"]
        )
        current_pool_odds = _wtsl_pool_decimal_odds(
            self.fixture,
            self.selection_id,
        )
        try:
            verified_links = await _wtsl_verified_player_links(interaction.user.id)
            placed = await asyncio.to_thread(
                place_wtsl_bet,
                discord_user_id=interaction.user.id,
                fixture_key=str(self.fixture["key"]),
                selection_id=str(selection_id),
                selection_name=str(selection_name),
                odds=Decimal(str(official_odds)),
                stake=stake,
                verified_player_links=verified_links,
            )
        except Exception as exc:
            await interaction.followup.send(
                f"Bet not placed: {str(exc)[:800]}",
                ephemeral=True,
            )
            return
        await interaction.followup.send(
            f"✅ Bet placed on **{selection_name}**.\n"
            f"WTSL odds: **{_wtsl_decimal_odds(official_odds)}**\n"
            f"House-adjusted live odds after your bet: **"
            f"{_wtsl_odds(placed['pool_odds'])}**\n"
            f"Guaranteed minimum odds: **{_wtsl_odds(placed['guaranteed_odds'])}**\n"
            "This return is guaranteed at minimum. Other bets can only "
            "increase your final return through the closing pool.\n"
            f"Stake: **{_wtsl_dollars(placed['stake'])}**\n"
            f"Gross return before house cut: "
            f"**{_wtsl_dollars(placed['gross_return'])}**\n"
            f"House cut (5% vig): **{_wtsl_dollars(placed['house_cut'])}**\n"
            f"Guaranteed minimum return after house cut: "
            f"**{_wtsl_dollars(placed['guaranteed_return'])}**\n"
            f"Remaining balance: **{_wtsl_dollars(placed['balance'])}**",
            ephemeral=True,
        )
        # Re-render from the persisted pool immediately. The background loop
        # may be busy fetching official fixtures and should not delay the
        # visible odds update after a successful bet.
        asyncio.create_task(
            _refresh_wtsl_fixture_messages(str(self.fixture["key"]))
        )


async def _show_wtsl_balance(interaction: discord.Interaction) -> None:
    await interaction.response.defer(ephemeral=True, thinking=True)
    if not await _is_wtsl_betting_verified(interaction.user.id):
        await interaction.followup.send(
            "Your WTSL Dollar account is available after an admin approves "
            "your WTSL identity.",
            ephemeral=True,
        )
        return
    try:
        account = await asyncio.to_thread(
            load_betting_account,
            interaction.user.id,
        )
    except Exception as exc:
        print(f"[WTSL Betting] balance lookup failed: {exc}", flush=True)
        await interaction.followup.send(
            "Your balance could not be loaded safely right now. Please try again.",
            ephemeral=True,
        )
        return
    await interaction.followup.send(
        f"🪙 **Your WTSL Dollar balance:** {_wtsl_dollars(account['balance'])}\n"
        f"Total staked: {_wtsl_dollars(account['total_staked'])}\n"
        f"Total returned: {_wtsl_dollars(account['total_returned'])}\n"
        f"Total profit: {_wtsl_dollars(account['total_profit'])}",
        ephemeral=True,
    )


async def _show_wtsl_ledger(interaction: discord.Interaction) -> None:
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        rows = await asyncio.to_thread(
            list_user_bets,
            interaction.user.id,
            500,
        )
        pages = _build_wtsl_bet_ledger_pages(rows)
    except Exception as exc:
        print(f"[WTSL Betting] ledger lookup failed: {exc}", flush=True)
        await interaction.followup.send(
            "Your bet ledger could not be loaded safely right now. Please try again.",
            ephemeral=True,
        )
        return
    if len(pages) > 1:
        await interaction.followup.send(
            embed=pages[0],
            view=WTSLLedgerView(interaction.user.id, pages),
            ephemeral=True,
        )
    else:
        await interaction.followup.send(
            embed=pages[0],
            ephemeral=True,
        )


async def _find_verified_wtsl_player_user(
    tour: str,
    player_name: str,
) -> int | None:
    wanted = normalize_matchlog_name(player_name)
    identities = dict(_matchlog_identity_index)
    try:
        stored = await asyncio.to_thread(load_matchlog_identities)
        identities.update(stored)
    except Exception as exc:
        print(f"[WTSL Betting] referral identity lookup failed: {exc}", flush=True)
    for user_id, links in identities.items():
        if isinstance(links, str):
            prefix, separator, linked_name = links.partition(":")
            links = {
                normalize_matchlog_name(prefix) if separator else "atp":
                linked_name.strip() if separator else links
            }
        linked = links.get(tour) if isinstance(links, dict) else None
        if linked and normalize_matchlog_name(linked) == wanted:
            return int(user_id)
    return None


async def _record_wtsl_referral(
    interaction: discord.Interaction,
    tour_value: str,
    player_name: str,
):
    if not await _is_wtsl_betting_verified(interaction.user.id):
        await interaction.followup.send(
            "You need an admin-approved WTSL identity before you can refer a player.",
            ephemeral=True,
        )
        return
    try:
        rankings = await _get_stats_rankings()
        candidates = [
            str(name)
            for name in rankings.get(tour_value, {}).values()
            if normalize_matchlog_name(name)
            == normalize_matchlog_name(player_name)
        ]
    except Exception as exc:
        await interaction.followup.send(
            f"The current {tour_value.upper()} rankings could not be loaded: "
            f"{str(exc)[:500]}",
            ephemeral=True,
        )
        return
    if len(candidates) != 1:
        await interaction.followup.send(
            "Choose the exact player from the ranking search dropdown. "
            "Free-text names and aliases are not accepted.",
            ephemeral=True,
        )
        return
    canonical = candidates[0]
    referred_user_id = await _find_verified_wtsl_player_user(
        tour_value,
        canonical,
    )
    if referred_user_id == interaction.user.id:
        await interaction.followup.send(
            "You cannot refer your own verified player identity.",
            ephemeral=True,
        )
        return
    try:
        referral = await asyncio.to_thread(
            create_referral,
            referrer_user_id=interaction.user.id,
            tour=tour_value,
            player_name=canonical,
            referred_user_id=referred_user_id,
        )
    except Exception as exc:
        await interaction.followup.send(
            f"Referral not recorded: {str(exc)[:700]}",
            ephemeral=True,
        )
        return
    if referred_user_id is None:
        try:
            owner = await client.fetch_user(OWNER_ID)
            await owner.send(
                f"<@{OWNER_ID}> 🔗 **WTSL referral verification needed**\n"
                f"Referrer: {interaction.user.mention} "
                f"(`{interaction.user.id}`)\n"
                f"Exact ranked player: **{tour_value.upper()}: {canonical}**\n"
                f"Referral ID: `{int(referral['referral_id'])}`\n"
                "Run `/linkmatchlogplayer`, select the Discord member, and "
                "enter the exact player name. This reminder repeats every three "
                "hours until the identity is linked.",
                allowed_mentions=discord.AllowedMentions(
                    users=True,
                    roles=False,
                    everyone=False,
                ),
            )
        except Exception as exc:
            print(
                f"[WTSL Betting] referral owner DM failed: {exc}",
                flush=True,
            )
        await interaction.followup.send(
            f"✅ Referral recorded for **{tour_value.upper()}: {canonical}**. "
            "That player is not linked to a verified Discord account yet. "
            "The verification owner has been tagged and will be reminded every "
            "three hours.",
            ephemeral=True,
        )
    else:
        await interaction.followup.send(
            f"✅ Referral recorded for **{tour_value.upper()}: {canonical}**. "
            f"The verified player is linked to <@{referred_user_id}>. "
            f"When their first post-referral bet of at least "
            f"**{_wtsl_dollars(Decimal('25.00'))}** wins, you receive "
            f"**{_wtsl_dollars(REFERRAL_REWARD)}**.",
            ephemeral=True,
        )


@client.tree.command(
    name="wtslbalance",
    description="Check your private WTSL Dollar balance",
)
async def wtslbalance(interaction: discord.Interaction):
    await _show_wtsl_balance(interaction)


@client.tree.command(
    name="wtslledger",
    description="View your private WTSL betting ledger",
)
async def wtslledger(interaction: discord.Interaction):
    await _show_wtsl_ledger(interaction)


@client.tree.command(
    name="wtslreset",
    description="Reset all WTSL betting data and rebuild the fixtures panel",
)
@app_commands.describe(
    confirm="Set this to true to permanently clear all betting data",
)
async def wtslreset(
    interaction: discord.Interaction,
    confirm: bool = False,
):
    if not _character_workbook_admin_allowed(interaction):
        await interaction.response.send_message(
            "Only the bot owner or a server administrator can reset WTSL betting data.",
            ephemeral=True,
        )
        return
    if not confirm:
        await interaction.response.send_message(
            "Nothing was reset. Run `/wtslreset confirm:true` to clear all "
            "bets, parlays, fixtures, ledger totals, and restore every "
            "account to W$1,000.00.",
            ephemeral=True,
        )
        return

    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        async with _betting_channel_lock:
            async with _betting_target_refresh_lock:
                deleted_messages = await _clear_wtsl_betting_messages_for_reset()
                await asyncio.to_thread(reset_all_betting_data)
                await _refresh_wtsl_betting_unlocked()
        await interaction.followup.send(
            "✅ WTSL betting reset complete.\n"
            "All bets, parlays, fixtures, and ledger totals were cleared; "
            "accounts were restored to **W$1,000.00**.\n"
            f"Deleted **{deleted_messages}** old betting message(s) and "
            "posted a fresh fixtures layout.",
            ephemeral=True,
        )
    except Exception as exc:
        print(
            f"[WTSL Betting] Discord reset command failed: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        await interaction.followup.send(
            "The betting reset failed safely before completion. "
            "Check the bot logs before trying again.",
            ephemeral=True,
        )


@client.tree.command(
    name="linkmatchlogplayer",
    description="Verify a Discord member's WTSL player for private stats",
)
@app_commands.describe(
    member="Discord member whose identity has been verified",
    player_name="Exact ATP or WTA player name",
)
@app_commands.checks.has_permissions(manage_guild=True)
async def linkmatchlogplayer(
    interaction: discord.Interaction,
    member: discord.Member,
    player_name: str,
):
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        rankings = await _get_stats_rankings()
        requested = player_name.strip()
        requested_tour = None
        prefix, separator, remainder = requested.partition(":")
        if separator and normalize_matchlog_name(prefix) in {"atp", "wta"}:
            requested_tour = normalize_matchlog_name(prefix)
            requested = remainder
        candidates = {
            (tour, canonical)
            for tour in ("atp", "wta")
            for canonical in rankings.get(tour, {}).values()
            if normalize_matchlog_name(canonical)
            == normalize_matchlog_name(requested)
            and (requested_tour is None or tour == requested_tour)
        }
        if len(candidates) != 1:
            await interaction.followup.send(
                "That name does not resolve uniquely to one ATP/WTA player. "
                "For a shared name, use `ATP: Player Name` or "
                "`WTA: Player Name`.",
                ephemeral=True,
            )
            return
        tour, canonical = next(iter(candidates))
        qualified_player = f"{tour.upper()}: {canonical}"
        encoded_player = qualified_player.encode("utf8").hex()
        receipt = (
            f"MatchLog admin identity: `{member.id}|{encoded_player}`"
        )
        owner = await client.fetch_user(OWNER_ID)
        await owner.send(receipt)
        await asyncio.to_thread(
            save_matchlog_identity,
            member.id,
            canonical,
            receipt,
            tour,
        )
        async with _stats_scrape_lock:
            await asyncio.to_thread(
                bind_matchlog_player_identity,
                MATCH_STATS_WORKBOOK,
                member.id,
                canonical,
                receipt,
                tour,
            )
            links = _matchlog_links(member.id)
            links[tour] = canonical
            _matchlog_identity_index[member.id] = links
        attached_referrals = await asyncio.to_thread(
            attach_pending_referrals,
            tour=tour,
            player_name=canonical,
            referred_user_id=member.id,
        )
        for referral in attached_referrals:
            try:
                referrer = await client.fetch_user(
                    int(referral["referrer_user_id"])
                )
                await referrer.send(
                    "✅ **WTSL referral identity verified.**\n"
                    f"**{tour.upper()}: {canonical}** is now linked to "
                    f"<@{member.id}>. If their first post-referral bet of at "
                    f"least **{_wtsl_dollars(Decimal('25.00'))}** wins, you "
                    f"receive **{_wtsl_dollars(REFERRAL_REWARD)}**."
                )
            except Exception as notify_exc:
                print(
                    f"[WTSL Betting] referral verification DM failed: "
                    f"{notify_exc}",
                    flush=True,
                )
        dm_delivered = True
        try:
            await member.send(
                "Your WTSL player identity has been verified as "
                f"**{qualified_player}**. You can now use `/mystats` to view "
                "your private MatchLog or screenshot statistics."
            )
        except Exception as notify_exc:
            dm_delivered = False
            print(
                f"[MatchLog Stats] verification DM failed for {member.id}: "
                f"{notify_exc}",
                flush=True,
            )
        dm_status = (
            " They have been notified by DM."
            if dm_delivered
            else " Their verification was saved, but the DM could not be delivered."
        )
        await interaction.followup.send(
            f"Linked {member.mention} to **{qualified_player}**. Their `/mystats` "
            f"identity will survive replacement publishes.{dm_status}",
            ephemeral=True,
        )
    except Exception as exc:
        await interaction.followup.send(
            f"The MatchLog identity link was not completed: {str(exc)[:1000]}",
            ephemeral=True,
        )


async def _send_mystats_followup(
    interaction: discord.Interaction,
    content: str | None = None,
    *,
    embed: discord.Embed | None = None,
    timeout: float = 5,
) -> bool:
    args: tuple[typing.Any, ...] = (content,) if content is not None else ()
    kwargs: dict[str, typing.Any] = {"ephemeral": True}
    if embed is not None:
        kwargs["embed"] = embed
    try:
        await asyncio.wait_for(
            interaction.followup.send(*args, **kwargs),
            timeout=timeout,
        )
        return True
    except Exception as exc:
        print(
            f"[MatchLog Stats] mystats followup failed: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        return False


async def _send_mystats_dm(
    user: typing.Any,
    embed: discord.Embed,
    *,
    timeout: float = 5,
    content: str = "Your private WTSL dashboard (DM copy):",
) -> bool:
    send = getattr(user, "send", None)
    if not callable(send):
        return False
    try:
        await asyncio.wait_for(
            send(content, embed=embed),
            timeout=timeout,
        )
        return True
    except Exception as exc:
        print(
            f"[MatchLog Stats] mystats DM failed: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        return False


async def _deliver_mystats_dashboard(
    interaction: discord.Interaction,
    embed: discord.Embed,
) -> tuple[bool, bool]:
    started = time.monotonic()
    followup_result, dm_result = await asyncio.gather(
        _send_mystats_followup(
            interaction,
            embed=embed,
        ),
        _send_mystats_dm(interaction.user, embed),
    )
    print(
        f"[MatchLog Stats] mystats delivery: "
        f"ephemeral={'sent' if followup_result else 'failed'}, "
        f"dm={'sent' if dm_result else 'failed'}, "
        f"duration={time.monotonic() - started:.1f}s",
        flush=True,
    )
    return followup_result, dm_result


_STATS_QUESTION_METRIC_ALIASES = {
    "aces": "aces",
    "ace": "aces",
    "serve aces": "aces",
    "double faults": "double_faults",
    "double fault": "double_faults",
    "dfs": "double_faults",
    "fastest serve": "fastest_serve",
    "average first serve speed": "avg_first_serve_speed",
    "avg first serve speed": "avg_first_serve_speed",
    "average second serve speed": "avg_second_serve_speed",
    "avg second serve speed": "avg_second_serve_speed",
    "winners": "winners",
    "winner": "winners",
    "forced errors": "forced_errors",
    "forced error": "forced_errors",
    "unforced errors": "unforced_errors",
    "unforced error": "unforced_errors",
    "first serve percentage": "first_serve_pct",
    "first serve %": "first_serve_pct",
    "first serve won percentage": "first_serve_won_pct",
    "first serve won %": "first_serve_won_pct",
    "second serve won percentage": "second_serve_won_pct",
    "second serve won %": "second_serve_won_pct",
    "return points won percentage": "return_points_won_pct",
    "return points won %": "return_points_won_pct",
    "net points won percentage": "net_points_won_pct",
    "net points won %": "net_points_won_pct",
    "net player": "net_points_won_pct",
    "net play": "net_points_won_pct",
    "at the net": "net_points_won_pct",
    "break points won percentage": "break_points_won_pct",
    "break points won %": "break_points_won_pct",
    "total points won": "total_points_won",
    "return winners": "return_winners",
    "tie breaks won": "tiebreaks_won_pct",
    "tiebreaks won": "tiebreaks_won_pct",
    "tiebreak won": "tiebreaks_won_pct",
    "tiebreak win percentage": "tiebreaks_won_pct",
    "tiebreak win rate": "tiebreaks_won_pct",
    "tiebreak percentage": "tiebreaks_won_pct",
    "deciding sets won": "deciding_sets_won_pct",
    "deciding set won": "deciding_sets_won_pct",
    "deciding set percentage": "deciding_sets_won_pct",
    "deciding set win rate": "deciding_sets_won_pct",
    "break points saved": "break_points_saved_pct",
    "average rally length": "average_rally_length",
}
_STATS_QUESTION_SET_WORDS = {
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
}
_STATS_QUESTION_PLAYER_STOP_WORDS = {
    "about",
    "aces",
    "average",
    "avg",
    "best",
    "career",
    "count",
    "did",
    "does",
    "exactly",
    "fewest",
    "for",
    "from",
    "how",
    "least",
    "many",
    "mean",
    "most",
    "my",
    "of",
    "on",
    "past",
    "sets",
    "sum",
    "the",
    "total",
    "what",
    "with",
    "year",
}
_MATCH_TOTAL_STATS = frozenset({
    "aces",
    "double_faults",
    "winners",
    "forced_errors",
    "unforced_errors",
    "total_points_won",
    "return_winners",
    "set_points_saved",
    "match_points_saved",
})


def _stats_question_player_name(
    question: str,
    normalized: str,
) -> str | None:
    """Resolve an exact or unique abbreviated player name from the cache."""
    cached = _stats_autocomplete_cache
    if cached is None:
        return None
    names = cached[1]
    if not names:
        return None

    normalized_names = [
        (name, re.sub(r"[^a-z0-9]+", " ", str(name).casefold()).strip())
        for name in names
    ]
    exact_matches = [
        name for name, normalized_name in normalized_names
        if normalized_name and re.search(
            rf"(?<![a-z0-9]){re.escape(normalized_name)}(?![a-z0-9])",
            normalized,
        )
    ]
    if len(exact_matches) == 1:
        return exact_matches[0]

    # Common WTSL shorthand drops a numeric suffix, e.g. "Dani" for Dani21.
    # Only accept a unique prefix so a short name cannot select the wrong player.
    for token in dict.fromkeys(normalized.split()):
        if (
            len(token) < 3
            or token in _STATS_QUESTION_PLAYER_STOP_WORDS
            or not token.isalnum()
        ):
            continue
        prefix_matches = [
            name for name, normalized_name in normalized_names
            if normalized_name.startswith(token)
        ]
        if len(prefix_matches) == 1:
            return prefix_matches[0]
    return None


def _stats_question_player_mentions(
    question: str,
    normalized: str,
) -> list[str]:
    """Resolve all uniquely identifiable player names in a query."""
    cached = _stats_autocomplete_cache
    if cached is None or not cached[1]:
        return []
    normalized_names = [
        (
            name,
            re.sub(r"[^a-z0-9]+", " ", str(name).casefold()).strip(),
        )
        for name in cached[1]
    ]
    mentions: list[tuple[int, str]] = []
    for name, normalized_name in normalized_names:
        if not normalized_name:
            continue
        match = re.search(
            rf"(?<![a-z0-9]){re.escape(normalized_name)}(?![a-z0-9])",
            normalized,
        )
        if match:
            mentions.append((match.start(), name))

    for token_match in re.finditer(r"\b[a-z0-9]+\b", normalized):
        token = token_match.group(0)
        if (
            len(token) < 3
            or token in _STATS_QUESTION_PLAYER_STOP_WORDS
            or not token.isalnum()
        ):
            continue
        candidates = [
            name
            for name, normalized_name in normalized_names
            if (
                normalized_name == token
                or normalized_name.startswith(token)
                or normalized_name.endswith(f" {token}")
            )
        ]
        if len(candidates) == 1:
            mentions.append((token_match.start(), candidates[0]))

    resolved: list[str] = []
    for _position, name in sorted(mentions, key=lambda item: item[0]):
        if name not in resolved:
            resolved.append(name)
    return resolved


@functools.lru_cache(maxsize=1)
def _stats_question_character_names() -> tuple[str, ...]:
    names: set[str] = set()
    for tour in ("atp", "wta"):
        try:
            names.update(str(name).strip() for name in get_character_names(tour))
        except Exception:
            continue
    return tuple(sorted(name for name in names if name))


def _stats_question_character_match(left: str, right: str) -> bool:
    left_tokens = normalize_matchlog_name(left).split()
    right_tokens = normalize_matchlog_name(right).split()
    if not left_tokens or not right_tokens:
        return False
    if left_tokens == right_tokens:
        return True
    if left_tokens[-1] != right_tokens[-1]:
        return False
    return (
        len(left_tokens) == 1
        or len(right_tokens) == 1
        or left_tokens[0][:1] == right_tokens[0][:1]
    )


def _stats_question_character_mention(
    normalized: str,
) -> str | None:
    cue_pattern = r"(?:using|use|as|with|playing\s+as)\s*$"
    mentions: list[tuple[int, str]] = []
    for character in _stats_question_character_names():
        character_key = normalize_matchlog_name(character)
        if not character_key:
            continue
        exact = re.search(
            rf"(?<![a-z0-9]){re.escape(character_key)}(?![a-z0-9])",
            normalized,
        )
        if exact and re.search(cue_pattern, normalized[:exact.start()]):
            mentions.append((exact.start(), character))
            continue
        surname = character_key.split()[-1]
        for match in re.finditer(
            rf"(?<![a-z0-9]){re.escape(surname)}(?![a-z0-9])",
            normalized,
        ):
            if re.search(cue_pattern, normalized[:match.start()]):
                mentions.append((match.start(), character))
                break
    return min(mentions, default=(0, None))[1]


def _interpret_stats_question_sync(question: str) -> dict[str, typing.Any]:
    """Turn free-form wording into a validated local stats query."""
    client = OpenAI(
        base_url=os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL"),
        api_key=os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY"),
        timeout=8.0,
        max_retries=0,
    )
    metric_keys = list(MATCHLOG_STATS)
    response = client.chat.completions.create(
        model=AI_MODEL,
        messages=[
            {
                "role": "system",
                "content": (
                    "You classify a user's question about verified WTSL tennis "
                    "match statistics. Return only the requested query fields. "
                    "Never answer the question and never invent a metric. "
                    "Use operation=max for record, highest, most, best, or who "
                    "has the most; min for lowest, fewest, or least; average "
                    "for average or mean; sum only when explicitly asking for "
                    "a total countable stat. Use one of the supplied metric "
                    "keys. If the question asks what a player is 'best at', "
                    "'strongest at', 'weakest at', or 'worst at', or asks "
                    "for their strengths or weaknesses without naming one "
                    "metric, use question_type=best_at and metric_key=null. "
                    "Use rank_direction=lowest for weakest/worst profile "
                    "questions. A set_count means the match played exactly that "
                    "many sets. If the question asks who is best, strongest, "
                    "or has the most for a named metric without naming a "
                    "specific player, use question_type=leaderboard. "
                    "Set rank_direction=highest for best/highest/most and "
                    "rank_direction=lowest for worst/lowest/least. Set "
                    "rank_position=2 for 'second best', 3 for 'third worst', "
                    "and 1 when no rank is specified. Resolve 'my' as "
                    "tournament_query for a named event, date_query for a "
                    "requested year/date, and surface for hard, clay, grass, "
                    "or carpet filters. Never silently discard a requested "
                    "filter. "
                    "is_personal=true and leave "
                    "player_name null. If the question names a second player "
                    "after against, versus, vs, playing, with, or using, "
                    "return that person as opponent_name. If it says using, "
                    "as, or playing with a character, return the character "
                    "as character_name instead. player_name is always the "
                    "person whose statistic is requested; opponent_name is "
                    "the person they faced. For wording such as 'X averages "
                    "when X faces Y', use X as player_name and Y as "
                    "opponent_name. Unknown or unsupported requests use "
                    "supported=false."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Supported metric keys: {', '.join(metric_keys)}\n"
                    "Question: " + str(question or "")
                ),
            },
        ],
        max_completion_tokens=420,
        response_format={
            "type": "json_schema",
            "json_schema": {
                "name": "stats_question",
                "strict": True,
                "schema": {
                    "type": "object",
                    "properties": {
                        "supported": {"type": "boolean"},
                        "question_type": {
                            "type": "string",
                            "enum": ["metric", "best_at", "leaderboard"],
                        },
                        "operation": {
                            "type": "string",
                            "enum": ["max", "min", "average", "sum"],
                        },
                        "rank_direction": {
                            "type": "string",
                            "enum": ["highest", "lowest"],
                        },
                        "rank_position": {
                            "type": ["integer", "null"],
                            "minimum": 1,
                            "maximum": 10,
                        },
                        "tournament_query": {"type": ["string", "null"]},
                        "date_query": {"type": ["string", "null"]},
                        "surface": {
                            "type": ["string", "null"],
                            "enum": ["hard", "clay", "grass", "carpet", None],
                        },
                        "metric_key": {
                            "type": ["string", "null"],
                            "enum": [*metric_keys, None],
                        },
                        "tour": {
                            "type": ["string", "null"],
                            "enum": ["atp", "wta", None],
                        },
                        "period": {
                            "type": "string",
                            "enum": ["career", "30d", "90d", "year", "52w"],
                        },
                        "set_count": {
                            "type": ["integer", "null"],
                        },
                        "player_name": {"type": ["string", "null"]},
                        "opponent_name": {"type": ["string", "null"]},
                        "character_name": {"type": ["string", "null"]},
                        "is_personal": {"type": "boolean"},
                    },
                    "required": [
                        "supported", "question_type", "operation", "metric_key",
                        "rank_direction", "rank_position",
                        "tournament_query", "date_query", "surface",
                        "tour", "period",
                        "set_count", "player_name", "opponent_name",
                        "character_name",
                        "is_personal",
                    ],
                    "additionalProperties": False,
                },
            },
        },
    )
    if not response.choices:
        raise ValueError("stats question interpreter returned no choices")
    parsed = json.loads(response.choices[0].message.content or "{}")
    question_type = parsed.get("question_type") or "metric"
    if question_type not in {"metric", "best_at", "leaderboard"}:
        raise ValueError("The stats question returned an invalid question type")
    if (
        not parsed.get("supported")
        or (
            question_type == "metric"
            and parsed.get("metric_key") not in MATCHLOG_STATS
        )
        or (
            question_type == "best_at"
            and parsed.get("metric_key") is not None
        )
        or (
            question_type == "leaderboard"
            and parsed.get("metric_key") not in MATCHLOG_STATS
        )
    ):
        raise ValueError("That question is outside the verified stats dataset")
    if parsed.get("tour") not in {None, "atp", "wta"}:
        raise ValueError("The stats question returned an invalid tour")
    if parsed.get("period") not in {"career", "30d", "90d", "year", "52w"}:
        raise ValueError("The stats question returned an invalid period")
    set_count = parsed.get("set_count")
    if set_count is not None and int(set_count) not in range(1, 6):
        raise ValueError("The stats question returned an invalid set count")
    if parsed.get("rank_direction") not in {"highest", "lowest"}:
        raise ValueError("The stats question returned an invalid rank direction")
    rank_position = parsed.get("rank_position")
    if rank_position is not None and int(rank_position) not in range(1, 11):
        raise ValueError("The stats question returned an invalid rank position")
    if parsed.get("surface") not in {None, "hard", "clay", "grass", "carpet"}:
        raise ValueError("The stats question returned an invalid surface")
    return parsed


def _parse_stats_question(question: str) -> dict[str, typing.Any]:
    normalized = re.sub(r"[^a-z0-9%]+", " ", str(question or "").casefold()).strip()
    profile_question = bool(
        re.search(
            r"\b(best at|strongest at|good at|great at|main strength|"
            r"strengths?|weakest (?:at|in)|worst (?:at|in)|"
            r"weakness(?:es)?|weak at)\b",
            normalized,
        )
    )
    metric_key = next(
        (
            key
            for alias, key in sorted(
                _STATS_QUESTION_METRIC_ALIASES.items(),
                key=lambda item: len(item[0]),
                reverse=True,
            )
            if re.search(rf"\b{re.escape(alias)}\b", normalized)
        ),
        None,
    )
    if metric_key is None and not profile_question:
        return {"error": "I couldn't identify a supported stat in that question."}
    leaderboard = bool(
        metric_key
        and not profile_question
        and re.search(
            r"\b(who|which player|top|leaderboard|best|strongest|"
            r"weakest|worst|highest|lowest|most|least|fewest)\b",
            normalized,
        )
        and not _stats_question_player_mentions(question, normalized)
    )
    rank_direction = (
        "lowest"
        if re.search(r"\b(weakest|worst|lowest|least|fewest)\b", normalized)
        else "highest"
    )
    rank_position = 1
    rank_match = re.search(
        r"\b(first|1st|second|2nd|third|3rd|fourth|4th|fifth|5th)\b",
        normalized,
    )
    if rank_match:
        rank_position = {
            "first": 1, "1st": 1,
            "second": 2, "2nd": 2,
            "third": 3, "3rd": 3,
            "fourth": 4, "4th": 4,
            "fifth": 5, "5th": 5,
        }[rank_match.group(1)]
    surface = next(
        (
            surface_name
            for surface_name in ("hard", "clay", "grass", "carpet")
            if re.search(rf"\b{surface_name}\b", normalized)
        ),
        None,
    )
    tournament_match = re.search(
        r"\b(?:at|in|during|at the)\s+([a-z0-9][a-z0-9 '&-]{2,})",
        normalized,
    )
    tournament_candidate = (
        tournament_match.group(1).strip()
        if tournament_match
        else None
    )
    if tournament_candidate:
        tournament_candidate = re.sub(
            r"\s+in\s+20\d{2}(?:-\d{1,2}(?:-\d{1,2})?)?$",
            "",
            tournament_candidate,
        ).strip()
        tournament_candidate = re.sub(
            r"\s+on\s+(?:hard|clay|grass|carpet)$",
            "",
            tournament_candidate,
        ).strip()
        if re.fullmatch(
            r"(?:a|an|the)?\s*(?:one|two|three|four|five|\d+)[ -]set(?:ter|ters)",
            tournament_candidate,
        ):
            tournament_candidate = None
    tournament_query = (
        tournament_candidate
        if (
            tournament_candidate
            and tournament_candidate
            not in {"the game", "game", "the field", "field", "tour", "career"}
        )
        else None
    )
    date_query = None
    date_match = re.search(
        r"\b(20\d{2}(?:-\d{1,2}(?:-\d{1,2})?)?)\b",
        normalized,
    )
    if date_match:
        date_query = date_match.group(1)
    set_count = None
    set_match = re.search(
        r"\b(one|two|three|four|five|[1-5])[- ]?set(?:ter|ters|s)?\b",
        normalized,
    )
    if set_match:
        set_token = set_match.group(1)
        set_count = (
            int(set_token)
            if set_token.isdigit()
            else _STATS_QUESTION_SET_WORDS.get(set_token)
        )
    tour = (
        "wta"
        if re.search(r"\b(wta|women|woman|female)\b", normalized)
        else "atp"
        if re.search(r"\b(atp|men|man|male)\b", normalized)
        else None
    )
    period = (
        "30d"
        if re.search(r"\b(last|past)\s+30\s+days?\b", normalized)
        else "90d"
        if re.search(r"\b(last|past)\s+90\s+days?\b", normalized)
        else "year"
        if re.search(r"\b(year|year to date|ytd)\b", normalized)
        else "52w"
        if re.search(r"\b(last|past)\s+52\s+weeks?\b", normalized)
        else "career"
    )
    character_name = _stats_question_character_mention(normalized)
    mentions = _stats_question_player_mentions(question, normalized)
    if character_name:
        mentions = [
            mention
            for mention in mentions
            if not _stats_question_character_match(mention, character_name)
        ]
    is_personal = bool(re.search(r"\b(my|mine)\b", normalized))
    player_name = None if is_personal else (mentions[0] if mentions else None)
    opponent_name = (
        mentions[0]
        if is_personal and mentions
        else mentions[1]
        if len(mentions) > 1
        else None
    )
    return {
        "metric_key": metric_key,
        "question_type": (
            "best_at"
            if profile_question and metric_key is None
            else "leaderboard"
            if leaderboard
            else "metric"
        ),
        "tour": tour,
        "period": period,
        "set_count": set_count,
        "rank_direction": rank_direction,
        "rank_position": rank_position,
        "tournament_query": tournament_query,
        "date_query": date_query,
        "surface": surface,
        "is_personal": is_personal,
        "operation": (
            "average"
            if re.search(r"\b(average|avg|mean)\b", normalized)
            else "min"
            if re.search(
                r"\b(weakest|worst|lowest|least|fewest|min)\b",
                normalized,
            )
            else "sum"
            if re.search(r"\b(total|sum)\b", normalized)
            else "max"
        ),
        "player_name": player_name,
        "opponent_name": opponent_name,
        "character_name": character_name,
    }


def _merge_stats_question_entities(
    parsed: dict[str, typing.Any],
    question: str,
) -> dict[str, typing.Any]:
    """Reconcile planner entities with the names explicitly present in text."""
    normalized = re.sub(
        r"[^a-z0-9%]+", " ", str(question or "").casefold()
    ).strip()
    mentions = _stats_question_player_mentions(question, normalized)
    character_name = parsed.get("character_name") or (
        _stats_question_character_mention(normalized)
    )
    if character_name:
        mentions = [
            mention
            for mention in mentions
            if not _stats_question_character_match(mention, character_name)
        ]
        parsed["character_name"] = character_name
    if parsed.get("is_personal"):
        if mentions and not parsed.get("opponent_name"):
            parsed["opponent_name"] = mentions[0]
        return parsed
    if mentions:
        # The first explicitly mentioned athlete is the subject unless the
        # query is personal; later names are contextual opponents/compare sides.
        parsed["player_name"] = mentions[0]
        if len(mentions) > 1:
            parsed["opponent_name"] = mentions[1]
    return parsed


def _query_stats_question_records_sync(
    metric_key: str,
    *,
    tour: str | None,
    period: str,
    set_count: int | None,
    player_name: str | None,
    opponent_name: str | None,
) -> list[dict[str, typing.Any]]:
    screenshot_records = query_screenshot_match_stat_values(
        MATCH_STATS_WORKBOOK,
        MATCHLOG_STATS[metric_key],
        tour=tour,
        period=period,
        set_count=set_count,
        player_name=player_name,
        opponent_name=opponent_name,
    )
    for record in screenshot_records:
        record["source"] = "screenshots"
    matchlog_records = query_match_stat_values(
        MATCH_STATS_WORKBOOK,
        metric_key,
        tour=tour,
        period=period,
        set_count=set_count,
        player_name=player_name,
        opponent_name=opponent_name,
    )
    screenshot_keys = {
        _stats_question_match_key(record)
        for record in screenshot_records
    }
    records = list(screenshot_records)
    for record in matchlog_records:
        record["source"] = "MatchLog"
        if _stats_question_match_key(record) not in screenshot_keys:
            records.append(record)
    return records


def _primary_screenshot_summary_sync(
    player_name: str,
    tour: str | None,
    period: str,
) -> dict[str, typing.Any] | None:
    tours = [tour] if tour in {"atp", "wta"} else ["atp", "wta"]
    summaries = [
        summary
        for current_tour in tours
        if (
            summary := get_screenshot_player_summary(
                MATCH_STATS_WORKBOOK,
                player_name,
                current_tour,
                period,
            )
        )
    ]
    if len(summaries) == 1:
        return summaries[0]
    if len(summaries) > 1 and tour in {"atp", "wta"}:
        return summaries[0]
    return None


@functools.lru_cache(maxsize=24)
def _screenshot_tournament_surfaces(
    tour: str,
    year: str,
) -> tuple[tuple[str, str], ...]:
    path = Path(f"wtsl_tournaments_cache_{tour}_{year}.json")
    if not path.exists():
        return ()
    try:
        rows = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return ()
    return tuple(
        (
            normalize_matchlog_name(row.get("tournament")),
            str(row.get("surface") or "").casefold(),
        )
        for row in rows
        if isinstance(row, dict)
        and normalize_matchlog_name(row.get("tournament"))
        and row.get("surface")
    )


def _stats_question_record_surface(record: dict[str, typing.Any]) -> str | None:
    tournament = normalize_matchlog_name(record.get("tournament"))
    year_match = re.search(r"\b(20\d{2})\b", str(record.get("date") or ""))
    year = year_match.group(1) if year_match else ""
    tour = str(record.get("tour") or "").casefold()
    if not tournament or tour not in {"atp", "wta"} or not year:
        return None
    for event_name, surface in _screenshot_tournament_surfaces(tour, year):
        if (
            event_name == tournament
            or event_name in tournament
            or tournament in event_name
        ):
            if "clay" in surface:
                return "clay"
            if "grass" in surface:
                return "grass"
            if "carpet" in surface:
                return "carpet"
            if "hard" in surface:
                return "hard"
    return None


def _filter_stats_question_context(
    records: list[dict[str, typing.Any]],
    *,
    tournament_query: str | None = None,
    date_query: str | None = None,
    surface: str | None = None,
) -> list[dict[str, typing.Any]]:
    filtered: list[dict[str, typing.Any]] = []
    tournament_key = normalize_matchlog_name(tournament_query)
    date_key = str(date_query or "").casefold()
    for record in records:
        if tournament_key and tournament_key not in normalize_matchlog_name(
            record.get("tournament")
        ):
            continue
        if date_key and date_key not in str(record.get("date") or "").casefold():
            continue
        if surface:
            record_surface = _stats_question_record_surface(record)
            if record_surface != surface:
                continue
            record["surface"] = record_surface
        filtered.append(record)
    return filtered


def _query_screenshot_leaderboard_sync(
    metric_key: str,
    tour: str | None,
    rank_direction: str = "highest",
    rank_position: int = 1,
    tournament_query: str | None = None,
    date_query: str | None = None,
    surface: str | None = None,
) -> list[dict[str, typing.Any]]:
    tours = [tour] if tour in {"atp", "wta"} else ["atp", "wta"]
    records: list[dict[str, typing.Any]] = []
    for current_tour in tours:
        records.extend(query_screenshot_match_stat_values(
            MATCH_STATS_WORKBOOK,
            MATCHLOG_STATS[metric_key],
            tour=current_tour,
            period="career",
        ))
    records = _filter_stats_question_context(
        records,
        tournament_query=tournament_query,
        date_query=date_query,
        surface=surface,
    )
    grouped: dict[tuple[str, str], list[float]] = defaultdict(list)
    for record in records:
        grouped[
            (
                str(record.get("tour") or "").casefold(),
                normalize_matchlog_name(record.get("player")),
            )
        ].append(float(record["value"]))
    minimum_matches = (
        3
        if tournament_query or date_query or surface
        else LEADERBOARD_MIN_MATCHES
    )
    rows = [
        {
            "player": next(
                record.get("player")
                for record in records
                if (
                    str(record.get("tour") or "").casefold(),
                    normalize_matchlog_name(record.get("player")),
                ) == key
            ),
            "tour": key[0],
            "value": sum(values) / len(values),
            "matches": len(values),
            "metric_label": MATCHLOG_STATS[metric_key],
            "source": "screenshots",
        }
        for key, values in grouped.items()
        if len(values) >= minimum_matches
    ]
    rows.sort(
        key=lambda row: (float(row["value"]), int(row["matches"])),
        reverse=rank_direction != "lowest",
    )
    position = max(1, int(rank_position or 1))
    return rows[position - 1:position] if position > 1 else rows[:3]


def _format_stats_leaderboard_response(
    rows: list[dict[str, typing.Any]],
    metric_key: str,
    *,
    rank_direction: str = "highest",
    rank_position: int = 1,
) -> str:
    label = MATCHLOG_STATS[metric_key]
    if rank_position > 1:
        rank_label = f"{_ordinal(rank_position)}-{'worst' if rank_direction == 'lowest' else 'best'}"
    else:
        rank_label = "Worst" if rank_direction == "lowest" else "Best"
    lines = [f"🏆 **{rank_label} {label} players in the verified data:**"]
    display_start = rank_position if rank_position > 1 else 1
    for index, row in enumerate(rows, start=display_start):
        lines.append(
            f"{index}. **{row['player']}** ({str(row['tour']).upper()}) — "
            f"**{_format_stats_question_value(metric_key, row['value'])}** "
            f"across {row['matches']} matches"
        )
    lines.append("_Source: Screenshots._")
    return "\n".join(lines)


def _format_stats_match_total_response(
    record: dict[str, typing.Any],
    metric_key: str,
    source_label: str,
) -> str:
    metric_label = MATCHLOG_STATS[metric_key].lower()
    total = _format_stats_question_value(metric_key, record["value"])
    lines = [f"**{total} {metric_label}**"]
    for side in record.get("side_values") or []:
        lines.append(
            f"{side.get('player')}: "
            f"{_format_stats_question_value(metric_key, side.get('value'))}"
        )
    lines.append(f"_Source: {source_label}._")
    return "\n".join(lines)


def _format_stats_question_with_echo(
    question: str,
    answer: str,
) -> str:
    question_text = discord.utils.escape_mentions(
        discord.utils.escape_markdown(str(question or "").strip())
    ) or "(question unavailable)"
    question_block = "\n".join(
        f"> {line}" for line in question_text.splitlines()
    )
    return (
        f"**Question:**\n{question_block}\n\n"
        f"**Answer:**\n{answer}"
    )


def _filter_stats_question_character_records(
    records: list[dict[str, typing.Any]],
    official_results: list[dict[str, typing.Any]],
    character_name: str,
) -> list[dict[str, typing.Any]]:
    """Keep stat rows where the requested player used the requested character."""
    filtered: list[dict[str, typing.Any]] = []
    for record in records:
        if _stats_question_character_match(
            str(record.get("character") or ""),
            character_name,
        ):
            filtered.append(record)
            continue
        pair = _dashboard_pair_key(
            record.get("player"),
            record.get("opponent"),
        )
        date_key = _dashboard_date_key(record.get("date"))
        score_key = result_score_equivalence_key(record.get("result"))
        candidates = []
        for official in official_results:
            if str(official.get("tour") or "").casefold() != str(
                record.get("tour") or ""
            ).casefold():
                continue
            official_pair = _dashboard_pair_key(
                official.get("player1"),
                official.get("player2"),
            )
            if official_pair != pair:
                continue
            if date_key != _dashboard_date_key(official.get("date")):
                continue
            official_score = result_score_equivalence_key(
                official.get("result")
            )
            if score_key and official_score and score_key != official_score:
                continue
            if not _dashboard_event_identity_compatible(
                record.get("tournament"),
                official.get("tournament"),
                screenshot_date=record.get("date"),
                official_date=official.get("date"),
            ):
                continue
            if _dashboard_player_key(record.get("player")) == _dashboard_player_key(
                official.get("player1")
            ):
                selected_character = official.get("player1_character")
            else:
                selected_character = official.get("player2_character")
            if _stats_question_character_match(
                str(selected_character or ""),
                character_name,
            ):
                candidates.append(official)
        if candidates:
            filtered.append(record)
    return filtered


def _stats_question_match_key(
    record: dict[str, typing.Any],
) -> tuple[typing.Any, ...] | None:
    tour = str(record.get("tour") or "").casefold()
    pair = _dashboard_pair_key(record.get("player"), record.get("opponent"))
    date_key = _dashboard_date_key(record.get("date"))
    score_key = _dashboard_score_key(record.get("result"))
    if (
        tour not in {"atp", "wta"}
        or not pair[0]
        or not pair[1]
        or date_key == (0, 0, 0)
        or not score_key
    ):
        return None
    return tour, pair, date_key, score_key


def _aggregate_stats_question_match_totals(
    records: list[dict[str, typing.Any]],
    metric_key: str,
) -> list[dict[str, typing.Any]]:
    """Combine reciprocal player rows for an unscoped match-total query."""
    if metric_key not in _MATCH_TOTAL_STATS:
        return records

    grouped: dict[tuple[typing.Any, ...], list[dict[str, typing.Any]]] = {}
    for record in records:
        match_key = _stats_question_match_key(record)
        if match_key is not None:
            grouped.setdefault(match_key, []).append(record)

    aggregated: list[dict[str, typing.Any]] = []
    for group in grouped.values():
        sides: dict[str, dict[str, typing.Any]] = {}
        for record in group:
            player_key = _dashboard_player_key(record.get("player"))
            if not player_key:
                continue
            existing = sides.get(player_key)
            if existing is None:
                sides[player_key] = record
                continue
            # MatchLog and screenshot sources can both contain the same
            # player-side row. Prefer the parsed MatchLog value when both
            # sources disagree, while still preserving the source label.
            existing_source = str(existing.get("source") or "")
            current_source = str(record.get("source") or "")
            if "MatchLog" in current_source and "MatchLog" not in existing_source:
                sides[player_key] = record

        if len(sides) < 2:
            continue
        side_records = sorted(
            sides.values(),
            key=lambda record: _dashboard_player_key(record.get("player")),
        )
        aggregate = dict(side_records[0])
        aggregate["value"] = sum(
            float(record["value"]) for record in side_records
        )
        aggregate["player"] = side_records[0].get("player")
        aggregate["opponent"] = side_records[1].get("player")
        aggregate["side_values"] = [
            {
                "player": record.get("player"),
                "value": float(record["value"]),
            }
            for record in side_records
        ]
        aggregate["source"] = " + ".join(sorted({
            str(record.get("source") or "")
            for record in side_records
            if record.get("source")
        }))
        aggregate["match_total"] = True
        aggregated.append(aggregate)

    # A match total is only valid when both player-side values are present.
    # Preserve the old behavior if the dataset has no complete reciprocal
    # matches for this metric.
    return aggregated or records


def _stats_question_official_match(
    record: dict[str, typing.Any],
    official_results: list[dict[str, typing.Any]],
) -> dict[str, typing.Any] | None:
    """Resolve one stats row to a unique all-results match when possible."""
    record_tour = str(record.get("tour") or "").casefold()
    record_pair = _dashboard_pair_key(
        record.get("player"),
        record.get("opponent"),
    )
    record_date = _dashboard_date_key(record.get("date"))
    record_score = _dashboard_score_key(record.get("result"))

    candidates = []
    for result in official_results:
        if (
            record_tour
            and str(result.get("tour") or "").casefold() != record_tour
        ):
            continue
        if _dashboard_date_key(result.get("date")) != record_date:
            continue
        if _dashboard_pair_key(
            result.get("p1") or result.get("player1"),
            result.get("p2") or result.get("player2"),
        ) != record_pair:
            continue
        if record_score and (
            _dashboard_score_key(result.get("result")) != record_score
        ):
            continue
        candidates.append(result)

    if len(candidates) == 1:
        return candidates[0]

    # Confirmed historical aliases can have a stale screenshot date or score.
    # If the normalized pair identifies exactly one row in the normalized
    # event/year, use that official row rather than falling back to raw labels.
    pair_event_candidates = [
        result for result in official_results
        if (
            record_tour
            and str(result.get("tour") or "").casefold() == record_tour
            and _dashboard_pair_key(
                result.get("p1") or result.get("player1"),
                result.get("p2") or result.get("player2"),
            ) == record_pair
            and _dashboard_year_key(result.get("date")) == _dashboard_year_key(
                record.get("date")
            )
            and _dashboard_event_identity_compatible(
                record.get("tournament"),
                result.get("tournament"),
                screenshot_date=record.get("date"),
                official_date=result.get("date"),
            )
        )
    ]
    if len(pair_event_candidates) == 1:
        return pair_event_candidates[0]

    # Some historical screenshots use an alias that is not present in the
    # all-results feed. A unique event/date/score row is still safe to use.
    event_candidates = []
    for result in official_results:
        if (
            record_tour
            and str(result.get("tour") or "").casefold() != record_tour
        ):
            continue
        if _dashboard_date_key(result.get("date")) != record_date:
            continue
        if not _dashboard_event_identity_compatible(
            record.get("tournament"),
            result.get("tournament"),
            screenshot_date=record.get("date"),
            official_date=result.get("date"),
        ):
            continue
        if record_score and (
            _dashboard_score_key(result.get("result")) != record_score
        ):
            continue
        event_candidates.append(result)
    return event_candidates[0] if len(event_candidates) == 1 else None


async def _enrich_stats_question_records(
    records: list[dict[str, typing.Any]],
) -> None:
    """Replace screenshot event labels with official all-results metadata."""
    try:
        official_results = await _get_matchlog_official_results()
    except Exception as exc:
        print(
            f"[MatchLog Stats] official match-evidence enrichment unavailable: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        return

    for record in records:
        official = _stats_question_official_match(record, official_results)
        if official is not None:
            record["tournament"] = official.get("tournament") or record.get(
                "tournament"
            )
            record["round"] = official.get("round") or record.get("round")
            record["date"] = official.get("date") or record.get("date")
            record["result"] = official.get("result") or record.get("result")
            record["evidence_source"] = "official all-results match"
            continue

        # Even when the exact pair is absent from the feed, use its canonical
        # event label rather than exposing a workbook ground/court identifier.
        year = _dashboard_year_key(record.get("date"))
        event_candidates = [
            result for result in official_results
            if (
                str(result.get("tour") or "").casefold()
                == str(record.get("tour") or "").casefold()
                and _dashboard_year_key(result.get("date")) == year
                and _dashboard_event_identity_compatible(
                    record.get("tournament"),
                    result.get("tournament"),
                    screenshot_date=record.get("date"),
                    official_date=result.get("date"),
                )
            )
        ]
        labels = {}
        for result in event_candidates:
            label = str(result.get("tournament") or "").strip()
            if label:
                labels[label] = labels.get(label, 0) + 1
        if labels:
            record["tournament"] = max(
                labels,
                key=lambda label: (labels[label], len(label)),
            )
            record["evidence_source"] = "official all-results event"


def _stats_question_player_label(
    player_name: typing.Any,
    tour: typing.Any,
) -> str:
    """Return a verified Discord mention, or the plain WTSL player name."""
    display_name = str(player_name or "").strip()
    if not display_name:
        return ""
    target = normalize_matchlog_name(display_name)
    target = normalize_matchlog_name(
        SCREENSHOT_NAME_ALIASES.get(target, target)
    )
    selected_tour = str(tour or "").casefold()
    for user_id, links in _matchlog_identity_index.items():
        if not isinstance(links, dict):
            continue
        for linked_tour, linked_name in links.items():
            if (
                selected_tour
                and str(linked_tour or "").casefold() != selected_tour
            ):
                continue
            linked_key = normalize_matchlog_name(linked_name)
            if linked_key == target:
                return f"<@{user_id}>"
    return display_name


def _format_stats_question_value(metric_key: str, value: typing.Any) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    label = MATCHLOG_STATS.get(metric_key, metric_key)
    if label.endswith("%"):
        return f"{number * 100:.1f}%"
    if metric_key in {
        "fastest_serve",
        "avg_first_serve_speed",
        "avg_second_serve_speed",
    }:
        return f"{number:.1f} km/h"
    return str(int(number)) if number.is_integer() else f"{number:.2f}"


def _format_best_at_response(
    summary: dict[str, typing.Any],
    player_name: str,
    *,
    is_personal: bool = False,
    strength: bool = True,
) -> str:
    raw_metrics = {
        str(label): (value, count)
        for label, value, count in summary.get("metrics") or []
    }
    ranked: list[tuple[str, int, int, int]] = []
    for profile in (summary.get("relative_profile") or {}).values():
        if not isinstance(profile, dict):
            continue
        for metric in profile.get("metrics") or []:
            label = str(metric.get("metric") or "").strip()
            percentile = metric.get("percentile")
            players = metric.get("players")
            if (
                not label
                or not isinstance(percentile, (int, float))
                or not isinstance(players, (int, float))
            ):
                continue
            ranked.append((label, round(float(percentile)), int(players), 0))
    deduped: dict[str, tuple[str, int, int, int]] = {}
    for item in ranked:
        existing = deduped.get(item[0])
        if existing is None or (
            item[1] > existing[1] if strength else item[1] < existing[1]
        ):
            value_count = raw_metrics.get(item[0], (None, 0))
            deduped[item[0]] = (item[0], item[1], item[2], value_count[1])
    top_metrics = sorted(
        deduped.values(),
        key=lambda item: (item[1], item[2], item[0]),
        reverse=strength,
    )[:3]
    clear_threshold = top_metrics and (
        top_metrics[0][1] >= 60 if strength else top_metrics[0][1] <= 40
    )
    if not top_metrics or not clear_threshold:
        response = (
            f"I couldn't find a clear {'standout strength' if strength else 'weakest area'} "
            f"for **{player_name}** in the verified profile. Their measured "
            f"areas are broadly {'around or above' if not strength else 'around or below'} "
            "the field average."
        )
        if is_personal:
            response += (
                "\nFor the complete breakdown, use **`/mystats`** to open "
                "your personal dashboard."
            )
        response += "\n_Source: Screenshots._"
        return response

    def shown_value(label: str) -> str:
        value = raw_metrics.get(label, (None, 0))[0]
        if not isinstance(value, (int, float)):
            return "value unavailable"
        if label.endswith("%"):
            return f"{float(value):.1%}"
        if "Speed" in label:
            return f"{float(value):.1f} km/h"
        return f"{float(value):.2f}".rstrip("0").rstrip(".")

    lines = [
        f"📊 **{player_name} is {'strongest' if strength else 'weakest'} in:**",
        f"Based on **{summary.get('matches', 0)} matches with complete "
        f"stat data** ({summary.get('period_label', 'career')}).",
    ]
    for index, (label, percentile, players, count) in enumerate(
        top_metrics,
        start=1,
    ):
        sample = f"; {count} observations" if count else ""
        lines.append(
            f"{index}. **{label}** — {shown_value(label)}, "
            f"{_ordinal(percentile)} percentile among {players} players{sample}."
        )
    lines.append(
        metric_insight(
            top_metrics[0][0],
            strength=strength,
            subject=player_name,
        )
    )
    if is_personal:
        lines.append(
            "For the complete breakdown, use **`/mystats`** to open "
            "your personal dashboard."
        )
    lines.append(
        "_Source: Screenshots._"
    )
    return "\n".join(lines)


def _stats_question_scope(parsed: dict[str, typing.Any]) -> str:
    scope = parsed["period"].replace("30d", "last 30 days")
    scope = scope.replace("90d", "last 90 days")
    scope = scope.replace("52w", "last 52 weeks")
    scope = scope.replace("year", "year to date")
    if parsed.get("set_count"):
        scope += f", exactly {parsed['set_count']} sets"
    if parsed.get("tour"):
        scope += f", {parsed['tour'].upper()}"
    if parsed.get("opponent_name"):
        scope += f", against {parsed['opponent_name']}"
    if parsed.get("character_name"):
        scope += f", using {parsed['character_name']}"
    if parsed.get("surface"):
        scope += f", on {parsed['surface']}"
    if parsed.get("tournament_query"):
        scope += f", at {parsed['tournament_query']}"
    if parsed.get("date_query"):
        scope += f", in {parsed['date_query']}"
    return scope


def _stats_question_recovery_message(
    question: str,
    parsed: dict[str, typing.Any],
    reason: str | None = None,
) -> str:
    """Give an actionable nearby query when the exact request cannot answer."""
    player = str(parsed.get("player_name") or "").strip()
    metric_key = str(parsed.get("metric_key") or "").strip()
    metric_label = MATCHLOG_STATS.get(metric_key)
    if player and metric_label:
        nearby = (
            f"What is **{player}**'s average **{metric_label}** "
            "across their career?"
        )
    elif player:
        nearby = f"What is **{player}** best at?"
    else:
        nearby = (
            "Try naming a player and a stat, such as "
            "**What is KINGBARBOZA best at?**"
        )
    opening = reason or "I couldn't answer that exact question"
    recovery = (
        f"{opening} from the verified records. "
        f"I can try this nearby question: {nearby}\n"
        "Would you like to ask another stats question?"
    )
    return _format_stats_question_with_echo(question, recovery)


@client.tree.command(
    name="askstats",
    description="Ask about verified WTSL match stats",
)
@app_commands.describe(
    question="Your statistics question",
)
async def askstats(interaction: discord.Interaction, question: str):
    await interaction.response.defer(thinking=True)
    try:
        if _stats_autocomplete_cache is None:
            try:
                await asyncio.wait_for(
                    _refresh_stats_autocomplete_cache(),
                    timeout=5,
                )
            except Exception as cache_exc:
                print(
                    f"[MatchLog Stats] name cache unavailable: "
                    f"{type(cache_exc).__name__}",
                    flush=True,
                )
        fallback = _parse_stats_question(question)
        try:
            parsed = await asyncio.wait_for(
                _run_askstats_worker(
                    _interpret_stats_question_sync,
                    question,
                ),
                timeout=12,
            )
            parsed = _merge_stats_question_entities(parsed, question)
        except (AIBudgetExceeded, AIBudgetStateError, asyncio.TimeoutError) as ai_exc:
            print(
                f"[MatchLog Stats] askstats interpreter unavailable: "
                f"{type(ai_exc).__name__}",
                flush=True,
            )
            parsed = fallback
        except Exception as ai_exc:
            print(
                f"[MatchLog Stats] askstats interpreter failed: "
                f"{type(ai_exc).__name__}: {ai_exc}",
                flush=True,
            )
            parsed = fallback
        is_best_at = parsed.get("question_type") == "best_at"
        is_leaderboard = parsed.get("question_type") == "leaderboard"
        if parsed.get("error") or (
            not parsed.get("metric_key")
            and not is_best_at
            and not is_leaderboard
        ):
            await interaction.followup.send(
                _stats_question_recovery_message(
                    question,
                    parsed,
                    "I couldn't map that exact wording to a verified statistic",
                ),
                ephemeral=True,
            )
            return
        player_name = None
        requested_player = str(parsed.get("player_name") or "").strip()
        opponent_name = str(parsed.get("opponent_name") or "").strip() or None
        character_name = (
            str(parsed.get("character_name") or "").strip() or None
        )
        if parsed.get("is_personal"):
            links = _matchlog_links(interaction.user.id)
            selected_tour = parsed.get("tour")
            if selected_tour is None and len(links) == 1:
                selected_tour = next(iter(links))
                parsed["tour"] = selected_tour
            player_name = links.get(selected_tour) if selected_tour else None
            if not player_name:
                if is_best_at:
                    await interaction.followup.send(
                        _stats_question_recovery_message(
                            question,
                            parsed,
                            "I couldn't identify the player for that profile",
                        ),
                        ephemeral=True,
                    )
                    return
                await interaction.followup.send(
                    _stats_question_recovery_message(
                        question,
                        parsed,
                        "I could not resolve **my** to one verified ATP/WTA identity",
                    ),
                    ephemeral=True,
                )
                return
        elif requested_player:
            player_name = requested_player
        if _matchlog_rebuild_state == "failed":
            await interaction.followup.send(
                _stats_question_recovery_message(
                    question,
                    parsed,
                    "The verified statistics workbook is temporarily unavailable",
                ),
                ephemeral=True,
            )
            return
        if is_leaderboard:
            leaderboard_rows = await asyncio.wait_for(
                _run_askstats_worker(
                    _query_screenshot_leaderboard_sync,
                    parsed["metric_key"],
                    parsed.get("tour"),
                    parsed.get("rank_direction") or "highest",
                    parsed.get("rank_position") or 1,
                    parsed.get("tournament_query"),
                    parsed.get("date_query"),
                    parsed.get("surface"),
                ),
                timeout=MYSTATS_SUMMARY_TIMEOUT_SECONDS,
            )
            if not leaderboard_rows:
                await interaction.followup.send(
                    _stats_question_recovery_message(
                        question,
                        parsed,
                        "I couldn't find enough screenshot coverage for that leaderboard",
                    ),
                    ephemeral=True,
                )
                return
            await interaction.followup.send(
                _format_stats_question_with_echo(
                    question,
                    _format_stats_leaderboard_response(
                        leaderboard_rows,
                        parsed["metric_key"],
                        rank_direction=parsed.get("rank_direction") or "highest",
                        rank_position=parsed.get("rank_position") or 1,
                    ),
                )
            )
            return
        if is_best_at:
            summary = await asyncio.wait_for(
                asyncio.to_thread(
                    _primary_screenshot_summary_sync,
                    player_name,
                    parsed.get("tour"),
                    parsed.get("period") or "career",
                ),
                timeout=MYSTATS_SUMMARY_TIMEOUT_SECONDS,
            )
            if summary is None:
                await interaction.followup.send(
                    _stats_question_recovery_message(
                        question,
                        parsed,
                        f"I couldn't find a verified profile for **{player_name}**",
                    ),
                    ephemeral=True,
                )
                return
            await interaction.followup.send(
                _format_stats_question_with_echo(
                    question,
                    _format_best_at_response(
                        summary,
                        player_name,
                        is_personal=bool(parsed.get("is_personal")),
                        strength=(parsed.get("rank_direction") or "highest")
                        != "lowest",
                    ),
                )
            )
            return
        records = await asyncio.wait_for(
            _run_askstats_worker(
                _query_stats_question_records_sync,
                parsed["metric_key"],
                tour=parsed.get("tour"),
                period=parsed["period"],
                set_count=parsed.get("set_count"),
                player_name=player_name,
                opponent_name=opponent_name,
            ),
            timeout=MYSTATS_SUMMARY_TIMEOUT_SECONDS,
        )
        records = _filter_stats_question_context(
            records,
            tournament_query=parsed.get("tournament_query"),
            date_query=parsed.get("date_query"),
            surface=parsed.get("surface"),
        )
        if not records:
            await interaction.followup.send(
                _stats_question_recovery_message(
                    question,
                    parsed,
                    "I couldn't find a verified match for that exact filter",
                ),
                ephemeral=True,
            )
            return
        unique_records: dict[tuple[str, ...], dict[str, typing.Any]] = {}
        for record in records:
            record_key = (
                str(record.get("tour") or ""),
                normalize_matchlog_name(record.get("player")),
                normalize_matchlog_name(record.get("opponent")),
                str(record.get("date") or ""),
                str(record.get("result") or ""),
                str(record.get("metric") or record.get("metric_label") or ""),
            )
            existing = unique_records.get(record_key)
            if existing is None:
                unique_records[record_key] = record
            else:
                source_names = {
                    str(existing.get("source") or ""),
                    str(record.get("source") or ""),
                }
                existing["source"] = " + ".join(sorted(source_names))
        records = list(unique_records.values())
        if character_name:
            official_results = await asyncio.wait_for(
                get_all_results(allow_stale=True),
                timeout=10,
            )
            records = _filter_stats_question_character_records(
                records,
                official_results,
                character_name,
            )
            if not records:
                await interaction.followup.send(
                    _stats_question_recovery_message(
                        question,
                        parsed,
                        "I couldn't find a verified match for that character filter",
                    ),
                    ephemeral=True,
                )
                return
        await _enrich_stats_question_records(records)
        match_total_query = (
            player_name is None
            and parsed["metric_key"] in _MATCH_TOTAL_STATS
        )
        if match_total_query:
            records = _aggregate_stats_question_match_totals(
                records,
                parsed["metric_key"],
            )
        operation = parsed.get("operation") or "max"
        if operation == "average":
            answer_value = sum(float(record["value"]) for record in records) / len(records)
        elif operation == "sum":
            answer_value = sum(float(record["value"]) for record in records)
        elif operation == "min":
            answer_value = min(float(record["value"]) for record in records)
        else:
            operation = "max"
            answer_value = max(float(record["value"]) for record in records)
        matching_records = [
            record for record in records
            if float(record["value"]) == answer_value
        ]
        metric_label = MATCHLOG_STATS[parsed["metric_key"]]
        metric_heading = (
            f"combined {metric_label}"
            if match_total_query and any(
                record.get("match_total") for record in records
            )
            else metric_label
        )
        subject = (
            f"for **{player_name}**"
            if player_name
            else "across all verified players"
        )
        if opponent_name:
            subject += f" against **{opponent_name}**"
        if character_name:
            subject += f" using **{character_name}**"
        operation_label = {
            "max": "Highest",
            "min": "Lowest",
            "average": "Average",
            "sum": "Total",
        }[operation]
        answer = (
            f"📊 **{operation_label.capitalize()} {metric_heading}"
            f" {subject}:** "
            f"**{_format_stats_question_value(parsed['metric_key'], answer_value)}**"
        )
        answer += (
            f"\nBased on **{len(records)} verified observation"
            f"{'s' if len(records) != 1 else ''}**."
        )
        source_names = {
            str(record.get("source") or "").casefold()
            for record in records
        }
        source_footer = (
            "Screenshots" if "screenshots" in source_names else "MatchLog"
        )
        if (
            match_total_query
            and operation in {"max", "min"}
            and matching_records
            and matching_records[0].get("match_total")
        ):
            compact_answer = _format_stats_match_total_response(
                matching_records[0],
                parsed["metric_key"],
                source_footer,
            )
            await interaction.followup.send(
                _limit_discord_message(
                    _format_stats_question_with_echo(
                        question,
                        compact_answer,
                    )
                ),
                allowed_mentions=discord.AllowedMentions(
                    everyone=False,
                    roles=False,
                    users=True,
                ),
            )
            return
        answer += f"\n_Source: {source_footer}._"
        if operation in {"max", "min"}:
            winner = matching_records[0]
            tournament = str(winner.get("tournament") or "tournament unavailable")
            round_name = str(winner.get("round") or "").strip()
            event_label = (
                f"{tournament} • {round_name}"
                if round_name
                else f"{tournament} • official round unavailable"
            )
            player_label = _stats_question_player_label(
                winner.get("player"),
                winner.get("tour"),
            )
            opponent_label = _stats_question_player_label(
                winner.get("opponent"),
                winner.get("tour"),
            )
            answer += (
                f"\n**{player_label}** vs {opponent_label} "
                f"({winner['tour'].upper()}) • "
                f"{event_label} • {winner['date']} • "
                f"{winner['result'] or 'score unavailable'}"
            )
            if len(matching_records) > 1:
                answer += (
                    f"\nTie: {len(matching_records)} verified result(s) share "
                    "that value."
                )
        answer = _format_stats_question_with_echo(question, answer)
        await interaction.followup.send(
            _limit_discord_message(answer),
            allowed_mentions=discord.AllowedMentions(
                everyone=False,
                roles=False,
                users=True,
            ),
        )
    except asyncio.TimeoutError:
        await interaction.followup.send(
            _stats_question_recovery_message(
                question,
                locals().get("parsed") or {},
                "That statistics question took too long to answer",
            ),
            ephemeral=True,
        )
    except Exception as exc:
        print(
            f"[MatchLog Stats] askstats failed: {type(exc).__name__}: {exc}",
            flush=True,
        )
        await interaction.followup.send(
            _stats_question_recovery_message(
                question,
                locals().get("parsed") or {},
                "I couldn't answer that exact question from the verified records",
            ),
            ephemeral=True,
        )


@client.tree.command(
    name="mystats",
    description="Show your private official WTSL performance dashboard",
)
@app_commands.describe(tour="Choose your verified WTSL tour")
@app_commands.choices(tour=[
    app_commands.Choice(name="ATP", value="atp"),
    app_commands.Choice(name="WTA", value="wta"),
])
@app_commands.describe(source="Choose which statistics dataset to use")
@app_commands.choices(source=[
    app_commands.Choice(name="Match logs", value="matchlog"),
    app_commands.Choice(name="Screenshots", value="screenshots"),
])
@app_commands.describe(period="Choose the statistics time period")
@app_commands.choices(period=[
    app_commands.Choice(name="Last 30 days", value="30d"),
    app_commands.Choice(name="Last 90 days", value="90d"),
    app_commands.Choice(name="Year to date", value="year"),
    app_commands.Choice(name="Career", value="career"),
    app_commands.Choice(name="Last 52 weeks", value="52w"),
])
async def mystats(
    interaction: discord.Interaction,
    tour: app_commands.Choice[str],
    source: app_commands.Choice[str],
    period: app_commands.Choice[str],
):
    await interaction.response.defer(ephemeral=True, thinking=True)
    command_started = time.monotonic()
    comparison_task: asyncio.Task | None = None
    try:
        selected_tour = tour.value
        selected_source = source.value
        selected_period = period.value
        if _matchlog_rebuild_state in {"not_started", "running"}:
            links = _matchlog_links(interaction.user.id)
            if selected_tour in links:
                _matchlog_status_subscribers.add(interaction.user.id)
                player = f"{selected_tour.upper()}: {links[selected_tour]}"
                message = (
                    f"Your MatchLog identity is approved as **{player}**. "
                    "The database sync is still rebuilding the temporary "
                    "workbook, so the bot cannot yet confirm whether your "
                    "statistics exist. The bot owner receives private progress "
                    "updates. You and the bot owner will receive DMs when the "
                    "sync completes or fails."
                )
            else:
                message = (
                    "The statistics database is still rebuilding after the "
                    "latest deployment. Please try `/mystats` again shortly."
                )
            await _send_mystats_followup(
                interaction,
                message,
            )
            return
        if _matchlog_rebuild_state == "failed":
            await _send_mystats_followup(
                interaction,
                "Private statistics are temporarily unavailable because the "
                "latest database sync failed. No workbook statistics are being "
                "served to avoid showing stale or incomplete data. The bot "
                "owner has been notified.",
            )
            return
        as_of = _dt.datetime.now(_dt.timezone.utc).date()
        links = _matchlog_links(interaction.user.id)
        restored_identity = False
        if not links:
            restored_identity = await asyncio.wait_for(
                _restore_matchlog_identity_for_user(interaction.user.id),
                timeout=10,
            )
            links = _matchlog_links(interaction.user.id)
        if not links and not restored_identity:
            await _send_mystats_followup(
                interaction,
                "No verified MatchLog player identity is bound to your "
                "Discord account. Ask an administrator to approve you.",
            )
            return
        if links and selected_tour not in links:
            await _send_mystats_followup(
                interaction,
                f"You do not have a verified {selected_tour.upper()} MatchLog identity.",
            )
            return
        screenshot_identity = links.get(selected_tour, "")
        screenshot_summary, matchlog_summary = await asyncio.wait_for(
            _get_mystats_summaries(
                interaction.user.id,
                screenshot_identity,
                selected_tour,
                selected_period,
                as_of,
                selected_source,
            ),
            timeout=MYSTATS_SUMMARY_TIMEOUT_SECONDS,
        )
        summary = (
            screenshot_summary
            if selected_source == "screenshots"
            else matchlog_summary
        )
        if summary is None and restored_identity:
            screenshot_summary, matchlog_summary = await asyncio.wait_for(
                _get_mystats_summaries(
                    interaction.user.id,
                    screenshot_identity,
                    selected_tour,
                    selected_period,
                    as_of,
                    selected_source,
                ),
                timeout=MYSTATS_SUMMARY_TIMEOUT_SECONDS,
            )
            summary = (
                screenshot_summary
                if selected_source == "screenshots"
                else matchlog_summary
            )
        if summary is None:
            if interaction.user.id in _matchlog_identity_index:
                selected_links = _matchlog_links(interaction.user.id)
                player = (
                    f"{selected_tour.upper()}: {selected_links[selected_tour]}"
                    if selected_tour in selected_links
                    else _matchlog_identity_label(selected_links)
                )
                if selected_source == "screenshots":
                    message = (
                        f"Your WTSL identity is approved as **{player}**, but no "
                        "verified screenshot statistics were found for that "
                        "player yet."
                    )
                elif _matchlog_rebuild_state in {"not_started", "running"}:
                    _matchlog_status_subscribers.add(interaction.user.id)
                    message = (
                        f"Your MatchLog identity is approved as **{player}**. "
                        "The database sync is still rebuilding the temporary "
                        "workbook, so the bot cannot "
                        "yet confirm whether your statistics exist. The bot "
                        "owner receives private progress updates. You and the "
                        "bot owner will receive DMs when the sync completes "
                        "or fails."
                    )
                elif _matchlog_rebuild_state == "failed":
                    message = (
                        f"Your MatchLog identity is approved as **{player}**, "
                        "but the database sync failed. The bot owner has been "
                        "notified; statistics cannot be confirmed until that "
                        "failure is resolved."
                    )
                else:
                    message = (
                        f"Your MatchLog identity is approved as **{player}** and "
                        "the database sync is complete, but no verified "
                        f"{'screenshot' if selected_source == 'screenshots' else 'MatchLog'} "
                        "statistics were found for that player."
                    )
            else:
                message = (
                    "No verified MatchLog player identity is bound to your "
                    "Discord account. Ask an administrator to approve you."
                )
            await _send_mystats_followup(
                interaction,
                _limit_discord_message(message),
            )
            return
        comparison_source = (
            "matchlog" if selected_source == "screenshots" else "screenshots"
        )
        comparison_task = asyncio.create_task(
            _get_mystats_summaries(
                interaction.user.id,
                screenshot_identity,
                selected_tour,
                selected_period,
                as_of,
                comparison_source,
            )
        )
        profile_started = time.monotonic()
        try:
            profile, fixture = await asyncio.wait_for(
                asyncio.gather(
                    _fetch_mystats_ranking(summary["player"], selected_tour),
                    _verified_player_fixture(summary["player"], selected_tour),
                    return_exceptions=True,
                ),
                timeout=MYSTATS_PROFILE_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError:
            profile, fixture = {}, None
        if isinstance(profile, Exception):
            exc = profile
            print(
                f"[MatchLog Stats] WTSL profile unavailable: "
                f"{type(exc).__name__}: {exc}",
                flush=True,
            )
            profile = {
                "category": f"{selected_tour.upper()} Singles",
                "rank": None,
                "wtsl_elo": None,
                "movement": None,
                "previous_rank": None,
            }
        if isinstance(fixture, Exception):
            fixture = None
        print(
            f"[MatchLog Stats] mystats profile and fixture loaded in "
            f"{time.monotonic() - profile_started:.1f}s",
            flush=True,
        )
        dashboard_started = time.monotonic()
        insights = _generate_mystats_insights_sync(summary, profile)
        character_recommendations = []
        if insights:
            try:
                character_recommendations = await asyncio.wait_for(
                    asyncio.to_thread(
                        recommend_character_choices,
                        summary,
                        insights,
                        selected_tour,
                        3,
                    ),
                    timeout=MYSTATS_CHARACTER_RECOMMENDATION_TIMEOUT_SECONDS,
                )
            except asyncio.TimeoutError:
                print(
                    "[MatchLog Stats] character recommendations timed out; "
                    "continuing without them",
                    flush=True,
                )
            except Exception as recommendation_exc:
                print(
                    "[MatchLog Stats] character recommendations unavailable: "
                    f"{type(recommendation_exc).__name__}: {recommendation_exc}",
                    flush=True,
                )
        dashboard = _build_mystats_dashboard(
            summary,
            profile,
            insights,
            fixture,
            screenshot_summary=screenshot_summary,
            matchlog_summary=matchlog_summary,
            character_recommendations=character_recommendations,
        )
        print(
            f"[MatchLog Stats] mystats dashboard built in "
            f"{time.monotonic() - dashboard_started:.1f}s",
            flush=True,
        )
        dashboard_delivery = await _deliver_mystats_dashboard(
            interaction,
            dashboard,
        )
        print(
            f"[MatchLog Stats] mystats completed in "
            f"{time.monotonic() - command_started:.1f}s",
            flush=True,
        )
        if any(dashboard_delivery):
            try:
                other_screenshot, other_matchlog = await asyncio.wait_for(
                    comparison_task,
                    timeout=MYSTATS_COMPARISON_TIMEOUT_SECONDS,
                )
                comparison_screenshot = (
                    screenshot_summary or other_screenshot
                )
                comparison_matchlog = matchlog_summary or other_matchlog
                if comparison_screenshot and comparison_matchlog:
                    comparison_embeds = _build_mystats_source_comparison_embeds(
                        comparison_screenshot,
                        comparison_matchlog,
                        profile,
                    )
                    delivery_results = []
                    for comparison_embed in comparison_embeds:
                        delivery_results.append(await asyncio.gather(
                            _send_mystats_followup(
                                interaction,
                                embed=comparison_embed,
                                timeout=10,
                            ),
                            _send_mystats_dm(
                                interaction.user,
                                comparison_embed,
                                timeout=10,
                                content=(
                                    "Your private Screenshots vs MatchLog "
                                    "comparison:"
                                ),
                            ),
                        ))
                    delivered_pages = sum(
                        1 for result in delivery_results if any(result)
                    )
                    print(
                        "[MatchLog Stats] mystats comparison delivery: "
                        f"{delivered_pages}/{len(comparison_embeds)} page(s) "
                        "sent by at least one private channel",
                        flush=True,
                    )
            except asyncio.TimeoutError:
                print(
                    "[MatchLog Stats] mystats comparison source timed out after "
                    "the primary dashboard was delivered",
                    flush=True,
                )
                await _send_mystats_followup(
                    interaction,
                    "Your selected-source dashboard was delivered, but the "
                    "second source did not finish in time for this comparison.",
                )
            except Exception as comparison_exc:
                print(
                    "[MatchLog Stats] mystats comparison unavailable: "
                    f"{type(comparison_exc).__name__}: {comparison_exc}",
                    flush=True,
                )
    except AmbiguousPlayerNameError:
        await _send_mystats_followup(
            interaction,
            "Your approved MatchLog identity matches both an ATP and WTA "
            "player. Ask an administrator to re-link it using "
            "`ATP: Player Name` or `WTA: Player Name`.",
        )
    except asyncio.TimeoutError as exc:
        print(
            f"[MatchLog Stats] mystats timed out: {type(exc).__name__}",
            flush=True,
        )
        await _send_mystats_followup(
            interaction,
            "Your statistics took too long to load. Please try again in a moment.",
        )
    except Exception as exc:
        print(
            f"[MatchLog Stats] mystats failed: {type(exc).__name__}: {exc}",
            flush=True,
        )
        await _send_mystats_followup(
            interaction,
            "I couldn't read your statistics right now. Please try again later.",
        )
    finally:
        if comparison_task is not None:
            if not comparison_task.done():
                comparison_task.cancel()
            try:
                await comparison_task
            except asyncio.CancelledError:
                pass
            except Exception as comparison_exc:
                print(
                    "[MatchLog Stats] mystats comparison task ended with: "
                    f"{type(comparison_exc).__name__}: {comparison_exc}",
                    flush=True,
                )


async def _verified_player_fixture(
    player_name: str,
    tour: str,
) -> dict[str, typing.Any] | None:
    async with aiohttp.ClientSession() as session:
        async with session.get(
            "https://playwtsl.com/TE4",
            timeout=aiohttp.ClientTimeout(total=15),
        ) as response:
            response.raise_for_status()
            fixtures = parse_upcoming_fixtures(
                await response.text(),
                season=str(_dt.datetime.now(_dt.timezone.utc).year),
            )
    return _select_verified_player_fixture(fixtures, player_name, tour)


async def _verified_pair_fixture(
    first_name: str,
    second_name: str,
    tour: str,
) -> dict[str, typing.Any] | None:
    async with aiohttp.ClientSession() as session:
        async with session.get(
            "https://playwtsl.com/TE4",
            timeout=aiohttp.ClientTimeout(total=15),
        ) as response:
            response.raise_for_status()
            fixtures = parse_upcoming_fixtures(
                await response.text(),
                season=str(_dt.datetime.now(_dt.timezone.utc).year),
            )
    wanted = {
        normalize_matchlog_name(first_name),
        normalize_matchlog_name(second_name),
    }
    matches = [
        fixture for fixture in fixtures
        if normalize_matchlog_name(fixture.get("tour")) == tour
        and {
            normalize_matchlog_name(fixture.get("first_name")),
            normalize_matchlog_name(fixture.get("second_name")),
        } == wanted
    ]
    dated = sorted(matches, key=lambda item: str(item.get("scheduled_at") or ""))
    return dated[0] if dated else None


def _select_verified_player_fixture(
    fixtures: list[dict[str, typing.Any]],
    player_name: str,
    tour: str,
) -> dict[str, typing.Any] | None:
    wanted = normalize_matchlog_name(player_name)
    matches = []
    for fixture in fixtures:
        if normalize_matchlog_name(fixture.get("tour")) != tour:
            continue
        if wanted in {
            normalize_matchlog_name(fixture.get("first_name")),
            normalize_matchlog_name(fixture.get("second_name")),
        }:
            matches.append(fixture)
    if len(matches) == 1:
        return matches[0]
    dated = [fixture for fixture in matches if fixture.get("scheduled_at")]
    if len(dated) != len(matches):
        return None
    return min(dated, key=lambda fixture: str(fixture["scheduled_at"]))


@client.tree.command(
    name="matchkeys",
    description="Show private keys for your next match from your verified stats",
)
@app_commands.describe(tour="Optional tour when you have both ATP and WTA links")
@app_commands.choices(tour=[
    app_commands.Choice(name="ATP", value="atp"),
    app_commands.Choice(name="WTA", value="wta"),
])
@app_commands.describe(source="Choose which statistics dataset to use")
@app_commands.choices(source=[
    app_commands.Choice(name="Match logs", value="matchlog"),
    app_commands.Choice(name="Screenshots", value="screenshots"),
])
async def matchkeys(
    interaction: discord.Interaction,
    tour: app_commands.Choice[str] | None = None,
    source: app_commands.Choice[str] | None = None,
):
    await interaction.response.defer(ephemeral=True, thinking=True)
    selected_tour = tour.value if tour else None
    selected_source = source.value if source else "matchlog"
    try:
        links = _matchlog_links(interaction.user.id)
        if not links:
            await _restore_matchlog_identity_for_user(interaction.user.id)
            links = _matchlog_links(interaction.user.id)
        if not links:
            await interaction.followup.send(
                "No verified WTSL player identity is bound to your Discord account.",
                ephemeral=True,
            )
            return
        if selected_tour is None and len(links) > 1:
            await interaction.followup.send(
                "Choose ATP or WTA because both tours are linked to your account.",
                ephemeral=True,
            )
            return
        selected_tour = selected_tour or next(iter(links))
        if selected_tour not in links:
            await interaction.followup.send(
                f"You do not have a verified {selected_tour.upper()} WTSL "
                "identity on this Discord account. Your server nickname is not "
                "used to identify players.",
                ephemeral=True,
            )
            return
        player_name = links[selected_tour]
        try:
            fixture = await _verified_player_fixture(player_name, selected_tour)
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            print(
                f"[Match Keys] upcoming fixture lookup failed for "
                f"{player_name} ({selected_tour}): "
                f"{type(exc).__name__}: {exc}",
                flush=True,
            )
            await interaction.followup.send(
                "I couldn't check WTSL's upcoming fixtures right now. "
                "Please try `/matchkeys` again shortly.",
                ephemeral=True,
            )
            return
        if fixture is None:
            await interaction.followup.send(
                f"No upcoming {selected_tour.upper()} fixture was found for "
                f"your verified WTSL player **{player_name}**. "
                "Other upcoming fixtures do not qualify; `/matchkeys` only "
                "works when WTSL lists you in the fixture.",
                ephemeral=True,
            )
            return
        player_is_first = (
            normalize_matchlog_name(fixture["first_name"])
            == normalize_matchlog_name(player_name)
        )
        opponent_name = (
            fixture["second_name"] if player_is_first else fixture["first_name"]
        )
        if selected_source == "screenshots":
            exclusions = await _get_screenshot_statistics_exclusions()
            player_summary, opponent_summary = await asyncio.gather(
                asyncio.to_thread(
                    get_screenshot_player_summary,
                    MATCH_STATS_WORKBOOK,
                    player_name,
                    selected_tour,
                    excluded_match_keys_by_player=exclusions.get(
                        selected_tour, {}
                    ),
                ),
                asyncio.to_thread(
                    get_screenshot_player_summary,
                    MATCH_STATS_WORKBOOK,
                    opponent_name,
                    selected_tour,
                    excluded_match_keys_by_player=exclusions.get(
                        selected_tour, {}
                    ),
                ),
            )
            source_label = "Screenshot stats"
        else:
            player_summary, opponent_summary = await asyncio.gather(
                asyncio.to_thread(
                    get_matchlog_player_summary,
                    MATCH_STATS_WORKBOOK,
                    interaction.user.id,
                    selected_tour,
                ),
                asyncio.to_thread(
                    get_matchlog_player_summary_by_name,
                    MATCH_STATS_WORKBOOK,
                    f"{selected_tour.upper()}: {opponent_name}",
                ),
            )
            source_label = "MatchLog"
        if player_summary is None:
            await interaction.followup.send(
                f"No {source_label} statistics were found for your verified player.",
                ephemeral=True,
            )
            return
        keys = personalized_match_keys(
            player_name,
            player_summary,
            opponent_name,
            opponent_summary,
        )
        embed = discord.Embed(
            title=f"🔑 Your keys vs {opponent_name}",
            description=(
                f"**Source: {source_label}** • "
                f"{fixture.get('tournament') or 'Upcoming fixture'}"
            ),
            color=0x3498DB,
        )
        embed.add_field(
            name=f"For {player_name}",
            value="Each key is shown separately so the tactical guidance "
            "cannot be cut off by Discord's embed-field limit.",
            inline=False,
        )
        for key_index, key in enumerate(keys[:4], start=1):
            key_parts = split_discord_message(key, limit=950) or [key]
            for part_index, part in enumerate(key_parts, start=1):
                field_name = f"Key {key_index}"
                if part_index > 1:
                    field_name += f" (continued {part_index})"
                embed.add_field(name=field_name, value=part, inline=False)
        if opponent_summary is None:
            embed.set_footer(
                text="Opponent stats were unavailable; these keys use only your profile."
            )
        await interaction.followup.send(embed=embed, ephemeral=True)
    except Exception as exc:
        print(
            f"[Match Keys] private command failed: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        await interaction.followup.send(
            "I couldn't build your private match keys right now. Please try again later.",
            ephemeral=True,
        )


def _limit_discord_message(message: str) -> str:
    return message if len(message) <= 2000 else message[:1997] + "..."


_stats_autocomplete_cache: tuple[int, list[str]] | None = None


def _get_stats_autocomplete_names() -> list[str]:
    global _stats_autocomplete_cache
    modified = MATCH_STATS_WORKBOOK.stat().st_mtime_ns
    if (
        _stats_autocomplete_cache is None
        or _stats_autocomplete_cache[0] != modified
    ):
        _stats_autocomplete_cache = (
            modified,
            get_matchlog_player_summary_names(MATCH_STATS_WORKBOOK),
        )
    return _stats_autocomplete_cache[1]


async def _refresh_stats_autocomplete_cache() -> list[str]:
    """Rebuild names off the event loop, then atomically publish the snapshot."""
    global _stats_autocomplete_cache

    def load() -> tuple[int, list[str]]:
        names = get_matchlog_player_summary_names(MATCH_STATS_WORKBOOK)
        try:
            modified = MATCH_STATS_WORKBOOK.stat().st_mtime_ns
        except OSError:
            modified = 0
        return modified, names

    modified, names = await asyncio.to_thread(load)
    _stats_autocomplete_cache = (modified, names)
    return names


async def _stats_player_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    if not _stats_channel_allowed(interaction):
        return []
    cached = _stats_autocomplete_cache
    if cached is not None:
        names = cached[1]
    else:
        names = sorted({
            (
                f"{tour.upper()}: {player}"
                if len(links) > 1 else player
            )
            for links in _matchlog_identity_index.values()
            if isinstance(links, dict)
            for tour, player in links.items()
            if player
        }, key=normalize_matchlog_name)
    wanted = normalize_matchlog_name(current)
    matches = [
        name for name in names
        if not wanted or wanted in normalize_matchlog_name(name)
    ]
    return [
        app_commands.Choice(name=name[:100], value=name[:100])
        for name in matches[:25]
    ]


async def _wait_for_matchlog_rebuild() -> None:
    """Keep secondary workbook jobs idle until the atomic rebuild is ready."""
    while _matchlog_rebuild_state in {"not_started", "running"}:
        await asyncio.sleep(5)


def _stats_channel_allowed(interaction: discord.Interaction) -> bool:
    channel = getattr(interaction, "channel", None)
    channel_id = getattr(channel, "id", None)
    parent_id = getattr(channel, "parent_id", None)
    if WTSLSTATS_PUBLIC_CHANNEL_IDS.intersection({channel_id, parent_id}):
        return True
    guild = getattr(interaction, "guild", None)
    user = getattr(interaction, "user", None)
    permissions = getattr(user, "guild_permissions", None)
    is_admin = bool(
        getattr(permissions, "administrator", False)
        or getattr(permissions, "manage_guild", False)
    )
    if not is_admin or guild is None or channel is None:
        return False
    try:
        default_permissions = channel.permissions_for(guild.default_role)
    except (AttributeError, TypeError):
        return False
    return not bool(getattr(default_permissions, "view_channel", True))


async def _get_wtslstats_player_summary(
    player: str,
    source: str,
    tour: str | None,
    period: str = "career",
    as_of=None,
) -> dict[str, typing.Any] | None:
    prefix, separator, unqualified = player.partition(":")
    qualified_tour = prefix.strip().casefold() if separator else None
    if qualified_tour not in {"atp", "wta"}:
        qualified_tour = None
        unqualified = player
    elif tour is not None and qualified_tour != tour:
        return None
    selected_tour = tour or qualified_tour
    player_name = unqualified.strip()
    if source != "screenshots":
        lookup = (
            f"{selected_tour.upper()}: {player_name}"
            if selected_tour else player_name
        )
        return await asyncio.to_thread(
            get_matchlog_player_summary_by_name,
            MATCH_STATS_WORKBOOK, lookup, period, as_of,
        )
    exclusions = await _get_screenshot_statistics_exclusions()
    if selected_tour:
        return await asyncio.to_thread(
            get_screenshot_player_summary,
            MATCH_STATS_WORKBOOK,
            player_name,
            selected_tour,
            period,
            as_of,
            excluded_match_keys_by_player=exclusions.get(selected_tour, {}),
        )
    found = [
        summary
        for candidate_tour in ("atp", "wta")
        if (
            summary := await asyncio.to_thread(
                get_screenshot_player_summary,
                MATCH_STATS_WORKBOOK,
                player_name,
                candidate_tour,
                period,
                as_of,
                excluded_match_keys_by_player=exclusions.get(candidate_tour, {}),
            )
        ) is not None
    ]
    if len(found) > 1:
        raise AmbiguousPlayerNameError(
            f"**{player_name}** has screenshot statistics on both tours. "
            "Choose ATP or WTA."
        )
    return found[0] if found else None


def _dashboard_stat_value(label: str, value: typing.Any) -> str:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return "N/A"
    if label.endswith("%"):
        return f"{value:.1%}"
    shown = f"{value:.2f}".rstrip("0").rstrip(".")
    return (
        f"{shown} km/h"
        if "Speed" in label or label == "Fastest Serve"
        else shown
    )


def _wtslstats_recent_results(
    profile: dict[str, typing.Any],
    player_name: str,
    period: str = "career",
    as_of: str | None = None,
) -> str:
    recent = _dashboard_recent_results(
        profile,
        player_name,
        period,
        as_of,
    )
    if not recent:
        return "No recent matches available"
    return "\n".join(
        f"• {str(match.get('date') or match.get('match_datetime') or '?')[:10]} "
        f"vs {str(match.get('opponent') or '?')[:20]} — "
        f"{str(match.get('result') or 'No score')[:25]}"
        for match in recent
    )[:1024]


def _build_wtslstats_dashboard(
    summary: dict[str, typing.Any],
    source: str,
    profile: dict[str, typing.Any] | None = None,
    fixture: dict[str, typing.Any] | None = None,
) -> discord.Embed:
    profile = profile or {}
    summary = _with_official_result_metrics(summary, profile)
    source_label = "Screenshots" if source == "screenshots" else "MatchLog"
    match_count_label = (
        "verified matches used"
        if source == "screenshots"
        else "verified MatchLog matches"
    )
    tour = str(summary.get("tour") or "").upper()
    period_label = str(summary.get("period_label") or "Career")
    embed = discord.Embed(
        title=f"🎾 {summary['player']} — WTSL Stats Dashboard"[:256],
        description=(
            f"**Source: {source_label}**"
            + (f" • {tour}" if tour else "")
            + f" • **Period: {period_label}**"
            + f" • {summary.get('matches', 0)} {match_count_label}"
            + (
                _matchlog_coverage_description(summary, profile)
                if source == "matchlog" else ""
            )
        ),
        color=0x9B59B6 if source == "screenshots" else 0x2ECC71,
    )
    embed.add_field(
        name="🏆 Ranking",
        value=(
            f"#{profile['rank']}"
            if profile.get("rank") is not None else "Not currently available"
        ),
        inline=True,
    )
    coverage_span = (
        _matchlog_coverage_span_text(summary, profile)
        if source == "matchlog" else None
    )
    if coverage_span:
        embed.add_field(
            name="🗓️ MatchLog Coverage",
            value=coverage_span,
            inline=False,
        )
    embed.add_field(
        name="🔥 Recent Form",
        value=str(profile.get("form") or "Not currently available")[:100],
        inline=True,
    )
    embed.add_field(
        name=f"📅 {_dt.datetime.now(_dt.timezone.utc).year} Season Highlights",
        value=_mystats_year_summary(profile),
        inline=True,
    )
    embed.add_field(
        name="🎮 Most Picked Characters",
        value=_most_picked_characters_text(summary, profile),
        inline=True,
    )
    ratings = "\n".join(
        f"**{label}:** {_dashboard_stat_value(label, value)}"
        for label, value in summary.get("ratings") or []
    ) or "Not enough data"
    embed.add_field(name="⚡ Ratings", value=ratings[:1024], inline=False)
    career = [
        f"**{label}:** {_dashboard_stat_value(label, value)} "
        f"({int(count)} match{'es' if int(count) != 1 else ''} used)"
        for label, value, count in (summary.get("metrics") or [])
    ]
    _add_dashboard_line_fields(embed, f"📊 {period_label} Stats", career)
    embed.add_field(
        name="🗓️ Last 5 matches",
        value=_wtslstats_recent_results(
            profile,
            summary["player"],
            str(summary.get("period") or "career"),
            summary.get("as_of"),
        ),
        inline=False,
    )
    embed.add_field(
        name="⏭️ Upcoming Match & Odds",
        value=_dashboard_upcoming_fixture(fixture),
        inline=False,
    )
    _add_rating_formula_footnote(embed, source)
    embed.set_footer(
        text=(
            f"Source: {source_label} • Official WTSL profile and recent matches "
            "• Speeds use km/h"
        )
    )
    return embed


def _build_wtslstats_comparison_dashboard(
    first: dict[str, typing.Any],
    second: dict[str, typing.Any],
    source: str,
    first_profile: dict[str, typing.Any] | None = None,
    second_profile: dict[str, typing.Any] | None = None,
    fixture: dict[str, typing.Any] | None = None,
) -> discord.Embed:
    first_profile = first_profile or {}
    second_profile = second_profile or {}
    first = _with_official_result_metrics(first, first_profile)
    second = _with_official_result_metrics(second, second_profile)
    source_label = "Screenshots" if source == "screenshots" else "MatchLog"
    period_label = str(first.get("period_label") or "Career")
    first_ratings = dict(first.get("ratings") or [])
    second_ratings = dict(second.get("ratings") or [])
    first_metrics = {
        label: (value, count)
        for label, value, count in first.get("metrics") or []
    }
    second_metrics = {
        label: (value, count)
        for label, value, count in second.get("metrics") or []
    }
    embed = discord.Embed(
        title=f"⚖️ {first['player']} vs {second['player']}"[:256],
        description=(
            f"**Source: {source_label}** • "
            + (
                "Verified matches used: "
                if source == "screenshots"
                else "Official matches: "
            )
            + f"{first.get('matches', 0)} vs {second.get('matches', 0)} • "
            f"**Period: {period_label}**"
        ),
        color=0x3498DB,
    )
    rating_labels = ("Serve Rating", "Return Rating", "Under Pressure")
    embed.add_field(
        name="⚡ Ratings",
        value="\n".join(
            f"**{label}:** "
            f"{_dashboard_stat_value(label, first_ratings.get(label))} | "
            f"{_dashboard_stat_value(label, second_ratings.get(label))}"
            for label in rating_labels
        )[:1024],
        inline=False,
    )
    metric_labels = list(dict.fromkeys([
        *(label for label, _value, _count in first.get("metrics") or []),
        *(label for label, _value, _count in second.get("metrics") or []),
    ]))
    _add_dashboard_line_fields(
        embed,
        f"📊 {period_label} Stats",
        [
            f"**{label}:** "
            f"{_dashboard_stat_value(label, (first_metrics.get(label) or (None, 0))[0])} "
            f"({int((first_metrics.get(label) or (None, 0))[1])} used) | "
            f"{_dashboard_stat_value(label, (second_metrics.get(label) or (None, 0))[0])} "
            f"({int((second_metrics.get(label) or (None, 0))[1])} used)"
            for label in metric_labels
        ],
    )
    embed.add_field(
        name=(
            f"📅 {first['player']} — "
            f"{_dt.datetime.now(_dt.timezone.utc).year} Season Highlights"
        )[:256],
        value=_mystats_year_summary(first_profile),
        inline=True,
    )
    embed.add_field(
        name=(
            f"📅 {second['player']} — "
            f"{_dt.datetime.now(_dt.timezone.utc).year} Season Highlights"
        )[:256],
        value=_mystats_year_summary(second_profile),
        inline=True,
    )
    embed.add_field(
        name=f"🎮 {first['player']} — Most Picked"[:256],
        value=_most_picked_characters_text(first, first_profile),
        inline=True,
    )
    embed.add_field(
        name=f"🎮 {second['player']} — Most Picked"[:256],
        value=_most_picked_characters_text(second, second_profile),
        inline=True,
    )
    embed.add_field(
        name=f"🗓️ {first['player']} — Last 5"[:256],
        value=_wtslstats_recent_results(
            first_profile,
            first["player"],
            str(first.get("period") or "career"),
            first.get("as_of"),
        ),
        inline=True,
    )
    embed.add_field(
        name=f"🗓️ {second['player']} — Last 5"[:256],
        value=_wtslstats_recent_results(
            second_profile,
            second["player"],
            str(second.get("period") or "career"),
            second.get("as_of"),
        ),
        inline=True,
    )
    embed.add_field(
        name="🎯 Upcoming Match Odds",
        value=_dashboard_upcoming_fixture(fixture),
        inline=False,
    )
    _add_rating_formula_footnote(embed, source)
    embed.set_footer(
        text=(
            f"Source: {source_label} • Values show {first['player']} | "
            f"{second['player']} • Official WTSL recent matches"
        )[:2048]
    )
    return embed


LEADERBOARD_CATEGORIES = (
    ("🎾 Serve", "Serve (Overall)"),
    ("↩️ Return", "Return (Overall)"),
    ("🔥 Under Pressure", "Under Pressure"),
)
MOST_PICKED_CHARACTERS_STAT = "Most Picked Characters"
LEADERBOARD_SIZE = 10
LEADERBOARD_MIN_MATCHES = 20
WEEKLY_LEADERBOARD_CHANNEL_ID = 1496467915778686997
WEEKLY_LEADERBOARD_LEGACY_MARKER = "Weekly screenshot leaderboard"
WEEKLY_LEADERBOARD_STARTUP_DELAY_SECONDS = 90
LEADERBOARD_LOWER_IS_BETTER = frozenset({
    "Double Faults",
    "Unforced Errors",
})
_leaderboard_rankings_cache: dict[str, dict[str, dict[str, typing.Any]]] = {}
_leaderboard_rankings_cache_time: dict[str, float] = {}
_weekly_leaderboard_lock = asyncio.Lock()


def _leaderboard_stat_options(source: str) -> list[str]:
    ratings = [rating for _, rating in LEADERBOARD_CATEGORIES]
    metrics = (
        list(MATCHLOG_SUMMARY_STATS.values())
        if source == "matchlog"
        else list(SCREENSHOT_LEADERBOARD_METRICS)
    )
    return list(dict.fromkeys([
        MOST_PICKED_CHARACTERS_STAT,
        *ratings,
        *metrics,
    ]))


def _character_leaderboard_cards(
    results: list[dict[str, typing.Any]],
    tour: str,
) -> list[dict[str, typing.Any]]:
    counts: dict[str, int] = {}
    labels: dict[str, str] = {}
    for result in results:
        if str(result.get("tour") or "").casefold() != tour.casefold():
            continue
        for field in ("p1_character", "p2_character"):
            character = str(result.get(field) or "").strip()
            if not character:
                continue
            key = character.casefold()
            counts[key] = counts.get(key, 0) + 1
            labels.setdefault(key, character)
    total = sum(counts.values())
    ranked = sorted(
        counts,
        key=lambda key: (-counts[key], labels[key].casefold()),
    )[:LEADERBOARD_SIZE]
    return [
        {
            "place": place,
            "character": labels[key],
            "count": counts[key],
            "percentage": counts[key] / total,
        }
        for place, key in enumerate(ranked, 1)
    ]


def _build_character_leaderboard_embed(
    cards: list[dict[str, typing.Any]],
    tour: str,
) -> discord.Embed:
    medals = {1: "🥇", 2: "🥈", 3: "🥉"}
    lines = []
    for card in cards:
        marker = medals.get(card["place"], f"**#{card['place']}**")
        lines.append(
            f"{marker} "
            f"**{card['character']}** — {card['count']} "
            f"pick{'s' if card['count'] != 1 else ''} "
            f"({card['percentage']:.1%})"
        )
    embed = discord.Embed(
        title=f"{tour.upper()} 🎮 Most Picked Characters",
        description="\n".join(lines),
        color=discord.Color.gold(),
    )
    embed.set_footer(
        text=(
            f"{tour.upper()} • Official WTSL results • Career leaderboard • "
            "Share is among known character selections"
        )
    )
    return embed


def _leaderboard_cards(
    rows: list[dict[str, typing.Any]],
    selected_stat: str,
) -> list[dict[str, typing.Any]]:
    rating_labels = {rating for _, rating in LEADERBOARD_CATEGORIES}
    value_group = "ratings" if selected_stat in rating_labels else "metrics"
    lower_is_better = selected_stat in LEADERBOARD_LOWER_IS_BETTER
    eligible = [
        row for row in rows
        if isinstance(row.get(value_group, {}).get(selected_stat), (int, float))
    ]
    ranked = sorted(
        eligible,
        key=lambda row: (
            (
                float(row[value_group][selected_stat])
                if lower_is_better
                else -float(row[value_group][selected_stat])
            ),
            normalize_matchlog_name(row["player"]),
        ),
    )[:LEADERBOARD_SIZE]
    category = next(
        (label for label, rating in LEADERBOARD_CATEGORIES if rating == selected_stat),
        f"📊 {selected_stat}",
    )
    return [
        {
            **row,
            "category": category,
            "stat": selected_stat,
            "value": float(row[value_group][selected_stat]),
            "place": place,
        }
        for place, row in enumerate(ranked, 1)
    ]


async def _leaderboard_stat_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    namespace = getattr(interaction, "namespace", None)
    selected = getattr(namespace, "source", "screenshots")
    source = getattr(selected, "value", selected)
    if source not in {"matchlog", "screenshots"}:
        source = "screenshots"
    wanted = normalize_matchlog_name(current)
    options = _leaderboard_stat_options(source)
    return [
        app_commands.Choice(name=option[:100], value=option[:100])
        for option in options
        if not wanted or wanted in normalize_matchlog_name(option)
    ][:25]


async def _fetch_live_leaderboard_rankings(
    tour: str,
) -> dict[str, dict[str, typing.Any]]:
    """Fetch only players present in the current official ranking table."""
    now = time.time()
    if (
        tour in _leaderboard_rankings_cache
        and now - _leaderboard_rankings_cache_time.get(tour, 0) < 1800
    ):
        return _leaderboard_rankings_cache[tour]
    tour_slug = "TE4_(F)" if tour == "wta" else "TE4"
    url = (
        "https://www.playwtsl.com/TE4/pages/"
        f"rankings_fetch_list.php?tour={tour_slug}"
    )
    async with aiohttp.ClientSession(
        timeout=aiohttp.ClientTimeout(total=20)
    ) as session:
        async with session.get(url) as response:
            response.raise_for_status()
            soup = BeautifulSoup(await response.text(), "html.parser")
    table = soup.find("table", id="rankTable")
    if table is None:
        raise RuntimeError(f"Official {tour.upper()} rankings table not found")
    players: dict[str, dict[str, typing.Any]] = {}
    for row in table.find_all("tr"):
        cells = row.find_all("td")
        if len(cells) < 3:
            continue
        link = cells[2].find("a", href=True)
        if link is None:
            continue
        name = link.get_text(" ", strip=True)
        player_id = re.search(r"[?&]player=(\d+)", link["href"])
        if not name or player_id is None:
            continue
        players.setdefault(
            normalize_matchlog_name(name),
            {"name": name, "id": player_id.group(1)},
        )
    if not players:
        raise RuntimeError(f"Official {tour.upper()} rankings are empty")
    _leaderboard_rankings_cache[tour] = players
    _leaderboard_rankings_cache_time[tour] = now
    return players


async def _fetch_leaderboard_avatars(
    player_names: list[str],
    tour: str,
    official_players: dict[str, dict[str, typing.Any]] | None = None,
) -> dict[str, dict[str, str | None]]:
    """Fetch profile links and avatars in one bounded rankings/page batch."""
    tour_slug = "TE4_(F)" if tour == "wta" else "TE4"
    rankings_url = (
        "https://www.playwtsl.com/TE4/pages/"
        f"rankings_fetch_list.php?tour={tour_slug}"
    )
    result: dict[str, dict[str, str | None]] = {}
    try:
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=20)
        ) as session:
            wanted = {normalize_matchlog_name(name): name for name in player_names}
            player_ids = {}
            for name in player_names:
                key = normalize_matchlog_name(name)
                info = (official_players or {}).get(key, {})
                if info.get("id") is not None:
                    player_ids[key] = str(info["id"])
            if not player_ids:
                async with session.get(rankings_url) as response:
                    if response.status != 200:
                        return result
                    rankings_html = await response.text()
                soup = BeautifulSoup(rankings_html, "html.parser")
                for link in soup.find_all("a", href=True):
                    key = normalize_matchlog_name(link.get_text(" ", strip=True))
                    if key not in wanted or key in player_ids:
                        continue
                    match = re.search(r"[?&]player=(\d+)", link["href"])
                    if match:
                        player_ids[key] = match.group(1)

            async def fetch_one(key: str, player_id: str):
                profile_url = (
                    "https://www.playwtsl.com/TE4/pages/"
                    f"player_page.php?player={player_id}"
                )
                try:
                    async with session.get(profile_url) as response:
                        if response.status != 200:
                            return key, {"profile_url": profile_url, "avatar_url": None}
                        html = await response.text()
                    return key, {
                        "profile_url": profile_url,
                        "avatar_url": parse_player_avatar(html, wanted[key]),
                    }
                except Exception:
                    return key, {"profile_url": profile_url, "avatar_url": None}

            for key, player_id in player_ids.items():
                result[key] = {
                    "profile_url": (
                        "https://www.playwtsl.com/TE4/pages/"
                        f"player_page.php?player={player_id}"
                    ),
                    "avatar_url": None,
                }
            if player_ids:
                winner_key = next(iter(player_ids))
                key, winner_profile = await fetch_one(
                    winner_key, player_ids[winner_key]
                )
                result[key] = winner_profile
    except Exception as exc:
        print(
            f"[Leaderboard] Avatar lookup unavailable: {type(exc).__name__}: {exc}",
            flush=True,
        )
    return result


def _build_leaderboard_embeds(
    cards: list[dict[str, typing.Any]],
    source: str,
    tour: str,
    avatars: dict[str, dict[str, str | None]],
    *,
    weekly: bool = False,
) -> list[discord.Embed]:
    source_label = "Match Logs" if source == "matchlog" else "Screenshots"
    medals = {1: "🥇", 2: "🥈", 3: "🥉"}
    colors = {
        "🎾 Serve": discord.Color.green(),
        "↩️ Return": discord.Color.blue(),
        "🔥 Under Pressure": discord.Color.orange(),
    }
    if not cards:
        return []
    lines = []
    for card in cards:
        profile = avatars.get(normalize_matchlog_name(card["player"]), {})
        marker = medals.get(card["place"], f"**#{card['place']}**")
        player = (
            f"[{card['player']}]({profile['profile_url']})"
            if profile.get("profile_url")
            else card["player"]
        )
        lines.append(
            f"{marker} "
            f"{player} — **"
            f"{_dashboard_stat_value(card['stat'], card['value'])}** "
            f"({int(card.get('matches') or 0)} matches)"
        )
    winner = cards[0]
    winner_profile = avatars.get(
        normalize_matchlog_name(winner["player"]), {}
    )
    embed = discord.Embed(
        title=f"{tour.upper()} {winner['category']} Leaderboard",
        description="\n".join(lines),
        color=colors.get(winner["category"], discord.Color.gold()),
    )
    if winner_profile.get("avatar_url"):
        embed.set_thumbnail(url=winner_profile["avatar_url"])
    footer_parts = [
        f"{tour.upper()} • {source_label} • Career leaderboard",
        "Officially ranked",
        f"Minimum {LEADERBOARD_MIN_MATCHES} matches",
    ]
    formula_prefix = {
        "Serve (Overall)": "Serve:",
        "Return (Overall)": "Return:",
        "Under Pressure": "Under Pressure:",
    }.get(winner["stat"])
    if formula_prefix:
        formula = next(
            (
                line.partition(":")[2].strip()
                for line in rating_formula_footnote(source).splitlines()
                if line.startswith(formula_prefix)
            ),
            "",
        )
        if formula:
            footer_parts.append(f"Formula: {formula}")
    embed.set_footer(text=" • ".join(footer_parts)[:2048])
    return [embed]


async def _generate_weekly_leaderboard_embeds() -> list[discord.Embed]:
    """Build the six screenshot-rating leaderboards for ATP and WTA."""
    embeds: list[discord.Embed] = []
    official_results = await get_all_results(allow_stale=True)
    exclusions = await _get_screenshot_statistics_exclusions(official_results)
    for tour in ("atp", "wta"):
        rows, official_players = await asyncio.gather(
            asyncio.wait_for(
                asyncio.to_thread(
                    get_screenshot_leaderboard_rows,
                    MATCH_STATS_WORKBOOK,
                    tour,
                    excluded_match_keys_by_player=exclusions.get(tour, {}),
                ),
                timeout=MYSTATS_SUMMARY_TIMEOUT_SECONDS,
            ),
            asyncio.wait_for(_fetch_live_leaderboard_rankings(tour), timeout=20),
        )
        eligible_rows = [
            _with_official_result_metrics_leaderboard_row(
                row, official_results
            )
            for row in rows
            if int(row.get("matches") or 0) >= LEADERBOARD_MIN_MATCHES
            and normalize_matchlog_name(row.get("player")) in official_players
        ]
        for _category, stat in LEADERBOARD_CATEGORIES:
            cards = _leaderboard_cards(eligible_rows, stat)
            if not cards:
                print(
                    f"[Leaderboard Weekly] No eligible {tour.upper()} {stat} data",
                    flush=True,
                )
                continue
            avatars = await _fetch_leaderboard_avatars(
                [card["player"] for card in cards],
                tour,
                official_players,
            )
            embeds.extend(
                _build_leaderboard_embeds(
                    cards,
                    "screenshots",
                    tour,
                    avatars,
                    weekly=True,
                )
            )
    return embeds


async def _upsert_weekly_leaderboards(channel) -> None:
    """Edit the six stable weekly messages, creating only missing ones."""
    async with _weekly_leaderboard_lock:
        embeds = await _generate_weekly_leaderboard_embeds()
        existing: dict[str, typing.Any] = {}
        wanted_titles = {embed.title for embed in embeds}
        bot_user_id = getattr(getattr(client, "user", None), "id", None)
        async for message in channel.history(limit=500):
            if bot_user_id is not None and getattr(message.author, "id", None) != bot_user_id:
                continue
            for embed in getattr(message, "embeds", []):
                if embed.title in wanted_titles:
                    existing.setdefault(embed.title, message)
        last_mutation_at = 0.0
        for embed in embeds:
            message = existing.get(embed.title)
            if message is None:
                elapsed = time.monotonic() - last_mutation_at
                if last_mutation_at and elapsed < 2.0:
                    await asyncio.sleep(2.0 - elapsed)
                await channel.send(embed=embed)
                action = "Posted"
                last_mutation_at = time.monotonic()
            elif _wtsl_message_needs_embed_update(message, [embed]):
                elapsed = time.monotonic() - last_mutation_at
                if last_mutation_at and elapsed < 2.0:
                    await asyncio.sleep(2.0 - elapsed)
                await message.edit(embed=embed)
                action = "Updated"
                last_mutation_at = time.monotonic()
            else:
                action = "Unchanged"
            print(f"[Leaderboard Weekly] {action} {embed.title}", flush=True)


async def _post_weekly_leaderboards_now() -> None:
    """Create/update the weekly leaderboard messages once after startup."""
    await client.wait_until_ready()
    await _wait_for_matchlog_rebuild()
    try:
        channel = client.get_channel(WEEKLY_LEADERBOARD_CHANNEL_ID)
        if channel is None:
            channel = await client.fetch_channel(WEEKLY_LEADERBOARD_CHANNEL_ID)
        await _upsert_weekly_leaderboards(channel)
    except Exception as exc:
        print(
            f"[Leaderboard Weekly] Startup update failed: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )


async def _post_weekly_leaderboards_after_startup() -> None:
    """Refresh non-announcing leaderboards after startup."""
    await client.wait_until_ready()
    await asyncio.sleep(WEEKLY_LEADERBOARD_STARTUP_DELAY_SECONDS)
    await _post_weekly_leaderboards_now()


@client.tree.command(
    name="wtslleaderboard",
    description="Show tour leaders for ratings, statistics, or character picks",
)
@app_commands.describe(
    tour="Choose the ATP or WTA tour",
    source="Choose which statistics dataset to use",
    stat="Choose an overall rating or individual statistic",
)
@app_commands.choices(tour=[
    app_commands.Choice(name="ATP", value="atp"),
    app_commands.Choice(name="WTA", value="wta"),
])
@app_commands.choices(source=[
    app_commands.Choice(name="Match Logs", value="matchlog"),
    app_commands.Choice(name="Screenshots", value="screenshots"),
])
async def wtslleaderboard(
    interaction: discord.Interaction,
    tour: app_commands.Choice[str],
    source: app_commands.Choice[str],
    stat: str,
):
    allowed = _stats_channel_allowed(interaction)
    await interaction.response.defer(thinking=True, ephemeral=not allowed)
    if not allowed:
        await interaction.followup.send(
            "Use `/wtslleaderboard` in <#812742338669576252>, "
            "<#1411110448333328455>, or in a private admin-only channel.",
            ephemeral=True,
        )
        return
    selected_tour = tour.value
    selected_source = source.value
    selected_stat = stat.strip()
    if selected_stat not in _leaderboard_stat_options(selected_source):
        await interaction.followup.send(
            "Choose a statistic from the `/wtslleaderboard` autocomplete list.",
            ephemeral=True,
        )
        return
    if selected_stat == MOST_PICKED_CHARACTERS_STAT:
        try:
            results = await asyncio.wait_for(
                get_all_results(allow_stale=True),
                timeout=10,
            )
            cards = _character_leaderboard_cards(results, selected_tour)
            if not cards:
                await interaction.followup.send(
                    f"No known character-pick data is currently cached for "
                    f"the {selected_tour.upper()} tour. The full WTSL results "
                    "refresh may still be preparing."
                )
                return
            await interaction.followup.send(
                embed=_build_character_leaderboard_embed(
                    cards,
                    selected_tour,
                )
            )
        except asyncio.TimeoutError:
            await interaction.followup.send(
                "The character leaderboard took too long to load. "
                "Please try again in a moment.",
                ephemeral=True,
            )
        return
    reader = (
        get_matchlog_leaderboard_rows
        if selected_source == "matchlog"
        else get_screenshot_leaderboard_rows
    )
    try:
        rows = await asyncio.wait_for(
            asyncio.to_thread(reader, MATCH_STATS_WORKBOOK, selected_tour),
            timeout=MYSTATS_SUMMARY_TIMEOUT_SECONDS,
        )
        official_players = await asyncio.wait_for(
            _fetch_live_leaderboard_rankings(selected_tour),
            timeout=20,
        )
        eligible_rows = [
            row for row in rows
            if int(row.get("matches") or 0) >= LEADERBOARD_MIN_MATCHES
            and normalize_matchlog_name(row.get("player")) in official_players
        ]
        if selected_stat in {
            "Tie-breaks Won %",
            "Deciding Sets Won %",
            "Under Pressure",
        }:
            official_results = await asyncio.wait_for(
                get_all_results(allow_stale=True),
                timeout=10,
            )
            eligible_rows = [
                _with_official_result_metrics_leaderboard_row(
                    row, official_results
                )
                for row in eligible_rows
            ]
        cards = _leaderboard_cards(eligible_rows, selected_stat)
        if not cards:
            await interaction.followup.send(
                f"No {selected_stat} leaderboard data is available for "
                f"{selected_tour.upper()} {selected_source} statistics among "
                f"officially ranked players with at least "
                f"{LEADERBOARD_MIN_MATCHES} matches."
            )
            return
        names = list(dict.fromkeys(card["player"] for card in cards))
        try:
            avatars = await asyncio.wait_for(
                _fetch_leaderboard_avatars(
                    names, selected_tour, official_players
                ),
                timeout=20,
            )
        except asyncio.TimeoutError:
            avatars = {}
        await interaction.followup.send(
            embeds=_build_leaderboard_embeds(
                cards, selected_source, selected_tour, avatars
            )
        )
    except asyncio.TimeoutError:
        await interaction.followup.send(
            "The leaderboard took too long to load. Please try again in a moment.",
            ephemeral=True,
        )
    except Exception as exc:
        print(
            f"[Leaderboard] Failed: {type(exc).__name__}: {exc}",
            flush=True,
        )
        await interaction.followup.send(
            "I couldn't load the leaderboard right now. Please try again later.",
            ephemeral=True,
        )


wtslleaderboard.autocomplete("stat")(_leaderboard_stat_autocomplete)


def _character_stats_bar_line(stat: dict[str, typing.Any]) -> str:
    if stat.get("rank") is None:
        rank = "all tied"
    else:
        rank = f"tied #{stat['rank']} of {stat['count']}"
    percentile = stat.get("percentile")
    percentile_text = (
        f"{float(percentile):.0%}" if isinstance(percentile, (int, float))
        else "n/a"
    )
    return (
        f"**{stat['attribute']}** {format_character_value(stat['value'])} "
        f"· {stat['bar']} {percentile_text} · {rank}"
    )


def _character_stats_group_lines(
    stats: list[dict[str, typing.Any]],
) -> dict[str, list[str]]:
    groups = {
        "Groundstrokes": [],
        "Serve": [],
        "Net & Feel": [],
        "Movement & Variety": [],
    }
    for stat in stats:
        attribute = str(stat["attribute"]).casefold()
        if "serve" in attribute or "service" in attribute:
            group = "Serve"
        elif any(
            token in attribute
            for token in ("volley", "smash", "net presence", "ball feeling")
        ):
            group = "Net & Feel"
        elif any(
            token in attribute
            for token in ("forehand", "backhand", "slice mastery", "early ball")
        ):
            group = "Groundstrokes"
        else:
            group = "Movement & Variety"
        groups[group].append(_character_stats_bar_line(stat))
    return groups


def _character_stats_comparison_line(
    item: dict[str, typing.Any],
    winner: str,
    value: typing.Any,
) -> str:
    return f"**{item['attribute']}** · {winner} leads at {format_character_value(value)}"


def _character_stats_matchup_edges(
    items: list[dict[str, typing.Any]],
    *,
    selected_is_first: bool,
    advantage: bool,
) -> list[str]:
    lines = []
    for item in items:
        selected_value = (
            item["first_value"] if selected_is_first else item["second_value"]
        )
        other_value = (
            item["second_value"] if selected_is_first else item["first_value"]
        )
        gap = abs(float(item["delta"]) * 100)
        sign = "+" if advantage else "-"
        lines.append(
            f"• **{item['attribute']}**: "
            f"{format_character_value(selected_value)} vs "
            f"{format_character_value(other_value)} "
            f"({sign}{gap:.0f} percentile pts)"
        )
    return lines


def _character_stats_guidance_lines(
    guidance: dict[str, typing.Any],
) -> str:
    return "\n".join(
        _character_stats_bar_line(stat)
        for stat in guidance.get("top_edges", [])[:5]
    ) or "No distinctive roster edge was found."


def _character_stats_combined_line(stat: dict[str, typing.Any]) -> str:
    components = stat.get("components") or {}
    serve_context = ""
    if stat.get("attribute") == "Serve Rating":
        max_speed = float(stat.get("max_serve_speed_kmh") or 0)
        serve_context = f"\n  Max serve {max_speed:.1f} km/h"
    return (
        f"{_character_stats_bar_line(stat)}\n"
        f"  Power {format_character_value(components.get('Power'))} · "
        f"Consistency {format_character_value(components.get('Consistency'))} · "
        f"Precision {format_character_value(components.get('Precision'))}"
        f"{serve_context}"
    )


def _build_character_profile_embed(
    profile: dict[str, typing.Any],
    official: dict[str, str | None],
    comparison: dict[str, typing.Any] | None = None,
) -> discord.Embed:
    tour = str(profile["sex"])
    pronoun = "her" if tour == "WTA" else "him"
    flag = str(
        profile.get("country_flag")
        or get_country_flag(profile.get("country"))
    )
    description = (
        f"{flag} **{tour}**"
        f" • {profile.get('height') or '?'} cm"
        f" • {profile.get('weight') or '?'} kg\n"
        f"**Style:** {profile['style']} — "
        f"{profile.get('style_description') or 'Flexible point construction.'}\n"
        f"**Acceleration:** {profile['acceleration']}\n"
        "Attribute bars show where this character sits within the selected roster."
    )
    if official.get("profile_url"):
        profile_label = (
            f"Official {tour} profile"
            if official.get("source") == tour
            else "Player profile"
        )
        description += f"\n[{profile_label}]({official['profile_url']})"
    embed = discord.Embed(
        title=f"🎾 {profile['character']} — Character Profile",
        description=description[:4096],
        color=0x2ECC71 if tour == "ATP" else 0xE84393,
    )
    if official.get("avatar_url"):
        embed.set_thumbnail(url=official["avatar_url"])
    groups = _character_stats_group_lines(profile["stats"])
    for group, lines in groups.items():
        if lines:
            embed.add_field(
                name=f"📊 {group}",
                value="\n".join(lines)[:1024],
                inline=False,
            )
    combined_lines = "\n".join(
        _character_stats_combined_line(stat)
        for stat in profile.get("combined_ratings", [])
    )
    embed.add_field(
        name="🎾 Combined skill ratings",
        value=(combined_lines or "Not enough roster data")[:1024],
        inline=False,
    )
    strengths = "\n".join(
        _character_stats_bar_line(stat)
        for stat in profile["strengths"][:5]
    ) or "Not enough roster data"
    weaknesses = "\n".join(
        _character_stats_bar_line(stat)
        for stat in profile["weaknesses"][:5]
    ) or "Not enough roster data"
    embed.add_field(name="💪 Relative strengths", value=strengths[:1024])
    embed.add_field(name="⚠️ Relative weaknesses", value=weaknesses[:1024])
    guidance = profile.get("selection_guidance") or {}
    mechanics = guidance.get("mechanics_insights") or {}
    edge_text = _character_stats_guidance_lines(guidance)
    strongest_label = str(guidance.get("strongest_label") or "overall balance")
    impact_parts = [
        str(mechanics.get("serve") or "").strip(),
        str(mechanics.get("groundstrokes") or "").strip(),
        str(mechanics.get("surface_fit") or "").strip(),
        str(mechanics.get("counter") or "").strip(),
        str(mechanics.get("net") or "").strip(),
        str(guidance.get("style_mechanics") or "").strip(),
    ]
    if str(profile["acceleration"]).casefold() == "none":
        impact_parts.append(
            "There is no separate acceleration trait, so "
            + str(guidance.get("acceleration_mechanics") or "")
            + "."
        )
    else:
        impact_parts.append(
            f"The {profile['acceleration']} acceleration trait "
            f"{guidance.get('acceleration_mechanics') or ''}."
        )
    documented_edges = guidance.get("documented_edges") or []
    if documented_edges:
        impact_parts.extend(str(item) + "." for item in documented_edges[:2])
    documented_talents = guidance.get("documented_talents") or []
    if documented_talents:
        covered_attributes = {
            str(item).split(":", 1)[0].casefold()
            for item in documented_edges[:2]
        }
        impact_parts.extend(
            str(item) + "."
            for item in documented_talents
            if str(item).split(":", 1)[0].casefold() not in covered_attributes
        )
    impact_text = ""
    for part in (part for part in impact_parts if part):
        candidate = f"{impact_text} {part}".strip()
        if len(candidate) > 1024:
            break
        impact_text = candidate
    embed.add_field(
        name="🎾 Technical Summary",
        value=impact_text or "No game-impact details are available.",
        inline=False,
    )
    embed.add_field(
        name=f"🎯 Why select {pronoun}: {strongest_label}",
        value=(
            f"{guidance.get('why_select') or guidance.get('benefit') or ''}\n\n"
            f"**Best for:** {guidance.get('best_for') or 'A flexible roster profile.'}\n\n"
            f"**Roster evidence:**\n{edge_text}"
        )[:1024],
        inline=False,
    )
    embed.add_field(
        name=f"🧠 How to use {pronoun}",
        value=(
            f"{guidance.get('game_plan') or 'Use the strongest attributes deliberately.'}\n\n"
            f"**Why not select {pronoun}:** "
            f"{guidance.get('why_not_select') or guidance.get('tradeoff') or 'No clear weakness was found.'}"
        )[:1024],
        inline=False,
    )
    if comparison:
        selected_is_first = comparison["first"] == profile["character"]
        opponent = (
            comparison["second"] if selected_is_first else comparison["first"]
        )
        pros = (
            comparison["first_edges"]
            if selected_is_first
            else comparison["second_edges"]
        )
        cons = (
            comparison["second_edges"]
            if selected_is_first
            else comparison["first_edges"]
        )
        selected_guidance = (
            comparison["first_guidance"]
            if selected_is_first
            else comparison["second_guidance"]
        )
        other_guidance = (
            comparison["second_guidance"]
            if selected_is_first
            else comparison["first_guidance"]
        )
        pro_lines = _character_stats_matchup_edges(
            pros,
            selected_is_first=selected_is_first,
            advantage=True,
        )
        con_lines = _character_stats_matchup_edges(
            cons,
            selected_is_first=selected_is_first,
            advantage=False,
        )
        tactical_pros = (
            comparison.get("first_mechanics", [])
            if selected_is_first
            else comparison.get("second_mechanics", [])
        )
        tactical_cons = (
            comparison.get("second_mechanics", [])
            if selected_is_first
            else comparison.get("first_mechanics", [])
        )
        pro_lines.extend(f"• {line}" for line in tactical_pros[:2])
        con_lines.extend(f"• {line}" for line in tactical_cons[:2])
        comparison_lines = [
            f"**Pros of {profile['character']}:**",
            *(
                pro_lines
                or ["No material attribute advantage over this alternative."]
            ),
            "",
            f"**Cons of {profile['character']}:**",
            *(
                con_lines
                or ["No material attribute disadvantage over this alternative."]
            ),
            "",
            f"**Choose {profile['character']} if:** "
            f"{selected_guidance.get('why_select') or selected_guidance.get('benefit')}",
            f"**Choose {opponent} instead if:** "
            f"{other_guidance.get('why_select') or other_guidance.get('benefit')}",
        ]
        comparison_text = "\n".join(comparison_lines)
        if len(comparison_text) > 1024:
            compact_lines = [
                f"**Pros of {profile['character']}:**",
                *(pro_lines[:3] or [
                    "No material attribute advantage over this alternative."
                ]),
                "",
                f"**Cons of {profile['character']}:**",
                *(con_lines[:3] or [
                    "No material attribute disadvantage over this alternative."
                ]),
                "",
                comparison_lines[-2][:360],
                comparison_lines[-1][:360],
            ]
            comparison_text = "\n".join(compact_lines)
        if len(comparison_text) > 1024:
            choice_text = "\n".join(comparison_lines[-2:])
            choice_budget = max(0, 1023 - len(choice_text) - 1)
            comparison_text = (
                comparison_text[:choice_budget].rstrip()
                + "…\n"
                + choice_text
            )[:1024]
        embed.add_field(
            name=f"⚔️ Compared with {opponent}",
            value=comparison_text,
            inline=False,
        )
    pick_lines = [
        f"**{picker}** — {count} pick{'s' if count != 1 else ''}"
        for picker, count in profile["top_pickers"]
    ]
    pick_value = (
        f"**{profile['pick_count']}** known pick"
        f"{'s' if profile['pick_count'] != 1 else ''} in official results"
    )
    if pick_lines:
        pick_value += "\nTop pickers:\n" + "\n".join(pick_lines)
    else:
        pick_value += "\nNo character-pick records are currently known."
    embed.add_field(name="🎮 Pick frequency", value=pick_value[:1024])
    embed.set_footer(
        text=f"{tour} roster • {profile['roster_count']} characters"
    )
    for prefix in (
        "💪 Relative strengths",
        "⚠️ Relative weaknesses",
        "🎮 Pick frequency",
    ):
        if len(embed) <= MYSTATS_EMBED_SAFE_CHARACTER_LIMIT:
            break
        for index in range(len(embed.fields) - 1, -1, -1):
            if embed.fields[index].name.startswith(prefix):
                embed.remove_field(index)
                break
    protected_prefixes = (
        "🎾 Technical Summary",
        "🎾 Combined skill ratings",
        "🎯 Why select",
        "🧠 How to use",
        "⚔️ Compared with",
    )
    while len(embed) > MYSTATS_EMBED_SAFE_CHARACTER_LIMIT and embed.fields:
        candidates = [
            index
            for index, field in enumerate(embed.fields)
            if not field.name.startswith(protected_prefixes)
        ]
        if not candidates:
            candidates = list(range(len(embed.fields)))
        index = max(
            candidates,
            key=lambda item: len(embed.fields[item].value),
        )
        field = embed.fields[index]
        overflow = len(embed) - MYSTATS_EMBED_SAFE_CHARACTER_LIMIT
        keep = len(field.value) - overflow - 20
        if keep < 120:
            embed.remove_field(index)
        else:
            embed.set_field_at(
                index,
                name=field.name,
                value=field.value[:keep].rsplit(" ", 1)[0] + "…",
                inline=field.inline,
            )
    return embed


def _build_character_attribute_embed(
    ranking: dict[str, typing.Any],
    selected_character: str | None = None,
) -> discord.Embed:
    tour = str(ranking["tour"]).upper()
    attribute = str(ranking["attribute"])
    ranked = ranking["ranked"]
    title_tour = tour if tour != "ALL" else "ATP + WTA"
    description = (
        f"**Roster:** {ranking['count']} canonical characters"
        f" • **Range:** {format_character_value(ranking['minimum'])}"
        f"–{format_character_value(ranking['maximum'])}\n"
        "Ranked high-to-low. Version rows such as v2/v3 are collapsed."
    )
    if selected_character:
        selected_key = normalize_matchlog_name(selected_character)
        selected = next(
            (
                item for item in ranked
                if normalize_matchlog_name(item["character"]) == selected_key
            ),
            None,
        )
        if selected:
            description += (
                f"\n**{selected['character']}:** "
                f"{format_character_value(selected['value'])} "
                f"(tied rank **#{selected['rank']} of {ranking['count']}**)"
            )
    embed = discord.Embed(
        title=f"📈 {title_tour} — {attribute} ranking",
        description=description[:4096],
        color=discord.Color.gold(),
    )
    top = ranked[:10]
    bottom = ranked[-3:] if len(ranked) > 10 else []
    embed.add_field(
        name="Top characters",
        value="\n".join(format_character_ranked_line(item) for item in top)
        or "No values available",
        inline=False,
    )
    if bottom:
        embed.add_field(
            name="Bottom of roster",
            value="\n".join(
                format_character_ranked_line(item) for item in bottom
            ),
            inline=False,
        )
    embed.set_footer(
        text=(
            "WTSL character roster • "
            "Use /characterstats with a character for the full profile"
        )
    )
    return embed


@client.tree.command(
    name="characterstats",
    description="Show TE4 character attributes, rankings, and pick data",
)
@app_commands.describe(
    character="Optional character profile, with version suffixes ignored",
    attribute="Optional attribute to rank across the roster",
    compare="Optional second character to compare against the profile",
    tour="Choose ATP, WTA, or the combined roster",
)
@app_commands.choices(tour=[
    app_commands.Choice(name="ATP", value="atp"),
    app_commands.Choice(name="WTA", value="wta"),
    app_commands.Choice(name="ATP + WTA", value="all"),
])
async def characterstats(
    interaction: discord.Interaction,
    tour: app_commands.Choice[str],
    character: str | None = None,
    attribute: str | None = None,
    compare: str | None = None,
):
    allowed = _stats_channel_allowed(interaction)
    await interaction.response.defer(thinking=True, ephemeral=not allowed)
    if not allowed:
        await interaction.followup.send(
            "Use `/characterstats` in the configured statistics channel "
            "or in a private admin-only channel.",
            ephemeral=True,
        )
        return
    selected_tour = tour.value
    if compare and not character:
        await interaction.followup.send(
            "Choose a primary `character` before selecting a comparison "
            "character.",
            ephemeral=True,
        )
        return
    if not character and not attribute:
        await interaction.followup.send(
            "Use `/characterstats character:<name>` for a character profile, "
            "or `/characterstats attribute:<attribute>` for a roster ranking."
        )
        return
    resolved_character = None
    if character:
        resolved_character = resolve_character(character, selected_tour)
        if resolved_character is None:
            names = get_character_names(selected_tour)
            wanted = normalize_matchlog_name(character)
            suggestions = [
                name for name in names
                if wanted and wanted in normalize_matchlog_name(name)
            ][:10]
            suffix = (
                " Did you mean: " + ", ".join(suggestions) + "."
                if suggestions else ""
            )
            await interaction.followup.send(
                f"I couldn't find a unique {selected_tour.upper()} character "
                f"called **{character}**.{suffix}",
                ephemeral=True,
            )
            return
    resolved_compare = None
    if compare:
        resolved_compare = resolve_character(compare, selected_tour)
        if resolved_compare is None:
            await interaction.followup.send(
                f"I couldn't find a unique {selected_tour.upper()} comparison "
                f"character called **{compare}**.",
                ephemeral=True,
            )
            return
    resolved_attribute = None
    if attribute:
        resolved_attribute = resolve_character_attribute(attribute)
        if resolved_attribute is None:
            suggestions = [
                name for name in get_character_attribute_names()
                if normalize_matchlog_name(attribute)
                in normalize_matchlog_name(name)
            ][:10]
            suffix = (
                " Did you mean: " + ", ".join(suggestions) + "."
                if suggestions else ""
            )
            await interaction.followup.send(
                f"I couldn't find the attribute **{attribute}**.{suffix}",
                ephemeral=True,
            )
            return
    embeds: list[discord.Embed] = []
    try:
        results: list[dict[str, typing.Any]] = []
        if resolved_character:
            results = await asyncio.wait_for(
                get_all_results(allow_stale=True),
                timeout=10,
            )
            profile = await asyncio.to_thread(
                get_character_profile,
                resolved_character["_canonical"],
                selected_tour,
                results,
            )
            comparison = None
            if resolved_compare:
                comparison = await asyncio.to_thread(
                    compare_character_profiles,
                    resolved_character["_canonical"],
                    resolved_compare["_canonical"],
                    selected_tour,
                )
            try:
                official = await asyncio.wait_for(
                    fetch_character_official_profile(
                        profile["character"],
                        profile["sex"],
                    ),
                    timeout=8,
                )
            except (asyncio.TimeoutError, Exception) as avatar_exc:
                print(
                    "[Character Stats] Avatar unavailable; sending local "
                    f"profile: {type(avatar_exc).__name__}: {avatar_exc}",
                    flush=True,
                )
                official = {}
            embeds.append(
                _build_character_profile_embed(
                    profile,
                    official,
                    comparison,
                )
            )
        if resolved_attribute:
            ranking = await asyncio.to_thread(
                get_character_attribute_ranking,
                resolved_attribute,
                selected_tour,
            )
            embeds.append(
                _build_character_attribute_embed(
                    ranking,
                    resolved_character["_canonical"]
                    if resolved_character else None,
                )
            )
        await interaction.followup.send(embeds=embeds)
    except asyncio.TimeoutError:
        await interaction.followup.send(
            "The character profile took too long to load. "
            "The workbook ranking is local, but the official avatar lookup "
            "did not finish in time. Please try again.",
            ephemeral=True,
        )
    except Exception as exc:
        print(
            f"[Character Stats] Failed: {type(exc).__name__}: {exc}",
            flush=True,
        )
        await interaction.followup.send(
            "I couldn't load the character statistics right now. "
            "Please try again later.",
            ephemeral=True,
        )


async def _character_stats_character_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    namespace = getattr(interaction, "namespace", None)
    selected = getattr(namespace, "tour", "all")
    selected_tour = getattr(selected, "value", selected)
    if selected_tour not in {"atp", "wta", "all"}:
        selected_tour = "all"
    wanted = normalize_matchlog_name(current)
    return [
        app_commands.Choice(name=name[:100], value=name[:100])
        for name in get_character_names(selected_tour)
        if not wanted or wanted in normalize_matchlog_name(name)
    ][:25]


async def _character_stats_attribute_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    wanted = normalize_matchlog_name(current)
    return [
        app_commands.Choice(name=name[:100], value=name[:100])
        for name in get_character_attribute_names()
        if not wanted or wanted in normalize_matchlog_name(name)
    ][:25]


characterstats.autocomplete("character")(
    _character_stats_character_autocomplete
)
characterstats.autocomplete("compare")(
    _character_stats_character_autocomplete
)
characterstats.autocomplete("attribute")(
    _character_stats_attribute_autocomplete
)


def _character_workbook_admin_allowed(
    interaction: discord.Interaction,
) -> bool:
    user = getattr(interaction, "user", None)
    if getattr(user, "id", None) == OWNER_ID:
        return True
    permissions = getattr(user, "guild_permissions", None)
    if getattr(permissions, "administrator", False):
        return True
    if getattr(permissions, "manage_guild", False):
        return True
    return any(
        getattr(role, "id", None) == ADMIN_ROLE_ID
        for role in getattr(user, "roles", [])
    )


@client.tree.command(
    name="characterstats_upload",
    description="Replace the character roster workbook with an updated XLSX",
)
@app_commands.describe(
    workbook="Updated character-stats XLSX; the uploaded filename can be anything",
)
async def characterstats_upload(
    interaction: discord.Interaction,
    workbook: discord.Attachment,
):
    if not _character_workbook_admin_allowed(interaction):
        await interaction.response.send_message(
            "Only the bot owner or a server administrator can update the "
            "character roster workbook.",
            ephemeral=True,
        )
        return
    filename = str(workbook.filename or "")
    if not filename.casefold().endswith(".xlsx"):
        await interaction.response.send_message(
            "Please upload an `.xlsx` workbook.",
            ephemeral=True,
        )
        return
    if workbook.size and workbook.size > 20 * 1024 * 1024:
        await interaction.response.send_message(
            "That workbook is larger than the 20 MB upload limit.",
            ephemeral=True,
        )
        return
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        data = await workbook.read()
        summary = await asyncio.to_thread(
            install_character_workbook,
            data,
        )
        await interaction.followup.send(
            f"Installed **{summary['filename']}** from `{filename}`. "
            f"Validated {summary['rows']} character rows and "
            f"{summary['columns']} columns through AQ. "
            "Future `/characterstats` requests will use this version.",
            ephemeral=True,
        )
    except Exception as exc:
        print(
            f"[Character Stats] Workbook upload failed: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        await interaction.followup.send(
            f"I rejected that workbook: {str(exc)[:1000]}",
            ephemeral=True,
        )


@client.tree.command(
    name="characterstats_export",
    description="Export the current canonical character roster workbook",
)
async def characterstats_export(interaction: discord.Interaction):
    if not _character_workbook_admin_allowed(interaction):
        await interaction.response.send_message(
            "Only the bot owner or a server administrator can export the "
            "character roster workbook.",
            ephemeral=True,
        )
        return
    path = get_character_workbook_path()
    if not path.exists():
        await interaction.response.send_message(
            "The character roster workbook is not available yet.",
            ephemeral=True,
        )
        return
    await interaction.response.send_message(
        "Current canonical character roster:",
        file=discord.File(
            str(path),
            filename="WTSL_Character_Stats_Roster.xlsx",
        ),
        ephemeral=True,
    )


@client.tree.command(
    name="wtslstats",
    description="View or compare official WTSL player statistics",
)
@app_commands.describe(
    player="Exact ATP or WTA player name",
    compare_with="Optional second player for a side-by-side comparison",
    tour="Choose the ATP or WTA tour",
    source="Choose which statistics dataset to use",
)
@app_commands.choices(tour=[
    app_commands.Choice(name="ATP", value="atp"),
    app_commands.Choice(name="WTA", value="wta"),
])
@app_commands.choices(source=[
    app_commands.Choice(name="Match logs", value="matchlog"),
    app_commands.Choice(name="Screenshots", value="screenshots"),
])
@app_commands.describe(period="Choose the statistics time period")
@app_commands.choices(period=[
    app_commands.Choice(name="Last 30 days", value="30d"),
    app_commands.Choice(name="Last 90 days", value="90d"),
    app_commands.Choice(name="Year to date", value="year"),
    app_commands.Choice(name="Career", value="career"),
    app_commands.Choice(name="Last 52 weeks", value="52w"),
])
async def stats(
    interaction: discord.Interaction,
    player: str,
    tour: app_commands.Choice[str],
    source: app_commands.Choice[str],
    period: app_commands.Choice[str],
    compare_with: str | None = None,
):
    allowed = _stats_channel_allowed(interaction)
    await interaction.response.defer(thinking=True, ephemeral=not allowed)
    if not allowed:
        await interaction.followup.send(
            "Use `/wtslstats` in <#812742338669576252>, "
            "<#1411110448333328455>, or in a private admin-only channel.",
            ephemeral=True,
        )
        return
    if _matchlog_rebuild_state == "running":
        await interaction.followup.send(
            "The statistics database is still rebuilding after the latest "
            "deployment. Please try `/wtslstats` again shortly.",
            ephemeral=True,
        )
        return
    try:
        selected_tour = tour.value
        selected_source = source.value
        selected_period = period.value
        as_of = _dt.datetime.now(_dt.timezone.utc).date()
        source_label = (
            "Screenshot" if selected_source == "screenshots" else "MatchLog"
        )
        try:
            first = await _get_wtslstats_player_summary(
                player, selected_source, selected_tour, selected_period, as_of,
            )
        except AmbiguousPlayerNameError as exc:
            await interaction.followup.send(_limit_discord_message(str(exc)))
            return
        if first is None:
            await interaction.followup.send(
                _limit_discord_message(
                    f"No verified {source_label} statistics were found for **{player}**."
                )
            )
            return
        if compare_with is None:
            try:
                first_profile, fixture = await asyncio.wait_for(
                    asyncio.gather(
                        _fetch_mystats_ranking(first["player"], selected_tour),
                        _verified_player_fixture(first["player"], selected_tour),
                        return_exceptions=True,
                    ),
                    timeout=20,
                )
            except asyncio.TimeoutError:
                first_profile, fixture = {}, None
            if isinstance(first_profile, Exception):
                first_profile = {}
            if isinstance(fixture, Exception):
                fixture = None
            await interaction.followup.send(
                embed=_build_wtslstats_dashboard(
                    first,
                    selected_source,
                    first_profile,
                    fixture,
                )
            )
            return
        try:
            comparison_tour = selected_tour or first.get("tour")
            second = await _get_wtslstats_player_summary(
                compare_with, selected_source, comparison_tour, selected_period,
                as_of,
            )
        except AmbiguousPlayerNameError as exc:
            await interaction.followup.send(_limit_discord_message(str(exc)))
            return
        if second is None:
            await interaction.followup.send(
                _limit_discord_message(
                    f"No verified {source_label} statistics were found for "
                    f"**{compare_with}**."
                )
            )
            return
        try:
            first_profile, second_profile, fixture = await asyncio.wait_for(
                asyncio.gather(
                    _fetch_mystats_ranking(first["player"], selected_tour),
                    _fetch_mystats_ranking(second["player"], selected_tour),
                    _verified_pair_fixture(
                        first["player"],
                        second["player"],
                        selected_tour,
                    ),
                    return_exceptions=True,
                ),
                timeout=20,
            )
        except asyncio.TimeoutError:
            first_profile, second_profile, fixture = {}, {}, None
        if isinstance(first_profile, Exception):
            first_profile = {}
        if isinstance(second_profile, Exception):
            second_profile = {}
        if isinstance(fixture, Exception):
            fixture = None
        await interaction.followup.send(
            embed=_build_wtslstats_comparison_dashboard(
                first,
                second,
                selected_source,
                first_profile,
                second_profile,
                fixture,
            )
        )
    except Exception as exc:
        await interaction.followup.send(
            f"I couldn't read those statistics: {str(exc)[:1000]}"
        )


stats.autocomplete("player")(_stats_player_autocomplete)
stats.autocomplete("compare_with")(_stats_player_autocomplete)


def _stats_image_attachments(message):
    supported = (".png", ".jpg", ".jpeg", ".webp", ".gif")
    return [
        attachment for attachment in message.attachments
        if ((attachment.content_type or "").startswith("image/")
            or attachment.filename.lower().endswith(supported))
    ]


def _is_stats_result_text(message):
    text = message.content.lower()
    return (
        not message.author.bot
        and len(message.mentions) >= 2
        and "heads" not in text
        and "tails" not in text
    )


def _is_stats_result_message(message):
    return _is_stats_result_text(message) and bool(_stats_image_attachments(message))


def _combine_stats_result_messages(result_message, image_message):
    """Represent a split result-text + image post as one scrape source."""
    return types.SimpleNamespace(
        id=result_message.id,
        content=result_message.content,
        author=result_message.author,
        mentions=result_message.mentions,
        created_at=result_message.created_at,
        jump_url=result_message.jump_url,
        attachments=_stats_image_attachments(image_message),
        embeds=[],
        channel=result_message.channel,
    )


async def _get_stats_rankings():
    global _stats_rankings_cache, _stats_rankings_cache_time
    now = time.time()
    if _stats_rankings_cache and now - _stats_rankings_cache_time < 1800:
        return _stats_rankings_cache
    _stats_rankings_cache = await fetch_canonical_rankings()
    _stats_rankings_cache_time = now
    return _stats_rankings_cache


def _load_stats_delivery_state():
    try:
        state = json.loads(STATS_DELIVERY_STATE_FILE.read_text(encoding="utf-8"))
        return state if isinstance(state, dict) else {}
    except Exception:
        return {}


def _save_stats_delivery_state(state):
    temporary = STATS_DELIVERY_STATE_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(STATS_DELIVERY_STATE_FILE)


def _mark_stats_workbook_dirty():
    now = datetime.now(STATS_TIMEZONE)
    state = _load_stats_delivery_state()
    state["dirty"] = True
    state["last_written_at"] = now.isoformat()
    state["pending_matches"] = int(state.get("pending_matches") or 0) + 1
    _save_stats_delivery_state(state)


def _mark_stats_workbook_delivered(*, daily_date: str | None = None):
    state = _load_stats_delivery_state()
    state["dirty"] = False
    state["last_sent_at"] = datetime.now(STATS_TIMEZONE).isoformat()
    state["pending_matches"] = 0
    if daily_date:
        state["daily_sent_date"] = daily_date
    _save_stats_delivery_state(state)


async def _deliver_pending_stats_workbook(
    reason: str,
    *,
    force: bool = False,
    daily_date: str | None = None,
) -> bool:
    """Deliver the workbook once, optionally requiring pending changes."""
    state = _load_stats_delivery_state()
    if (not force and not state.get("dirty")) or not MATCH_STATS_WORKBOOK.exists():
        return False
    pending = int(state.get("pending_matches") or 0)
    await _dm_stats_owner(
        f"📊 **Daily match stats workbook**\n"
        f"Includes {pending} newly extracted "
        f"{'match' if pending == 1 else 'matches'} "
        f"since the last delivery ({reason}).",
        include_workbook=True,
    )
    _mark_stats_workbook_delivered(daily_date=daily_date)
    print(
        f"[Stats Delivery] Sent {reason} workbook with "
        f"{pending} new match(es)"
    )
    return True


def _remove_delivery_snapshot(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except OSError as exc:
        print(
            f"[Stats Delivery] Could not remove staging workbook {path.name}: "
            f"{exc}",
            flush=True,
        )


async def _build_workbook_review_snapshot() -> tuple[Path, int]:
    """Build an annotated delivery copy without ever replacing live data."""
    if not MATCH_STATS_WORKBOOK.exists():
        raise FileNotFoundError("Statistics workbook is missing")
    official_results = await _get_matchlog_official_results()
    summaries = await asyncio.to_thread(
        get_screenshot_match_record_summaries, MATCH_STATS_WORKBOOK
    )
    annotations = await asyncio.to_thread(
        _screenshot_review_annotations,
        summaries,
        official_results,
    )
    snapshot = MATCH_STATS_WORKBOOK.with_name(
        f".{MATCH_STATS_WORKBOOK.stem}.delivery-"
        f"{os.getpid()}-{time.time_ns()}.xlsx"
    )
    copy_task = asyncio.create_task(asyncio.to_thread(
        shutil.copy2,
        MATCH_STATS_WORKBOOK,
        snapshot,
    ))
    try:
        await asyncio.shield(copy_task)
    except asyncio.CancelledError:
        copy_task.add_done_callback(
            lambda _task: _remove_delivery_snapshot(snapshot)
        )
        raise
    except Exception:
        _remove_delivery_snapshot(snapshot)
        raise
    apply_task = asyncio.create_task(asyncio.to_thread(
        apply_screenshot_review_annotations,
        annotations,
        snapshot,
    ))
    try:
        marked = await asyncio.shield(apply_task)
    except asyncio.CancelledError:
        apply_task.add_done_callback(
            lambda _task: _remove_delivery_snapshot(snapshot)
        )
        raise
    except Exception:
        _remove_delivery_snapshot(snapshot)
        raise
    print(
        f"[Screenshot Review] Prepared delivery annotations for "
        f"{marked} row(s)"
    )
    return snapshot, marked


def _send_stats_workbook_per_result():
    """Keep extraction/recalculation per-result, but deliver on the daily schedule."""
    return False


async def _dm_stats_owner(text, include_workbook=False):
    owner = await client.fetch_user(DM_USER_ID)
    if include_workbook and MATCH_STATS_WORKBOOK.exists():
        annotation_note = ""
        delivery_path = MATCH_STATS_WORKBOOK
        snapshot = None
        try:
            snapshot, marked = await asyncio.wait_for(
                _build_workbook_review_snapshot(),
                timeout=45,
            )
            delivery_path = snapshot
            annotation_note = (
                f"\n\nWorkbook review columns refreshed: "
                f"**{marked} row{' is' if marked == 1 else 's are'} flagged.**"
            )
        except Exception as annotation_exc:
            annotation_note = (
                "\n\n⚠️ Review-column refresh did not complete before delivery. "
                "The preserved workbook is attached unchanged; no data was "
                "deleted or replaced."
            )
            print(
                "[Stats Delivery] Review annotation refresh failed; sending "
                f"preserved workbook: {type(annotation_exc).__name__}: "
                f"{annotation_exc}",
                flush=True,
            )
        try:
            await asyncio.wait_for(
                owner.send(
                    text + annotation_note,
                    file=discord.File(
                        str(delivery_path),
                        filename=MATCH_STATS_WORKBOOK.name,
                    ),
                ),
                timeout=30,
            )
        finally:
            if snapshot is not None:
                _remove_delivery_snapshot(snapshot)
    else:
        await asyncio.wait_for(owner.send(text), timeout=30)


def _player_stats_upload_receipt(delivery_date: str) -> str:
    return _player_stats_upload_receipt_for_phase(
        delivery_date,
        "startup",
    )


def _player_stats_upload_receipt_for_phase(
    delivery_date: str,
    phase: str,
) -> str:
    return (
        f"{PLAYER_STATS_UPLOAD_RECEIPT_PREFIX} {phase} "
        f"`{delivery_date}`"
    )


async def _player_stats_upload_receipt_exists(
    owner: typing.Any,
    delivery_date: str,
    phase: str,
) -> bool:
    """Recover a confirmed owner-DM send before retrying an uncertain delivery."""
    create_dm = getattr(owner, "create_dm", None)
    if not callable(create_dm):
        return False
    try:
        channel = getattr(owner, "dm_channel", None) or await create_dm()
        if channel is None:
            return False
        start = datetime.combine(
            _dt.date.fromisoformat(delivery_date),
            _dt.time.min,
            tzinfo=STATS_TIMEZONE,
        ).astimezone(timezone.utc)
        bot_id = getattr(getattr(client, "user", None), "id", None)
        receipt = _player_stats_upload_receipt_for_phase(
            delivery_date,
            phase,
        )
        async for message in channel.history(limit=250, after=start):
            if (
                receipt in str(getattr(message, "content", ""))
                and (
                    bot_id is None
                    or getattr(getattr(message, "author", None), "id", None)
                    == bot_id
                )
            ):
                return True
    except Exception as exc:
        print(
            f"[Stats Upload Delivery] Receipt recovery check failed: {exc}",
            flush=True,
        )
    return False


async def _send_daily_player_stats_upload_csv(
    reason: str,
    *,
    force: bool = False,
) -> bool:
    """Send a screenshot-workbook upload for startup or end-of-day."""
    today = datetime.now(STATS_TIMEZONE).date().isoformat()
    phase = "end-of-day" if reason == "daily" else "startup"
    phase_key = "eod" if phase == "end-of-day" else "startup"
    sent_date_key = f"screenshot_player_stats_upload_{phase_key}_sent_date"
    sent_reason_key = f"screenshot_player_stats_upload_{phase_key}_sent_reason"
    state = _load_stats_delivery_state()
    if (
        not force
        and state.get(sent_date_key) == today
    ):
        return False
    if (
        not MATCH_STATS_WORKBOOK.exists()
        or not SCREENSHOT_STATS_UPLOAD_TEMPLATE.exists()
    ):
        print(
            "[Stats Upload Delivery] Workbook or upload template is missing; "
            "delivery skipped",
            flush=True,
        )
        return False
    owner = await client.fetch_user(OWNER_ID)
    if await _player_stats_upload_receipt_exists(owner, today, phase):
        state[sent_date_key] = today
        state[sent_reason_key] = "receipt-recovery"
        _save_stats_delivery_state(state)
        print(
            "[Stats Upload Delivery] Recovered prior daily delivery "
            "from owner DM",
            flush=True,
        )
        return False
    atp_upload_csv, wta_upload_csv = await asyncio.gather(
        asyncio.to_thread(
            build_screenshot_player_upload_csv,
            MATCH_STATS_WORKBOOK,
            SCREENSHOT_STATS_UPLOAD_TEMPLATE,
            "atp",
        ),
        asyncio.to_thread(
            build_screenshot_player_upload_csv,
            MATCH_STATS_WORKBOOK,
            SCREENSHOT_STATS_UPLOAD_TEMPLATE,
            "wta",
        ),
    )
    await asyncio.wait_for(
        owner.send(
            f"📄 **Screenshot-based player stats upload sheet**\n"
            f"{_player_stats_upload_receipt_for_phase(today, phase)}\n"
            f"Generated as separate ATP and WTA files. The ATP file follows "
            f"the full supplied rankings sheet ({reason}).",
            files=[
                discord.File(
                    io.BytesIO(atp_upload_csv),
                    filename="pl_stats_upload.csv",
                ),
                discord.File(
                    io.BytesIO(wta_upload_csv),
                    filename="pl_stats_upload_wta.csv",
                ),
            ],
        ),
        timeout=30,
    )
    state[sent_date_key] = today
    state[sent_reason_key] = reason
    _save_stats_delivery_state(state)
    print(
        f"[Stats Upload Delivery] Sent screenshot-based player stats upload "
        f"({reason})",
        flush=True,
    )
    return True


async def _send_startup_player_stats_upload_before_catchup() -> None:
    """Send the current upload before the unbounded history catch-up scan."""
    try:
        async with _stats_scrape_lock:
            await _send_daily_player_stats_upload_csv(
                "startup/publish",
                force=True,
            )
    except Exception as exc:
        print(
            "[Stats Upload Delivery] Startup delivery before catch-up "
            f"failed: {exc}",
            flush=True,
        )


async def _dm_atp_csv_recipient(rows_written: int, test_run=False):
    """Send only the ATP CSV to the configured recipient."""
    recipient = await client.fetch_user(ATP_CSV_RECIPIENT_ID)
    heading = (
        "📄 **ONE-TIME TEST — Master TE Hub Stats**\n"
        if test_run
        else "📄 **Daily Master TE Hub Stats**\n"
    )
    await recipient.send(
        heading
        + "ATP tab export: columns A through AH, followed by AK "
        "(AI and AJ are omitted).\n"
        + f"{rows_written:,} data rows.",
        file=discord.File(
            str(ATP_CSV_RECIPIENT_FILE),
            filename="Master TE Hub Stats.csv",
        ),
    )


def _apply_discord_match_metadata(extracted, message):
    """Add trusted result-post metadata without overriding screenshot evidence."""
    text = message.content.strip()
    extracted["date"] = message.created_at.astimezone(STATS_TIMEZONE).date().isoformat()
    mention_names = []
    seen_mention_ids = set()
    for mentioned_user in getattr(message, "mentions", []):
        user_id = getattr(mentioned_user, "id", None)
        if user_id in seen_mention_ids:
            continue
        seen_mention_ids.add(user_id)
        mentioned_name = (
            getattr(mentioned_user, "display_name", None)
            or getattr(mentioned_user, "name", None)
            or ""
        ).strip()
        if mentioned_name:
            mention_names.append(mentioned_name)

    is_doubles = len(message.mentions) >= 4 or "&" in text
    if is_doubles:
        extracted["is_doubles"] = True

    # Screenshot names remain authoritative. Discord mentions are a trusted
    # fallback only when the vision response could not read a side.
    if is_doubles and len(mention_names) >= 4:
        fallback_names = (
            " & ".join(mention_names[:2]),
            " & ".join(mention_names[2:4]),
        )
    else:
        fallback_names = tuple(mention_names[:2])
    for side_key, fallback_name in zip(("player", "opponent"), fallback_names):
        side = extracted.get(side_key)
        if not isinstance(side, dict):
            side = {}
            extracted[side_key] = side
        if not str(side.get("name") or "").strip() and fallback_name:
            side["name"] = fallback_name
            side["note"] = "; ".join(
                value
                for value in (
                    str(side.get("note") or ""),
                    "Name supplied by Discord mention fallback",
                )
                if value
            )

    score_tokens = re.findall(r"\b\d{1,2}\s*[-/]\s*\d{1,2}(?:\(\d+\))?", text)
    if score_tokens:
        extracted["result"] = " ".join(
            re.sub(r"\s*[-/]\s*", "-", token) for token in score_tokens
        )
    elif re.search(r"\b(?:walkover|w/?o)\b", text, re.I):
        extracted["result"] = "Walkover"

    # The vision response is authoritative when the tournament is visible in
    # the screenshot. Only use unambiguous text metadata as a fallback.
    if not str(extracted.get("tournament") or "").strip():
        labeled_tournament = re.search(
            r"\b(?:tournament|event)\s*[:\-]\s*([^\n|]+)",
            text,
            flags=re.I,
        )
        tournament = labeled_tournament.group(1).strip(" ,-:") if labeled_tournament else ""

        if not tournament:
            before_mention = re.split(r"<@!?\d+>", text, maxsplit=1)[0].strip(" ,-:")
            if before_mention:
                tournament = re.sub(
                    r"\s+(?:final|f|semi[- ]?final|sf|quarter[- ]?final|qf|"
                    r"round of 16|r16|round of 32|r32|round of 64|r64)\s*:?\s*$",
                    "",
                    before_mention,
                    flags=re.I,
                ).strip(" ,-:")

        if tournament:
            extracted["tournament"] = tournament
    return extracted


async def _scrape_stats_message(message, test_run=False, force_reextract=False):
    """Extract one Discord result post without blocking other bot handlers."""
    attachments = _stats_image_attachments(message)
    key = f"{message.id}:" + ",".join(str(a.id) for a in attachments)
    async with _stats_scrape_lock:
        processed = load_processed_stats()
        if await asyncio.to_thread(workbook_has_source_message, message.id):
            processed.add(key)
            await _save_processed_screenshot_receipts(processed)
            print(f"[Stats Scraper] Reconciled message {message.id} from workbook")
            return False
        if key in processed and not force_reextract:
            print(f"[Stats Scraper] Already processed message {message.id}")
            return False
        workbook_appended = False
        try:
            images = []
            for attachment in attachments:
                raw = await attachment.read()
                media_type = attachment.content_type or "image/png"
                images.append((attachment.filename, media_type, raw))

            extracted = await extract_match(
                images,
                message.content,
                os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL", ""),
                os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY", ""),
            )
            extracted = _apply_discord_match_metadata(extracted, message)
            extracted = validate_extracted(extracted)
            rankings = await _get_stats_rankings()
            sheet, extracted = canonicalize_match(extracted, rankings)
            rows = build_match_stats_rows(
                extracted,
                sheet,
                [f"{message.id}_{attachment.filename}" for attachment in attachments],
            )
            await asyncio.to_thread(
                append_match_stats_rows,
                rows,
                MATCH_STATS_WORKBOOK,
                recalculate_summaries=True,
            )
            workbook_appended = True
            try:
                await asyncio.to_thread(
                    persist_screenshot_workbook,
                    MATCH_STATS_WORKBOOK,
                    MATCH_STATS_RECEIPTS_FILE,
                )
            except Exception:
                await asyncio.to_thread(
                    restore_screenshot_workbook_from_store,
                    MATCH_STATS_WORKBOOK,
                    MATCH_STATS_RECEIPTS_FILE,
                )
                workbook_appended = False
                raise
            processed.add(key)
            await _save_processed_screenshot_receipts(processed)
            _mark_stats_workbook_dirty()

            player = rows[0]["Player"]
            opponent = rows[0]["Opponent"]
            tournament = rows[0]["Tournament"] or "Unknown tournament"
            prefix = "ONE-TIME TEST — " if test_run else ""
            if test_run or _send_stats_workbook_per_result():
                try:
                    await _dm_stats_owner(
                        f"📊 **{prefix}match stats scraped**\n"
                        f"**{player} vs {opponent}** — {tournament}\n"
                        f"Added 2 rows to `{MATCH_STATS_WORKBOOK.name}` "
                        f"({sheet.upper()}).",
                        include_workbook=True,
                    )
                    _mark_stats_workbook_delivered()
                except Exception as dm_exc:
                    print(
                        f"[Stats Scraper] Workbook saved but delivery failed for "
                        f"message {message.id}: {dm_exc}"
                    )
            else:
                print(
                    f"[Stats Scraper] Workbook delivery queued for end of day "
                    f"after message {message.id}"
                )
            print(f"[Stats Scraper] Added {player} vs {opponent} from message {message.id}")
            return True
        except Exception as exc:
            if workbook_appended:
                try:
                    await asyncio.to_thread(
                        restore_screenshot_workbook_from_store,
                        MATCH_STATS_WORKBOOK,
                        MATCH_STATS_RECEIPTS_FILE,
                    )
                except Exception as restore_exc:
                    print(
                        "[Stats Scraper] Failed to restore the last durable "
                        f"workbook after an error: {restore_exc}",
                        flush=True,
                    )
            label = "one-time test" if test_run else "live result"
            print(f"[Stats Scraper] Failed message {message.id}: {exc}")
            try:
                await _dm_stats_owner(
                    f"⚠️ **Match stats scrape failed ({label})**\n"
                    f"Message: {message.jump_url}\n"
                    f"Reason: {str(exc)[:1200]}"
                )
            except Exception as dm_exc:
                print(f"[Stats Scraper] Failed to DM owner: {dm_exc}")
            return False


async def _one_time_stats_scrape_test():
    if os.path.exists(STATS_TEST_FLAG):
        print("[Stats Scraper Test] Flag found — skipping")
        return
    await _wait_for_matchlog_rebuild()
    await asyncio.sleep(5)
    verified = False
    try:
        channel = client.get_channel(TE4_RESULTS_CHANNEL_ID)
        if channel is None:
            channel = await client.fetch_channel(TE4_RESULTS_CHANNEL_ID)
        candidates = []
        pending_by_author = {}
        cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
        async for message in channel.history(
            limit=None, after=cutoff, oldest_first=True
        ):
            if _is_stats_result_message(message):
                candidates.append(message)
                pending_by_author.pop(message.author.id, None)
            elif _is_stats_result_text(message):
                pending_by_author[message.author.id] = message
            elif not message.author.bot and _stats_image_attachments(message):
                result_message = pending_by_author.get(message.author.id)
                if result_message:
                    age = (
                        message.created_at - result_message.created_at
                    ).total_seconds()
                    if 0 <= age <= 5 * 60:
                        candidates.append(
                            _combine_stats_result_messages(result_message, message)
                        )
                        pending_by_author.pop(message.author.id, None)

        if candidates:
            latest = candidates[-1]
            print(f"[Stats Scraper Test] Testing latest message {latest.id}")
            imported = await _scrape_stats_message(
                latest, test_run=True, force_reextract=True
            )
            async with _stats_scrape_lock:
                details = await asyncio.to_thread(
                    verify_workbook_source_message,
                    latest.id,
                    MATCH_STATS_WORKBOOK,
                    True,
                )
                await asyncio.to_thread(
                    persist_screenshot_workbook,
                    MATCH_STATS_WORKBOOK,
                    MATCH_STATS_RECEIPTS_FILE,
                )
                key = f"{latest.id}:" + ",".join(
                    str(attachment.id)
                    for attachment in _stats_image_attachments(latest)
                )
                if key not in load_processed_stats():
                    raise RuntimeError(
                        "Latest source was not persisted in the dedupe ledger"
                    )
                if not imported:
                    await _dm_stats_owner(
                        "📊 **ONE-TIME TEST — latest match verified**\n"
                        f"**{details['player']} vs {details['opponent']}** is "
                        "already present as exactly two reciprocal rows on the "
                        f"`{details['sheet']}` sheet and was not duplicated.",
                        include_workbook=True,
                    )
                    _mark_stats_workbook_delivered()
            print(
                f"[Stats Scraper Test] Verified message {latest.id}: "
                f"sheet={details['sheet']}, rows={details['rows']}, "
                f"formulas_repaired={details['repaired_formulas']}, "
                "ledger=yes, workbook_delivered=yes"
            )
            verified = True
        else:
            await _dm_stats_owner(
                "⚠️ **One-time match stats test:** no qualifying result with screenshots "
                "was found in the last 24 hours."
            )
    except Exception as exc:
        print(f"[Stats Scraper Test] Error: {exc}")
        try:
            await _dm_stats_owner(f"⚠️ **One-time match stats test failed:** {str(exc)[:1200]}")
        except Exception:
            pass
    if verified:
        with open(STATS_TEST_FLAG, "w") as handle:
            handle.write("done")
        print("[Stats Scraper Test] Verification complete; flag written")
    else:
        print("[Stats Scraper Test] Verification incomplete; flag not written")


async def _send_daily_atp_csv():
    """Send the ATP CSV daily without attaching the owner's Excel workbook."""
    if not PERIODIC_ATP_CSV_DELIVERY_ENABLED:
        print(
            "[Stats CSV Delivery] Periodic recipient delivery is paused"
        )
        return False
    today = datetime.now(STATS_TIMEZONE).date().isoformat()
    state = _load_stats_delivery_state()
    if state.get("csv_recipient_last_sent_date") == today:
        return False
    if not MATCH_STATS_WORKBOOK.exists():
        print(
            "[Stats CSV Delivery] Workbook not found; "
            "daily recipient delivery skipped"
        )
        return False
    rows_written = await asyncio.to_thread(
        export_atp_columns_csv, ATP_CSV_RECIPIENT_FILE
    )
    await _dm_atp_csv_recipient(rows_written)
    state["csv_recipient_last_sent_date"] = today
    _save_stats_delivery_state(state)
    try:
        await _dm_stats_owner(
            "✅ **Daily CSV delivery confirmed**\n"
            f"`Master TE Hub Stats.csv` was sent to Discord user "
            f"`{ATP_CSV_RECIPIENT_ID}`."
        )
    except Exception as confirmation_exc:
        print(
            "[Stats CSV Delivery] Recipient received the file, "
            f"but owner confirmation failed: {confirmation_exc}"
        )
    print(
        f"[Stats CSV Delivery] Sent renamed ATP CSV to "
        f"{ATP_CSV_RECIPIENT_ID} ({rows_written} data rows)"
    )
    return True

def _screenshot_review_receipt(delivery_date: str) -> str:
    return f"{SCREENSHOT_REVIEW_RECEIPT_PREFIX} `{delivery_date}`"
async def _stats_workbook_delivery_loop():
    """Send the master workbook once per calendar day at midnight."""
    await asyncio.sleep(20)
    await _wait_for_matchlog_rebuild()
    while True:
        try:
            now = datetime.now(STATS_TIMEZONE)
            async with _stats_scrape_lock:
                state = _load_stats_delivery_state()
                today = now.date().isoformat()
                daily_due = (
                    now.hour == STATS_EOD_HOUR
                    and now.minute == STATS_EOD_MINUTE
                    and state.get("daily_sent_date") != today
                )
                if daily_due:
                    try:
                        await _send_daily_player_stats_upload_csv("daily")
                    except Exception as upload_exc:
                        print(
                            f"[Stats Upload Delivery] End-of-day delivery "
                            f"error: {upload_exc}",
                            flush=True,
                        )
                    try:
                        await _send_daily_atp_csv()
                    except Exception as csv_exc:
                        print(f"[Stats CSV Delivery] Daily delivery error: {csv_exc}")
                    await _deliver_pending_stats_workbook(
                        "daily",
                        force=True,
                        daily_date=today,
                    )
        except Exception as exc:
            print(f"[Stats Delivery] End-of-day delivery error: {exc}")
        await asyncio.sleep(60)


async def _stats_daily_catchup_loop():
    """Catch result posts missed in the last three days, then repeat daily."""
    await asyncio.sleep(25)
    await _wait_for_matchlog_rebuild()
    await _send_startup_player_stats_upload_before_catchup()
    startup_reconciliation = True
    while True:
        try:
            channel = client.get_channel(TE4_RESULTS_CHANNEL_ID)
            if channel is None:
                channel = await client.fetch_channel(TE4_RESULTS_CHANNEL_ID)
            # Scan three full days so temporary AI configuration or budget
            # failures can recover after the bot is republished. Existing
            # source-message and workbook match-key checks prevent duplicates.
            cutoff = datetime.now(timezone.utc) - timedelta(hours=72)
            scanned = 0
            imported = 0
            pending_by_author = {}
            async for message in channel.history(
                limit=None, after=cutoff, oldest_first=True
            ):
                if _is_stats_result_message(message):
                    scanned += 1
                    if await _scrape_stats_message(message):
                        imported += 1
                    pending_by_author.pop(message.author.id, None)
                elif _is_stats_result_text(message):
                    pending_by_author[message.author.id] = message
                elif not message.author.bot and _stats_image_attachments(message):
                    result_message = pending_by_author.get(message.author.id)
                    if result_message:
                        age = (message.created_at - result_message.created_at).total_seconds()
                        if 0 <= age <= 5 * 60:
                            scanned += 1
                            combined = _combine_stats_result_messages(
                                result_message, message
                            )
                            if await _scrape_stats_message(combined):
                                imported += 1
                            pending_by_author.pop(message.author.id, None)
            print(
                f"[Stats Daily Catch-up] Scanned {scanned} qualifying posts; "
                f"imported {imported} new matches"
            )
            if startup_reconciliation:
                try:
                    async with _stats_scrape_lock:
                        startup_date = datetime.now(
                            STATS_TIMEZONE
                        ).date().isoformat()
                        await _deliver_pending_stats_workbook(
                            "startup/publish",
                            force=True,
                            daily_date=startup_date,
                        )
                        await _send_daily_player_stats_upload_csv(
                            "startup/publish",
                            force=True,
                        )
                except Exception as delivery_exc:
                    print(
                        f"[Stats Daily Catch-up] Startup workbook delivery "
                        f"failed: {delivery_exc}"
                    )
                startup_reconciliation = False
        except Exception as exc:
            print(f"[Stats Daily Catch-up] Error: {exc}")
            try:
                await _dm_stats_owner(
                    f"⚠️ **Daily match stats catch-up failed:** {str(exc)[:1200]}"
                )
            except Exception as dm_exc:
                print(f"[Stats Daily Catch-up] Failed to DM owner: {dm_exc}")
        await asyncio.sleep(24 * 60 * 60)


@client.event
#async def on_message():
async def on_message(message):
    try:
        if await _route_match_scheduler_message(message):
            await client.process_commands(message)
            return
    except Exception as exc:
        print(f"[Match scheduler] message routing error: {exc}", flush=True)
    # Pre-match replies are deliberately handled before unrelated DM features.
    if not message.author.bot:
        try:
            if await _route_outreach_reply(message):
                await client.process_commands(message)
                return
        except Exception as exc:
            # Outreach persistence must never prevent the bot's other handlers.
            print(f"[Outreach] reply routing error: {exc}")
    if (
        message.channel.id == MATCHLOG_SUBMISSIONS_CHANNEL_ID
        and not message.author.bot
        and _matchlog_attachments(message)
    ):
        asyncio.create_task(_process_matchlog_submission(message))
    if _is_announcement_channel(message.channel) and not message.author.bot:
        asyncio.create_task(_mirror_announcement_to_twitter(message))
    if message.channel.id == 1246542846585212960 and not message.author.bot:
        await message.delete()
        response = f'Hey there {message.author.mention}, welcome to WTSL 😁, your journey to greatness has begun! Please talk in ⁠https://discord.com/channels/786583939028090881/786583939573219350 or ⁠https://discord.com/channels/786583939028090881/1248269113009373315 Please submit info for your ⁠https://discord.com/channels/786583939028090881/806259741269164062 by messaging an admin https://discord.com/channels/786583939028090881/956208982958157864'
      #  await message.channel.send(response)
        await message.author.send(response)

    # --- Acknowledge messages in pending interview invite threads ---
    if (
        hasattr(message.channel, "parent_id")
        and message.channel.id in _pending_interviews
        and not message.author.bot
    ):
        try:
            await _ack_pending_interview_message(message)
        except Exception as exc:
            print(f"[AI Interview] Pending invite acknowledgement failed: {exc}")

    # --- Handle replies in active public interview threads ---
    # These threads are intentionally open to other human participants, not
    # only the player who accepted the original invite.
    if (
        hasattr(message.channel, "parent_id")
        and not message.author.bot
    ):
        interview = _active_interviews.get(message.channel.id)
        if interview is None:
            interview = await _recover_interview_for_message(message)
        if interview is not None:
            try:
                await _handle_interview_reply(message, interview)
            except Exception as e:
                print(f"[AI Interview] Error handling reply: {e}")

    # --- Support channel unanswered-message watch ---
    if message.channel.id in WATCHED_SUPPORT_CHANNELS and not message.author.bot:
        guild = message.guild
        is_staff = False
        if guild:
            member = guild.get_member(message.author.id)
            if member:
                staff_ids = {ADMIN_ROLE_ID, MODERATOR_ROLE_ID}
                is_staff = any(r.id in staff_ids for r in member.roles)
        state = _support_watch[message.channel.id]
        if is_staff:
            # Staff replied — clear everything so the next non-staff message starts fresh
            state["pending_msg_time"] = None
            state["pending_msg_id"] = None
            state["pending_msg_content"] = None
            state["alerted"] = False
        else:
            if state["alerted"]:
                # Already alerted staff about this unanswered stretch — don't spam
                pass
            else:
                if state["pending_msg_time"] is None:
                    # First message in this unanswered stretch — start the 10-min clock
                    state["pending_msg_time"] = time.time()
                # Always track the latest message content/id so the DM shows what's most recent
                state["pending_msg_id"] = message.id
                state["pending_msg_content"] = message.content[:300] or "(no text)"

    # --- Contact-admins thread unanswered-message watch ---
    if (isinstance(message.channel, discord.Thread)
            and message.channel.parent_id == CONTACT_ADMINS_CHANNEL_ID
            and not message.author.bot):
        guild = message.guild
        is_staff = False
        if guild:
            member = guild.get_member(message.author.id)
            if member:
                staff_ids = {ADMIN_ROLE_ID, MODERATOR_ROLE_ID}
                is_staff = any(r.id in staff_ids for r in member.roles)
        tid = message.channel.id
        if tid not in _thread_watch:
            _thread_watch[tid] = {
                "pending_msg_time": None, "pending_msg_id": None,
                "pending_msg_content": None, "alerted": False,
                "thread_name": message.channel.name,
            }
        state = _thread_watch[tid]
        if is_staff:
            state["pending_msg_time"] = None
            state["pending_msg_id"] = None
            state["pending_msg_content"] = None
            state["alerted"] = False
        else:
            if not state["alerted"]:
                if state["pending_msg_time"] is None:
                    state["pending_msg_time"] = time.time()
                state["pending_msg_id"] = message.id
                state["pending_msg_content"] = message.content[:300] or "(no text)"

    if message.channel.id == TE4_RESULTS_CHANNEL_ID and not message.author.bot:
        msg_lower_check = message.content.lower()
        has_two_mentions = len(message.mentions) >= 2
        is_coin_toss = "heads" in msg_lower_check or "tails" in msg_lower_check
        has_attachment = len(message.attachments) > 0
        pending_key = (message.channel.id, message.author.id)

        if _is_stats_result_text(message) and not _stats_image_attachments(message):
            _pending_stats_result_posts[pending_key] = message
            print(f"[Stats Scraper] Waiting for image after result message {message.id}")
        elif _stats_image_attachments(message) and len(message.mentions) < 2:
            result_message = _pending_stats_result_posts.get(pending_key)
            if result_message:
                age = (message.created_at - result_message.created_at).total_seconds()
                if 0 <= age <= 5 * 60:
                    combined = _combine_stats_result_messages(result_message, message)
                    asyncio.create_task(_scrape_stats_message(combined))
                    _pending_stats_result_posts.pop(pending_key, None)

        if has_two_mentions and not is_coin_toss and has_attachment:
            # Queue stats independently of interviews. Result posts do not
            # always contain the literal "def." text, but image attachments
            # and two player mentions are the same signal used by interviews.
            if _is_stats_result_message(message):
                asyncio.create_task(_scrape_stats_message(message))
            try:
                ai_client = OpenAI(
                    base_url=os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL"),
                    api_key=os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY"),
                )
                await _try_trigger_interview(message, ai_client)
            except Exception as e:
                print(f"[AI Interview] Error generating interview: {e}")

    await client.process_commands(message)


'''@client.listen()
async def on_ready():
    print(f'{client.user} successfully logged in!')

    try:
        djokorer = await client.fetch_user(859691230941282304)
        await djokorer.send('Bot has started.')
    except Exception as e:
        print(f"[on_ready error] Failed to DM djokorer: {e}")

    # Run dailyresults once (if needed — not a loop)
    try:
        await dailyresults()
    except Exception as e:
        print(f"[on_ready error] Failed to run dailyresults: {e}")

    # Start latestresults if not already running
    if not hasattr(client, 'latestresults_started'):
        client.latestresults_started = True
        try:
            client.loop.create_task(latestresults())
            print("[on_ready] latestresults task started.")
        except Exception as e:
            print(f"[on_ready error] Failed to start latestresults: {e}")'''

'''@client.event
async def on_ready():
    print(f'{client.user} succesfully logged in!')
    djokorer = await client.fetch_user(859691230941282304)
    await djokorer.send('bot has started')

    try:
        dailyresults.start()
    except:
        dailyresults.cancel()
        dailyresults.start()

    try:
        client.loop.create_task(latestresults())  # <-- THIS IS WHAT YOU NEED
    except Exception as e:
        print(f"Failed to start latestresults loop: {e}")'''

#now = datetime.datetime.now() 
async def today():
        now = datetime.datetime.now()
        url = 'https://www.wtetour.com/pages/all_results.php'
        r = requests.get(url)
        if now.hour == 22 and now.minute == 59: #and now.second == 0:
          try:
            def save_html(html, path):
              with open(path, 'wb') as f:
                  f.write(html)
            save_html(r.content, 'wtetresults {}'.format(date.today()))
            def open_html(path):
              with open(path, 'rb') as f:
                return f.read()

#import requests
#url = 'https://wtetour.wtetour.com/edit/latest_scores_all.php?showall'
#r = requests.get(url)
#import beautifulsoup4
#from bs4 import BeautifulSoup
            html = open_html('wtetresults {}'.format(date.today()))
            soup = BeautifulSoup(r.content, 'html.parser')
            rows = soup.select('tr td')
            results_wtet = rows[101:]
            dates = list(results_wtet[2])
            tournament = list(results_wtet[1]) 
            rounds = list(results_wtet[3])
            P1 = list(results_wtet[5])
            P2 = list(results_wtet[6])
            score = []
            for i in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55]:
                dates.append(results_wtet[(9*i)+2])
                tournament.append(results_wtet[(9*i)+1])
                rounds.append(results_wtet[(9*i)+3])
                P1.append(results_wtet[(9*i)+5])
                P2.append(results_wtet[(9*i)+6])
            for i in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55]: 
                score.append(results_wtet[(9*i)+8])
            results = pd.DataFrame(dates)
            results['Tournament'] = tournament
            results['Round'] = rounds
            results['P1'] = P1
            results['P2'] = P2
            results['Score'] = score
            results.to_csv('wtet_results {}.csv'.format(date.today()))
            results = pd.read_csv('wtet_results {}.csv'.format(date.today()))
            results.rename(columns = {'0':'Date'}, inplace = True)
            results['Date'] = results['Date'].str.replace('<td>', '').str.replace('</td>', '')
            results['Tournament'] = results['Tournament'].str.replace('<td>', '').str.replace('</td>', '')
            results['Round'] = results['Round'].str.replace('<td>', '').str.replace('</td>', '')
            results['P1'] = results['P1'].str.replace('<td>', '').str.replace('</td>', '')
            results['P2'] = results['P2'].str.replace('<td>', '').str.replace('</td>', '')
            results['Score'] = results['Score'].str.replace('<td>', '').str.replace('</td>', '')
            results['Result'] = 1
            results['Scores'] = 1 
            del results[results.columns[0]]
            djokorer = await client.fetch_user(859691230941282304)
            await djokorer.send(now)
    #if now.second == 0: 
    #now.minute == 33 
    #now.second == 0
      
  #await ctx.message.delete()
            willito = await client.fetch_user(188524743488438273)
            djokorer = await client.fetch_user(859691230941282304)
            channel = client.get_channel(993448895818518558)
            for i in range(len(results)):
              results['Result'].iloc[i]= results.iloc[i].P1 + ' d. ' + results.iloc[i].P2
              results['Scores'].iloc[i] = results.iloc[i].Result + ':' +     results.iloc[i].Score
            await channel.send('** 🎾 Results: {}**'.format(date.today().strftime('%A %d %B %Y')))
            await djokorer.send('** 🎾 Results: {}**'.format(date.today().strftime('%A %d %B %Y')))
  #await ctx.send(str(tuple(results[['Date', 'Tournament', 'Round', 'Result', 'Score']].columns))[1:-1])
            for x, y in enumerate(results[['Tournament', 'Round', 'Result', 'Score']].values):
              if results[['Date','Tournament', 'Round', 'Result', 'Score']].values[x][0] == date.today().strftime('%d.%m.%Y') and results[['Date','Tournament', 'Round', 'Result', 'Score']].values[x][4] != " ": 
                await channel.send(str(tuple(y)).replace("'","")[1:-1])
         # await willito.send(str(tuple(y)).replace("'","")[1:-1])    
            if results.Date[0] == date.today().strftime('%d.%m.%Y'):
              api.update_status('{}{}{}'.format('🎾 Results:{}' .format(date.today().strftime('%A %d %B %Y')), '\n',  results[['Tournament', 'Round', 'Scores']][results.Date == date.today().strftime('%d.%m.%Y')].to_string(header = False, index = False)))
            elif results.Date[0] < date.today().strftime('%d.%m.%Y'):
              await channel.send('No matches played today')
       # await willito.send('No matches played today')
              api.update_status('No matches played today')
    #        else:
    #             pass
          except:
                pass
     #     djokorer = await client.fetch_user(859691230941282304)
      #    await djokorer.send('exception')
@client.command(pass_context = True) 
async def results(ctx):
        await ctx.message.delete()
        now = datetime.datetime.now()
        url = 'https://www.wtetour.com/pages/all_results.php'
        r = requests.get(url)
        #if now.hour == 2217 and now.minute == 59: #and now.second == 0:
        try:
          def save_html(html, path):
            with open(path, 'wb') as f:
                f.write(html)
          save_html(r.content, 'wtetresults {}'.format(date.today()))
          def open_html(path):
            with open(path, 'rb') as f:
              return f.read()

#import requests
#url = 'https://wtetour.wtetour.com/edit/latest_scores_all.php?showall'
#r = requests.get(url)
#import beautifulsoup4
#from bs4 import BeautifulSoup
          html = open_html('wtetresults {}'.format(date.today()))
          soup = BeautifulSoup(r.content, 'html.parser')
          rows = soup.select('tr td')
          results_wtet = rows[101:]
          dates = list(results_wtet[2])
          tournament = list(results_wtet[1]) 
          rounds = list(results_wtet[3])
          P1 = list(results_wtet[5])
          P2 = list(results_wtet[6])
          score = []
          for i in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55]:
              dates.append(results_wtet[(9*i)+2])
              tournament.append(results_wtet[(9*i)+1])
              rounds.append(results_wtet[(9*i)+3])
              P1.append(results_wtet[(9*i)+5])
              P2.append(results_wtet[(9*i)+6])
          for i in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55]:
              score.append(results_wtet[(9*i)+8])
          results = pd.DataFrame(dates)
          results['Tournament'] = tournament
          results['Round'] = rounds
          results['P1'] = P1
          results['P2'] = P2
          results['Score'] = score
          results.to_csv('wtet_results {}.csv'.format(date.today()))
          results = pd.read_csv('wtet_results {}.csv'.format(date.today()))
          results.rename(columns = {'0':'Date'}, inplace = True)
          results['Date'] = results['Date'].str.replace('<td>', '').str.replace('</td>', '')
          results['Tournament'] = results['Tournament'].str.replace('<td>', '').str.replace('</td>', '')
          results['Round'] = results['Round'].str.replace('<td>', '').str.replace('</td>', '')
          results['P1'] = results['P1'].str.replace('<td>', '').str.replace('</td>', '')
          results['P2'] = results['P2'].str.replace('<td>', '').str.replace('</td>', '')
          results['Score'] = results['Score'].str.replace('<td>', '').str.replace('</td>', '')
          results['Result'] = 1
          results['Scores'] = 1
          del results[results.columns[0]]
          djokorer = await client.fetch_user(859691230941282304)
          await djokorer.send(now)
    #if now.second == 0: 
    #now.minute == 33 
    #now.second == 0
      
  #await ctx.message.delete()
          willito = await client.fetch_user(188524743488438273)
          djokorer = await client.fetch_user(859691230941282304)
          channel = client.get_channel(993448895818518558)
          for i in range(len(results)):
            results['Result'].iloc[i]= results.iloc[i].P1 + ' d. ' + results.iloc[i].P2
            results['Scores'].iloc[i] = results.iloc[i].Result + ':' +     results.iloc[i].Score
          await channel.send('** 🎾 Results: {}**'.format(date.today().strftime('%A %d %B %Y')))
          await djokorer.send('** 🎾 Results: {}**'.format(date.today().strftime('%A %d %B %Y')))
  #await ctx.send(str(tuple(results[['Date', 'Tournament', 'Round', 'Result', 'Score']].columns))[1:-1])
          for x, y in enumerate(results[['Tournament', 'Round', 'Result', 'Score']].values):
            if results[['Date','Tournament', 'Round', 'Result', 'Score']].values[x][0] == date.today().strftime('%d.%m.%Y') and results[['Date','Tournament', 'Round', 'Result', 'Score']].values[x][4] != " ": 
              await channel.send(str(tuple(y)).replace("'","")[1:-1])
         # await willito.send(str(tuple(y)).replace("'","")[1:-1])    
          if results.Date[0] == date.today().strftime('%d.%m.%Y'):
            api.update_status('{}{}{}'.format('🎾 Results:{}' .format(date.today().strftime('%A %d %B %Y')), '\n',  results[['Tournament', 'Round', 'Scores']][results.Date == date.today().strftime('%d.%m.%Y')].to_string(header = False, index = False)))
          elif results.Date[0] < date.today().strftime('%d.%m.%Y'):
            await channel.send('No matches played today')
       # await willito.send('No matches played today')
            api.update_status('No matches played today')
    #        else:
    #             pass
        except:
              pass
     #     djokorer = await client.fetch_user(859691230941282304)
      #    await djokorer.send('exception')
      
@client.event        
async def on_member_join(member):
      #guild = await client.fetch_guild(786583939028090881)
      #from discord.utils import get
      #role_id = '873925957348622366'
      #role = get(guild.roles, role_id)
      logging_channel = client.get_channel(998168370086158367)
      arrival_channel = client.get_channel(953651276296634369) #join-logs channel
      #print(role.name)
      #role = ''<@&873925957348622366>
      #while True:
      #  if len(member.roles) == 1:
      #    print(len(member.roles))
      #    print(member.roles)
      #await arrival_channel.send(client.fetch_guild)
      #while member.get_role
      #while member.get_role
      await member.send("Please **read and accept the server rules** (https://discord.com/channels/786583939028090881/1246556295922716722) and then follow the instruction in the #verification channel (https://discord.com/channels/786583939028090881/953651276296634369) to verify your account on the server Veuillez **lire et accepter les règles du serveur** (https://discord.com/channels/786583939028090881/806962143638978641) puis suivez les instructions dans le canal #vérification (https://discord.com/channels/786583939028090881/953651276296634369) pour vérifier votre compte sur le serveur")
      await arrival_channel.send(member.mention+ "Please type **/verify** into this channel and press enter to complete the verification process.**You will receive a private message from the Double Counter bot, after typing this message into the channel, asking to verify your account. You must complete the verification before selecting a role, https://discord.com/channels/786583939028090881/953645351850639410/1246526149169909772 after which you will be able to access our other channels.** If you have any questions, contact an admin https://discord.com/channels/786583939028090881/956208982958157864 or raise a ticket https://discord.com/channels/786583939028090881/1170434120988495902/1170437995992711208 Feel free to sign up for one of our open tournaments in https://discord.com/channels/786583939028090881/1246506085347491841  https://discord.com/channels/786583939028090881/816049124079173672 or https://discord.com/channels/786583939028090881/1267550609763078165 Veuillez taper **/verify** dans ce canal et appuyer sur entrer pour compléter le processus de vérification.**Vous recevrez un message privé du bot Double Counter après avoir tapé ce message dans le canal, demandant de vérifier votre compte. Vous devez compléter la vérification avant de sélectionner un rôle, https://discord.com/channels/786583939028090881/953645351850639410/1246526149169909772 après quoi vous pourrez accéder à nos autres canaux.** Si vous avez des questions, contactez un admin https://discord.com/channels/786583939028090881/956208982958157864 ou ouvrez un ticket https://discord.com/channels/786583939028090881/1170434120988495902/1170437995992711208 N'hésitez pas à vous inscrire à l'un de nos tournois ouverts dans https://discord.com/channels/786583939028090881/1246506085347491841 https://discord.com/channels/786583939028090881/816049124079173672 ou https://discord.com/channels/786583939028090881/1267550609763078165")
      #await logging_channel.send(member+" Joined the server")
         # break
@client.command(pass_context = True)  
async def upload(ctx, filename):
    print("{}".format(filename))
    await ctx.message.delete()
    channel = client.get_channel(946536990512382002) 
    attachment_url = ctx.message.attachments[0].url
    file_request = requests.get(attachment_url)
    with open('{}.csv'.format(filename), 'wb') as file:
        file.write(file_request.content)
    rankings_ = pd.read_csv('{}.csv'.format(filename))
    rankings_.to_csv('test_{}.csv'.format(date.today().strftime('%d%m%y')))
        #for line in file_request.iter_lines():
        #    writer.writerow(line.decode('utf-8').split(','))
    #print(file_request.content)
    await channel.send('test {}'.format(date.today().strftime('%d%m%y')), file=discord.File('test_{}.csv'.format(date.today().strftime('%d%m%y'))))

@client.command(pass_context = True)  
async def scraperesults(ctx, tournament, next_tournament):
    djokorer = await client.fetch_user(859691230941282304)
    oserkos = await client.fetch_user(694626703376384081)
    print("{}{}".format(tournament, next_tournament))
    await ctx.message.delete()
    channel = client.get_channel(946536990512382002) 
    tournaments = ['Auckland', 'Brisbane', 'Madrid','Rome',     'Roland_Garros',        'Queens',       'Halle',        'Hertogenbosch',        'Stuttgart',    'Eastbourne',   'Newport',      'Summer Cup',   'Wimbledon',    'Hamburg',      'Gstaad',       'Atlanta',      'Washington',   'Acapulco',     'Toronto',      'Montreal',     'Cincinnati',   'US_Open',      'Moselle', 'Wuhan', 'Astana', 'Beijing', 'Tokyo',       'Shanghai', 'Chengdu',  'Shenzen',      'Winston_Salem',        'Antwerp',      'Moscow',       'Vienna',       'Basel',        'Paris',        'Stockholm',    'Doha', 'Sydney', 'Adelaide',   'Australian_Open',      'Montpellier',  'Cordoba', 'Dallas',    'Marseille',    'Buenos_Aires', 'Rotterdam',    'Dubai', 'Rio', 'Indian_Wells', 'Miami',        'Kitzbuhel',    'Houston',      'Monte_Carlo',  'Barcelona',    'Munich',       'Belgrade',     'Marrakech', 'Delray_Beach', 'Nice', 'Estoril', 'Geneva', 'Lyon','World_Tour_Finals', 'Next_Gen_Finals', 'Mallorca', 'Olympics', 'Rafa_Nadal', 'Bordeaux', 'Sumter'
]

    categories = ['250', '250', '1000', '1000', '2000', '500',  '500',  '250',  '250',  '250',  '250',  '250',  '2000', '500',  '250',  '500',  '500',  '500',  '1000', '1000', '1000', '2000', '250', '250', '250', '500', '500', '1000', '250',       '250',  '250',  '250',  '250',  '500',  '500',  '1000', '250',  '250',  '250',  '250',  '2000', '250', '250',   '250', '250',   '250',  '500',  '500',  '500',  '1000', '1000', '250',  '250',  '1000', '500',  '250',  '250',  '250',  '250',  '250',  '250',  '250',  '250', '1500',  '300', '250', '250', '75', '175', '175'
]

#categories = ['1000', '1000', '2000', '500', '250', '250', '2000', '500', '500', '500', '1000']
  
    rounds = ['W', 'F', 'SF', 'QF', 'R16', 'R32', 'R64', 'First Round','Q', 'na']
    finalsrounds = ['W', 'W1L', 'W2L', 'F', 'F1L', 'F2L', 'SF', 'SF1L', 'SF2L', 'G1L', 'G2L', 'G3L', 'na']
    #slams = [2000, 1300, 800, 400, 200, 100, 50, 50, 10, 0]
    slam_rounds = ['W', 'F', 'SF', 'QF', 'R16', 'R32', 'R64','Q', 'na']
    masters_rounds = ['W', 'F', 'SF', 'QF', 'R16', 'First Round','Q', 'na']
    fivehundred_rounds = ['W', 'F', 'SF', 'QF', 'R16', 'First Round','Q', 'na']
    twofifty_rounds = ['W', 'F', 'SF', 'QF', 'First Round','Q', 'na']
    sevenfive_rounds = ['W', 'F', 'SF', 'QF', 'na']
    slams_id = [8, 7, 6, 5, 4, 3, 2, 1, 0]
    masters_id = [6, 5, 4, 3, 2, 1, 0, 0]
    fivehundred_id = [6, 5, 4, 3, 2, 1, 0, 0]
    #twofifty_id = [5, 4, 3, 2, 1, 0, 0]
    twofifty_id = [6, 5, 4, 3, 2, 1, 1]
    sevenfive_id = [4, 3, 2, 1, 0]
    def challonge_scrape(tournament_name):
        dict = {}
        for i, j in enumerate(zip(tournaments, categories)):
            dict[tournaments[i]]= categories[i]
        if dict[tournament_name] == '2000':
            slamsdict = {}
            for i, j in enumerate(zip(slams_id, slam_rounds)):
                slamsdict[slams_id[i]]= slam_rounds[i]
            return slamsdict
        elif dict[tournament_name] == '1000':
            mastersdict = {}
            for i, j in enumerate(zip(masters_id, masters_rounds)):
                mastersdict[masters_id[i]]= masters_rounds[i]
            return mastersdict
        elif dict[tournament_name] == '500':
            fivehundreddict = {}
            for i, j in enumerate(zip(fivehundred_id, fivehundred_rounds)):
                fivehundreddict[fivehundred_id[i]]= fivehundred_rounds[i]
            return fivehundreddict
        elif dict[tournament_name] == '250':
            twofiftydict = {}
            for i, j in enumerate(zip(twofifty_id, twofifty_rounds)):
                twofiftydict[twofifty_id[i]]= twofifty_rounds[i]
            return twofiftydict
        elif dict[tournament_name] == '75':
            sevenfivedict = {}
            for i, j in enumerate(zip(sevenfive_id, sevenfive_rounds)):
                sevenfivedict[sevenfive_id[i]]= sevenfive_rounds[i]
            return sevenfivedict
    import pandas as pd
    import http.client
    import json
    import re
    nextweek_conn = http.client.HTTPSConnection("api.challonge.com")
    payload = ''
    headers = {

    }
    tournament_address = "/v1/tournaments/91d510368cb4170cd5ac3776-{}_2024_TE4/participants.json?api_key={}&subdomain=91d510368cb4170cd5ac3776".format(next_tournament, os.environ.get('CHALLONGE_API_KEY', ''))
    nextweek_conn.request("GET", tournament_address , payload, headers)
    nextweek_res = nextweek_conn.getresponse()
    _increment_challonge_counter("nextweek: next tournament participants")
    nextweek_data = nextweek_res.read()
    #nextweek = json.load(open(nextweek_data))
    nextweek  = json.loads(nextweek_data.decode("utf-8"))
    nextweek_list = []
    for i in nextweek:
        nextweek_list.append(re.sub(r'\(.*?\)\ *', '', i['participant']['name']))
    entrylist = pd.DataFrame()
    entrylist['Player'] = nextweek_list
    entrylist.to_csv('{}_entrylist.csv'.format(next_tournament))

    participants_conn = http.client.HTTPSConnection("api.challonge.com")
    payload = ''
    headers = {

    }
    tournament_address = "/v1/tournaments/91d510368cb4170cd5ac3776-{}_2024_TE4/participants.json?api_key={}&subdomain=91d510368cb4170cd5ac3776".format(tournament, os.environ.get('CHALLONGE_API_KEY', ''))
    participants_conn.request("GET", tournament_address , payload, headers)
    participants_res = participants_conn.getresponse()
    _increment_challonge_counter("nextweek: current tournament participants")
    participants_data = participants_res.read()
    participants  = json.loads(participants_data.decode("utf-8"))
    
    player_id = []
    player = []
    for i in participants:
    #print(re.sub(r'\(.*?\)\ *', '', i['participant']['name']))
    #print(i)
        player_id.append(str(i['participant']['id']))
        player.append(re.sub(r'\(.*?\)\ *', '', i['participant']['name']))
    #    print(str(i['participant']['id'])+"_"+re.sub(r'\(.*?\)\ *', '', i['participant']['name']))
    player_dict = dict(zip(player_id, player))
    
    matches_conn = http.client.HTTPSConnection("api.challonge.com")
    payload = ''
    headers = {

    }
    tournament_address_matches = "/v1/tournaments/91d510368cb4170cd5ac3776-{}_2024_TE4/matches.json?api_key={}&subdomain=91d510368cb4170cd5ac3776".format(tournament, os.environ.get('CHALLONGE_API_KEY', ''))
    matches_conn.request("GET", tournament_address_matches , payload, headers)
    matches_res =  matches_conn.getresponse()
    _increment_challonge_counter("nextweek: current tournament matches")
    matches_data =  matches_res.read()
    matches  = json.loads(matches_data.decode("utf-8"))
   # matchscores = []
    loser = []
    winners = []
    rounds = []
    rounds_text = []
    player_dict = dict(zip(player_id, player))
    for i in matches:
    #print(re.sub(r'\(.*?\)\ *', '', i['matches']['name']))
    #print(i['player1_id'])
    
        #print(player_dict[str(i['match']['winner_id'])])
       # print(i['match']['scores_csv'])
        #print(player_dict[str(i['match']['loser_id'])])
        #print("Round", i['match']['round'])
        winners.append(player_dict[str(i['match']['winner_id'])])
        loser.append(player_dict[str(i['match']['loser_id'])])
        #matchscores.append(i['match']['scores_csv'])
        rounds.append(i['match']['round'])
    
        rounds_text.append(challonge_scrape(tournament)[i['match']['round']])
    #matchscores.append(["winner"])
    winners.append("winner")
    winner = list(set(player)-set(loser))[0]
    winner_round = rounds[-1]+1
    loser.append(winner)
    rounds_text.append(challonge_scrape(tournament)[winner_round])
    results = pd.DataFrame()
    results["Player"] = loser
    results["Round"] = rounds_text
    results.iloc[-1]["Player"] = winner
   # results["Score"] = matchscores
    results["Winner"] = winners
    results.to_csv('{}_results.csv'.format(tournament))
    await channel.send('{} Results'.format(tournament), file=discord.File('{}_results.csv'.format(tournament)))
    await channel.send('{} Entry List'.format(next_tournament), file=discord.File('{}_entrylist.csv'.format(next_tournament)))
    #await oserkos.send('{} Results'.format(tournament), file=discord.File('{}_results.csv'.format(tournament)))
    await djokorer.send('{} Results'.format(tournament), file=discord.File('{}_results.csv'.format(tournament)))
    #await oserkos.send('{} Entry List'.format(next_tournament), file=discord.File('{}_entrylist.csv'.format(next_tournament)))
    await djokorer.send('{} Entry List'.format(next_tournament), file=discord.File('{}_entrylist.csv'.format(next_tournament)))

wtsl_loop_task = None

# -------------------------------------
# TE4 LIVE SCORES SYSTEM (NO PINGS)
# -------------------------------------

def norm(s: str) -> str:
    return re.sub(r"\s+", " ", str(s)).strip().lower()

# Cache for WTSL rankings (refreshed every 5 minutes)
_wtsl_rankings_cache = {}
_wtsl_rankings_cache_ts = 0
WTSL_RANKINGS_CACHE_TTL = 300  # 5 minutes

async def fetch_wtsl_rankings():
    """Fetch ATP and WTA WTSL rankings for live-score Elo lookups."""
    global _wtsl_rankings_cache, _wtsl_rankings_cache_ts
    import time
    
    now = time.time()
    if _wtsl_rankings_cache and (now - _wtsl_rankings_cache_ts) < WTSL_RANKINGS_CACHE_TTL:
        return _wtsl_rankings_cache
    
    try:
        tour_slugs = ("TE4", "TE4_(F)")
        async with aiohttp.ClientSession() as session:
            rankings = {}
            for tour_slug in tour_slugs:
                url = (
                    "https://www.playwtsl.com/TE4/pages/"
                    f"rankings_fetch_list.php?tour={tour_slug}"
                )
                async with session.get(
                    url, timeout=aiohttp.ClientTimeout(total=15)
                ) as resp:
                    if resp.status != 200:
                        print(
                            f"[WTSL Rankings] {tour_slug} HTTP {resp.status}",
                            flush=True,
                        )
                        continue
                    html = await resp.text()

                for player_name, wtsl_elo in _parse_wtsl_elo_rankings(html).items():
                    # Keep the higher Elo when a display name exists in both
                    # tour ranking tables.
                    rankings[player_name] = max(
                        rankings.get(player_name, 0), wtsl_elo
                    )
        
        _wtsl_rankings_cache = rankings
        _wtsl_rankings_cache_ts = now
        print(
            f"[WTSL Rankings] Fetched ATP + WTA rankings for {len(rankings)} players",
            flush=True,
        )
        return rankings
    except Exception as e:
        print(f"[WTSL Rankings] Error fetching: {e}")
        return _wtsl_rankings_cache or {}


def _parse_wtsl_elo_rankings(html: str) -> dict[str, int]:
    """Extract player Elo values from one ATP or WTA rankings response."""
    rankings = {}
    soup = BeautifulSoup(html, "html.parser")
    for table in soup.find_all("table"):
        for row in table.find_all("tr"):
            cells = row.find_all("td")
            if len(cells) < 6:
                continue
            player_link = cells[2].find("a")
            if not player_link:
                continue
            player_name = player_link.get_text(strip=True)
            try:
                wtsl_elo = int(cells[5].get_text(strip=True))
            except (ValueError, IndexError):
                continue
            if player_name and wtsl_elo > 0:
                key = player_name.lower()
                rankings[key] = max(rankings.get(key, 0), wtsl_elo)
    return rankings

_wtsl_player_ids_cache = {}
_wtsl_player_ids_cache_ts = 0

async def fetch_wtsl_player_ids():
    """Fetch player name -> ID mapping from rankings page"""
    global _wtsl_player_ids_cache, _wtsl_player_ids_cache_ts
    now = time.time()
    if _wtsl_player_ids_cache and (now - _wtsl_player_ids_cache_ts) < WTSL_RANKINGS_CACHE_TTL:
        return _wtsl_player_ids_cache
    try:
        url = "https://www.playwtsl.com/TE4/pages/rankings_fetch_list.php?tour=TE4"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status != 200:
                    return _wtsl_player_ids_cache or {}
                html = await resp.text()
        soup = BeautifulSoup(html, 'html.parser')
        player_ids = {}
        tables = soup.find_all('table')
        for table in tables:
            rows = table.find_all('tr')
            for row in rows:
                cells = row.find_all('td')
                if len(cells) >= 6:
                    player_cell = cells[2]
                    player_link = player_cell.find('a')
                    if player_link:
                        player_name = player_link.get_text(strip=True)
                        href = player_link.get('href', '')
                        if 'player=' in href:
                            player_id = href.split('player=')[-1]
                            rank_cell = cells[0].get_text(strip=True)
                            points_cell = cells[3].get_text(strip=True)
                            wtsl_elo_cell = cells[5].get_text(strip=True)
                            ingame_elo_cell = cells[6].get_text(strip=True) if len(cells) > 6 else ""
                            try:
                                rank_num = int(''.join(filter(str.isdigit, rank_cell))) if rank_cell else 99999
                            except (ValueError, TypeError):
                                rank_num = 99999
                            key = player_name.lower()
                            existing_info = player_ids.get(f"_info_{key}", {})
                            try:
                                existing_rank = int(''.join(filter(str.isdigit, str(existing_info.get('rank', '99999'))))) if existing_info else 99999
                            except (ValueError, TypeError):
                                existing_rank = 99999
                            if rank_num < existing_rank:
                                player_ids[key] = player_id
                                player_ids[f"_info_{key}"] = {
                                    "rank": rank_cell,
                                    "points": points_cell,
                                    "wtsl_elo": wtsl_elo_cell,
                                    "ingame_elo": ingame_elo_cell
                                }
        _wtsl_player_ids_cache = player_ids
        _wtsl_player_ids_cache_ts = now
        return player_ids
    except Exception as e:
        print(f"[WTSL Player IDs] Error: {e}")
        return _wtsl_player_ids_cache or {}

RANKINGS_WEEKLY_CHANNEL_ID = 804380564861485056
RANKINGS_REPLY_MESSAGE_ID  = 1335759065942462486
RANKINGS_GUILD_ID          = 786583939028090881

async def fetch_top20_rankings_data(
    tour: str = "TE4",
    limit: int | None = 20,
):
    """Fetch top 20 players from WTSL rankings for the given tour slug.
    Returns list of (rank, name, pts, race, wtsl_elo, ig_elo) sorted by rank.
    Column layout: [0]=rank [1]=flag [2]=player [3]=pts [4]=race [5]=wtsl_elo [6]=ig_elo
    """
    try:
        url = f"https://www.playwtsl.com/TE4/pages/rankings_fetch_list.php?tour={tour}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status != 200:
                    print(f"[Rankings Top20/{tour}] HTTP {resp.status}")
                    return None
                html = await resp.text()
        soup = BeautifulSoup(html, 'html.parser')
        rows = []
        for table in soup.find_all('table'):
            for row in table.find_all('tr'):
                cells = row.find_all('td')
                if len(cells) >= 6:
                    rank_text = cells[0].get_text(strip=True)
                    player_link = cells[2].find('a')
                    if not player_link:
                        continue
                    player_name = player_link.get_text(strip=True)
                    pts_text   = cells[3].get_text(strip=True)
                    race_text  = cells[4].get_text(strip=True) if len(cells) > 4 else ""
                    elo_text   = cells[5].get_text(strip=True)
                    ig_text    = cells[6].get_text(strip=True) if len(cells) > 6 else ""
                    try:
                        rank    = int(''.join(filter(str.isdigit, rank_text)))
                        pts     = int(''.join(filter(str.isdigit, pts_text)))   if pts_text   else 0
                        race    = int(''.join(filter(str.isdigit, race_text)))  if race_text  else 0
                        wtsl_elo= int(''.join(filter(str.isdigit, elo_text)))   if elo_text   else 0
                        ig_elo  = int(''.join(filter(str.isdigit, ig_text)))    if ig_text    else 0
                        if rank > 0 and player_name:
                            rows.append((rank, player_name, pts, race, wtsl_elo, ig_elo))
                    except (ValueError, TypeError):
                        continue
            if rows:
                break
        rows.sort(key=lambda x: x[0])
        return rows[:limit] if limit is not None else rows
    except Exception as e:
        print(f"[Rankings Top20/{tour}] Error: {e}")
        return None

def build_rankings_message(rows, label: str = "TE4", url: str = "", show_ig: bool = True):
    """Format top 20 rankings into a Discord code-block table."""
    from datetime import datetime as _dt
    date_str = _dt.utcnow().strftime("%d %B %Y")
    title = f"**[WTSL {label} Rankings \u2014 Top 20]({url})**" if url else f"**WTSL {label} Rankings \u2014 Top 20**"
    header = f"\U0001f3be {title} *(updated {date_str})*"
    if show_ig:
        lines = [
            f"{'#':<3}  {'Player':<20}  {'Pts':>6}  {'Race':>6}  {'ELO':>5}  {'In-Game Elo':>11}",
            "\u2500" * 58,
        ]
        for rank, name, pts, race, wtsl_elo, ig_elo in rows:
            lines.append(f"{rank:<3}  {name[:20]:<20}  {pts:>6}  {race:>6}  {wtsl_elo:>5}  {ig_elo:>11}")
    else:
        lines = [
            f"{'#':<3}  {'Player':<22}  {'Pts':>6}  {'Race':>6}  {'ELO':>5}",
            "\u2500" * 48,
        ]
        for rank, name, pts, race, wtsl_elo, ig_elo in rows:
            lines.append(f"{rank:<3}  {name[:22]:<22}  {pts:>6}  {race:>6}  {wtsl_elo:>5}")
    table = "```\n" + "\n".join(lines) + "\n```"
    return header + "\n" + table

# Comp Dubs first, WTA second, ATP last — so ATP is the most recent (top) message in the channel
# Each entry: (tour_slug, display_label, page_url, show_ig, reply_message_id_or_None)
RANKINGS_WEEKLY_TOURS = [
    ("TE4_CD",  "TE4 (Competitive Doubles)", "https://www.playwtsl.com/TE4/pages/rankings.php?tour=TE4_CD", False, RANKINGS_REPLY_MESSAGE_ID),
    ("TE4_(F)", "TE4 (WTA)",                "https://www.playwtsl.com/TE4/pages/rankings.php?tour=TE4_(F)", True,  RANKINGS_REPLY_MESSAGE_ID),
    ("TE4",     "TE4 (ATP)",                "https://www.playwtsl.com/TE4/pages/rankings.php?tour=TE4",      True,  RANKINGS_REPLY_MESSAGE_ID),
]

import os as _os
RANKINGS_PREV_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "rankings_prev_week.json")
RANKINGS_TODAY_POST_FLAG = _os.path.join(
    _os.path.dirname(_os.path.abspath(__file__)),
    ".rankings_today_post_done",
)


def _load_prev_rankings():
    """Load saved previous-week ranks. Returns {tour_slug: {player_name: rank}}."""
    try:
        with open(RANKINGS_PREV_FILE, "r") as f:
            raw = json.load(f)
        return {
            tour_slug: {
                normalize_matchlog_name(name): int(rank)
                for name, rank in ranks.items()
            }
            for tour_slug, ranks in raw.items()
            if isinstance(ranks, dict)
        }
    except Exception:
        return {}


def _save_prev_rankings(all_prev: dict):
    """Persist current week's ranks for next week's comparison."""
    try:
        with open(RANKINGS_PREV_FILE, "w") as f:
            json.dump(all_prev, f, indent=2)
        print(f"[Rankings Movers] Saved prev ranks for {list(all_prev.keys())}")
    except Exception as e:
        print(f"[Rankings Movers] Could not save prev ranks: {e}")


def _parse_published_rankings_message(content: str) -> dict[str, int]:
    """Extract player ranks from a previously posted Top 20 table."""
    parsed: dict[str, int] = {}
    in_table = False
    for raw_line in str(content or "").splitlines():
        line = raw_line.strip()
        if line.startswith("```"):
            in_table = not in_table
            continue
        if not in_table or not line or line.startswith("─"):
            continue
        parts = re.split(r"\s{2,}", line)
        if len(parts) < 2 or not parts[0].isdigit():
            continue
        name = parts[1].strip()
        if name:
            parsed[normalize_matchlog_name(name)] = int(parts[0])
    return parsed


async def _load_previous_published_rankings(channel) -> dict[str, dict[str, int]]:
    """Prefer the latest bot-posted ranking tables over stale local snapshots."""
    previous = _load_prev_rankings()
    from datetime import datetime as _dt, timezone as _tz, timedelta as _td

    now_utc = _dt.now(_tz.utc)
    current_week_start = (
        now_utc - _td(days=now_utc.weekday())
    ).replace(hour=0, minute=0, second=0, microsecond=0)
    labels = {
        tour_slug: label
        for tour_slug, label, *_ in RANKINGS_WEEKLY_TOURS
    }
    found: dict[str, dict[str, int]] = {}
    bot_user_id = getattr(getattr(client, "user", None), "id", None)
    try:
        async for message in channel.history(limit=200):
            if (
                bot_user_id is not None
                and getattr(getattr(message, "author", None), "id", None)
                != bot_user_id
            ):
                continue
            created_at = getattr(message, "created_at", None)
            if created_at is not None:
                if created_at.tzinfo is None:
                    created_at = created_at.replace(tzinfo=_tz.utc)
                if created_at >= current_week_start:
                    continue
            content = getattr(message, "content", "") or ""
            for tour_slug, label in labels.items():
                if tour_slug in found:
                    continue
                title = f"WTSL {label} Rankings — Top 20"
                if title not in content:
                    continue
                ranks = _parse_published_rankings_message(content)
                if ranks:
                    found[tour_slug] = ranks
    except Exception as exc:
        print(
            f"[Rankings Movers] Published-history lookup unavailable: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
    if found:
        previous = {**previous, **found}
        print(
            f"[Rankings Movers] Using published history for "
            f"{', '.join(sorted(found))}",
            flush=True,
        )
    return previous


def build_movers_embed(rows, prev_ranks: dict, label: str, page_url: str):
    """Build a discord.Embed showing top 5 biggest positive movers this week.
    prev_ranks: {player_name: prev_rank}  (empty dict = first run, no movers available)
    """
    if not prev_ranks:
        return None

    movers = []
    for rank, name, pts, race, wtsl_elo, ig_elo in rows:
        prev = prev_ranks.get(normalize_matchlog_name(name))
        if prev is not None and prev > rank:
            movers.append((prev - rank, name, prev, rank))

    if not movers:
        return None

    movers.sort(key=lambda x: (-x[0], x[3]))
    top = movers[:5]

    medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"]
    lines = []
    for i, (gain, name, was, now) in enumerate(top):
        lines.append(f"{medals[i]} **{name}** — +{gain} (#{was} → #{now})")

    embed = discord.Embed(
        title=f"📈 {label} — Movers of the Week",
        description="\n".join(lines),
        color=0x2ecc71,
        url=page_url,
    )
    return embed


async def _post_all_rankings(channel):
    """Post all three ranking tables plus movers-of-the-week to the channel."""
    all_prev = await _load_previous_published_rankings(channel)
    accumulated_prev = dict(all_prev)
    posted_ranks: dict[str, dict[str, int]] = {}

    for tour_slug, label, page_url, show_ig, reply_msg_id in RANKINGS_WEEKLY_TOURS:
        try:
            rows = await fetch_top20_rankings_data(tour_slug)
            if rows:
                msg = build_rankings_message(rows, label, page_url, show_ig)
                ref = discord.MessageReference(
                    message_id=reply_msg_id,
                    channel_id=RANKINGS_WEEKLY_CHANNEL_ID,
                    guild_id=RANKINGS_GUILD_ID,
                    fail_if_not_exists=False,
                ) if reply_msg_id else None
                await channel.send(msg, reference=ref)

                movers_embed = build_movers_embed(rows, all_prev.get(tour_slug, {}), label, page_url)
                if movers_embed:
                    await channel.send(embed=movers_embed)
                    print(f"[Rankings Weekly] Posted {label} movers embed")

                posted_ranks[tour_slug] = {
                    normalize_matchlog_name(name): rank
                    for rank, name, *_ in rows
                }
                print(f"[Rankings Weekly] Posted {label} top 20 ({len(rows)} players)")
            else:
                print(f"[Rankings Weekly] No data for {label}, skipping")
        except Exception as e:
            print(f"[Rankings Weekly] Error posting {label}: {e}")
        await asyncio.sleep(2)
    if posted_ranks:
        accumulated_prev.update(posted_ranks)
        _save_prev_rankings(accumulated_prev)
        return True
    return False
    try:
        leaderboard_channel = client.get_channel(WEEKLY_LEADERBOARD_CHANNEL_ID)
        if leaderboard_channel is None:
            leaderboard_channel = await client.fetch_channel(
                WEEKLY_LEADERBOARD_CHANNEL_ID
            )
        await _upsert_weekly_leaderboards(leaderboard_channel)
    except Exception as exc:
        print(
            f"[Leaderboard Weekly] Scheduled update failed: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )

async def weekly_rankings_loop():
    """Posts top 20 rankings every Monday at 00:00 GMT. Does NOT fire on startup."""
    from datetime import datetime as _dt, timezone as _tz, timedelta as _td
    await client.wait_until_ready()
    channel = client.get_channel(RANKINGS_WEEKLY_CHANNEL_ID)
    if channel is None:
        try:
            channel = await client.fetch_channel(RANKINGS_WEEKLY_CHANNEL_ID)
        except Exception as e:
            print(f"[Rankings Weekly] Could not fetch channel: {e}")
            return

    while not client.is_closed():
        now_utc = _dt.now(_tz.utc)
        days_ahead = (0 - now_utc.weekday()) % 7
        if days_ahead == 0:
            days_ahead = 7
        next_post = (now_utc + _td(days=days_ahead)).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        wait_secs = (next_post - now_utc).total_seconds()
        print(f"[Rankings Weekly] Next post in {wait_secs:.0f}s (at {next_post})")
        await asyncio.sleep(max(wait_secs, 1))

        weekly_results = await asyncio.gather(
            _post_all_rankings(channel),
            _post_weekly_leaderboards_now(),
            _post_wtsl_weekly_message_now(),
            return_exceptions=True,
        )
        for label, result in zip(
            ("rankings", "leaderboards", "betting message"),
            weekly_results,
        ):
            if isinstance(result, Exception):
                print(
                    f"[Weekly Update] {label} failed: "
                    f"{type(result).__name__}: {result}",
                    flush=True,
                )
        await asyncio.sleep(60)

async def _rankings_test_post():
    """Compatibility wrapper for a deliberate one-time rankings post."""
    await client.wait_until_ready()
    channel = client.get_channel(RANKINGS_WEEKLY_CHANNEL_ID)
    if channel is None:
        try:
            channel = await client.fetch_channel(RANKINGS_WEEKLY_CHANNEL_ID)
        except Exception as e:
            print(f"[Rankings Test] Could not fetch channel: {e}")
            return

    print("[Rankings Test] Firing one-time real rankings post...")
    posted = await _post_all_rankings(channel)
    if posted:
        with open(RANKINGS_TODAY_POST_FLAG, "w") as f:
            f.write("done")

async def fetch_player_profile_context(player_name, opponent_name=None):
    """Fetch player profile data for interview context"""
    try:
        player_ids = await fetch_wtsl_player_ids()
        player_id = player_ids.get(player_name.lower())
        if not player_id:
            return ""

        player_info = player_ids.get(f"_info_{player_name.lower()}", {})

        url = f"https://www.playwtsl.com/TE4/pages/player_page.php?player={player_id}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status != 200:
                    return ""
                html = await resp.text()

        soup = BeautifulSoup(html, 'html.parser')
        tables = soup.find_all('table')

        context_parts = []

        context_parts.append(f"WTSL Rank: #{player_info.get('rank', '?')}")
        context_parts.append(f"WTSL Points: {player_info.get('points', '?')}")
        context_parts.append(f"WTSL Elo: {player_info.get('wtsl_elo', '?')}")
        context_parts.append(f"In-game Elo: {player_info.get('ingame_elo', '?')}")

        # Table 3 = player info (Name, Coach, Joined, Nationality, Rank)
        if len(tables) > 3:
            info_table = tables[3]
            for row in info_table.find_all('tr'):
                cells = row.find_all('td')
                if len(cells) == 2:
                    key = cells[0].get_text(strip=True)
                    val = cells[1].get_text(strip=True)
                    if key in ['Joined', 'Nationality', 'Coach']:
                        context_parts.append(f"{key}: {val}")

        # Table 5 = recent match history
        if len(tables) > 5:
            history_table = tables[5]
            history_rows = history_table.find_all('tr')
            recent_matches = []
            h2h_matches = []
            for row in history_rows[1:]:
                cells = row.find_all('td')
                if len(cells) >= 5:
                    tournament = cells[1].get_text(strip=True) if len(cells) > 1 else ""
                    rnd = cells[2].get_text(strip=True) if len(cells) > 2 else ""
                    opp = cells[3].get_text(strip=True) if len(cells) > 3 else ""
                    date = cells[4].get_text(strip=True) if len(cells) > 4 else ""
                    result = cells[5].get_text(strip=True) if len(cells) > 5 else ""
                    match_str = f"{tournament} {rnd} vs {opp}: {result} ({date})"
                    if len(recent_matches) < 10:
                        recent_matches.append(match_str)
                    if opponent_name and opp.lower() == opponent_name.lower():
                        h2h_matches.append(match_str)

            if recent_matches:
                context_parts.append(f"\nRecent match history:\n" + "\n".join(recent_matches))
            if h2h_matches:
                context_parts.append(f"\nHead-to-head vs {opponent_name}:\n" + "\n".join(h2h_matches))

        return "\n".join(context_parts)
    except Exception as e:
        print(f"[Player Profile] Error fetching {player_name}: {e}")
        return ""

async def fetch_wtsl_elos_for_players(player_names):
    """Get WTSL Elo for a list of player names. Returns dict {player_name: elo}"""
    rankings = await fetch_wtsl_rankings()
    result = {}
    for name in player_names:
        name_lower = name.lower().strip()
        if name_lower in rankings:
            result[name] = rankings[name_lower]
    return result

def get_wtsl_elo_sync(player_name):
    """Synchronous lookup from cache (for use in embed building)"""
    name_lower = player_name.lower().strip()
    return _wtsl_rankings_cache.get(name_lower, 0)


# -------- Live Scores Settings --------

live_notice_message = None

LIVESCORE_CHANNEL_ID = 1464795893269139679
LIVESCORE_POLL_INTERVAL = 3
POST_MATCH_DISPLAY_SECONDS = 30

# Prevent Discord 429 from frequent edits
MIN_SECONDS_BETWEEN_EDITS = 30.0
_last_edit_ts = 0.0

LIVE_SCORE_FILTERS = {
    "wtsl": True,
    "xkt": True,
    "unknown": True,
}

match_state = {}


# -------- Helpers --------

def _hex_to_int(x: str) -> int:
    try:
        return int(str(x), 16)
    except:
        return 0

def _bits(value: int, offset: int, width: int) -> int:
    return (value >> offset) & ((1 << width) - 1)

def decode_gameinfo(gameinfo_hex: str) -> dict:
    gi = int(str(gameinfo_hex), 16)

    player_cfg = _bits(gi, 2, 3)
    nb_set     = _bits(gi, 5, 2)

    mode = {
        0: "Singles",
        2: "Competitive Doubles",
        3: "Cooperative Doubles",
    }.get(player_cfg, f"Mode({player_cfg})")

    best_of = {
        0: "Best of 1",
        1: "Best of 1",   # seen in the wild
        2: "Best of 3",
        3: "Best of 5",
    }.get(nb_set, "Best of 1")

    return {"mode": mode, "best_of": best_of}

def surface_icon(court):
    c = str(court).lower()
    if any(x in c for x in ["clay", "roland", "rg"]): return "🟧"
    if any(x in c for x in ["grass", "wimbledon"]): return "🟩"
    if any(x in c for x in ["indoor", "arena"]): return "🟪"
    if any(x in c for x in ["open", "ao", "us open"]): return "🟦"
    return "🎾"

def _short_court(court: str) -> str:
    return re.sub(r'^\s*\d+\s+', '', str(court)).strip() or "—"

def _pill(text: str) -> str:
    return f"`{text}`"

def extract_winner(score, players):
    try:
        sets = re.findall(r"(\d+)/(\d+)", str(score))
        p1_sets = sum(1 for a, b in sets if int(a) > int(b))
        p2_sets = sum(1 for a, b in sets if int(b) > int(a))
        if p1_sets > p2_sets: return players[0]
        if p2_sets > p1_sets: return players[1]
    except:
        pass
    return None

def _format_scoreline(score, flip=False):
    sets = re.findall(r"(\d+)/(\d+)", str(score))
    if flip:
        return " ".join([f"{b}-{a}" for a, b in sets])
    return " ".join([f"{a}-{b}" for a, b in sets])

def _winner_line(winner, p1, p2, score):
    winner = str(winner).strip()
    p1 = str(p1).strip()
    p2 = str(p2).strip()
    loser = p2 if winner == p1 else p1
    # Flip score to show from winner's perspective if winner is p2
    flip_score = (winner != p1)
    scoreline = _format_scoreline(score, flip=flip_score)
    return f"🏆 **{winner}** def **{loser}** {scoreline}".strip()


# -------- Parser --------

def parse_all_live_matches_livescore(poll_text):
    tokens = tokenize_poll_text(poll_text)
    blocks = split_into_blocks(tokens)
    matches = []
    now = time.time()

    for block in blocks:
        if len(block) < 14:
            continue

        i = 0
        ip = block[i][0]; i += 1
        port_hex = block[i][0]; i += 1

        if i >= len(block) or not block[i][1]:
            continue
        name = block[i][0]; i += 1

        if i + 3 >= len(block):
            continue
        gameinfo_hex = block[i][0]; i += 1
        maxping_hex  = block[i][0]; i += 1
        elo1_hex     = block[i][0]; i += 1
        nbgame_hex   = block[i][0]; i += 1

        if i >= len(block) or not block[i][1]:
            continue
        message = (block[i][0] or "").strip() or "Unknown"; i += 1

        if i >= len(block) or not block[i][1]:
            continue
        score = (block[i][0] or "").strip() or "—"; i += 1

        if i + 2 >= len(block):
            continue
        elo2_hex = block[i][0]; i += 1
        giveup_hex = block[i][0]; i += 1
        rep_hex = block[i][0]; i += 1

        if i >= len(block) or not block[i][1]:
            continue
        court = block[i][0]; i += 1

        if i >= len(block):
            continue
        creation_hex = block[i][0]; i += 1

        if " vs " not in str(name).lower():
            continue

        msg_lower = str(message).lower()
        is_wtsl = "xkt(wtsl)" in msg_lower
        is_xkt = ("xkt" in msg_lower) and not is_wtsl
        is_unknown = not is_wtsl and not is_xkt

        if is_wtsl and not LIVE_SCORE_FILTERS["wtsl"]:
            continue
        if is_xkt and not LIVE_SCORE_FILTERS["xkt"]:
            continue
        if is_unknown and not LIVE_SCORE_FILTERS["unknown"]:
            continue

        key = match_pair_key(name)
        players = [p.strip() for p in str(name).split("vs")]

        settings = decode_gameinfo(gameinfo_hex)

        state = match_state.get(key)
        if not state:
            match_state[key] = {
                "last_seen": now,
                "ended": False,
                "winner": None,
                "ended_at": None,
                "last_score": score,
                "last_players": players,
            }
        else:
            state["last_seen"] = now
            state["last_score"] = score
            state["last_players"] = players

        matches.append({
            "key": key,
            "players": players,
            "score": score,
            "court": court,
            "message": message,
            "elo1": _hex_to_int(elo1_hex),
            "elo2": _hex_to_int(elo2_hex),
            "mode": settings["mode"],
            "best_of": settings["best_of"],
        })

    final = []
    for key, state in list(match_state.items()):
        active = next((m for m in matches if m["key"] == key), None)

        if not active and not state["ended"]:
            state["ended"] = True
            state["ended_at"] = now

        if state["ended"] and now - state["ended_at"] > POST_MATCH_DISPLAY_SECONDS:
            del match_state[key]
            continue

        if active:
            w = extract_winner(active["score"], active["players"])
            if w:
                match_state[key]["winner"] = w
            final.append(active)
        else:
            w = state.get("winner")
            if w:
                final.append({"winner": w, "players": state["last_players"], "score": state["last_score"]})

    return final


# -------- Embed Builder --------

def build_livescore_embed_livescore(matches, wtsl_elos):
    updated = datetime.utcnow().strftime("%H:%M:%S UTC")

    finished = [m for m in matches if isinstance(m, dict) and m.get("winner")]
    live = [m for m in matches if isinstance(m, dict) and m.get("players")]

    def sort_key(m):
        msg = str(m.get("message", "")).lower()
        court = m.get("court") or ""
        if "xkt(wtsl)" in msg:
            return (0, _short_court(court))
        if "xkt" in msg:
            return (1, _short_court(court))
        return (2, _short_court(court))

    live.sort(key=sort_key)

    has_wtsl_live = any("xkt(wtsl)" in str(m.get("message", "")).lower() for m in live)

    embed = discord.Embed(
        title="🎾 TE4 Live Scores",
        color=0x39FF14 if has_wtsl_live else 0x2ECC71
    )

    if not live and not finished:
        embed.add_field(name="No activity", value="No live matches right now.", inline=False)
        return embed

    for m in live[:12]:
        players = m.get("players") or ["Unknown", "Unknown"]
        if len(players) < 2:
            players = (players + ["Unknown"])[:2]
        p1, p2 = players[0], players[1]

        court_raw = m.get("court") or "—"
        field = f"{surface_icon(court_raw)} 🟢 LIVE  •  {_short_court(court_raw)}"

        # Check if this is a WTSL match
        is_wtsl = "xkt(wtsl)" in str(m.get("message", "")).lower()
        
        ingame_elo1 = m.get('elo1', 0)
        ingame_elo2 = m.get('elo2', 0)
        
        if is_wtsl:
            # For WTSL matches, show both Game and Tour Elo
            wtsl_elo1 = get_wtsl_elo_sync(p1)
            wtsl_elo2 = get_wtsl_elo_sync(p2)
            
            if ingame_elo1 > 0 and wtsl_elo1 > 0:
                elo1_str = f"[Game: {ingame_elo1} | Tour: {wtsl_elo1}]"
            elif ingame_elo1 > 0:
                elo1_str = f"[Game: {ingame_elo1}]"
            elif wtsl_elo1 > 0:
                elo1_str = f"[Tour: {wtsl_elo1}]"
            else:
                elo1_str = ""
            
            if ingame_elo2 > 0 and wtsl_elo2 > 0:
                elo2_str = f"[Game: {ingame_elo2} | Tour: {wtsl_elo2}]"
            elif ingame_elo2 > 0:
                elo2_str = f"[Game: {ingame_elo2}]"
            elif wtsl_elo2 > 0:
                elo2_str = f"[Tour: {wtsl_elo2}]"
            else:
                elo2_str = ""
            
            player_line = f"**{p1}** {elo1_str} vs **{p2}** {elo2_str}"
        else:
            # For non-WTSL matches, show only in-game Elo
            player_line = f"**{p1}** ({ingame_elo1}) vs **{p2}** ({ingame_elo2})"

        value = (
            f"{player_line}\n"
            f"Score: `{m.get('score', '—')}`\n"
            f"Message: `{m.get('message', '—')}`\n"
            f"{_pill(m.get('mode', '—'))}  {_pill(m.get('best_of', '—'))}"
        )

        embed.add_field(name=field, value=value, inline=True)

    if finished:
        lines = []
        for m in finished[:8]:
            players = m.get("players") or ["Unknown", "Unknown"]
            if len(players) < 2:
                players = (players + ["Unknown"])[:2]
            p1, p2 = players[0], players[1]
            lines.append(_winner_line(m.get("winner", "Unknown"), p1, p2, m.get("score", "")))
        embed.add_field(name="Recently finished", value="\n".join(lines), inline=False)

    embed.set_footer(text=f"Online  •  {len(live)} Live  •  {len(finished)} Finished  •  Updated {updated}")
    return embed


# -------- Loop (rate-limit safe edits) --------

async def livescore_loop_separate():
    await client.wait_until_ready()
    channel = client.get_channel(LIVESCORE_CHANNEL_ID)
    if not channel:
        print("LiveScore channel not found")
        return

    message = None
    last_sig = None
    global live_notice_message, _last_edit_ts

    # On startup, find existing embeds/messages to reuse (avoid duplicates)
    try:
        found_embeds = []
        found_notices = []
        async for old_msg in channel.history(limit=50):
            if old_msg.author == client.user:
                if old_msg.content == "🎾 **Matches are now in progress**":
                    found_notices.append(old_msg)
                elif old_msg.embeds:
                    for e in old_msg.embeds:
                        if e.title and "TE4 Live Scores" in e.title:
                            found_embeds.append(old_msg)
                            break
        # Keep the most recent embed, delete any extras
        if found_embeds:
            message = found_embeds[0]
            for extra in found_embeds[1:]:
                try:
                    await extra.delete()
                except Exception:
                    pass
        # Keep the most recent notice, delete any extras
        if found_notices:
            live_notice_message = found_notices[0]
            for extra in found_notices[1:]:
                try:
                    await extra.delete()
                except Exception:
                    pass
        else:
            live_notice_message = None
    except Exception:
        pass

    connector = aiohttp.TCPConnector(limit=10, ttl_dns_cache=300)
    async with aiohttp.ClientSession(connector=connector) as session:
        while not client.is_closed():
            try:
                poll_text = await fetch_poll_text_with_retry(session, "https://www.managames.com/tennis/online/TE4_ServerList.php?Poll=1")

                matches = parse_all_live_matches_livescore(poll_text)
                embed = build_livescore_embed_livescore(matches, {})

                # IMPORTANT: Do NOT include description in signature (it has a live timestamp)
                sig = (
                    embed.title,
                    embed.color.value if embed.color else None,
                    tuple((f.name, f.value, f.inline) for f in embed.fields),
                )

                # Optional: live notice message create/delete (max 1 at a time)
                try:
                    if matches and live_notice_message is None:
                        live_notice_message = await channel.send("🎾 **Matches are now in progress**")
                    elif not matches and live_notice_message:
                        try:
                            await live_notice_message.delete()
                        except Exception:
                            pass
                        live_notice_message = None
                except discord.NotFound:
                    live_notice_message = None
                except Exception:
                    pass

                now = time.time()

                # Handle embed message
                try:
                    if message is None:
                        message = await channel.send(embed=embed)
                        last_sig = sig
                        _last_edit_ts = now
                    else:
                        if sig != last_sig and (now - _last_edit_ts) >= MIN_SECONDS_BETWEEN_EDITS:
                            try:
                                await asyncio.wait_for(
                                    message.edit(embed=embed),
                                    timeout=5,
                                )
                                last_sig = sig
                            except asyncio.TimeoutError:
                                print(
                                    "LiveScore: embed edit timed out; backing off",
                                    flush=True,
                                )
                            except discord.HTTPException as exc:
                                if getattr(exc, "status", None) == 429:
                                    print(
                                        "LiveScore: embed edit rate-limited; "
                                        "backing off",
                                        flush=True,
                                    )
                                else:
                                    raise
                            finally:
                                _last_edit_ts = now
                except discord.NotFound:
                    print("LiveScore: embed message was deleted, will create a new one next cycle")
                    message = None

            except Exception as e:
                print("LiveScore error:", repr(e))

            await asyncio.sleep(LIVESCORE_POLL_INTERVAL)


async def _support_watch_loop():
    """Every 3 minutes: if a non-staff message in any watched channel has gone unanswered
    for 10+ minutes, DM every admin and moderator once with a transcript snippet.
    Resets when staff reply comes in."""
    await client.wait_until_ready()
    ALERT_AFTER_SECS = 10 * 60
    CHECK_INTERVAL   = 3 * 60
    GUILD_ID         = 786583939028090881
    while not client.is_closed():
        await asyncio.sleep(CHECK_INTERVAL)
        try:
            guild = client.get_guild(GUILD_ID)
            if guild is None:
                continue
            admin_role = guild.get_role(ADMIN_ROLE_ID)
            mod_role   = guild.get_role(MODERATOR_ROLE_ID)
            recipients = {}
            for role in filter(None, [admin_role, mod_role]):
                for member in role.members:
                    if not member.bot:
                        recipients[member.id] = member

            for ch_id, ch_label in WATCHED_SUPPORT_CHANNELS.items():
                state = _support_watch[ch_id]
                pending_time = state["pending_msg_time"]
                alerted      = state["alerted"]
                msg_id       = state["pending_msg_id"]
                msg_content  = state["pending_msg_content"] or ""
                if not (pending_time and not alerted and (time.time() - pending_time) >= ALERT_AFTER_SECS):
                    continue

                msg_link = (
                    f"https://discord.com/channels/{GUILD_ID}/{ch_id}/{msg_id}"
                    if msg_id else f"https://discord.com/channels/{GUILD_ID}/{ch_id}"
                )
                elapsed_mins = int((time.time() - pending_time) / 60)
                transcript = f"> {msg_content}" if msg_content else ""
                dm_text = (
                    f"👋 **Heads up!** An unanswered message in **#{ch_label}** "
                    f"has been waiting {elapsed_mins} minutes:\n"
                    f"{msg_link}\n"
                    + (f"\n{transcript}\n" if transcript else "")
                    + f"\nCould someone take a look? 🙏"
                )
                for member in recipients.values():
                    try:
                        await member.send(dm_text)
                    except Exception as _dm_err:
                        print(f"[SupportWatch] Could not DM {member} ({member.id}): {_dm_err}")
                state["alerted"] = True
                print(f"[SupportWatch] Alerted {len(recipients)} staff about unanswered msg {msg_id} in #{ch_label}")

            # --- Contact-admins threads ---
            THREAD_ALERT_AFTER_SECS = 5 * 60  # 5 minutes for contact-admins threads
            for tid, state in list(_thread_watch.items()):
                pending_time = state["pending_msg_time"]
                alerted      = state["alerted"]
                msg_id       = state["pending_msg_id"]
                msg_content  = state["pending_msg_content"] or ""
                thread_name  = state.get("thread_name", "contact-admins thread")
                if not (pending_time and not alerted and (time.time() - pending_time) >= THREAD_ALERT_AFTER_SECS):
                    continue

                msg_link = (
                    f"https://discord.com/channels/{GUILD_ID}/{tid}/{msg_id}"
                    if msg_id else f"https://discord.com/channels/{GUILD_ID}/{tid}"
                )
                elapsed_mins = int((time.time() - pending_time) / 60)
                transcript = f"> {msg_content}" if msg_content else ""
                dm_text = (
                    f"👋 **Heads up!** An unanswered message in thread **{thread_name}** "
                    f"(contact-admins) has been waiting {elapsed_mins} minutes:\n"
                    f"{msg_link}\n"
                    + (f"\n{transcript}\n" if transcript else "")
                    + f"\nCould someone take a look? 🙏"
                )
                for member in recipients.values():
                    try:
                        await member.send(dm_text)
                    except Exception as _dm_err:
                        print(f"[SupportWatch] Could not DM {member} ({member.id}): {_dm_err}")
                state["alerted"] = True
                print(f"[SupportWatch] Alerted {len(recipients)} staff about unanswered msg in thread {thread_name}")
        except Exception as e:
            print(f"[SupportWatch] Loop error: {e}")


_LOSER_TEST_FLAG = ".loser_test_done"


async def _one_time_loser_catchup():
    """Fires once on startup to start the loser interview for a specific message."""
    if os.path.exists(_LOSER_TEST_FLAG):
        print("[Loser Test] Flag file found — skipping")
        return

    await asyncio.sleep(8)
    TARGET_MSG_ID = 1516218670228050072
    TE4_RESULTS_CHANNEL_ID = 801918765226917988
    try:
        channel = client.get_channel(TE4_RESULTS_CHANNEL_ID) or await client.fetch_channel(TE4_RESULTS_CHANNEL_ID)
        msg = await channel.fetch_message(TARGET_MSG_ID)
        print(f"[Loser Test] Fetched message: {msg.content[:80]!r}")
        ai_client = OpenAI(
            base_url=os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL"),
            api_key=os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY"),
        )
        await _try_trigger_interview(msg, ai_client, loser_only=True)
        print("[Loser Test] Loser interview triggered successfully")
    except Exception as e:
        print(f"[Loser Test] Error: {e}")

    with open(_LOSER_TEST_FLAG, "w") as f:
        f.write("done")
    print("[Loser Test] Flag file written — will not run again")


async def _one_time_rankings_post():
    """Post today's rankings once, then leave the Monday schedule unchanged."""
    if _os.path.exists(RANKINGS_TODAY_POST_FLAG):
        return
    await client.wait_until_ready()
    await asyncio.sleep(5)
    try:
        channel = client.get_channel(RANKINGS_WEEKLY_CHANNEL_ID)
        if channel is None:
            channel = await client.fetch_channel(RANKINGS_WEEKLY_CHANNEL_ID)
        posted = await _post_all_rankings(channel)
        if posted:
            with open(RANKINGS_TODAY_POST_FLAG, "w") as f:
                f.write("done")
            print("[Rankings One-Time] Today's rankings post complete", flush=True)
    except Exception as exc:
        print(
            f"[Rankings One-Time] Today's post failed: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )


async def _api_tally_loop():
    """Every 6 hours at clock boundaries (00:00, 06:00, 12:00, 18:00 UTC): DM the owner with
    the Challonge API call count for that window, then reset. Snaps to the next boundary so
    bot restarts don't delay or skip a send."""
    import datetime as _dt2
    WINDOW_HOURS = 6
    while True:
        try:
            # Sleep until the next 6-hour UTC boundary (00, 06, 12, 18)
            now_utc = _dt2.datetime.utcnow()
            current_window = (now_utc.hour // WINDOW_HOURS) * WINDOW_HOURS
            next_boundary = now_utc.replace(hour=current_window, minute=0, second=0, microsecond=0) \
                            + _dt2.timedelta(hours=WINDOW_HOURS)
            secs_until_next = (next_boundary - now_utc).total_seconds()
            print(f"[APITally] Next tally DM in {secs_until_next/3600:.1f}h at {next_boundary.strftime('%H:%M UTC')}")
            await asyncio.sleep(secs_until_next)

            global _challonge_api_calls, _challonge_api_call_date, _challonge_api_call_sources
            calls_window = _challonge_api_calls
            sources_window = dict(_challonge_api_call_sources)
            now_str = _dt2.datetime.utcnow().strftime("%H:%M UTC %d %b %Y")

            # Reset for next window and persist the cleared state
            _challonge_api_calls = 0
            _challonge_api_call_sources = {}
            _challonge_api_call_date = _dt2.date.today()
            _save_tally_to_disk()

            try:
                owner = await client.fetch_user(OWNER_ID)
                await owner.send(_build_tally_message(calls_window, sources_window, now_str, window_hours=WINDOW_HOURS))
                print(f"[APITally] Sent tally DM ({calls_window} calls this window)")
            except Exception as _dm_err:
                print(f"[APITally] Failed to DM owner: {_dm_err}")
        except Exception as e:
            print(f"[APITally] Loop error: {e}")
            await asyncio.sleep(60)


@client.event
async def on_ready():
    global _stats_workbook_promotion_started, _matchlog_rebuild_state
    if _matchlog_rebuild_state == "not_started":
        # Close the interaction-readiness gap before the first awaited startup
        # operation. The rebuild task later owns complete/failed transitions.
        _matchlog_rebuild_state = "running"
    print(f'{client.user} succesfully logged in!')

    if not getattr(client, "_wtsl_betting_started", False):
        client._wtsl_betting_started = True
        asyncio.create_task(_wtsl_betting_loop())
        print("[on_ready] wtsl_betting_loop started early")
    if not getattr(client, "_prediction_leaderboard_started", False):
        client._prediction_leaderboard_started = True
        asyncio.create_task(_prediction_leaderboard_loop())
        print("[on_ready] prediction_leaderboard_loop started")

    if not _stats_workbook_promotion_started:
        _stats_workbook_promotion_started = True
        try:
            promotion = await _activate_newer_statistics_workbook()
            if promotion:
                print(
                    "[Stats Workbook] activated "
                    f"{promotion['candidate'].name}; backup "
                    f"{promotion['backup'].name}; rows {promotion['rows']}",
                    flush=True,
                )
        except Exception as exc:
            print(
                "[Stats Workbook] newer upload rejected; active workbook "
                f"unchanged: {exc}",
                flush=True,
            )

    # Sync slash commands
    try:
        synced = await client.tree.sync()
        print(f"[on_ready] Synced {len(synced)} slash command(s)")
    except Exception as e:
        print(f"[on_ready] Failed to sync slash commands: {e}")
    try:
        # Global application-command updates can take time to propagate. Keep
        # the configured WTSL server responsive immediately after a restart.
        preview_guild = discord.Object(id=786583939028090881)
        client.tree.copy_global_to(guild=preview_guild)
        guild_synced = await client.tree.sync(guild=preview_guild)
        print(
            f"[on_ready] Synced {len(guild_synced)} guild slash command(s) "
            "for the WTSL server"
        )
    except Exception as e:
        print(f"[on_ready] Failed to sync guild slash commands: {e}")

    if not getattr(client, "_wtsl_verification_panel_started", False):
        client._wtsl_verification_panel_started = True
        asyncio.create_task(_upsert_wtsl_verification_panel())
        print("[on_ready] WTSL verification request panel queued")

    try:
        start_wtsl_system_once()  # starts BOTH WTSL alert + live score loops safely
    except Exception as e:
        print("Failed to start WTSL system:", repr(e))

    global _interview_expiry_started, _interview_recovery_started
    if not _interview_expiry_started:
        _interview_expiry_started = True
        client.loop.create_task(_close_expired_interviews())
        print("[on_ready] Interview expiry task started.")
    if not _interview_recovery_started:
        _interview_recovery_started = True
        client.loop.create_task(_recover_interviews_after_restart())
        print("[on_ready] Recent interview recovery queued.")

    # DM notification with error handling
    try:
        djokorer = await client.fetch_user(859691230941282304)
        await djokorer.send('bot has started')
        print("[on_ready] DM sent to djokorer")
    except Exception as e:
        print(f"[on_ready] Failed to DM djokorer: {e}")

    # Your separate TE4 live score system (only start once)
    if not getattr(client, "_livescore_started", False):
        client._livescore_started = True
        try:
            client.loop.create_task(livescore_loop_separate())
            print("[on_ready] livescore_loop_separate started")
        except Exception as e:
            print(f"[on_ready] Failed to start livescore_loop_separate: {e}")

    # Start latestresults once
    if not getattr(client, "latestresults_started", False):
        client.latestresults_started = True
        try:
            client.loop.create_task(latestresults())
            print("[on_ready] latestresults started")
        except Exception as e:
            print(f"[on_ready] Failed to start latestresults: {e}")

    # Weekly rankings (Monday 00:00 GMT only — no auto-fire on startup)
    if not getattr(client, "_rankings_weekly_started", False):
        client._rankings_weekly_started = True
        try:
            client.loop.create_task(weekly_rankings_loop())
            print("[on_ready] weekly_rankings_loop started")
        except Exception as e:
            print(f"[on_ready] Failed to start weekly_rankings_loop: {e}")
    if not getattr(client, "_weekly_leaderboards_initial_started", False):
        client._weekly_leaderboards_initial_started = True
        asyncio.create_task(_post_weekly_leaderboards_after_startup())
        print("[on_ready] initial weekly leaderboard update queued")

    asyncio.create_task(_one_time_loser_catchup())
    if not getattr(client, "_stats_daily_catchup_started", False):
        client._stats_daily_catchup_started = True
        asyncio.create_task(_stats_daily_catchup_loop())
        print("[on_ready] stats_daily_catchup_loop queued")
    if not getattr(client, "_stats_delivery_started", False):
        client._stats_delivery_started = True
        asyncio.create_task(_stats_workbook_delivery_loop())
        print("[on_ready] stats_workbook_delivery_loop queued")
    asyncio.create_task(_one_time_stats_scrape_test())
    print("[on_ready] one_time_stats_workbook_test queued")
    if not getattr(client, "_matchlog_rebuild_started", False):
        client._matchlog_rebuild_started = True
        asyncio.create_task(_matchlog_startup_rebuild())
        print("[on_ready] matchlog_startup_rebuild queued")
    asyncio.create_task(_support_watch_loop())
    print("[on_ready] support_watch_loop started")

    # Send one-time startup tally DM
    try:
        _owner_user = await client.fetch_user(OWNER_ID)
        _test_date_str = _challonge_api_call_date.strftime("%A %d %B %Y")
        _partial_note = (
            "\n✅ *Count restored from disk — full day total.*"
            if _tally_loaded_from_disk else
            "\n⚠️ *No saved data found for today — count starts from this restart.*"
        )
        await _owner_user.send(
            _build_tally_message(_challonge_api_calls, dict(_challonge_api_call_sources), _test_date_str, is_test=True)
            + _partial_note
        )
        print("[on_ready] Sent startup API tally DM")
    except Exception as e:
        print(f"[on_ready] Failed to send tally test DM: {e}")

    if not getattr(client, "_api_tally_loop_started", False):
        client._api_tally_loop_started = True
        asyncio.create_task(_api_tally_loop())
        print("[on_ready] api_tally_loop started")

    asyncio.create_task(_one_time_rankings_post())
    print("[on_ready] one_time_rankings_post queued")
    if not getattr(client, "_outreach_startup_scheduled", False):
        client._outreach_startup_scheduled = True
        asyncio.create_task(_safe_start_fixture_outreach())
    if not getattr(client, "_deadline_reminder_startup_scheduled", False):
        client._deadline_reminder_startup_scheduled = True
        asyncio.create_task(_start_deadline_reminders())
    if not getattr(client, "_match_scheduler_startup_scheduled", False):
        client._match_scheduler_startup_scheduled = True
        asyncio.create_task(_start_match_scheduler())


# === Latest results (every minute) – Challonge parity with dailyresults ===
# Uses your existing key + subdomain + channel + user IDs
# - Polls in-progress tournaments
# - Maps participant IDs to names (same regex cleanup)
# - Filters matches completed "today"
# - Converts special scores (Walkover / Coin Toss / BCT)
# - De-duplicates using posted_matches.json
# - Prints to console, DMs you, and posts to your channel

import asyncio
import http.client
import json
import re
from datetime import datetime, date

POSTED_FILE = "posted_matches.json"
CHALLONGE_HOST = "api.challonge.com"
CHALLONGE_KEY  = "1gHbUuGSI8eYsIaczCSjqY8q7zrqsvQEB5pRAixJ"
CHALLONGE_SUB  = "91d510368cb4170cd5ac3776"
LATESTRESULTS_POLL_INTERVAL = 60  # seconds — scraping WTSL page, no API quota concern

RESULTS_CHANNEL_ID = 1247808036911714314
DM_USER_ID         = 859691230941282304  # you (djokorer)

# --- Challonge API call tally (resets at midnight UTC each day, persisted to disk) ---
import datetime as _dt
import json as _json

_TALLY_FILE = "challonge_tally.json"
_challonge_api_calls: int = 0
_challonge_api_call_date: _dt.date = _dt.date.today()
_challonge_api_call_sources: dict = {}  # source label -> count today
_tally_loaded_from_disk: bool = False  # True if today's count was restored on startup

def _load_tally_from_disk():
    """On startup, restore today's running total from disk so restarts don't wipe the count."""
    global _challonge_api_calls, _challonge_api_call_date, _challonge_api_call_sources, _tally_loaded_from_disk
    try:
        with open(_TALLY_FILE, "r") as f:
            data = _json.load(f)
        saved_date = _dt.date.fromisoformat(data.get("date", ""))
        if saved_date == _dt.date.today():
            _challonge_api_calls = data.get("total", 0)
            _challonge_api_call_sources = data.get("sources", {})
            _challonge_api_call_date = saved_date
            _tally_loaded_from_disk = True
            print(f"[APITally] Restored today's count from disk: {_challonge_api_calls} calls")
    except Exception:
        pass  # no file or bad data — start fresh

def _save_tally_to_disk():
    """Persist the current counter to disk so bot restarts don't lose today's total."""
    try:
        with open(_TALLY_FILE, "w") as f:
            _json.dump({
                "date": _challonge_api_call_date.isoformat(),
                "total": _challonge_api_calls,
                "sources": _challonge_api_call_sources,
            }, f)
    except Exception:
        pass

_load_tally_from_disk()

def _increment_challonge_counter(source: str = "unknown"):
    global _challonge_api_calls, _challonge_api_call_date, _challonge_api_call_sources
    today = _dt.date.today()
    if today != _challonge_api_call_date:
        _challonge_api_calls = 0
        _challonge_api_call_sources = {}
        _challonge_api_call_date = today
    _challonge_api_calls += 1
    _challonge_api_call_sources[source] = _challonge_api_call_sources.get(source, 0) + 1
    _save_tally_to_disk()

def _build_tally_message(calls_total: int, sources: dict, date_str: str, is_test: bool = False, window_hours: int = 6) -> str:
    windows_per_day = 24 // window_hours
    daily_proj = calls_total * windows_per_day
    monthly_proj = daily_proj * 30
    header = (
        f"📊 **Challonge API tally — test snapshot ({date_str})**"
        if is_test else
        f"📊 **Challonge API tally — last {window_hours}h ({date_str})**"
    )
    lines = [header, f"**Calls this window: {calls_total}**", "", "**Breakdown by source:**"]
    if sources:
        for src, cnt in sorted(sources.items(), key=lambda x: -x[1]):
            lines.append(f"• {src}: **{cnt}**")
    else:
        lines.append("• No calls recorded yet")
    lines += [
        "",
        f"Projected daily (×{windows_per_day}): **{daily_proj:,}**",
        f"Projected monthly (×{windows_per_day * 30}): **{monthly_proj:,}** / 10,000 cap",
        "",
        "⚙️ *Settings: poll every 30 min · stale filter 14 days · forced full-check once per day*",
    ]
    return "\n".join(lines)

def _http_json(path: str, source: str = "latestresults: unknown"):
    """GET Challonge JSON with basic error checks; returns (ok, data_or_msg)."""
    _increment_challonge_counter(source)
    conn = http.client.HTTPSConnection(CHALLONGE_HOST, timeout=30)
    conn.request("GET", path, headers={})
    res = conn.getresponse()
    raw = res.read()
    if res.status != 200:
        try:
            body = raw.decode("utf-8", "ignore")
        except Exception:
            body = "<decode-failed>"
        return False, f"HTTP {res.status}: {body[:300]}"
    try:
        return True, json.loads(raw.decode("utf-8"))
    except json.JSONDecodeError as e:
        return False, f"JSON decode error: {e}"

async def _http_json_async(path: str, source: str = "latestresults: unknown"):
    """Non-blocking wrapper — runs _http_json in a thread pool so the event loop never freezes."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _http_json, path, source)

def _clean_name(s: str) -> str:
    # same cleanup you use in dailyresults
    return re.sub(r"\(.*?\)\s*", "", s or "").strip()

def _score_normalize(csv_score: str) -> str:
    if csv_score == "0-0":
        return "Walkover"
    # coin-toss encodings you use
    if csv_score in ("0-9","9-0","1-8","8-1","2-7","7-2","3-6","6-3","4-5","5-4"):
        return f"Coin Toss {csv_score}"
    if csv_score in ("0-1","1-0"):
        return "BCT"
    return csv_score or ""
    
import asyncio
import json
import csv
import os
@tasks.loop(minutes = 1)
@client.listen()
async def latestresults():
    """Poll playwtsl.com for new match results and post them to Discord.

    On startup: fetches the page once, marks all currently visible results as
    already-seen so the bot doesn't replay history.  Then polls every 60 s and
    posts anything new that appears at the top of the results table.
    """
    from datetime import datetime, timezone

    WTSL_URL = "https://playwtsl.com/TE4/pages/all_results_fetch.php"

    # ── Channels ──────────────────────────────────────────────────────────────
    default_channel  = client.get_channel(RESULTS_CHANNEL_ID)
    topspin_channel  = client.get_channel(1412480433039605901)
    tiebreak_channel = client.get_channel(1412481630416932895)

    for attr, cid in [("default_channel", RESULTS_CHANNEL_ID),
                      ("topspin_channel",  1412480433039605901),
                      ("tiebreak_channel", 1412481630416932895)]:
        if locals()[attr] is None:
            try:
                locals()[attr]  # just to reference; reassign below
            except Exception:
                pass

    if default_channel is None:
        try:
            default_channel = await client.fetch_channel(RESULTS_CHANNEL_ID)
        except Exception:
            default_channel = None
    if topspin_channel is None:
        try:
            topspin_channel = await client.fetch_channel(1412480433039605901)
        except Exception:
            topspin_channel = None
    if tiebreak_channel is None:
        try:
            tiebreak_channel = await client.fetch_channel(1412481630416932895)
        except Exception:
            tiebreak_channel = None

    # ── Seen-result fingerprints (persisted across restarts) ──────────────────
    try:
        with open(POSTED_FILE, "r") as f:
            posted_matches = set(json.load(f))
    except Exception:
        posted_matches = set()

    # ── HTML parser ───────────────────────────────────────────────────────────
    def _parse_results(html: str) -> list:
        """Return list of result dicts from the WTSL all_results_fetch page."""
        import re
        # Results table is always the 3rd <table> on the page (index 2)
        tables = re.findall(r'<table[^>]*>(.*?)</table>', html, re.DOTALL)
        if len(tables) < 3:
            return []
        rows = re.findall(r'<tr>(.*?)</tr>', tables[2], re.DOTALL)
        out = []
        for row in rows:
            cells = re.findall(r'<td[^>]*>(.*?)</td>', row, re.DOTALL)
            if len(cells) < 4:
                continue
            tourn = re.sub(r'<[^>]+>', '', cells[0]).strip()
            tour  = re.sub(r'<[^>]+>', '', cells[1]).strip()
            players = re.findall(r'<a[^>]+>([^<]+)</a>', cells[2])
            score = re.sub(r'<[^>]+>', '', cells[3]).strip()
            if len(players) < 2 or not tourn or not score:
                continue
            p1, p2 = players[0].strip(), players[1].strip()
            out.append({
                "tournament": tourn,
                "tour":       tour,
                "p1":         p1,
                "p2":         p2,
                "score":      score,
                "fp":         f"{tourn}|{p1}|{p2}|{score}",
            })
        return out

    # ── Seed step: mark everything currently on the page as already-seen ──────
    print("[latestresults] Fetching WTSL page to seed seen-results...")
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(WTSL_URL, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                if resp.status == 200:
                    seed_results = _parse_results(await resp.text())
                    added = sum(1 for r in seed_results if r["fp"] not in posted_matches)
                    for r in seed_results:
                        posted_matches.add(r["fp"])
                    with open(POSTED_FILE, "w") as f:
                        json.dump(list(posted_matches), f)
                    print(f"[latestresults] Seeded {added} new fingerprints "
                          f"({len(seed_results)} results on page). Polling every 60 s.")
                else:
                    print(f"[latestresults] Seed fetch returned {resp.status} — continuing anyway")
    except Exception as e:
        print(f"[latestresults] Seed fetch error: {e} — continuing anyway")

    # ── Poll loop ─────────────────────────────────────────────────────────────
    while True:
        await asyncio.sleep(LATESTRESULTS_POLL_INTERVAL)
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(WTSL_URL, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                    if resp.status != 200:
                        print(f"[latestresults] page returned {resp.status}")
                        continue
                    results = _parse_results(await resp.text())

            new_results = [r for r in results if r["fp"] not in posted_matches]
            if not new_results:
                continue

            # Page lists newest-first; reverse so we post in chronological order
            new_results.reverse()

            now = datetime.now(timezone.utc)
            suffix = lambda d: "th" if 11 <= d <= 13 else {1: "st", 2: "nd", 3: "rd"}.get(d % 10, "th")
            short_date = now.strftime(f"%a {now.day}{suffix(now.day)} %B %Y -")

            new_messages  = []
            new_csv_rows  = []

            for r in new_results:
                posted_matches.add(r["fp"])
                t_name = r["tournament"]
                p1, p2, score = r["p1"], r["p2"], r["score"]
                line = f"{short_date} {t_name}, {p1} vs {p2}, {score}"
                print(f"[latestresults] NEW: {line}")
                new_messages.append((t_name, line))
                new_csv_rows.append({
                    "Date":       now.strftime(f"%a {now.day}{suffix(now.day)} %B %Y"),
                    "Tournament": t_name,
                    "Player 1":   p1,
                    "Player 2":   p2,
                    "Score":      score,
                })

            # Persist fingerprints
            try:
                with open(POSTED_FILE, "w") as f:
                    json.dump(list(posted_matches), f)
            except Exception as e:
                print(f"[latestresults] failed to write {POSTED_FILE}: {e}")

            # Append to CSV
            if new_csv_rows:
                try:
                    file_exists = os.path.isfile("posted_results.csv")
                    with open("posted_results.csv", "a", newline='') as csvfile:
                        writer = csv.DictWriter(
                            csvfile,
                            fieldnames=["Date", "Tournament", "Player 1", "Player 2", "Score"]
                        )
                        if not file_exists:
                            writer.writeheader()
                        writer.writerows(new_csv_rows)
                except Exception as e:
                    print(f"[latestresults] failed to write posted_results.csv: {e}")

            # DM owner
            try:
                me = await client.fetch_user(DM_USER_ID)
                for _, msg in new_messages:
                    await me.send(msg)
            except Exception as e:
                print(f"[latestresults] DM error: {e}")

            # Post to channel
            for t_name, msg in new_messages:
                try:
                    if "TopSpin 2K25" in t_name and topspin_channel:
                        await topspin_channel.send(msg)
                    elif "Tiebreak" in t_name and tiebreak_channel:
                        await tiebreak_channel.send(msg)
                    elif default_channel:
                        await default_channel.send(msg)
                except Exception as e:
                    print(f"[latestresults] channel post error: {e}")

        except Exception as outer:
            print(f"[latestresults] poll error: {outer}")


# every minute


#async def today():
    # this code will be executed every 10 seconds after the bot is ready
#@client.listen()

#now = datetime.datetime.now() 
#@client.command(pass_context = True) 


#@client.listen()
#async def dailyresults():
#    import datetime
#    now = datetime.datetime.now()
#    djokorer = await client.fetch_user(859691230941282304)
#    if now.hour == 22 and now.minute == 59:
#        #await djokorer.send(now.hour)
#        djokorer = await client.fetch_user(859691230941282304)
#        oserkos = await client.fetch_user(694626703376384081)
        #print("{}{}".format(tournament, next_tournament))
        #await ctx.message.delete()
#        channel = client.get_channel(1247808036911714314) 
#        builds_channel = client.get_channel(1249495403909484715) 
#        tournaments = ['Auckland', 'Brisbane', 'Madrid',       'Rome', 'Roland_Garros',        'Queens',       'Halle',        'Hertogenbosch',        'Stuttgart',    'Eastbourne',   'Newport',      'Summer Cup',   'Wimbledon',    'Hamburg',      'Gstaad',       'Atlanta',      'Washington',   'Acapulco',     'Toronto',      'Montreal',     'Cincinnati',   'US_Open',      'Moselle', 'Wuhan', 'Astana', 'Beijing', 'Tokyo',       'Shanghai', 'Chengdu',  'Shenzen',      'Winston_Salem',        'Antwerp',      'Moscow',       'Vienna',       'Basel',        'Paris',        'Stockholm',    'Doha', 'Sydney', 'Adelaide',   'Australian_Open',      'Montpellier',  'Cordoba', 'Dallas',    'Marseille',    'Buenos_Aires', 'Rotterdam',    'Dubai', 'Rio', 'Indian_Wells', 'Miami',        'Kitzbuhel',    'Houston',      'Monte_Carlo',  'Barcelona',    'Munich',       'Belgrade',     'Marrakech',    'Delray_Beach', 'Nice', 'Estoril',      'Geneva', 'Lyon','World_Tour_Finals',   'Next_Gen_Finals', 'Warm_Up_I', 'Warm_Up_II', 'Mallorca', 'Olympics', 'Rafa_Nadal', 'Rosario', 'Bahrain', 'Qatar', 'Sumter']

#        categories = ['250', '250', '1000',    '1000', '2000', '500',  '500',  '250',  '250',  '250',  '250',  '250',  '2000', '500',  '250',  '500',  '500',  '500',  '1000', '1000', '1000', '2000', '250', '250', '250', '500', '500', '1000', '250',       '250',  '250',  '250',  '250',  '500',  '500',  '1000', '250',  '250',  '250',  '250',  '2000', '250', '250',   '250', '250',   '250',  '500',  '500',  '500',  '1000', '1000', '250',  '250',  '1000', '500',  '250',  '250',  '250',  '250',  '250',  '250',  '250',  '250', '1500',  '300', '250', '250', '250','250', '125', '125', '125','1000', '175']

    #categories = ['1000', '1000', '2000', '500', '250', '250', '2000', '500', '500', '500', '1000']

     #   rounds = ['W', 'F', 'SF', 'QF', 'R16', 'R32', 'R64', 'First Round','Q', 'na']
      #  finalsrounds = ['W', 'W1L', 'W2L', 'F', 'F1L', 'F2L', 'SF', 'SF1L', 'SF2L', 'G1L', 'G2L', 'G3L', 'na']
        #slams = [2000, 1300, 800, 400, 200, 100, 50, 50, 10, 0]
       # slam_rounds = ['W', 'F', 'SF', 'QF', 'R16', 'R32', 'First Round','Q', 'na']
       # masters_rounds = ['W', 'F', 'SF', 'QF', 'R16', 'First Round','Q', 'na']
        #fivehundred_rounds = ['W', 'F', 'SF', 'QF', 'R16', 'First Round','Q', 'na']
        #twofifty_rounds = ['W', 'F', 'SF', 'QF', 'First Round','Q', 'na']
        #onetwofive_rounds = ['W', 'F', 'SF', 'QF', 'First Round','Q', 'na']
        #slams_id = [6, 5, 4, 3, 2, 1, 0, 0, 0]
        #masters_id = [6, 5, 4, 3, 2, 1, 0, 0]
        #fivehundred_id = [6, 5, 4, 3, 2, 1, 0, 0]
        #twofifty_id = [5, 4, 3, 2, 1, 0, 0]
        #twofifty_id = [6, 5, 4, 3, 2, 1, 1]
        #onetwofive_id = [6, 5, 4, 3, 2, 1, 1]
        #def challonge_scrape(tournament_name):
         #   dict = {}
        #    for i, j in enumerate(zip(tournaments, categories)):
         #       dict[tournaments[i]]= categories[i]
         #   if dict[tournament_name] == '2000':
         #       slamsdict = {}
         #       for i, j in enumerate(zip(slams_id, slam_rounds)):
                  #slamsdict[slams_id[i]]= slam_rounds[i]
               # return slamsdict
           # elif dict[tournament_name] == '1000':
               # mastersdict = {}
               # for i, j in enumerate(zip(masters_id, masters_rounds)):
                #    mastersdict[masters_id[i]]= masters_rounds[i]
               # return mastersdict
           # elif dict[tournament_name] == '500':
               # fivehundreddict = {}
               # for i, j in enumerate(zip(fivehundred_id, fivehundred_rounds)):
              #      fivehundreddict[fivehundred_id[i]]= fivehundred_rounds[i]
             #   return fivehundreddict
           # elif dict[tournament_name] == '250':
               # twofiftydict = {}
               # for i, j in enumerate(zip(twofifty_id, twofifty_rounds)):
               #     twofiftydict[twofifty_id[i]]= twofifty_rounds[i]
              #  return twofiftydict
           # elif dict[tournament_name] == '125':
               # onetwofivedict = {}
               # for i, j in enumerate(zip(onetwofive_id, onetwofive_rounds)):
               #     onetwofivedict[onetwofive_id[i]]= onetwofive_rounds[i]
               # return onetwofivedict
       # djokorer = await client.fetch_user(859691230941282304)
        #import pandas as pd
       # import http.client
        #import json
        #import re
        #challonge_conn = http.client.HTTPSConnection("api.challonge.com")
       # payload = ''
       # headers = {

       # }
       # tournamentlist = "/v1/tournaments.json?api_key=1gHbUuGSI8eYsIaczCSjqY8q7zrqsvQEB5pRAixJ&subdomain=91d510368cb4170cd5ac3776&state=in_progress"
       # challonge_conn.request("GET", tournamentlist , payload, headers)
       # challonge_res = challonge_conn.getresponse()
       # challonge_data = challonge_res.read()
        #nextweek = json.load(open(nextweek_data))
       # challonge  = json.loads(challonge_data.decode("utf-8"))
       # url = []
       # for i in challonge:
            #url.append(re.sub(r''', '', i['tournament']['url']))
       #     url.append(i['tournament']['url'].replace("'", ''))
       # await djokorer.send(url)
       # for i in url:
       #     participants_conn = http.client.HTTPSConnection("api.challonge.com")
       #     payload = ''
       #     headers = {
       #     }
       #     tournament_address = "/v1/tournaments/91d510368cb4170cd5ac3776-{}/participants.json?api_key=1gHbUuGSI8eYsIaczCSjqY8q7zrqsvQEB5pRAixJ&subdomain=91d510368cb4170cd5ac3776".format(i)
       #     participants_conn.request("GET", tournament_address , payload, headers)
       #     participants_res = participants_conn.getresponse()
       #     participants_data = participants_res.read()
       #     participants  = json.loads(participants_data.decode("utf-8"))

       #     player_id = []
       #     player = []
       #     for j in participants:
        #print(re.sub(r'\(.*?\)\ *', '', i['participant']['name']))
        #print(i)
        #        player_id.append(str(j['participant']['id']))
         #       player.append(re.sub(r'\(.*?\)\ *', '', j['participant']['name']))
        #    print(str(i['participant']['id'])+"_"+re.sub(r'\(.*?\)\ *', '', i['participant']['name']))
         #   player_dict = dict(zip(player_id, player))
         #   await djokorer.send(player)
         #   matches_conn = http.client.HTTPSConnection("api.challonge.com")
         #   payload = ''
         #   headers = {

          #  }
           # tournament_address_matches = "/v1/tournaments/91d510368cb4170cd5ac3776-{}/matches.json?api_key=1gHbUuGSI8eYsIaczCSjqY8q7zrqsvQEB5pRAixJ&subdomain=91d510368cb4170cd5ac3776".format(i)
           # matches_conn.request("GET", tournament_address_matches , payload, headers)
           # matches_res =  matches_conn.getresponse()
           # matches_data =  matches_res.read()
           # matches  = json.loads(matches_data.decode("utf-8")) 

            
            #tournament = []
            #tournament.append(i)
           # attachments = []
           # matchscores = []
           # tournament = []
            #loser = []
            #winners = []
           # player1 = []
           # player2 = []
           # rounds = []
           # rounds_text = []
           # player_dict = dict(zip(player_id, player))
            #await djokorer.send(matches[0])
           # for k in matches:
            #    if k['match']['attachment_count'] == 2:
            #        attach_conn = http.client.HTTPSConnection("api.challonge.com")
            #        payload = ''
             #       headers = {

             #       }
             #       tournament_address_attach = "/v1/tournaments/91d510368cb4170cd5ac3776-{}/matches/{}/attachments.json?api_key=1gHbUuGSI8eYsIaczCSjqY8q7zrqsvQEB5pRAixJ&subdomain=91d510368cb4170cd5ac3776".format(i, k['match']['id'])
             #       attach_conn.request("GET", tournament_address_attach , payload, headers)
             #       attach_res =  attach_conn.getresponse()
             #       attach_data =  attach_res.read()
             #       attach  = json.loads(attach_data.decode("utf-8"))
                    #await djokorer.send(attach[0]['match_attachment'])
                    #await djokorer.send(attach[0])
              #      attachments.append(player_dict[str(k['match']['player1_id'])])
              #      attachments.append(player_dict[str(k['match']['player2_id'])])
              #      attachments.append(attach[0]['match_attachment']['asset_url'])
              #      attachments.append(attach[1]['match_attachment']['asset_url'])
        #print(re.sub(r'\(.*?\)\ *', '', i['matches']['name']))
        #print(i['player1_id'])

            #print(player_dict[str(i['match']['winner_id'])])
           # print(i['match']['scores_csv'])
            #print(player_dict[str(i['match']['loser_id'])])
            #print("Round", i['match']['round'])
                #from datetime import datetime, timedelta
                #if k['match']['state']=="complete":
                #    datetime_str = k['match']['completed_at']
                #    date_completed = datetime.fromisoformat(datetime_str.replace("Z", "+00:00"))
                #    date_completed = date_completed.strftime('%Y-%m-%d')
                    #await djokorer.send(date_completed)
                #else:
                   # date_completed = (datetime.now() + timedelta(1)).strftime('%Y-%m-%d')
                   # await djokorer.send(date_completed)
                   # if date_completed == date.today().strftime('%Y-%m-%d'):
                   #     try:
                            #winners.append(player_dict[str(k['match']['winner_id'])])
                            #loser.append(player_dict[str(k['match']['loser_id'])])
                      #      player1.append(player_dict[str(k['match']['player1_id'])])
                      #      player2.append(player_dict[str(k['match']['player2_id'])])
                            #loser.append(player_dict[str(k['match']['loser_id'])]
                            #if k['match']['scores_csv'] == '0-0':
                            #    matchscores.append('Walkover')
                           # elif k['match']['scores_csv'] in (['0-9', '9-0', '1-8', '8-1', '2-7', '7-2', '3-6', '6-3', '4-5', '5-4']):
                         #       matchscores.append('Coin Toss ' + k['match']['scores_csv'])
                          #  elif k['match']['scores_csv'] in (['0-1', '1-0']):
                          #      matchscores.append('BCT')
                          #  else:
                          #      matchscores.append(k['match']['scores_csv'])
                          #  rounds.append(k['match']['round'])
                         #   try:
                          #      try:
                          #          rounds_text.append(challonge_scrape(i[:-12])[k['match']['round']])
                            #rounds_text.append(challonge_scrape(tournament)[winner_round])
                          #          tournament.append(i[:-12].replace("_", ' '))
                          #      except:
                          ##          rounds_text.append(challonge_scrape(i[:-9])[k['match']
                          #                         ['round']])
                                #rounds_text.append(challonge_scrape(tournament)[winner_round])
                          #          tournament.append(i[:-9].replace("_", ' '))
                          #  except:
                          #      rounds_text.append(challonge_scrape(i[:-8])[k['match']
                          #             ['round']])
                                #rounds_text.append(challonge_scrape(tournament)[winner_round])
                          #      tournament.append(i[:-8].replace("_", ' '))
                           # await djokorer.send(rounds_text)
                            
                       # except:
                        #    pass 
               # loser.append(player_dict[str(k['match']['player2_id'])])
            #await djokorer.send(matchscores)
            #await djokorer.send(i[:-9].replace("_", ' '))
            #for k in matches, l in range(len(attachments)):
            #    if k['match']['attachment_count'] == 2:
            #        await djokorer.send('{} vs {}'.format(winner, loser))
            #        await djokorer.send('https:{}'.format(attachments[l]))
            #await builds_channel.send('{} vs {}'.format(attachments[0], attachments[1]))
            #for i in range(len(attachments[2:])):
            #    if "//" not in attachments[i+2]:
            #        await builds_channel.send(attachments[i+2])
            #    else:
            #        await builds_channel.send('https:{}'.format(attachments[i+2]))
                #rounds_text.append(challonge_scrape(tournament)[i['match']['round']])
            #matchscores.append(["winner"])
            #winners.append("winner")
            #winner = list(set(player)-set(loser))[0]
            #winner_round = rounds[-1]+1
            #loser.append(winner)
            
            #results = pd.DataFrame()
            #results['Tournament'] = tournament 
            #results["Winner"] = winners
            #results["Loser"] = loser
            #results["Player1"] = player1
            #results["Player2"] = player2
            #results["Round"] = rounds_text
            #results["Round"] = rounds_text
            #results.iloc[-1]["Player"] = winner
            #results["Score"] = matchscores
            #results['Result'] = 1
            #results['Scores'] = 1 
            #results.to_csv('daily results.csv')
            #results = pd.read_csv('daily results.csv')
            #results.rename(columns = {'0':'Date'}, inplace = True)
            #channel = client.get_channel(1247808036911714314)
            #for i in range(len(results)):
              #results['Result'].iloc[i]= results.iloc[i].Winner + ' d. ' + results.iloc[i].Loser
               # results['Result'].iloc[i]= results.iloc[i].Player1 + ' vs ' + results.iloc[i].Player2
              #results['Scores'].iloc[i] = results.iloc[i].Result + ':' +     results.iloc[i].Score
            #await channel.send('** 🎾 Results: {}**'.format(date.today().strftime('%A %d %B %Y')))
            #await djokorer.send('** 🎾 Results: {}**'.format(date.today().strftime('%A %d %B %Y')))
            #await channel.send('**{}**'.format(results[['Tournament', 'Round', 'Winner', 'Loser', 'Score']].columns.values))
            #headers = []
            #headers = results[['Tournament', 'Result', 'Score']]
            #headers = results[['Tournament', 'Round', 'Result', 'Score']]
                # for x, y in enumerate(results[['Tournament', 'Round', 'Result', 'Score']].values):
               # headers.append(str(x).replace("'", ""))
            #await channel.send(str(tuple(headers.columns)).replace("'","")[1:-1])
            #api_client.create_tweet(text=str(tuple(headers.columns)).replace("'","")[1:-1])
            #await channel.send(headers)
            #if results[['Tournament', 'Result', 'Score']].values.size == 0:
              #  pass

            #else:
                #api_client.create_tweet(text='🎾 Results: {}'.format(date.today().strftime('%A %d %B %Y')))
               # for x, y in enumerate(results[['Tournament', 'Result', 'Score']].values):
                #    await channel.send(str(tuple(y)).replace("'", "")[1:-1])

            #await djokorer.send('daily Results', file=discord.File('daily results.csv'))

    
@client.command(pass_context = True)  
async def ranking(ctx, latest_tournament_name, latest_tournament_name2):
    import rankings
    djokorer = await client.fetch_user(859691230941282304)
    barboza = await client.fetch_user(485273807360360448)
    channel = client.get_channel(828002769146478642)
    rank_channel = client.get_channel(804380564861485056)
    latest_tournament_csv = 'weeklyresults.csv'
    tournament_list_csv = '52weeks.csv'
    last_week_csv = 'rankingscsv.csv'
    elos_csv = 'elos.csv'
    print("{},{}".format(latest_tournament_name, latest_tournament_name2))
    #await ctx.message.delete()
    from rankings import ranks
    
    rank = ranks(latest_tournament_csv, latest_tournament_name, latest_tournament_name2, tournament_list_csv, last_week_csv, elos_csv)
    rank =pd.read_csv('rankings_update_{}.csv'.format(date.today().strftime('%d%m%y')))
    await djokorer.send('rankingscsv.csv', file=discord.File('rankings_update_{}.csv'.format(date.today().strftime('%d%m%y'))))
    await djokorer.send('52weeks.csv', file=discord.File('52weeks_tournaments_{}.csv'.format(date.today().strftime('%d%m%y'))))
    await djokorer.send('weeklyresults.csv', file=discord.File('weeklyresults.csv')) 
    await djokorer.send('elos.csv', file=discord.File('elos.csv'))
    #await djokorer.send('entrylisting.csv', file=discord.File('entrylisting.csv'))
    #await barboza.send('rankingscsv.csv', file=discord.File('rankings_update_{}.csv'.format(date.today().strftime('%d%m%y'))))
    #await barboza.send('52weeks.csv', file=discord.File('52weeks_tournaments_{}.csv'.format(date.today().strftime('%d%m%y'))))
    #await barboza.send('elos.csv', file=discord.File('elos.csv'))
    #await barboza.send('weeklyresults.csv', file=discord.File('weeklyresults.csv')) 
    #await djokorer.send('entrylisting.csv', file=discord.File('entrylisting.csv'))
    rank = rank.drop('name', 1)
    rank = rank[['Spots Moved','Rank','Player','Points', 'Elo', 'Race Points', 'Tournaments Played']]
    rank.Points = rank.Points.astype(int)
    #rank.to_csv('rankings_{}.csv'.format(date.today().strftime('%d%m%y')))
   
    #await ctx.send(rank.head(20))
#    await channel.send('**Top 20 Rankings Week of {}**'.format(date.today().strftime('%d%m%y')))
    await rank_channel.send('** Top 20 Rankings Week of {} https://t.co/f6TGfZ1Qhf**'.format(date.today().strftime('%d%m%y')))
#    await channel.send(str(tuple(rank.columns)).replace("'","")[1:-1])
    #https://t.co/zgu7XStIRZ
    await rank_channel.send(str(tuple(rank.columns)).replace("'","")[1:-1])
  
    for x, y in enumerate(np.array(rank[:20])):
  #      await channel.send(str(list(y)).replace("'","")[1:-1])
         await rank_channel.send(str(list(y)).replace("'","")[1:-1])
        #await ctx.send(rank)
      

@client.command(pass_context = True)  
async def bracketgen(ctx, tournament):
    print("{}".format(tournament))
    rankingcsv = 'rankingscsv.csv'
    entrylisting = 'entrylisting.csv'
    await ctx.message.delete()
    barboza = await client.fetch_user(485273807360360448)
    mystery = await client.fetch_user(787379133666557963)
    ptacek = await client.fetch_user(213224853686321152)
    djokorer = await client.fetch_user(859691230941282304)
    oserkos = await client.fetch_user(694626703376384081)
    admins = [djokorer, barboza, mystery, ptacek, oserkos]
    #admins = [djokorer]
    channel = client.get_channel(993896951508639764)
    from bracket import generator 
    generator = generator(rankingcsv,entrylisting)
    #await channel.send("**{} {}**".format(tournament,generator[0]))
    #await channel.send(generator[1])
    generator_init =[]
    for i in range(len(generator[3])):
      generator_init.append(generator[3][i])
    generator_init = pd.DataFrame(generator_init)
    await channel.send("**{} {}**".format(tournament,generator[1]))
    await channel.send("**{} {}**".format(tournament,generator[2]))
    for i in range(len(admins)):
      await admins[i].send("**{} {}**".format(tournament,generator[2]))
      await admins[i].send('**You can confirm the Draw is correct after its been posted by pasting input bracket list on https://challonge.com/tournament/bracket_generator/**')
    await channel.send(generator_init.to_string(index = False))
    for i in range(len(admins)):
      await admins[i].send(generator_init.to_string(header = False, index = False))

@client.command(pass_context = True)
async def announce(ctx, *, message):
    print("{}".format(message))
    await ctx.message.delete()
    await ctx.send(message)


TWITTER_ANNOUNCEMENT_STATE_PATH = Path("twitter_announcement_state.json")
_twitter_announcement_lock = asyncio.Lock()
try:
    ANNOUNCEMENTS_CHANNEL_ID = int(os.environ.get("ANNOUNCEMENTS_CHANNEL_ID", "0"))
except ValueError:
    ANNOUNCEMENTS_CHANNEL_ID = 0


def _twitter_announcement_state() -> dict[str, typing.Any]:
    try:
        state = json.loads(
            TWITTER_ANNOUNCEMENT_STATE_PATH.read_text(encoding="utf8")
        )
    except FileNotFoundError:
        return {"messages": {}}
    except (OSError, json.JSONDecodeError) as exc:
        print(f"[Twitter] announcement state unavailable: {exc}", flush=True)
        return {"messages": {}}
    if not isinstance(state, dict) or not isinstance(state.get("messages"), dict):
        return {"messages": {}}
    return state


def _save_twitter_announcement_state(state: dict[str, typing.Any]) -> None:
    temporary = TWITTER_ANNOUNCEMENT_STATE_PATH.with_suffix(".tmp")
    temporary.write_text(
        json.dumps(state, indent=2, sort_keys=True),
        encoding="utf8",
    )
    os.replace(temporary, TWITTER_ANNOUNCEMENT_STATE_PATH)


def _is_announcement_channel(channel) -> bool:
    channel_id = getattr(channel, "id", 0)
    if ANNOUNCEMENTS_CHANNEL_ID:
        return channel_id == ANNOUNCEMENTS_CHANNEL_ID
    name = str(getattr(channel, "name", "") or "").casefold()
    return "announcement" in re.sub(r"[^a-z]", "", name)


async def _post_twitter_announcement(
    content: str,
    *,
    attachments=(),
    source_url: str | None = None,
) -> dict[str, str]:
    """Post Discord announcement text and supported attachments to Twitter."""
    media_files: list[tuple[str, bytes]] = []
    attachment_urls: list[str] = []
    for attachment in attachments or ():
        url = str(getattr(attachment, "url", "") or "")
        filename = str(getattr(attachment, "filename", "attachment") or "attachment")
        content_type = getattr(attachment, "content_type", None)
        size = getattr(attachment, "size", None)
        if is_image_attachment(filename, content_type) and (
            not isinstance(size, int) or size <= 5 * 1024 * 1024
        ):
            try:
                data = await attachment.read()
                media_files.append((filename, data))
                continue
            except Exception as exc:
                print(
                    f"[Twitter] image download failed for {filename}: {exc}",
                    flush=True,
                )
        if url:
            attachment_urls.append(url)

    tweet_text = build_tweet_text(
        content,
        source_url=source_url,
        attachment_urls=attachment_urls,
    )
    poster = TwitterPoster()
    return await asyncio.to_thread(
        poster.post_sync,
        tweet_text,
        media_files,
    )


async def _mirror_announcement_to_twitter(message) -> None:
    """Mirror each announcement once, without blocking Discord message handling."""
    if getattr(getattr(message, "author", None), "bot", False):
        return
    async with _twitter_announcement_lock:
        state = _twitter_announcement_state()
        key = str(getattr(message, "id", ""))
        previous = state["messages"].get(key, {})
        if previous.get("status") == "posted":
            return
        try:
            result = await _post_twitter_announcement(
                getattr(message, "clean_content", None)
                or getattr(message, "content", ""),
                attachments=getattr(message, "attachments", ()),
                source_url=getattr(message, "jump_url", None),
            )
        except TwitterConfigurationError as exc:
            print(f"[Twitter] announcement mirror skipped: {exc}", flush=True)
            return
        except Exception as exc:
            state["messages"][key] = {
                "status": "failed",
                "error": str(exc)[:500],
            }
            _save_twitter_announcement_state(state)
            print(f"[Twitter] announcement mirror failed: {exc}", flush=True)
            return
        state["messages"][key] = {
            "status": "posted",
            "tweet_id": result["id"],
            "tweet_url": result["url"],
            "posted_at": datetime.now(timezone.utc).isoformat(),
        }
        _save_twitter_announcement_state(state)
        print(
            f"[Twitter] mirrored announcement {key} to {result['url']}",
            flush=True,
        )


@client.tree.command(name="tweet", description="Post a tweet to the WTSL Twitter/X account (admin only)")
@app_commands.describe(
    message="The text to tweet (max 280 characters)",
    image="Optional image to attach to the tweet (JPEG, PNG, GIF, WEBP — max 5 MB)"
)
async def tweet_slash(interaction: discord.Interaction, message: str, image: discord.Attachment = None):
    # Owner or admin only
    is_owner = interaction.user.id == OWNER_ID
    is_admin = any(r.id == ADMIN_ROLE_ID for r in getattr(interaction.user, "roles", []))
    if not (is_owner or is_admin):
        await interaction.response.send_message("❌ Only admins can post tweets.", ephemeral=True)
        return

    # Enforce Twitter's 280 character limit
    if len(message) > 280:
        await interaction.response.send_message(
            f"❌ Tweet is too long — **{len(message)}/280 characters**. Please shorten it and try again.",
            ephemeral=True
        )
        return

    # Validate image if provided
    if image is not None:
        if not is_image_attachment(image.filename, image.content_type):
            await interaction.response.send_message(
                f"❌ Unsupported file type `{image.content_type}`. Please use JPEG, PNG, GIF, or WEBP.",
                ephemeral=True
            )
            return
        if image.size > 5 * 1024 * 1024:
            await interaction.response.send_message(
                f"❌ Image is too large ({image.size / 1024 / 1024:.1f} MB). Twitter's limit is 5 MB.",
                ephemeral=True
            )
            return

    await interaction.response.defer(ephemeral=True)

    try:
        result = await _post_twitter_announcement(
            message,
            attachments=[image] if image is not None else (),
        )
        img_note = " with image" if result.get("has_media") == "true" else ""
        await interaction.followup.send(
            f"✅ **Tweet posted{img_note}!**\n{result['url']}",
            ephemeral=True
        )
        print(f"[Tweet] Posted by {interaction.user}: {message}")
    except TwitterConfigurationError as e:
        await interaction.followup.send(
            "❌ Twitter posting is not configured yet. An admin must add the "
            "Twitter posting secrets before using this command.",
            ephemeral=True,
        )
        print(f"[Tweet] Configuration error: {e}")
    except tweepy.errors.TweepyException as e:
        await interaction.followup.send(
            f"❌ Failed to post tweet: `{e}`",
            ephemeral=True
        )
        print(f"[Tweet] Error: {e}")
    except Exception as e:
        await interaction.followup.send(
            f"❌ Unexpected error: `{e}`",
            ephemeral=True
        )
        print(f"[Tweet] Unexpected error: {e}")
    

@client.tree.command(name="pm", description="Send a private message to a user with timestamp")
@app_commands.describe(user="The user to send a message to", message="The message to send")
async def pm_slash(interaction: discord.Interaction, user: discord.User, message: str):
    import datetime
    now = datetime.datetime.now()
    now = datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S')
    channel = client.get_channel(1003793830585323670)
    try:
        await user.send('**From {} at {} CET**:'.format(interaction.user.name, now))
        await user.send("{}\n\n**Reply here**: https://discord.com/channels/786583939028090881/1003787574130774137".format(message))
        # Send copy to sender
        await interaction.user.send('**From {}:** on {}'.format(interaction.user.name, now))
        await interaction.user.send("**To {}:** {}".format(user, message))
        # Log to channel
        await channel.send('**From: {} on {}**'.format(interaction.user.name, now))
        await channel.send("**To: {}** {}".format(user, message))
        await interaction.response.send_message(f"**Sent to {user} at {now}:** {message}", ephemeral=True)
    except:
        await interaction.response.send_message(f"**{user.name} is not accepting private messages from the bot**", ephemeral=True)
        await channel.send("**{}** tried to send {} this message '**{}**' on {} but the recipient cannot receive messages from WTSL bot".format(interaction.user.name, user, message, now))

@client.tree.command(name="cointoss", description="Run a coin toss between two players")
@app_commands.describe(
    tournament="The tournament name",
    user="First player (Discord user)",
    user2="Second player (Discord user)",
    p1="First player's name (Heads)",
    p2="Second player's name (Tails)"
)
async def cointoss_slash(interaction: discord.Interaction, tournament: str, user: discord.User, user2: discord.User, p1: str, p2: str):
    import datetime
    now = datetime.datetime.now()
    
    # Defer the response immediately (ephemeral)
    await interaction.response.defer(ephemeral=True)
    
    # Get the channel where command was run
    channel = interaction.channel
    
    # Fetch admins
    barboza = await client.fetch_user(485273807360360448)
    mystery = await client.fetch_user(787379133666557963)
    ptacek = await client.fetch_user(213224853686321152)
    djokorer = await client.fetch_user(859691230941282304)
    oserkos = await client.fetch_user(694626703376384081)
    admins = [djokorer, barboza, mystery, ptacek, oserkos]
    
    # Send initial info to channel, players and admins
    await channel.send(f"**{tournament}**")
    await channel.send(f"{p1} is 🪙 Heads and {p2} is 🔘 Tails")
    
    for recipient in [user, user2] + admins:
        try:
            await recipient.send(f"**{tournament}**")
            await recipient.send(f"{p1} is 🪙 Heads and {p2} is 🔘 Tails")
        except:
            pass
    
    # Do coin flips — collect results silently
    h = []
    t = []
    results = []
    for i in range(9):
        if random.random() > 0.5:
            h.append('Heads')
            results.append('🪙')
        else:
            t.append('Tails')
            results.append('🔘')

    # Reveal emojis one by one on a single line for suspense
    current_content = results[0]
    coin_msg = await channel.send(current_content)
    for emoji in results[1:]:
        await asyncio.sleep(1.5)
        current_content += " " + emoji
        await coin_msg.edit(content=current_content)

    coin_line = " ".join(results)
    for recipient in [user, user2]:
        try:
            await recipient.send(coin_line)
        except:
            pass

    # Final count
    final_count = f"{len(h)} Heads and {len(t)} Tails"
    await channel.send(final_count)
    for recipient in [user, user2] + admins:
        try:
            await recipient.send(final_count)
        except:
            pass

    # Determine winner
    winner = p1 if len(h) > len(t) else p2
    await channel.send(f"**{winner} wins!**")
    for recipient in [user, user2] + admins:
        try:
            await recipient.send(f"{winner} wins")
            await recipient.send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))
        except:
            pass

    await interaction.followup.send(f"Coin toss complete — {winner} wins!", ephemeral=True)

# Keep legacy prefix command for backwards compatibility
@client.command(pass_context = True, name="pm_legacy")
async def pm(ctx, user: discord.User, *, message):
    import datetime
    now = datetime.datetime.now()
    now = datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S')
    channel  = client.get_channel(1003793830585323670)
    message_channel = client.get_channel(1003787574130774137)
    try:
        print("{} {}".format(user, message))
        await ctx.message.delete()
    except:
        subprocess.run("kill 1", shell=True, check=True)
        system("python3 main.py")
    try:
      await user.send('**From {} at {} CET**:'.format(ctx.author.name, now))
      await user.send("{} **Reply here**: https://discord.com/channels/786583939028090881/1003787574130774137".format(message))
      await ctx.author.send('**From {}:** on {}'.format(ctx.author.name, now))
      await ctx.author.send("**To {}:** {}".format(user, message))
      await channel.send('**From: {} on {}**'.format(ctx.author.name, now))
      await channel.send("**To: {}** {}".format(user, message))
    except:
        try:
            await ctx.author.send('**This user is not accepting private messages from wtet bot, send him a private message instead**')
            await channel.send("**{}** tried to send {} this message '**{}**' on {} but his opponent cannot receive messages from WTSL bot. He has been notified to contact his opponent by private message instead".format(ctx.author.name, user, message, now))      
        except:
            await message_channel.send(ctx.author.mention+ 'You cannot use the scheduler as you cannot receive private messages from WTSL bot. Please authorize the bot to send you messages')
            await channel.send("**{}** tried to send {} this message '**{}**' on {} CET but he cannot use the bot as he cannot receive messages from WTSL bot".format(ctx.author.name, user, message, now))

APPEALS_CHANNEL_ID = 1481579911087919257
CONTACT_ADMINS_CHANNEL_ID = 1481714019449438308
ADMIN_ROLE_ID = 860659098218790982
MODERATOR_ROLE_ID = 1484904861924462594
APPEAL_TRANSCRIPT_CHANNEL_ID = 1055277431398866995
SUPPORT_WATCH_CHANNEL_ID = 1284362661504745565
TOUR_TALK_CHANNEL_ID     = 812742338669576252
WTSLSTATS_PUBLIC_CHANNEL_IDS = {
    TOUR_TALK_CHANNEL_ID,
    1411110448333328455,
}

REPORT_BUG_CHANNEL_ID    = 1024708207857389628

WATCHED_SUPPORT_CHANNELS = {
    SUPPORT_WATCH_CHANNEL_ID: "te4-general",
    TOUR_TALK_CHANNEL_ID:     "te4-tour-talk",
    REPORT_BUG_CHANNEL_ID:    "report-a-bug",
}

_support_watch = {
    ch_id: {"pending_msg_time": None, "pending_msg_id": None, "pending_msg_content": None, "alerted": False}
    for ch_id in WATCHED_SUPPORT_CHANNELS
}

# Tracks unanswered messages in contact-admins threads (keyed by thread ID, created dynamically)
_thread_watch: dict = {}  # thread_id -> {pending_msg_time, pending_msg_id, pending_msg_content, alerted, thread_name}

@client.event
async def on_thread_update(before: discord.Thread, after: discord.Thread):
    """When an appeal/contact thread is archived, generate a transcript and post it."""
    if before.archived or not after.archived:
        return
    if after.parent_id not in (APPEALS_CHANNEL_ID, CONTACT_ADMINS_CHANNEL_ID):
        return
    if not (after.name.startswith("Appeal") or after.name.startswith("Contact")):
        return

    # Clear contact thread tracking so player can open a new one immediately after close
    if after.name.startswith("Contact"):
        to_remove = [pid for pid, ct in _active_contact_threads.items() if ct["thread_id"] == after.id]
        for pid in to_remove:
            _active_contact_threads.pop(pid, None)
            print(f"[ContactAdmins] Thread {after.id} closed, player {pid} can now open a new one")

    # Clear unanswered-message watch state for this thread (it's now closed)
    if after.id in _thread_watch:
        _thread_watch.pop(after.id, None)
        print(f"[SupportWatch] Cleared thread watch for archived thread {after.id} ({after.name})")

    transcript_channel = client.get_channel(APPEAL_TRANSCRIPT_CHANNEL_ID)
    if transcript_channel is None:
        print(f"[Appeal Transcript] Transcript channel {APPEAL_TRANSCRIPT_CHANNEL_ID} not found.")
        return

    try:
        messages = []
        async for msg in after.history(limit=500, oldest_first=True):
            messages.append(msg)

        if not messages:
            return

        # Build transcript text
        lines = [f"📋 **Appeal Transcript: {after.name}**", f"Thread closed: {discord.utils.format_dt(discord.utils.utcnow(), style='F')}", ""]
        for msg in messages:
            timestamp = discord.utils.format_dt(msg.created_at, style="T")
            author = msg.author.display_name if hasattr(msg.author, 'display_name') else str(msg.author)
            content = msg.content or ""
            if msg.embeds:
                content += " [embed]" * len(msg.embeds)
            if msg.attachments:
                content += " " + " ".join(f"[attachment: {a.filename}]" for a in msg.attachments)
            lines.append(f"[{timestamp}] **{author}**: {content}")

        # Discord messages have a 2000 char limit — split into chunks if needed
        chunks = []
        current = ""
        for line in lines:
            if len(current) + len(line) + 1 > 1990:
                chunks.append(current)
                current = line
            else:
                current += ("\n" if current else "") + line
        if current:
            chunks.append(current)

        await transcript_channel.send(f"📋 **New Appeal Transcript posted** — `{after.name}`")
        for chunk in chunks:
            await transcript_channel.send(chunk)

        print(f"[Appeal Transcript] Posted transcript for '{after.name}' ({len(messages)} messages)")

    except Exception as e:
        print(f"[Appeal Transcript] Error generating transcript for '{after.name}': {e}")

@client.tree.command(name="appeal", description="Appeal a match result by linking the result message")
@app_commands.describe(message_link="The link or ID of the match result message you want to appeal")
async def appeal_slash(interaction: discord.Interaction, message_link: str):
    await interaction.response.defer(ephemeral=True)
    try:
        appeals_channel = client.get_channel(APPEALS_CHANNEL_ID)
        if appeals_channel is None:
            await interaction.followup.send("Appeals channel not found. Please contact an admin.", ephemeral=True)
            return

        match_message = None
        match_message_link = None
        players_to_notify = []
        match_preview = message_link

        # Parse a Discord message link: https://discord.com/channels/{guild}/{channel}/{message}
        link_pattern = re.search(r'discord(?:app)?\.com/channels/(\d+)/(\d+)/(\d+)', message_link)

        try:
            if link_pattern:
                channel_id = int(link_pattern.group(2))
                msg_id_int = int(link_pattern.group(3))
                channel = client.get_channel(channel_id)
                if channel:
                    try:
                        match_message = await channel.fetch_message(msg_id_int)
                    except (discord.NotFound, discord.Forbidden):
                        pass
            else:
                # Fallback: treat input as a plain message ID and search all text channels
                msg_id_int = int(message_link.strip())
                for channel in interaction.guild.text_channels:
                    try:
                        match_message = await channel.fetch_message(msg_id_int)
                        break
                    except (discord.NotFound, discord.Forbidden):
                        continue
        except ValueError:
            await interaction.followup.send("Invalid input. Please paste the message link (right-click the message → Copy Message Link).", ephemeral=True)
            return

        if match_message is None:
            await interaction.followup.send("Could not find that message. Make sure the link is correct and the bot has access to that channel.", ephemeral=True)
            return

        match_message_link = match_message.jump_url
        match_preview = match_message.content[:200] if match_message.content else "(no text)"
        players_to_notify = [u for u in match_message.mentions if not u.bot]

        # Timestamp
        appeal_time = discord.utils.utcnow()
        timestamp_str = discord.utils.format_dt(appeal_time, style="F")

        # Block appeals filed more than 12 hours after the match was posted
        match_age = appeal_time - match_message.created_at
        if match_age.total_seconds() > 12 * 3600:
            await interaction.followup.send(
                "This match occurred more than 12 hours ago, your window for filing an appeal has expired.",
                ephemeral=True
            )
            return

        # Only players involved in the match can file an appeal
        involved_ids = {u.id for u in players_to_notify}
        if match_message.author and not match_message.author.bot:
            involved_ids.add(match_message.author.id)
        if interaction.user.id not in involved_ids:
            await interaction.followup.send(
                "You did not participate in this match, you cannot appeal the result.",
                ephemeral=True
            )
            return

        # Build thread name from actual player display names
        all_players = list({u.id: u for u in players_to_notify}.values())
        if match_message.author and not match_message.author.bot and match_message.author.id not in {u.id for u in all_players}:
            all_players.insert(0, match_message.author)
        player_names = " vs ".join(u.display_name for u in all_players[:2])
        thread_name = f"Appeal – {player_names}"[:100] if player_names else f"Appeal – {match_preview[:60]}"

        admin_role = interaction.guild.get_role(ADMIN_ROLE_ID)
        mod_role = interaction.guild.get_role(MODERATOR_ROLE_ID)
        admin_mention = admin_role.mention if admin_role else "@admins"
        mod_mention = mod_role.mention if mod_role else ""

        # Create a private thread in the appeals channel
        thread = await appeals_channel.create_thread(
            name=thread_name,
            type=discord.ChannelType.private_thread,
            invitable=False
        )
        await thread.add_user(interaction.user)

        # Add all admins and moderators (best effort)
        for role in filter(None, [admin_role, mod_role]):
            for member in role.members:
                try:
                    await thread.add_user(member)
                except Exception:
                    pass

        mentions = " ".join(filter(None, [admin_mention, mod_mention]))
        await thread.send(
            f"{mentions} {interaction.user.mention} ⚖️ **Appeal Filed**\n\n"
            f"**Appealing player:** {interaction.user.mention}\n"
            f"**Match under appeal:** {match_message_link}\n"
            f"> {match_preview}\n"
            f"**Filed at:** {timestamp_str}\n\n"
            f"Please discuss the appeal here. Admins will review and make a decision."
        )

        # DM the players involved in the match
        dm_sent = []
        dm_failed = []
        for player in players_to_notify:
            try:
                await player.send(
                    f"⚖️ **Your match is under appeal**\n\n"
                    f"Match: {match_message_link}\n"
                    f"> {match_preview}\n\n"
                    f"**Do not schedule your next match** until this appeal has been resolved.\n"
                    f"Appeal filed at: {timestamp_str}"
                )
                dm_sent.append(player.display_name)
                print(f"[Appeal] DM sent to {player} ({player.id})")
            except Exception as e:
                print(f"[Appeal] Failed to DM {player} ({player.id}): {e}")
                dm_failed.append(player.display_name)

        # Also DM the author of the match message if they weren't tagged in it
        if match_message.author and not match_message.author.bot:
            if match_message.author not in players_to_notify:
                try:
                    await match_message.author.send(
                        f"⚖️ **Your match is under appeal**\n\n"
                        f"Match: {match_message_link}\n"
                        f"> {match_preview}\n\n"
                        f"**Do not schedule your next match** until this appeal has been resolved.\n"
                        f"Appeal filed at: {timestamp_str}"
                    )
                    dm_sent.append(match_message.author.display_name)
                except Exception as e:
                    print(f"[Appeal] Failed to DM match author {match_message.author}: {e}")
                    dm_failed.append(match_message.author.display_name)

        result_parts = [f"✅ Appeal filed successfully. A private thread has been created in the appeals channel."]
        if dm_sent:
            result_parts.append(f"DMs sent to: {', '.join(dm_sent)}")
        if dm_failed:
            result_parts.append(f"Could not DM: {', '.join(dm_failed)} (DMs may be disabled)")

        await interaction.followup.send("\n".join(result_parts), ephemeral=True)

    except Exception as e:
        print(f"[Appeal] Error: {e}")
        await interaction.followup.send("Something went wrong filing the appeal. Please try again or contact an admin.", ephemeral=True)


@client.tree.command(name="contactadmins", description="Open a private thread with the admins")
@app_commands.describe(message="Your message to the admins", attachment="Optional file or image to include")
async def contactadmins_slash(interaction: discord.Interaction, message: str, attachment: discord.Attachment = None):
    await interaction.response.defer(ephemeral=True)
    try:
        # Block if player already has an active contact thread within 24 hours
        existing = _active_contact_threads.get(interaction.user.id)
        if existing and (time.time() - existing["created_at"]) < 86400:
            existing_thread = client.get_channel(existing["thread_id"])
            thread_ref = existing_thread.mention if existing_thread else "your existing thread"
            await interaction.followup.send(
                f"You already have an active admin contact thread ({thread_ref}). "
                f"Please continue the conversation there. You can open a new one after 24 hours.",
                ephemeral=True
            )
            return

        contact_channel = client.get_channel(CONTACT_ADMINS_CHANNEL_ID)
        if contact_channel is None:
            await interaction.followup.send("Could not find the admin contact channel. Please try again later.", ephemeral=True)
            return

        admin_role = interaction.guild.get_role(ADMIN_ROLE_ID)
        mod_role = interaction.guild.get_role(MODERATOR_ROLE_ID)
        admin_mention = admin_role.mention if admin_role else "@admins"
        mod_mention = mod_role.mention if mod_role else ""
        timestamp_str = discord.utils.format_dt(discord.utils.utcnow(), style="F")

        thread_name = f"Contact – {interaction.user.display_name}"[:100]
        thread = await contact_channel.create_thread(
            name=thread_name,
            type=discord.ChannelType.private_thread,
            invitable=False
        )
        await thread.add_user(interaction.user)
        for role in filter(None, [admin_role, mod_role]):
            for member in role.members:
                try:
                    await thread.add_user(member)
                except Exception:
                    pass

        # Download and re-upload attachment if provided
        discord_file = None
        if attachment:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(attachment.url) as resp:
                        if resp.status == 200:
                            data = await resp.read()
                            import io
                            discord_file = discord.File(io.BytesIO(data), filename=attachment.filename)
            except Exception as e:
                print(f"[ContactAdmins] Failed to download attachment: {e}")

        contact_mentions = " ".join(filter(None, [admin_mention, mod_mention]))
        await thread.send(
            f"{contact_mentions} {interaction.user.mention} 📩 **Admin Contact Request**\n\n"
            f"**From:** {interaction.user.mention}\n"
            f"**Sent at:** {timestamp_str}\n\n"
            f">>> {message}",
            file=discord_file if discord_file else discord.utils.MISSING
        )

        _active_contact_threads[interaction.user.id] = {
            "thread_id": thread.id,
            "created_at": time.time(),
        }
        print(f"[ContactAdmins] Thread {thread.id} opened for {interaction.user} ({interaction.user.id})")

        await interaction.followup.send("Your message has been sent. A private thread has been opened with the admins.", ephemeral=True)

    except Exception as e:
        print(f"[ContactAdmins] Error: {e}")
        await interaction.followup.send("Something went wrong. Please try again or contact an admin directly.", ephemeral=True)


@client.tree.command(name="dm", description="Send a private message to a user")
@app_commands.describe(user="The user to send a message to", message="The message to send", attachment="Optional image or file to attach")
async def dm_slash(interaction: discord.Interaction, user: discord.User, message: str, attachment: discord.Attachment = None):
    await interaction.response.defer(ephemeral=True)
    try:
        _file_bytes = None
        if attachment:
            import aiohttp as _aiohttp
            async with _aiohttp.ClientSession() as _sess:
                async with _sess.get(attachment.url) as _r:
                    _file_bytes = await _r.read()
            await user.send(message, file=discord.File(io.BytesIO(_file_bytes), filename=attachment.filename))
        else:
            await user.send(message)
        # Send a copy to the owner
        try:
            _owner = await client.fetch_user(OWNER_ID)
            if _owner.id != user.id:
                _copy_text = f"📋 **DM copy** → sent to **{user}** ({user.id}):\n{message}"
                if _file_bytes:
                    await _owner.send(_copy_text, file=discord.File(io.BytesIO(_file_bytes), filename=attachment.filename))
                else:
                    await _owner.send(_copy_text)
        except Exception:
            pass
        await interaction.followup.send(f"**Sent to {user}:** {message}", ephemeral=True)
    except Exception as _e:
        await interaction.followup.send(f"**{user.name} is not accepting private messages from the bot**", ephemeral=True)

@client.tree.command(name="announce", description="Send an announcement in this channel")
@app_commands.describe(
    message="The announcement text",
    mention="Optional user or role to tag",
    mention2="Optional second user or role to tag",
    mention3="Optional third user or role to tag",
    attachment="Optional image or file to include",
    tweet="Also post this announcement to Twitter/X"
)
async def announce_slash(
    interaction: discord.Interaction,
    message: str,
    mention: typing.Union[discord.Role, discord.Member] = None,
    mention2: typing.Union[discord.Role, discord.Member] = None,
    mention3: typing.Union[discord.Role, discord.Member] = None,
    attachment: discord.Attachment = None,
    tweet: bool = False,
):
    if interaction.user.id != OWNER_ID and not any(r.id == ADMIN_ROLE_ID for r in getattr(interaction.user, "roles", [])):
        await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    try:
        discord_file = None
        if attachment:
            async with aiohttp.ClientSession() as session:
                async with session.get(attachment.url) as resp:
                    if resp.status == 200:
                        data = await resp.read()
                        discord_file = discord.File(io.BytesIO(data), filename=attachment.filename)
        mentions = [m.mention for m in (mention, mention2, mention3) if m is not None]
        content = f"{' '.join(mentions)}\n\n{message}" if mentions else message
        sent_announcement = await interaction.channel.send(
            content,
            file=discord_file if discord_file else discord.utils.MISSING
        )
        tweet_result = None
        tweet_error = None
        if tweet:
            try:
                tweet_result = await _post_twitter_announcement(
                    content,
                    attachments=[attachment] if attachment else (),
                    source_url=getattr(sent_announcement, "jump_url", None),
                )
            except Exception as exc:
                tweet_error = exc
                print(f"[Twitter] /announce tweet option failed: {exc}", flush=True)
        if tweet_result:
            await interaction.followup.send(
                f"✅ Announcement sent and tweeted.\n{tweet_result['url']}",
                ephemeral=True,
            )
        elif tweet_error:
            await interaction.followup.send(
                f"✅ Announcement sent, but Twitter posting failed: "
                f"`{str(tweet_error)[:300]}`",
                ephemeral=True,
            )
        else:
            await interaction.followup.send("✅ Announcement sent.", ephemeral=True)
    except Exception as e:
        await interaction.followup.send(f"Something went wrong: {e}", ephemeral=True)


@client.tree.command(name="editmessage", description="Edit a previous bot message using its message link")
@app_commands.describe(
    message_link="Full Discord message link (right-click message → Copy Message Link)",
    new_message="The new content to replace the message with"
)
async def editmessage_slash(interaction: discord.Interaction, message_link: str, new_message: str):
    if interaction.user.id != OWNER_ID and not any(r.id == ADMIN_ROLE_ID for r in getattr(interaction.user, "roles", [])):
        await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    try:
        parts = message_link.strip().rstrip("/").split("/")
        if len(parts) < 2:
            await interaction.followup.send("Invalid message link.", ephemeral=True)
            return
        channel_id, message_id = int(parts[-2]), int(parts[-1])
        channel = client.get_channel(channel_id) or await client.fetch_channel(channel_id)
        target = await channel.fetch_message(message_id)
        if target.author.id != client.user.id:
            await interaction.followup.send("I can only edit messages sent by the bot.", ephemeral=True)
            return
        await target.edit(content=new_message)
        await interaction.followup.send("✅ Message updated.", ephemeral=True)
    except Exception as e:
        await interaction.followup.send(f"Something went wrong: {e}", ephemeral=True)


OWNER_ID = 859691230941282304

MATCH_SCHEDULER_GUILD_ID = 786583939028090881
MATCH_SCHEDULER_CHANNEL_ID = 1003787574130774137
MATCH_SCHEDULING_LOG_CHANNEL_ID = 1003793830585323670
MATCH_SCHEDULER_PANEL_KEY = "match_scheduler:panel:v1"
MATCH_SCHEDULER_BUTTON_ID = "match_scheduler:start:v1"
MATCH_SCHEDULER_REPLY_PREFIX = "match_scheduler:reply:"
MATCH_SCHEDULER_OFFER_PREFIX = "match_scheduler:offer:"
MATCH_SCHEDULER_ROUND_CORRECTION_VERSION = "v1"
MATCH_SCHEDULER_MAX_CHOICES = 20
_match_scheduler_lock = asyncio.Lock()
_match_scheduler_records: dict[str, dict[str, typing.Any]] = {}
_match_scheduler_thread_index: dict[int, str] = {}
_match_scheduler_logged_message_ids: set[int] = set()


def _match_scheduler_staff(member) -> bool:
    return (
        getattr(member, "id", None) == OWNER_ID
        or any(
            getattr(role, "id", None) in {ADMIN_ROLE_ID, MODERATOR_ROLE_ID}
            for role in getattr(member, "roles", [])
        )
    )


def _match_scheduler_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%y%m%d%H%M")
    suffix = hashlib.sha1(
        f"{stamp}:{time.time_ns()}".encode("utf8")
    ).hexdigest()[:6].upper()
    return f"MS-{stamp}-{suffix}"


def _match_scheduler_embed() -> discord.Embed:
    return discord.Embed(
        title="🎾 Match scheduler",
        color=0x2ECC71,
    )


class MatchSchedulerView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Schedule my match",
        style=discord.ButtonStyle.success,
        emoji="🎾",
        custom_id=MATCH_SCHEDULER_BUTTON_ID,
    )
    async def schedule_match(
        self,
        interaction: discord.Interaction,
        _button: discord.ui.Button,
    ):
        await _begin_match_scheduler(interaction)


class MatchSchedulerChoiceView(discord.ui.View):
    def __init__(
        self,
        requester_id: int,
        choices: list[dict[str, typing.Any]],
        *,
        test_mode: bool,
    ):
        super().__init__(timeout=300)
        self.requester_id = requester_id
        self.choices = choices
        self.test_mode = test_mode
        for index, match in enumerate(choices[:MATCH_SCHEDULER_MAX_CHOICES]):
            label = (
                f"{match['tournament']} — {match['round']}"
                if test_mode
                else (
                    f"{match['tournament']} — vs "
                    f"{_scheduler_opponent_for_display(match, requester_id)}"
                )
            )
            button = discord.ui.Button(
                label=label[:80],
                style=discord.ButtonStyle.primary,
                custom_id=f"match_scheduler:choose:{requester_id}:{index}",
            )

            async def choose(
                interaction: discord.Interaction,
                chosen=match,
            ):
                if interaction.user.id != self.requester_id:
                    await interaction.response.send_message(
                        "These match choices belong to another player.",
                        ephemeral=True,
                    )
                    return
                await _create_match_scheduler_record(
                    interaction,
                    chosen,
                    test_mode=self.test_mode,
                )

            button.callback = choose
            self.add_item(button)


def _scheduler_opponent_for_display(
    match: dict[str, typing.Any],
    requester_id: int,
) -> str:
    links = _matchlog_links(requester_id)
    linked_names = {
        normalize_matchlog_name(value)
        for value in links.values()
        if value
    }
    for player in match.get("players") or []:
        if normalize_matchlog_name(player) not in linked_names:
            return player
    return "opponent"


async def _fetch_match_scheduler_matches() -> list[dict[str, typing.Any]]:
    """Return open draw matches with upcoming round deadlines."""
    async with aiohttp.ClientSession() as session:
        return await _load_open_draw_matches(session)


async def _fetch_match_scheduler_completed_matches() -> list[dict[str, typing.Any]]:
    """Fetch completed draw nodes used to close real scheduling threads."""
    found: list[dict[str, typing.Any]] = []
    async with aiohttp.ClientSession() as session:
        tournaments = []
        seen_tournaments: set[str] = set()
        for tournaments_url, tour in (
            (ONGOING_TOURNAMENTS_URL, "TE4"),
            (ONGOING_TOURNAMENTS_WTA_URL, "TE4_(F)"),
        ):
            async with session.get(
                tournaments_url,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as response:
                response.raise_for_status()
                for tournament in parse_ongoing_tournaments(
                    await response.text(),
                    tour=tour,
                ):
                    if tournament["id"] not in seen_tournaments:
                        tournaments.append(tournament)
                        seen_tournaments.add(tournament["id"])
        for tournament in tournaments:
            source = await _fetch_exact_draw_source(session, tournament)
            if source is None:
                continue
            draw_html, source_tournament = source
            found.extend(parse_completed_draw_matches(draw_html, source_tournament))
    return found


def _match_scheduler_notice_key(
    match: dict[str, typing.Any],
    user_id: int,
) -> str:
    """Keep first-detection notices stable when a deadline is revised."""
    return (
        f"wtsl:{match['tournament_id']}:{match['match_id']}"
        f":user:{int(user_id)}"
    )


def _match_scheduler_round_correction_key(
    match: dict[str, typing.Any],
    user_id: int,
) -> str:
    return (
        f"{_match_scheduler_notice_key(match, user_id)}"
        f":round-correction:{MATCH_SCHEDULER_ROUND_CORRECTION_VERSION}"
    )


def _match_scheduler_offer_view(
    match: dict[str, typing.Any],
) -> discord.ui.View:
    """Build a restart-safe offer button for one current draw match."""
    view = discord.ui.View(timeout=None)
    view.add_item(
        discord.ui.Button(
            label="Schedule this match",
            style=discord.ButtonStyle.success,
            emoji="🎾",
            custom_id=(
                f"{MATCH_SCHEDULER_OFFER_PREFIX}"
                f"{match['tournament_id']}:{match['match_id']}"
            ),
        )
    )
    return view


async def _send_match_scheduler_notice(
    match: dict[str, typing.Any],
    user_id: int,
    opponent: str,
) -> bool:
    """Send one first-detection DM, with a durable retry reservation."""
    notice_key = _match_scheduler_notice_key(match, user_id)
    try:
        claimed = await asyncio.to_thread(
            claim_match_scheduler_notice,
            notice_key,
            int(user_id),
        )
    except Exception as exc:
        print(
            f"[Match scheduler] notice claim failed for {notice_key}: {exc}",
            flush=True,
        )
        return False
    if not claimed:
        return False

    deadline = match.get("deadline")
    deadline_line = (
        f"**Deadline:** <t:{int(deadline.timestamp())}:F> "
        f"(<t:{int(deadline.timestamp())}:R>)\n"
        if isinstance(deadline, datetime)
        else ""
    )
    try:
        user = await client.fetch_user(int(user_id))
        await user.send(
            "🎾 **WTSL match available for scheduling**\n"
            f"**Tournament:** [{match['tournament']}]({match['draw_url']})\n"
            f"**Round:** {match['round']}\n"
            f"**Opponent:** {opponent}\n"
            f"{deadline_line}"
            f"**Draw:** [Open tournament draw]({match['draw_url']})\n"
            "Use the button below to create a private scheduling thread.",
            view=_match_scheduler_offer_view(match),
            allowed_mentions=discord.AllowedMentions.none(),
        )
    except Exception as exc:
        print(
            f"[Match scheduler] notice DM failed for {notice_key}: {exc}",
            flush=True,
        )
        try:
            await asyncio.to_thread(release_match_scheduler_notice, notice_key)
        except Exception as release_exc:
            print(
                f"[Match scheduler] notice release failed for {notice_key}: "
                f"{release_exc}",
                flush=True,
            )
        return False

    try:
        await asyncio.to_thread(mark_match_scheduler_notice_sent, notice_key)
    except Exception as exc:
        # The send succeeded, so leave the sending reservation for stale retry
        # rather than deleting it and making every scan resend immediately.
        print(
            f"[Match scheduler] notice mark-sent failed for {notice_key}: {exc}",
            flush=True,
        )
    return True


async def _send_match_scheduler_round_correction(
    match: dict[str, typing.Any],
    user_id: int,
    opponent: str,
) -> bool:
    """Send one correction only when the old bracket collision changed the label."""
    corrected_round = str(match.get("round") or "").strip()
    legacy_round = str(match.get("_legacy_round") or "").strip()
    if not corrected_round or corrected_round == legacy_round:
        return False

    notice_key = _match_scheduler_notice_key(match, user_id)
    try:
        originally_sent = await asyncio.to_thread(
            match_scheduler_notice_was_sent,
            notice_key,
        )
    except Exception as exc:
        print(
            f"[Match scheduler] correction lookup failed for {notice_key}: {exc}",
            flush=True,
        )
        return False
    if not originally_sent:
        return False

    correction_key = _match_scheduler_round_correction_key(match, user_id)
    try:
        claimed = await asyncio.to_thread(
            claim_match_scheduler_notice,
            correction_key,
            int(user_id),
        )
    except Exception as exc:
        print(
            f"[Match scheduler] correction claim failed for {correction_key}: {exc}",
            flush=True,
        )
        return False
    if not claimed:
        return False

    try:
        user = await client.fetch_user(int(user_id))
        await user.send(
            "🎾 **Correction to your WTSL scheduling notice**\n"
            f"**Tournament:** [{match['tournament']}]({match['draw_url']})\n"
            f"**Round (Corrected):** {corrected_round}\n"
            f"**Opponent:** {opponent}\n"
            "The previous round label was incorrect because of a bracket "
            "parsing error. Challonge is the source of truth.\n"
            "Use the button below to create a private scheduling thread.",
            view=_match_scheduler_offer_view(match),
            allowed_mentions=discord.AllowedMentions.none(),
        )
    except Exception as exc:
        print(
            f"[Match scheduler] correction DM failed for {correction_key}: {exc}",
            flush=True,
        )
        try:
            await asyncio.to_thread(release_match_scheduler_notice, correction_key)
        except Exception as release_exc:
            print(
                f"[Match scheduler] correction release failed for "
                f"{correction_key}: {release_exc}",
                flush=True,
            )
        return False

    try:
        await asyncio.to_thread(
            mark_match_scheduler_notice_sent,
            correction_key,
        )
    except Exception as exc:
        print(
            f"[Match scheduler] correction mark-sent failed for "
            f"{correction_key}: {exc}",
            flush=True,
        )
    return True


async def _notify_match_scheduler_matches(
    matches: list[dict[str, typing.Any]],
) -> None:
    """Notify every verified participant once when an open match is detected."""
    for match in matches:
        players = list(match.get("players") or [])
        if len(players) != 2:
            continue
        for index, player in enumerate(players):
            user_id = _match_scheduler_player_user_id(player)
            if user_id is None:
                continue
            await _send_match_scheduler_notice(
                match,
                user_id,
                players[1 - index],
            )


async def _notify_match_scheduler_round_corrections(
    matches: list[dict[str, typing.Any]],
) -> None:
    """Correct prior notices affected by the old winner/loser round collision."""
    for match in matches:
        players = list(match.get("players") or [])
        if len(players) != 2:
            continue
        for index, player in enumerate(players):
            user_id = _match_scheduler_player_user_id(player)
            if user_id is None:
                continue
            await _send_match_scheduler_round_correction(
                match,
                user_id,
                players[1 - index],
            )


async def _match_scheduler_completion_loop() -> None:
    """Notify new open matches and close schedules marked complete by WTSL."""
    while True:
        try:
            open_matches: list[dict[str, typing.Any]] = []
            try:
                open_matches = await _fetch_match_scheduler_matches()
                await _notify_match_scheduler_matches(open_matches)
            except Exception as exc:
                print(
                    f"[Match scheduler] open-match notification scan failed: {exc}",
                    flush=True,
                )
            completed = await _fetch_match_scheduler_completed_matches()
            await _notify_match_scheduler_round_corrections(
                [*open_matches, *completed],
            )
            completed_keys = {
                _match_scheduler_completion_key(match)
                for match in completed
            }
            for record in list(_match_scheduler_records.values()):
                if record.get("status") != "active" or record.get("is_test"):
                    continue
                record_players = {
                    normalize_matchlog_name(record.get("player_one", "")),
                    normalize_matchlog_name(record.get("player_two", "")),
                }
                key = (
                    str(record.get("tournament_id")),
                    str(record.get("source_match_id")),
                    frozenset(record_players),
                )
                if key in completed_keys:
                    await _finalize_match_scheduler(
                        record,
                        source="tournament result",
                    )
        except Exception as exc:
            print(f"[Match scheduler] completion scan failed: {exc}", flush=True)
        await asyncio.sleep(5 * 60)


def _match_scheduler_completion_key(match: dict[str, typing.Any]) -> tuple:
    return (
        str(match.get("tournament_id")),
        str(match.get("match_id")),
        frozenset(
            normalize_matchlog_name(player)
            for player in match.get("players") or []
        ),
    )


def _match_scheduler_player_user_id(
    player_name: str,
    *,
    exclude: int | None = None,
) -> int | None:
    wanted = normalize_matchlog_name(player_name)
    for user_id, links in _matchlog_identity_index.items():
        if exclude is not None and int(user_id) == int(exclude):
            continue
        if any(
            normalize_matchlog_name(value) == wanted
            for value in links.values()
            if value
        ):
            return int(user_id)
    return None


async def _begin_match_scheduler(interaction: discord.Interaction) -> None:
    """Resolve the clicker to one open draw match, or offer a short choice list."""
    await interaction.response.defer(ephemeral=True, thinking=True)
    if interaction.guild is None or interaction.guild.id != MATCH_SCHEDULER_GUILD_ID:
        await interaction.edit_original_response(
            content="This scheduler is only available in the WTSL server."
        )
        return
    try:
        matches = await _fetch_match_scheduler_matches()
    except Exception as exc:
        print(f"[Match scheduler] draw lookup failed: {exc}", flush=True)
        await interaction.edit_original_response(
            content="I couldn't load the current WTSL draws. Please try again shortly."
        )
        return

    is_test = interaction.user.id == OWNER_ID
    if is_test:
        choices = matches
        if not choices:
            await interaction.edit_original_response(
                content="There are no open upcoming draw matches to use as a test."
            )
            return
    else:
        links = _matchlog_links(interaction.user.id)
        if not links:
            await interaction.edit_original_response(
                content=(
                    "I couldn't find a verified WTSL player identity for your "
                    "Discord account. Ask an admin to link it first."
                )
            )
            return
        linked_names = {
            normalize_matchlog_name(value)
            for value in links.values()
            if value
        }
        choices = [
            match for match in matches
            if any(
                normalize_matchlog_name(player) in linked_names
                for player in match.get("players") or []
            )
        ]
        if not choices:
            await interaction.edit_original_response(
                content=(
                    "I couldn't find an open upcoming draw match involving your "
                    "verified player identity."
                )
            )
            return

    if len(choices) == 1:
        await _create_match_scheduler_record(
            interaction,
            choices[0],
            test_mode=is_test,
        )
        return
    await interaction.edit_original_response(
        content=(
            "Choose the upcoming match to schedule. "
            + (
                "This is a test only: the two real draw players will not be "
                "invited or DM'd."
                if is_test else
                "Only the selected match's two linked players will be invited."
            )
        ),
        view=MatchSchedulerChoiceView(
            interaction.user.id,
            choices,
            test_mode=is_test,
        ),
    )


async def _route_match_scheduler_offer(
    interaction: discord.Interaction,
    tournament_id: str,
    source_match_id: str,
) -> None:
    """Revalidate a durable DM offer before creating its real schedule."""
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        matches = await _fetch_match_scheduler_matches()
    except Exception as exc:
        print(f"[Match scheduler] offer lookup failed: {exc}", flush=True)
        await interaction.edit_original_response(
            content="I couldn't load the current WTSL draws. Please try again shortly."
        )
        return
    selected = next(
        (
            match for match in matches
            if str(match.get("tournament_id")) == str(tournament_id)
            and str(match.get("match_id")) == str(source_match_id)
        ),
        None,
    )
    if selected is None:
        await interaction.edit_original_response(
            content=(
                "That match is no longer open in the current draw. "
                "Please wait for a new match notification."
            )
        )
        return
    await _create_match_scheduler_record(
        interaction,
        selected,
        test_mode=False,
    )


def _scheduler_record_for_thread(thread_id: int):
    schedule_id = _match_scheduler_thread_index.get(int(thread_id))
    if schedule_id:
        return _match_scheduler_records.get(schedule_id)
    return None


async def _create_match_scheduler_record(
    interaction: discord.Interaction,
    source_match: dict[str, typing.Any],
    *,
    test_mode: bool,
) -> None:
    if not interaction.response.is_done():
        await interaction.response.defer(ephemeral=True, thinking=True)
    requester_id = int(interaction.user.id)
    source_players = list(source_match.get("players") or [])
    if len(source_players) != 2:
        await interaction.edit_original_response(
            content="That draw entry is no longer a complete two-player match."
        )
        return
    if test_mode:
        players = ["Squeaky", "Squeaky"]
        player_ids = [requester_id, requester_id]
    else:
        links = _matchlog_links(requester_id)
        linked_names = {
            normalize_matchlog_name(value)
            for value in links.values()
            if value
        }
        own_index = next(
            (
                index for index, player in enumerate(source_players)
                if normalize_matchlog_name(player) in linked_names
            ),
            None,
        )
        if own_index is None:
            await interaction.edit_original_response(
                content="That draw match does not involve your verified player identity."
            )
            return
        opponent_index = 1 - own_index
        opponent_id = _match_scheduler_player_user_id(
            source_players[opponent_index],
            exclude=requester_id,
        )
        if opponent_id is None:
            await interaction.edit_original_response(
                content=(
                    f"I found {source_players[0]} vs {source_players[1]}, but "
                    "the opponent does not have a linked Discord identity yet."
                )
            )
            return
        players = source_players
        player_ids = [requester_id, opponent_id]

    async with _match_scheduler_lock:
        duplicate = next(
            (
                record for record in _match_scheduler_records.values()
                if record.get("status") == "active"
                and record.get("tournament_id") == source_match["tournament_id"]
                and record.get("source_match_id") == source_match["match_id"]
                and bool(record.get("is_test")) == bool(test_mode)
                and (
                    test_mode
                    or set(
                        filter(None, (
                            record.get("player_one_user_id"),
                            record.get("player_two_user_id"),
                        ))
                    ) == set(player_ids)
                )
            ),
            None,
        )
        if duplicate:
            reply_side = _match_scheduler_reply_side(duplicate, requester_id)
            await interaction.edit_original_response(
                content=(
                    "That match already has an open scheduling thread.\n"
                    f"{_scheduler_thread_link(duplicate).strip()}\n"
                    "You can still reply to the scheduling conversation here."
                ),
                view=(
                    _match_scheduler_reply_view(duplicate, reply_side)
                    if reply_side
                    else None
                ),
            )
            return

        schedule_id = _match_scheduler_id()
        record = {
            "schedule_id": schedule_id,
            "guild_id": MATCH_SCHEDULER_GUILD_ID,
            "tournament_id": str(source_match["tournament_id"]),
            "tournament_name": str(source_match["tournament"]),
            "round_name": str(source_match["round"]),
            "source_match_id": str(source_match["match_id"]),
            "player_one": players[0],
            "player_two": players[1],
            "player_one_user_id": player_ids[0],
            "player_two_user_id": player_ids[1],
            "thread_id": None,
            "log_message_id": None,
            "status": "active",
            "is_test": bool(test_mode),
            "created_by": requester_id,
            "metadata": {
                "source_players": source_players,
                "dm_message_ids": {},
            },
        }
        try:
            await asyncio.to_thread(save_match_schedule, record)
        except Exception as exc:
            print(f"[Match scheduler] could not reserve {schedule_id}: {exc}")
            await interaction.edit_original_response(
                content="I couldn't reserve this match safely. Please try again."
            )
            return

        scheduler_channel = client.get_channel(MATCH_SCHEDULER_CHANNEL_ID)
        if scheduler_channel is None:
            scheduler_channel = await client.fetch_channel(MATCH_SCHEDULER_CHANNEL_ID)
        thread = None
        try:
            thread = await scheduler_channel.create_thread(
                name=(
                    f"🎾 {players[0]} vs {players[1]} · "
                    f"{record['tournament_name']}"
                )[:100],
                type=discord.ChannelType.private_thread,
                invitable=False,
                auto_archive_duration=1440,
            )
            for user_id in dict.fromkeys(player_ids):
                await thread.add_user(await client.fetch_user(int(user_id)))
            header = (
                "🎾 **Match scheduling**\n"
                f"**Tournament:** {record['tournament_name']}\n"
                f"**Round:** {record['round_name']}\n"
                f"**Match:** {players[0]} vs {players[1]}\n"
                "\n"
                + (
                    "This is a private test based on an upcoming draw. The "
                    "two real draw players were not invited or notified.\n"
                    if test_mode else
                    "Use this thread to agree a time. Each message is copied "
                    "to the scheduling log for admins.\n"
                )
            )
            header_message = await thread.send(
                header,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            record["thread_id"] = int(thread.id)
            await asyncio.to_thread(
                update_match_schedule,
                schedule_id,
                thread_id=int(thread.id),
            )
        except Exception as exc:
            print(f"[Match scheduler] thread creation failed for {schedule_id}: {exc}")
            try:
                await asyncio.to_thread(
                    update_match_schedule,
                    schedule_id,
                    status="failed",
                    metadata={"error": str(exc)[:500]},
                )
            except Exception:
                pass
            await interaction.edit_original_response(
                content="I couldn't create the private scheduling thread."
            )
            return

        _match_scheduler_records[schedule_id] = record
        _match_scheduler_thread_index[int(thread.id)] = schedule_id
        await _log_match_scheduler_message(
            record,
            author=client.user,
            content=header,
            message_id=getattr(header_message, "id", None),
            source="thread opening",
            created_at=getattr(header_message, "created_at", None),
        )

        log_channel = client.get_channel(MATCH_SCHEDULING_LOG_CHANNEL_ID)
        if log_channel is None:
            log_channel = await client.fetch_channel(MATCH_SCHEDULING_LOG_CHANNEL_ID)
        log_message = await log_channel.send(
            _scheduler_log_header(record, thread),
            allowed_mentions=discord.AllowedMentions.none(),
        )
        record["log_message_id"] = int(log_message.id)
        await asyncio.to_thread(
            update_match_schedule,
            schedule_id,
            log_message_id=int(log_message.id),
        )
        if not test_mode:
            await _send_match_scheduler_dms(record, thread)
        else:
            await _send_match_scheduler_dm(record, thread, requester_id, "test")
        await interaction.edit_original_response(
            content=(
                f"Created private scheduling thread `{schedule_id}`: "
                f"{thread.jump_url}"
            ),
        )


def _scheduler_log_header(record, thread=None) -> str:
    return (
        _scheduler_thread_link(record, thread)
        +
        f"🗂️ **Scheduling opened — "
        f"{record['player_one']} vs {record['player_two']}**\n"
        f"**Tournament:** {record['tournament_name']} • "
        f"**Round:** {record['round_name']}\n"
        f"**Players:** {record['player_one']} vs {record['player_two']}\n"
        + (
            "🧪 Test record."
            if record.get("is_test") else
            "Thread messages follow below."
        )
    )


def _scheduler_thread_link(record, thread=None) -> str:
    thread_url = getattr(thread, "jump_url", None)
    if not thread_url and record.get("thread_id"):
        thread_url = (
            f"https://discord.com/channels/{record['guild_id']}/"
            f"{MATCH_SCHEDULER_CHANNEL_ID}/{record['thread_id']}"
        )
    return (
        f"🧵 **Thread:** [Open scheduling thread]({thread_url})\n"
        if thread_url else
        ""
    )


async def _send_match_scheduler_dm(
    record: dict[str, typing.Any],
    thread,
    user_id: int,
    side: str,
) -> None:
    try:
        user = await client.fetch_user(int(user_id))
        view = _match_scheduler_reply_view(record, side)
        sent = await user.send(
            "🎾 **Your match is ready to arrange**\n"
            f"Your private thread for **{record['tournament_name']}**, "
            f"{record['round_name']}, is ready: {thread.jump_url}\n"
            "Use the button to send your availability or reply without "
            "having to open the server.",
            view=view,
        )
        metadata = dict(record.get("metadata") or {})
        dm_ids = dict(metadata.get("dm_message_ids") or {})
        dm_ids[side] = int(sent.id)
        metadata["dm_message_ids"] = dm_ids
        record["metadata"] = metadata
        await asyncio.to_thread(
            update_match_schedule,
            record["schedule_id"],
            metadata=metadata,
        )
    except Exception as exc:
        print(
            f"[Match scheduler] DM failed for {record['schedule_id']} "
            f"user {user_id}: {exc}",
            flush=True,
        )


async def _send_match_scheduler_dms(record, thread) -> None:
    for side, user_id in (
        ("side1", record.get("player_one_user_id")),
        ("side2", record.get("player_two_user_id")),
    ):
        if user_id:
            await _send_match_scheduler_dm(record, thread, int(user_id), side)


async def _send_match_scheduler_reply_dms(
    record: dict[str, typing.Any],
    *,
    author_id: int,
    author_name: str,
    text: str,
) -> None:
    """Forward an opponent's reply to the other participant's DM."""
    recipients = {
        int(user_id)
        for user_id in (
            record.get("player_one_user_id"),
            record.get("player_two_user_id"),
        )
        if user_id and int(user_id) != int(author_id)
    }
    for user_id in recipients:
        side = (
            "side1"
            if int(record.get("player_one_user_id") or 0) == user_id
            else "side2"
        )
        try:
            user = await client.fetch_user(user_id)
            view = _match_scheduler_reply_view(record, side)
            thread_url = (
                f"https://discord.com/channels/{record['guild_id']}/"
                f"{MATCH_SCHEDULER_CHANNEL_ID}/{record['thread_id']}"
            )
            await user.send(
                f"🎾 **New message from {author_name}**\n"
                f"**{author_name}:** {text[:1600]}\n"
                f"Private thread: {thread_url}",
                view=view,
            )
        except Exception as exc:
            print(
                f"[Match scheduler] reply DM failed for {record['schedule_id']} "
                f"user {user_id}: {exc}",
                flush=True,
            )


def _scheduler_record_for_id(schedule_id: str):
    return _match_scheduler_records.get(schedule_id)


def _match_scheduler_reply_side(
    record: dict[str, typing.Any],
    user_id: int,
) -> str | None:
    if record.get("is_test"):
        return (
            "test"
            if int(record.get("player_one_user_id") or 0) == int(user_id)
            or int(record.get("player_two_user_id") or 0) == int(user_id)
            else None
        )
    if int(record.get("player_one_user_id") or 0) == int(user_id):
        return "side1"
    if int(record.get("player_two_user_id") or 0) == int(user_id):
        return "side2"
    return None


def _match_scheduler_reply_view(
    record: dict[str, typing.Any],
    side: str,
) -> discord.ui.View:
    view = discord.ui.View(timeout=None)
    view.add_item(
        discord.ui.Button(
            label="Reply to scheduling thread",
            style=discord.ButtonStyle.primary,
            custom_id=(
                f"{MATCH_SCHEDULER_REPLY_PREFIX}"
                f"{record['schedule_id']}:{side}"
            ),
        )
    )
    return view


class MatchSchedulerReplyModal(discord.ui.Modal):
    def __init__(self, schedule_id: str, side: str):
        super().__init__(
            title=f"Reply to {schedule_id}",
            custom_id=f"match_scheduler_modal:{schedule_id}:{side}",
        )
        self.schedule_id = schedule_id
        self.side = side
        self.reply_text = discord.ui.TextInput(
            label="Your scheduling reply",
            placeholder="Give your availability or a message for your opponent.",
            style=discord.TextStyle.paragraph,
            min_length=1,
            max_length=1800,
        )
        self.add_item(self.reply_text)

    async def on_submit(self, interaction: discord.Interaction):
        record = _scheduler_record_for_id(self.schedule_id)
        if not record or record.get("status") != "active":
            await interaction.response.send_message(
                "This scheduling thread is no longer active.", ephemeral=True
            )
            return
        permitted = {
            int(record.get("player_one_user_id") or 0),
            int(record.get("player_two_user_id") or 0),
        }
        if interaction.user.id not in permitted and not _match_scheduler_staff(
            interaction.user
        ):
            await interaction.response.send_message(
                "You are not a participant in this scheduling thread.",
                ephemeral=True,
            )
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        thread = client.get_channel(int(record["thread_id"]))
        if thread is None:
            thread = await client.fetch_channel(int(record["thread_id"]))
        text = " ".join(str(self.reply_text.value).split())[:1800]
        participant_ids = [
            int(user_id)
            for user_id in (
                record.get("player_one_user_id"),
                record.get("player_two_user_id"),
            )
            if user_id
        ]
        recipient_ids = [
            user_id
            for user_id in participant_ids
            if user_id != int(interaction.user.id)
        ]
        recipient_mentions = " ".join(
            f"<@{user_id}>" for user_id in recipient_ids
        )
        author_name = getattr(
            interaction.user,
            "display_name",
            getattr(interaction.user, "name", "Participant"),
        )
        thread_message = f"**{author_name}:**"
        if recipient_mentions:
            thread_message += f" {recipient_mentions}"
        thread_message += f" {text}"
        sent = await thread.send(
            thread_message,
            allowed_mentions=discord.AllowedMentions(
                users=True,
                roles=False,
                everyone=False,
            ),
        )
        await _log_match_scheduler_message(
            record,
            author=interaction.user,
            content=text,
            message_id=getattr(sent, "id", None),
            source="reply",
            created_at=getattr(sent, "created_at", None),
        )
        await _send_match_scheduler_reply_dms(
            record,
            author_id=interaction.user.id,
            author_name=interaction.user.display_name,
            text=text,
        )
        await interaction.edit_original_response(
            content="Your reply was added to the private scheduling thread."
        )


async def _log_match_scheduler_message(
    record,
    *,
    author,
    content: str,
    message_id: int | None = None,
    source: str = "thread",
    attachments: list[str] | None = None,
    created_at: datetime | None = None,
) -> None:
    if message_id is not None and message_id in _match_scheduler_logged_message_ids:
        return
    log_channel = client.get_channel(MATCH_SCHEDULING_LOG_CHANNEL_ID)
    if log_channel is None:
        log_channel = await client.fetch_channel(MATCH_SCHEDULING_LOG_CHANNEL_ID)
    body = " ".join(str(content or "").split()) or "(no text)"
    timestamp = created_at or datetime.now(timezone.utc)
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=timezone.utc)
    timestamp = timestamp.astimezone(timezone.utc)
    discord_timestamp = int(timestamp.timestamp())
    attachment_text = ""
    if attachments:
        attachment_text = "\n**Attachments:** " + " ".join(attachments)
    await log_channel.send(
        _scheduler_thread_link(record)
        + f"💬 **{record['player_one']} vs {record['player_two']} — {source}**\n"
        f"**Time:** <t:{discord_timestamp}:F> "
        f"(<t:{discord_timestamp}:R>)\n"
        f"**From:** {getattr(author, 'display_name', getattr(author, 'name', author))}\n"
        f"**Message:** {body[:1700]}"
        f"{attachment_text[:500]}",
        allowed_mentions=discord.AllowedMentions.none(),
    )
    if message_id is not None:
        _match_scheduler_logged_message_ids.add(int(message_id))


async def _route_match_scheduler_message(message) -> bool:
    if not isinstance(message.channel, discord.Thread):
        return False
    if message.channel.parent_id != MATCH_SCHEDULER_CHANNEL_ID:
        return False
    record = _scheduler_record_for_thread(message.channel.id)
    if record is None or record.get("status") != "active":
        return False
    try:
        await _log_match_scheduler_message(
            record,
            author=message.author,
            content=message.content,
            message_id=message.id,
            attachments=[attachment.url for attachment in message.attachments],
            created_at=getattr(message, "created_at", None),
        )
        if not message.author.bot:
            await _send_match_scheduler_reply_dms(
                record,
                author_id=message.author.id,
                author_name=message.author.display_name,
                text=message.content or "(attachment)",
            )
    except Exception as exc:
        print(
            f"[Match scheduler] could not log {message.id}: {exc}",
            flush=True,
        )
    return True


async def _finalize_match_scheduler(
    record: dict[str, typing.Any],
    *,
    source: str,
    completed_by: int | None = None,
) -> None:
    if record.get("status") != "active" or record.get("_finalizing"):
        return
    schedule_id = str(record["schedule_id"])
    completed_at = datetime.now(timezone.utc)
    record["_finalizing"] = True
    try:
        thread = client.get_channel(int(record["thread_id"]))
        if thread is not None:
            try:
                await _transcribe_match_scheduler_thread(record, thread)
                await thread.edit(
                    archived=True,
                    locked=True,
                    reason=f"{schedule_id} completed",
                )
            except (discord.NotFound, discord.Forbidden, discord.HTTPException) as exc:
                print(f"[Match scheduler] thread close failed: {exc}", flush=True)

        record["status"] = "completed"
        record["completed_by"] = completed_by
        record["completed_at"] = completed_at
        values = {
            "status": "completed",
            "completed_at": completed_at,
        }
        if completed_by is not None:
            values["completed_by"] = completed_by
        await asyncio.to_thread(update_match_schedule, schedule_id, **values)
        _match_scheduler_thread_index.pop(int(record["thread_id"]), None)
    finally:
        record.pop("_finalizing", None)


async def _transcribe_match_scheduler_thread(record, thread) -> None:
    """Copy every retained thread message before the conversation is closed."""
    history = getattr(thread, "history", None)
    if history is None:
        return
    async for message in history(limit=None, oldest_first=True):
        await _log_match_scheduler_message(
            record,
            author=message.author,
            content=message.content,
            message_id=getattr(message, "id", None),
            attachments=[
                attachment.url for attachment in getattr(message, "attachments", [])
            ],
            created_at=getattr(message, "created_at", None),
        )


async def _upsert_match_scheduler_panel() -> None:
    await client.wait_until_ready()
    try:
        channel = client.get_channel(MATCH_SCHEDULER_CHANNEL_ID)
        if channel is None:
            channel = await client.fetch_channel(MATCH_SCHEDULER_CHANNEL_ID)
        stored = await asyncio.to_thread(
            load_bot_message,
            MATCH_SCHEDULER_PANEL_KEY,
        )
        existing = None
        if stored and stored[0] == MATCH_SCHEDULER_CHANNEL_ID:
            try:
                existing = await channel.fetch_message(stored[1])
            except discord.NotFound:
                existing = None
        if existing is None:
            async for message in channel.history(limit=100):
                if (
                    getattr(message.author, "id", None)
                    == getattr(client.user, "id", None)
                    and any(
                        getattr(component, "custom_id", None)
                        == MATCH_SCHEDULER_BUTTON_ID
                        for row in getattr(message, "components", [])
                        for component in (
                            getattr(row, "children", None)
                            or getattr(row, "components", None)
                            or [row]
                        )
                    )
                ):
                    existing = message
                    break
        view = MatchSchedulerView()
        if existing is None:
            existing = await channel.send(
                content="\u200b",
                view=view,
            )
        else:
            await existing.edit(content="\u200b", embed=None, view=view)
        await asyncio.to_thread(
            save_bot_message,
            MATCH_SCHEDULER_PANEL_KEY,
            MATCH_SCHEDULER_CHANNEL_ID,
            existing.id,
        )
    except Exception as exc:
        print(f"[Match scheduler] panel update failed: {exc}", flush=True)


def _has_legacy_match_completion_control(message) -> bool:
    if "Match completed" in str(getattr(message, "content", "") or ""):
        return True
    for row in getattr(message, "components", []) or []:
        for component in (
            getattr(row, "children", None)
            or getattr(row, "components", None)
            or [row]
        ):
            if str(getattr(component, "custom_id", "")).startswith(
                "match_scheduler:complete:"
            ):
                return True
    return False


async def _remove_legacy_match_completion_controls(records) -> None:
    """Remove manual-completion UI left on threads created by older revisions."""
    for record in records:
        thread_id = record.get("thread_id")
        if not thread_id:
            continue
        try:
            thread = client.get_channel(int(thread_id))
            if thread is None:
                thread = await client.fetch_channel(int(thread_id))
            async for message in thread.history(limit=100):
                if (
                    getattr(getattr(message, "author", None), "id", None)
                    != getattr(client.user, "id", None)
                    or not _has_legacy_match_completion_control(message)
                ):
                    continue
                content = str(getattr(message, "content", "") or "")
                content = re.sub(
                    r"\s*When the match is complete, press "
                    r"\*\*Match completed\*\*\.\s*",
                    "\n",
                    content,
                ).strip()
                await message.edit(content=content or "\u200b", view=None)
        except (discord.NotFound, discord.Forbidden, discord.HTTPException) as exc:
            print(
                f"[Match scheduler] legacy completion cleanup failed for "
                f"{record.get('schedule_id')}: {exc}",
                flush=True,
            )


async def _start_match_scheduler() -> None:
    if not getattr(client, "_match_scheduler_view_started", False):
        client.add_view(MatchSchedulerView())
        client._match_scheduler_view_started = True
        print("[Match scheduler] persistent panel view registered", flush=True)
    try:
        if not _matchlog_identity_index:
            _matchlog_identity_index.update(
                await asyncio.to_thread(load_matchlog_identities)
            )
        records = await asyncio.to_thread(load_match_schedules, "active")
    except Exception as exc:
        print(f"[Match scheduler] state load failed: {exc}", flush=True)
        records = []
    for record in records:
        if record.get("thread_id"):
            _match_scheduler_records[str(record["schedule_id"])] = record
            _match_scheduler_thread_index[int(record["thread_id"])] = str(
                record["schedule_id"]
            )
    await _remove_legacy_match_completion_controls(records)
    await _upsert_match_scheduler_panel()
    if not getattr(client, "_match_scheduler_completion_started", False):
        client._match_scheduler_completion_started = True
        asyncio.create_task(_match_scheduler_completion_loop())


# Real fixture outreach is enabled by default. It can still be explicitly
# disabled for maintenance with FIXTURE_OUTREACH_ENABLED=false.
FIXTURE_OUTREACH_ENABLED = (
    os.environ.get("FIXTURE_OUTREACH_ENABLED", "true").lower()
    not in {"false", "0", "no"}
)
ONE_TIME_OUTREACH_DEADLINE = datetime(
    2026, 9, 9, 19, tzinfo=timezone.utc
).timestamp()  # 20:00 BST on 9 September 2026
COMMENTARY_RETRY_VERSION = 3
OUTREACH_GUILD_ID = 786583939028090881
OUTREACH_CHANNEL_ID = 812742338669576252
FAKE_OUTREACH_KEY = "test:squeaky-vs-squeaky:v1"
OUTREACH_STARTUP_DELAY_SECONDS = 30
_outreach_state = OutreachState(
    load_backend=load_outreach_state,
    save_backend=save_outreach_state,
)
_outreach_deadline_tasks: dict[str, asyncio.Task] = {}
_outreach_preexisting_fixture_keys: set[str] = set()
_outreach_repair_complete = False
DEADLINE_REMINDER_CHANNEL_ID = 1247199135438999553
DEADLINE_REMINDER_GUILD_ID = OUTREACH_GUILD_ID
_deadline_reminder_state = DeadlineReminderState()


def _outreach_operation_ref(key: str, suffix: str) -> str:
    digest = hashlib.sha256(f"{key}|{suffix}".encode("utf8")).hexdigest()[:10].upper()
    return digest


def _outreach_nonce(reference: str) -> str:
    """Stable Discord nonce used as an additional same-session identifier."""
    return hashlib.sha256(reference.encode("utf8")).hexdigest()[:20]


def _outreach_hidden_marker(reference: str) -> str:
    """Encode a durable recovery reference with zero-width Unicode characters."""
    bits = "".join(f"{byte:08b}" for byte in reference.encode("utf8"))
    encoded = "".join("\u200b" if bit == "0" else "\u200c" for bit in bits)
    return f"\u2063\u2063{encoded}\u2063"


async def _find_message_with_ref(
    channel, reference: str, *, after: datetime | None = None
):
    if channel is None or not hasattr(channel, "history"):
        return None
    expected_nonce = _outreach_nonce(reference)
    hidden_marker = _outreach_hidden_marker(reference)
    history_kwargs = {"limit": 100}
    if after is not None:
        history_kwargs = {"limit": None, "after": after, "oldest_first": True}
    async for message in channel.history(**history_kwargs):
        if (
            (
                str(getattr(message, "nonce", "") or "") == expected_nonce
                or hidden_marker in (getattr(message, "content", "") or "")
                or reference in (getattr(message, "content", "") or "")
            )
            and getattr(getattr(message, "author", None), "id", None) == client.user.id
        ):
            return message
    return None


async def _reconcile_dm_prompt(
    member,
    prompt: dict,
    *,
    allow_semantic_fallback: bool = True,
) -> bool:
    operation_ref = prompt["operation_ref"]
    side = prompt.get("side")
    if side not in {"side1", "side2"}:
        return False
    channel = getattr(member, "dm_channel", None)
    if channel is None and hasattr(member, "create_dm"):
        channel = await member.create_dm()
    started_at = None
    try:
        started_at = datetime.fromisoformat(prompt.get("send_started_at", ""))
    except (TypeError, ValueError):
        # A fresh deployment has no local ledger timestamp. Search the full DM
        # history so an earlier deployment's deterministic marker still wins.
        started_at = datetime(2015, 1, 1, tzinfo=timezone.utc)
    button_ref = f"dm:{operation_ref}:button"
    found = await _find_message_with_ref(channel, button_ref, after=started_at)
    if not found:
        found = await _find_message_with_ref(
            channel, f"dm:{operation_ref}", after=started_at
        )
    if not found:
        # Backward compatibility for prompts sent before invisible nonces.
        found = await _find_message_with_ref(
            channel, f"Outreach ref: {operation_ref}"
        )
    if not found and allow_semantic_fallback:
        # A previous deployment may have used a different recovery reference
        # for the same fixture. Match the human-visible prompt exactly so a
        # replacement VM reuses it instead of sending a duplicate 15 minutes
        # later.
        fixture = prompt.get("fixture") or {}
        expected_lines = [
            f"**Pre-match outreach — {side.replace('side', 'Side ')}**",
            (
                f"**Match:** {fixture.get('first_name')} vs "
                f"{fixture.get('second_name')}"
            ),
            (
                f"**Tournament:** "
                f"{fixture.get('tournament') or 'WTSL fixture'}"
            ),
        ]
        if fixture and channel is not None and hasattr(channel, "history"):
            semantic_matches = []
            async for message in channel.history(limit=100):
                content = getattr(message, "content", "") or ""
                visible_lines = content.splitlines()
                if (
                    getattr(getattr(message, "author", None), "id", None)
                    == client.user.id
                    and visible_lines[:3] == expected_lines
                ):
                    semantic_matches.append(message)
            if semantic_matches:
                found = semantic_matches[0]
    if not found:
        return False
    if not _message_has_outreach_button(found, operation_ref, side):
        view = _outreach_reply_view(operation_ref, side)
        try:
            await found.edit(view=view)
        except Exception as exc:
            # Some legacy DMs cannot be edited after a library/API transition.
            # The button-specific marker makes this replacement one-and-done.
            try:
                found = await member.send(
                    f"**Pre-match outreach — {side.replace('side', 'Side ')}**\n"
                    "Use **Reply with thoughts** below to submit your response."
                    + _outreach_hidden_marker(button_ref),
                    view=view,
                    nonce=_outreach_nonce(button_ref),
                )
            except (discord.HTTPException, discord.Forbidden, asyncio.TimeoutError):
                print(
                    f"[Outreach] could not repair legacy prompt {operation_ref}: {exc}",
                    flush=True,
                )
                return False
    prompt.update({"status": "awaiting_reply", "message_id": found.id})
    prompt.pop("last_error", None)
    return True


async def _publish_match_preview(preview_data: dict, destination) -> object:
    """Shared native-thread publisher for slash and automated previews."""
    preview = format_match_preview(preview_data)
    chunks = split_discord_message(preview)
    # Creation is intentionally outside the send-error annotation: no preview
    # content is public until the thread exists.
    thread = await destination.create_thread(
        name=_matchpreview_thread_name(
            preview_data["first"]["name"], preview_data["second"]["name"]
        ),
        type=discord.ChannelType.public_thread,
    )
    embeds = _matchpreview_avatar_embeds(preview_data)
    posted_message_count = 0
    try:
        for index, chunk in enumerate(chunks):
            prefix = "" if index == 0 else f"**Match preview continued ({index + 1}/{len(chunks)})**\n"
            await thread.send(
                prefix + chunk, embeds=embeds if index == 0 else [],
                allowed_mentions=discord.AllowedMentions.none(),
            )
            posted_message_count += 1
        poll_names = (
            (f"{preview_data['first']['name']} (Side 1)", f"{preview_data['second']['name']} (Side 2)")
            if preview_data.get("same_player_test") else
            (preview_data["first"]["name"], preview_data["second"]["name"])
        )
        await thread.send(
            poll=_matchpreview_winner_poll(*poll_names),
            allowed_mentions=discord.AllowedMentions.none(),
        )
        posted_message_count += 1
    except discord.HTTPException as exc:
        exc.matchpreview_posted_message_count = posted_message_count
        raise
    return thread


async def _reconcile_preview_thread(destination, item: dict, operation_ref: str):
    stored_id = item.get("thread_id")
    if stored_id:
        stored = client.get_channel(stored_id)
        if stored is None and hasattr(destination, "get_thread"):
            stored = destination.get_thread(stored_id)
        if stored is not None:
            return stored
    expected = _matchpreview_thread_name(
        item["fixture"]["first_name"], item["fixture"]["second_name"]
    )
    started = datetime.fromisoformat(item["publishing_started_at"])
    candidates = []
    for thread in getattr(destination, "threads", []):
        created = getattr(thread, "created_at", None)
        if (
            getattr(thread, "name", None) != expected
            or getattr(thread, "owner_id", None) != client.user.id
            or created is None
            or created < started - timedelta(minutes=5)
            or created > started + timedelta(minutes=30)
        ):
            continue
        messages = []
        if hasattr(thread, "history"):
            messages = [message async for message in thread.history(limit=100)]
        first_unit_ref = f"{operation_ref}:chunk:0"
        if messages and not any(
            operation_ref in (getattr(message, "content", "") or "")
            or _outreach_hidden_marker(first_unit_ref)
            in (getattr(message, "content", "") or "")
            or str(getattr(message, "nonce", "") or "") == _outreach_nonce(first_unit_ref)
            for message in messages
        ):
            continue
        candidates.append(thread)
    if len(candidates) > 1:
        raise RuntimeError(
            f"ambiguous outreach thread reconciliation for {operation_ref}; refusing duplicate"
        )
    return candidates[0] if candidates else None


async def _publish_automated_match_preview(
    preview_data: dict, destination, key: str
) -> object:
    """Crash-resumable automated publisher; slash publishing stays uncomplicated."""
    item = _outreach_state.data["fixtures"][key]
    operation_ref = item["publish_operation_ref"]
    thread = await _reconcile_preview_thread(destination, item, operation_ref)
    if thread is None:
        thread = await destination.create_thread(
            name=_matchpreview_thread_name(
                preview_data["first"]["name"], preview_data["second"]["name"]
            ),
            type=discord.ChannelType.public_thread,
        )
        await _outreach_state.update(key, thread_id=thread.id)
    elif not item.get("thread_id"):
        await _outreach_state.update(key, thread_id=thread.id)

    preview = format_match_preview(preview_data)
    # Reserve room for the continuation prefix and durable zero-width marker.
    chunks = split_discord_message(preview, limit=1600)
    embeds = _matchpreview_avatar_embeds(preview_data)
    sent_units = item.setdefault("sent_units", {})
    for index, chunk in enumerate(chunks):
        unit = f"chunk:{index}"
        unit_ref = f"{operation_ref}:{unit}"
        if unit not in sent_units:
            found = await _find_message_with_ref(thread, unit_ref)
            if found:
                sent_units[unit] = found.id
                await _outreach_state.update(key, sent_units=sent_units)
            else:
                prefix = "" if index == 0 else f"**Match preview continued ({index + 1}/{len(chunks)})**\n"
                sent = await thread.send(
                    prefix + chunk + _outreach_hidden_marker(unit_ref),
                    embeds=embeds if index == 0 else [],
                    allowed_mentions=discord.AllowedMentions.none(),
                    nonce=_outreach_nonce(unit_ref),
                )
                sent_units[unit] = sent.id
                await _outreach_state.update(key, sent_units=sent_units)

    poll_ref = f"{operation_ref}:poll"
    if not item.get("poll_message_id"):
        found = await _find_message_with_ref(thread, poll_ref)
        if found:
            await _outreach_state.update(key, poll_message_id=found.id)
        else:
            poll_names = (
                (f"{preview_data['first']['name']} (Side 1)", f"{preview_data['second']['name']} (Side 2)")
                if preview_data.get("same_player_test") else
                (preview_data["first"]["name"], preview_data["second"]["name"])
            )
            sent = await thread.send(
                _outreach_hidden_marker(poll_ref),
                poll=_matchpreview_winner_poll(*poll_names),
                allowed_mentions=discord.AllowedMentions.none(),
                nonce=_outreach_nonce(poll_ref),
            )
            await _outreach_state.update(key, poll_message_id=sent.id)
    return thread


def _outreach_reply_view(operation_ref: str, side: str) -> discord.ui.View:
    """Create a restart-safe button; routing is handled by on_interaction."""
    view = discord.ui.View(timeout=None)
    view.add_item(
        discord.ui.Button(
            label="Reply with thoughts",
            style=discord.ButtonStyle.primary,
            custom_id=f"outreach_reply:{operation_ref}:{side}",
        )
    )
    return view


def _message_has_outreach_button(message, operation_ref: str, side: str) -> bool:
    expected = f"outreach_reply:{operation_ref}:{side}"
    for row in getattr(message, "components", []) or []:
        children = getattr(row, "children", None)
        if children is None:
            children = getattr(row, "components", None)
        for component in children or [row]:
            if getattr(component, "custom_id", None) == expected:
                return True
    return False


def _outreach_reply_choices_view(choices) -> discord.ui.View:
    """Render each active prompt as an explicit side-specific modal button."""
    view = discord.ui.View(timeout=None)
    for key, side, prompt in choices[:25]:
        item = _outreach_state.data["fixtures"][key]
        fixture = item.get("fixture", {})
        match = (
            f"{fixture.get('first_name', '?')} vs "
            f"{fixture.get('second_name', '?')}"
        )
        view.add_item(
            discord.ui.Button(
                label=f"{side.replace('side', 'Side ')} — {match}"[:80],
                style=discord.ButtonStyle.primary,
                custom_id=(
                    f"outreach_reply:{prompt['operation_ref']}:{side}"
                ),
            )
        )
    return view


def _find_outreach_prompt(operation_ref: str, side: str, member_id: int):
    for key, item in _outreach_state.data.get("fixtures", {}).items():
        if item.get("published"):
            continue
        prompt = item.get("prompts", {}).get(side, {})
        if (
            prompt.get("operation_ref") == operation_ref
            and prompt.get("member_id") == member_id
        ):
            return key, item, prompt
    return None


class _OutreachThoughtsModal(discord.ui.Modal):
    def __init__(self, operation_ref: str, side: str):
        side_label = side.replace("side", "Side ")
        super().__init__(
            title=f"Pre-match thoughts — {side_label}",
            custom_id=f"outreach_modal:{operation_ref}:{side}",
        )
        self.operation_ref = operation_ref
        self.side = side
        self.thoughts = discord.ui.TextInput(
            label="Your pre-match thoughts",
            style=discord.TextStyle.paragraph,
            placeholder="What are you expecting from the match?",
            min_length=1,
            max_length=1800,
        )
        self.add_item(self.thoughts)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        selected = _find_outreach_prompt(
            self.operation_ref, self.side, interaction.user.id
        )
        if selected is None:
            await interaction.response.send_message(
                "This pre-match prompt is no longer active.", ephemeral=True
            )
            return
        key, item, prompt = selected
        await interaction.response.defer(ephemeral=True, thinking=True)
        reply = " ".join(str(self.thoughts.value).strip().split())[:1800]
        try:
            prompt["reply"] = reply
            prompt["reply_interaction_id"] = interaction.id
            await _outreach_state.update(key, prompts=item["prompts"])
        except Exception:
            prompt.pop("reply", None)
            prompt.pop("reply_interaction_id", None)
            await interaction.edit_original_response(
                content="I couldn't save that response. Please try the button again."
            )
            return
        await interaction.edit_original_response(
            content=(
                f"Thanks — your {self.side.replace('side', 'Side ')} thoughts "
                "are recorded."
            )
        )
        if all(item["prompts"].get(name, {}).get("reply") for name in ("side1", "side2")):
            try:
                await _publish_outreach(key)
            except Exception as exc:
                print(f"[Outreach] publish deferred after modal reply: {exc}", flush=True)


@client.event
async def on_interaction(interaction: discord.Interaction):
    """Route persistent scheduling and pre-match response component buttons."""
    if interaction.type is not discord.InteractionType.component:
        return
    custom_id = str((interaction.data or {}).get("custom_id", ""))
    if custom_id == "wtsl_bet:v1:parlay":
        await _show_wtsl_parlay_builder(interaction)
        return
    if custom_id == "wtsl_bet:v1:balance":
        await _show_wtsl_balance(interaction)
        return
    if custom_id == "wtsl_bet:v1:ledger":
        await _show_wtsl_ledger(interaction)
        return
    if custom_id == "wtsl_bet:v1:refer":
        await interaction.response.send_modal(WTSLReferralModal())
        return
    if custom_id == "wtsl_bet:v1:referral_modal":
        await interaction.response.send_modal(WTSLReferralModal())
        return
    betting_button = re.fullmatch(
        r"wtsl_bet:v1:([0-9a-f]{16}):(one|two)",
        custom_id,
    )
    if betting_button:
        token, side = betting_button.groups()
        # Discord requires the component response within a few seconds. Use
        # the fixture snapshot already rendered into the button message so the
        # modal can open immediately. Verification, balance, reserve capacity,
        # and authoritative fixture state are checked after modal submission.
        fixture_key_value = _betting_fixture_tokens.get(token)
        fixture = _betting_fixtures_by_token.get(token)
        if not fixture or fixture.get("status") != "open":
            if not interaction.response.is_done():
                await interaction.response.defer(ephemeral=True, thinking=True)
            if not fixture_key_value:
                try:
                    open_fixtures = await asyncio.to_thread(
                        list_open_betting_fixtures
                    )
                    _remember_betting_fixtures(open_fixtures)
                    fixture_key_value = _betting_fixture_tokens.get(token)
                    fixture = _betting_fixtures_by_token.get(token)
                except Exception as exc:
                    print(
                        f"[WTSL Betting] button fixture lookup failed: {exc}",
                        flush=True,
                    )
            await interaction.followup.send(
                "That fixture is no longer open for betting.",
                ephemeral=True,
            )
            return
        await interaction.response.send_modal(WTSLBetModal(fixture, side))
        return
    scheduler_offer = re.fullmatch(
        rf"{re.escape(MATCH_SCHEDULER_OFFER_PREFIX)}([^:]+):([^:]+)",
        custom_id,
    )
    if scheduler_offer:
        await _route_match_scheduler_offer(
            interaction,
            scheduler_offer.group(1),
            scheduler_offer.group(2),
        )
        return
    scheduler_reply = re.fullmatch(
        rf"{re.escape(MATCH_SCHEDULER_REPLY_PREFIX)}(MS-[A-Z0-9-]+):(side[12]|test)",
        custom_id,
    )
    if scheduler_reply:
        schedule_id, side = scheduler_reply.groups()
        record = _scheduler_record_for_id(schedule_id)
        if not record or record.get("status") != "active":
            await interaction.response.send_message(
                "This scheduling thread is no longer active.", ephemeral=True
            )
            return
        permitted = {
            int(record.get("player_one_user_id") or 0),
            int(record.get("player_two_user_id") or 0),
        }
        if interaction.user.id not in permitted and not _match_scheduler_staff(
            interaction.user
        ):
            await interaction.response.send_message(
                "You are not a participant in this scheduling thread.",
                ephemeral=True,
            )
            return
        await interaction.response.send_modal(
            MatchSchedulerReplyModal(schedule_id, side)
        )
        return
    match = re.fullmatch(r"outreach_reply:([A-F0-9]{10}):(side[12])", custom_id)
    if not match:
        return
    operation_ref, side = match.groups()
    if _find_outreach_prompt(operation_ref, side, interaction.user.id) is None:
        await interaction.response.send_message(
            "This pre-match prompt is no longer active.", ephemeral=True
        )
        return
    await interaction.response.send_modal(_OutreachThoughtsModal(operation_ref, side))


async def _start_outreach_response_clock_if_ready(key: str) -> None:
    """Cap publication at 12 hours after both player prompts are delivered."""
    item = _outreach_state.data["fixtures"][key]
    if item.get("outreach_completed_at"):
        return
    prompts = item.get("prompts") or {}
    if not all(
        prompts.get(side, {}).get("message_id")
        and (
            prompts.get(side, {}).get("status") == "awaiting_reply"
            or prompts.get(side, {}).get("reply")
        )
        for side in ("side1", "side2")
    ):
        return
    completed_at = datetime.now(timezone.utc).timestamp()
    response_cutoff = completed_at + 12 * 3600
    draw_cutoff = item.get("draw_publish_cutoff")
    fixed_cutoff = item.get("one_time_publish_deadline")
    deadlines = [response_cutoff]
    if isinstance(draw_cutoff, (int, float)):
        deadlines.append(float(draw_cutoff))
    if isinstance(fixed_cutoff, (int, float)):
        deadlines.append(float(fixed_cutoff))
    deadline = min(deadlines)
    await _outreach_state.update(
        key,
        outreach_completed_at=completed_at,
        deadline=deadline,
    )
    _schedule_outreach_deadline(key)


async def _publish_outreach_at_deadline(
    key: str,
    expected_deadline: float,
) -> None:
    try:
        await asyncio.sleep(max(
            0.0,
            expected_deadline - datetime.now(timezone.utc).timestamp(),
        ))
        item = _outreach_state.data.get("fixtures", {}).get(key)
        if (
            item
            and not item.get("published")
            and item.get("deadline") == expected_deadline
        ):
            await _publish_outreach(key)
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        print(f"[Outreach] deadline publish failed for {key}: {exc}", flush=True)


def _schedule_outreach_deadline(key: str) -> None:
    item = _outreach_state.data.get("fixtures", {}).get(key) or {}
    deadline = item.get("deadline")
    if key == FAKE_OUTREACH_KEY or not isinstance(deadline, (int, float)):
        return
    current = _outreach_deadline_tasks.get(key)
    if current and not current.done():
        current.cancel()
    task = asyncio.create_task(_publish_outreach_at_deadline(key, deadline))
    _outreach_deadline_tasks[key] = task

    def discard(completed: asyncio.Task) -> None:
        if _outreach_deadline_tasks.get(key) is completed:
            _outreach_deadline_tasks.pop(key, None)

    task.add_done_callback(discard)


async def _send_outreach_prompt(key: str, side: str, member) -> None:
    """Record send intent first: an interrupted process never duplicates a DM."""
    item = _outreach_state.data["fixtures"][key]
    prompt = item["prompts"].setdefault(side, {"member_id": member.id})
    if prompt.get("member_id") != member.id:
        # A display-name match can move to a new Discord account after a
        # restart. Never let stale state suppress outreach to the new member.
        prompt.clear()
        prompt["member_id"] = member.id
    prompt.setdefault("operation_ref", _outreach_operation_ref(key, f"dm:{side}"))
    prompt["side"] = side
    prompt["fixture"] = item["fixture"]
    force_new = bool(prompt.get("force_new"))
    attempts = int(prompt.get("attempts", 0))
    if await _reconcile_dm_prompt(
        member,
        prompt,
        allow_semantic_fallback=not force_new,
    ):
        prompt.pop("force_new", None)
        await _outreach_state.update(key, prompts=item["prompts"])
        await _start_outreach_response_clock_if_ready(key)
        player_key = "first_name" if side == "side1" else "second_name"
        print(
            f"[Outreach] reconciled {side} prompt for "
            f"{item['fixture'].get(player_key, member.id)} "
            f"(Discord member {member.id})",
            flush=True,
        )
        return
    if prompt.get("message_id") or prompt.get("status") == "awaiting_reply":
        if await _reconcile_dm_prompt(
            member,
            prompt,
            allow_semantic_fallback=not force_new,
        ):
            prompt.pop("force_new", None)
            await _outreach_state.update(key, prompts=item["prompts"])
            await _start_outreach_response_clock_if_ready(key)
            print(
                f"[Outreach] reconciled {side} prompt for Discord member "
                f"{member.id}",
                flush=True,
            )
            return
        # The ledger says a DM exists, but Discord cannot find it. Treat the
        # stale state as retryable instead of silently skipping the player.
        prompt.pop("message_id", None)
        prompt["status"] = "failed"
        prompt["failed_at"] = datetime.now(timezone.utc).isoformat()
        await _outreach_state.update(key, prompts=item["prompts"])
        attempts = int(prompt.get("attempts", 0))
    if prompt.get("status") in {"send_started", "failed"}:
        if await _reconcile_dm_prompt(
            member,
            prompt,
            allow_semantic_fallback=not force_new,
        ):
            prompt.pop("force_new", None)
            await _outreach_state.update(key, prompts=item["prompts"])
            await _start_outreach_response_clock_if_ready(key)
            return
        stamp = prompt.get("send_started_at") or prompt.get("failed_at")
        try:
            age = (datetime.now(timezone.utc) - datetime.fromisoformat(stamp)).total_seconds()
        except (TypeError, ValueError):
            age = 10 * 60
        if age < 10 * 60 or attempts >= 3:
            return
    if attempts >= 3:
        return
    prompt["status"] = "send_started"
    prompt["attempts"] = attempts + 1
    prompt["send_started_at"] = datetime.now(timezone.utc).isoformat()
    await _outreach_state.update(key, prompts=item["prompts"])
    try:
        side_label = side.replace("side", "Side ")
        button_ref = f"dm:{prompt['operation_ref']}:button"
        sent = await member.send(
            f"**Pre-match outreach — {side_label}**\n"
            f"**Match:** {item['fixture']['first_name']} vs {item['fixture']['second_name']}\n"
            f"**Tournament:** {item['fixture'].get('tournament') or 'WTSL fixture'}\n"
            "Select **Reply with thoughts** below to open a response box. "
            "Your response may be used verbatim in the Match Preview."
            + _outreach_hidden_marker(button_ref),
            view=_outreach_reply_view(prompt["operation_ref"], side),
            nonce=_outreach_nonce(button_ref),
        )
    except (discord.HTTPException, discord.Forbidden, asyncio.TimeoutError) as exc:
        if await _reconcile_dm_prompt(member, prompt):
            await _outreach_state.update(key, prompts=item["prompts"])
            await _start_outreach_response_clock_if_ready(key)
            return
        prompt.update({
            "status": "failed", "last_error": str(exc)[:300],
            "failed_at": datetime.now(timezone.utc).isoformat(),
        })
        await _outreach_state.update(key, prompts=item["prompts"])
        print(f"[Outreach] prompt failed for {side}: {exc}", flush=True)
        return
    prompt.update({"status": "awaiting_reply", "message_id": sent.id})
    prompt.pop("force_new", None)
    await _outreach_state.update(key, prompts=item["prompts"])
    await _start_outreach_response_clock_if_ready(key)
    print(f"[Outreach] sent {side} prompt to Discord member {member.id}", flush=True)


async def _outreach_guild_members(guild) -> list:
    """Merge the startup cache with Discord's full member list when available."""
    members = {
        getattr(member, "id", id(member)): member
        for member in list(getattr(guild, "members", []))
    }
    if hasattr(guild, "fetch_members"):
        try:
            async for member in guild.fetch_members(limit=None):
                members[getattr(member, "id", id(member))] = member
        except Exception as exc:
            print(f"[Outreach] full member fetch unavailable; using cache: {exc}", flush=True)
    return list(members.values())


def _resolve_outreach_member(members: list, player_name: str):
    """Resolve by exact Discord alias, then by approved WTSL identity binding."""
    member = resolve_member_exact(members, player_name)
    if member is not None:
        return member
    wanted = normalize_matchlog_name(player_name)
    bound_ids = {
        user_id
        for user_id, links in _matchlog_identity_index.items()
        if wanted in {
            normalize_matchlog_name(linked_name)
            for linked_name in links.values()
        }
    }
    matches = [
        candidate
        for candidate in members
        if getattr(candidate, "id", None) in bound_ids
    ]
    return matches[0] if len(matches) == 1 else None


async def _repair_persisted_outreach_prompts(guild, members: list) -> None:
    """Restore buttons for every active prompt, independent of fixture scanning."""
    members_by_id = {
        getattr(member, "id", None): member
        for member in members
        if getattr(member, "id", None) is not None
    }
    for key, item in list(_outreach_state.data.get("fixtures", {}).items()):
        if item.get("published"):
            continue
        prompts_changed = False
        for side, prompt in item.get("prompts", {}).items():
            if prompt.get("reply"):
                continue
            member_id = prompt.get("member_id")
            if not member_id:
                continue
            member = members_by_id.get(member_id)
            if member is None and hasattr(guild, "fetch_member"):
                try:
                    member = await guild.fetch_member(member_id)
                    members_by_id[member_id] = member
                except Exception as exc:
                    print(
                        f"[Outreach] cannot resolve stored member {member_id}: {exc}",
                        flush=True,
                    )
                    continue
            if member is None:
                continue
            operation_ref = prompt.get("operation_ref")
            if not operation_ref:
                prompt["operation_ref"] = _outreach_operation_ref(
                    key, f"dm:{side}"
                )
                prompts_changed = True
            if prompt.get("side") != side:
                prompt["side"] = side
                prompts_changed = True
            before = (prompt.get("status"), prompt.get("message_id"))
            try:
                reconciled = await _reconcile_dm_prompt(member, prompt)
            except Exception as exc:
                print(
                    f"[Outreach] startup repair failed for {key} {side} "
                    f"(member {member_id}): {exc}",
                    flush=True,
                )
                continue
            if reconciled:
                prompts_changed = (
                    prompts_changed
                    or before != (prompt.get("status"), prompt.get("message_id"))
                )
        if prompts_changed:
            await _outreach_state.update(key, prompts=item["prompts"])


def _outreach_draw_match(
    fixture: dict[str, typing.Any],
    draw_matches: list[dict[str, typing.Any]],
):
    wanted = {
        normalize_matchlog_name(fixture.get("first_name")),
        normalize_matchlog_name(fixture.get("second_name")),
    }
    candidates = [
        match
        for match in draw_matches
        if {
            normalize_matchlog_name(player)
            for player in match.get("players") or []
        } == wanted
        and (
            not fixture.get("tournament_id")
            or not match.get("tournament_id")
            or str(match.get("tournament_id")) == str(fixture.get("tournament_id"))
        )
        and isinstance(match.get("deadline"), datetime)
    ]
    return min(candidates, key=lambda match: match["deadline"]) if candidates else None


def _outreach_draw_deadline(
    fixture: dict[str, typing.Any],
    draw_matches: list[dict[str, typing.Any]],
):
    match = _outreach_draw_match(fixture, draw_matches)
    return match.get("deadline") if match else None


def _preview_round(value: typing.Any) -> str:
    normalized = re.sub(r"[^a-z0-9]+", " ", str(value or "").casefold()).strip()
    if re.search(r"\b(?:semi final|semifinal|sf)\b", normalized):
        return "sf"
    if re.search(r"\b(?:quarter final|quarterfinal|qf)\b", normalized):
        return "qf"
    if re.search(r"\b(?:final|f)\b", normalized):
        return "f"
    return normalized


def _match_preview_allowed(preview_data: dict[str, typing.Any]) -> bool:
    """Apply WTSL event-level draw-stage limits before generating a preview."""
    odds = preview_data.get("odds") or {}
    category_value = (
        preview_data.get("event_category")
        or odds.get("event_category")
        or odds.get("tournament")
    )
    category = tournament_category(category_value)
    round_value = (
        preview_data.get("round")
        or odds.get("round")
        or odds.get("tournament")
    )
    round_name = _preview_round(round_value)
    if category == "250":
        return round_name in {"sf", "f"}
    if category in {"500", "1000"} or re.search(
        r"\b(?:grand slam|wimbledon|roland garros|us open|australian open)\b",
        str(category_value or ""),
        re.IGNORECASE,
    ):
        return round_name in {"qf", "sf", "f"}
    return True


def _fixture_preview_allowed(fixture: dict[str, typing.Any]) -> bool:
    return _match_preview_allowed(
        {
            "event_category": fixture.get("event_category"),
            "round": fixture.get("round"),
            "odds": {
                "event_category": fixture.get("event_category"),
                "round": fixture.get("round"),
                "tournament": fixture.get("tournament"),
            },
        }
    )


async def _begin_outreach(fixture: dict, guild, *, members: list | None = None) -> None:
    key = fixture["key"]
    existing = _outreach_state.data.get("fixtures", {}).get(key)
    if existing is not None:
        merged_fixture = {**(existing.get("fixture") or {}), **fixture}
        if merged_fixture != existing.get("fixture"):
            await _outreach_state.update(key, fixture=merged_fixture)
    if not _fixture_preview_allowed(fixture):
        print(
            f"[Outreach] preview skipped before allowed round for "
            f"{fixture.get('tournament')}: {fixture.get('round') or 'unknown round'}",
            flush=True,
        )
        return
    item = await _outreach_state.ensure(key, fixture)
    if item.get("published"):
        return
    one_time_deadline = (
        fixture.get("one_time_publish_deadline")
        or item.get("one_time_publish_deadline")
    )
    try:
        one_time_deadline = (
            float(one_time_deadline)
            if one_time_deadline is not None
            else None
        )
    except (TypeError, ValueError):
        one_time_deadline = None
    draw_deadline = fixture.get("draw_deadline")
    draw_cutoff = None
    if draw_deadline:
        try:
            draw_deadline_at = datetime.fromisoformat(str(draw_deadline))
            if draw_deadline_at.tzinfo is None:
                draw_deadline_at = draw_deadline_at.replace(
                    tzinfo=timezone.utc
                )
            draw_cutoff = (
                draw_deadline_at.astimezone(timezone.utc)
                - timedelta(hours=12)
            ).timestamp()
        except (TypeError, ValueError):
            draw_cutoff = None
    if one_time_deadline is None and draw_cutoff is None:
        print(
            f"[Outreach] no verified draw deadline for {key}; outreach skipped",
            flush=True,
        )
        return
    if one_time_deadline is not None:
        values = {
            "one_time_outreach": True,
            "one_time_publish_deadline": one_time_deadline,
            "deadline": min(
                one_time_deadline,
                draw_cutoff
                if draw_cutoff is not None
                else one_time_deadline,
            ),
        }
        await _outreach_state.update(key, **values)
    elif item.get("draw_publish_cutoff") != draw_cutoff:
        values = {"draw_publish_cutoff": draw_cutoff}
        if not item.get("outreach_completed_at"):
            values["deadline"] = draw_cutoff
        else:
            values["deadline"] = min(
                float(item.get("deadline", draw_cutoff)), draw_cutoff
            )
        await _outreach_state.update(key, **values)
    # Exact matching only. A same-player test gets two independently labelled prompts.
    candidates = members if members is not None else list(getattr(guild, "members", []))
    for side, name in (("side1", fixture["first_name"]), ("side2", fixture["second_name"])):
        member = _resolve_outreach_member(candidates, name)
        if member is None:
            print(
                f"[Outreach] zero or ambiguous Discord match for {name!r}; not DMing",
                flush=True,
            )
            continue
        try:
            await _send_outreach_prompt(key, side, member)
        except Exception as exc:
            print(f"[Outreach] unexpected prompt error for {side}: {exc}")
    _schedule_outreach_deadline(key)


async def _publish_outreach(key: str) -> None:
    item = _outreach_state.data["fixtures"][key]
    if not _fixture_preview_allowed(item.get("fixture") or {}):
        print(
            f"[Outreach] preview publication skipped before allowed round for {key}",
            flush=True,
        )
        return
    if not await _outreach_state.claim_publish(key):
        return
    try:
        item = _outreach_state.data["fixtures"][key]
        if not item.get("publish_operation_ref"):
            await _outreach_state.update(
                key,
                publish_operation_ref=_outreach_operation_ref(key, "publish"),
                publishing_started_at=datetime.now(timezone.utc).isoformat(),
            )
            item = _outreach_state.data["fixtures"][key]
        fixture, prompts = item["fixture"], item["prompts"]
        replies = [prompts.get("side1", {}).get("reply"), prompts.get("side2", {}).get("reply")]
        generated = await collect_match_data(
            fixture["first_name"], fixture["second_name"],
            MATCH_STATS_WORKBOOK,
            allow_same_player=(key == FAKE_OUTREACH_KEY),
        )
        editorial = await generate_match_preview_copy(generated) or {
            "desk": "The Match Preview Desk sees a compelling contest taking shape.",
            "first": "I am ready to compete and will focus on every point.",
            "second": "I am looking forward to the challenge and will bring my best.",
        }
        generated["preview_desk_quote"] = editorial["desk"]
        generated["player_quotes"] = [replies[0] or editorial["first"], replies[1] or editorial["second"]]
        generated["player_quote_sources"] = [
            "Submitted by player" if replies[0] else "Editorial copy (no response received)",
            "Submitted by player" if replies[1] else "Editorial copy (no response received)",
        ]
        generated["same_player_test"] = key == FAKE_OUTREACH_KEY
        channel = client.get_channel(OUTREACH_CHANNEL_ID) or await client.fetch_channel(OUTREACH_CHANNEL_ID)
        thread = await _publish_automated_match_preview(generated, channel, key)
        await _outreach_state.update(key, published=True, publish_status="published", thread_id=thread.id)
    except Exception:
        await _outreach_state.release_publish(key)
        raise


async def _clean_published_outreach_traces() -> None:
    """Remove legacy visible recovery markers from already-published previews."""
    for item in list(_outreach_state.data.get("fixtures", {}).values()):
        thread_id = item.get("thread_id")
        operation_ref = item.get("publish_operation_ref")
        if not item.get("published") or not thread_id or not operation_ref:
            continue
        try:
            thread = client.get_channel(thread_id) or await client.fetch_channel(thread_id)
            async for message in thread.history(limit=100):
                if getattr(getattr(message, "author", None), "id", None) != client.user.id:
                    continue
                original = getattr(message, "content", "") or ""
                cleaned = original.replace(" *(Submitted by player)*", "")
                cleaned = re.sub(
                    rf"\n?\[Outreach {re.escape(operation_ref)} · (?:chunk:\d+|poll)\]",
                    "",
                    cleaned,
                ).strip()
                if cleaned != original:
                    await message.edit(content=cleaned or None)
        except Exception as exc:
            print(
                f"[Outreach] legacy preview cleanup deferred for thread {thread_id}: {exc}",
                flush=True,
            )


async def _route_outreach_reply(message) -> bool:
    """Route an explicit reply or present buttons for every active prompt."""
    if message.guild is not None:
        return False
    choices = []
    repaired_keys = set()
    referenced = getattr(getattr(message, "reference", None), "message_id", None)
    for key, item in _outreach_state.data.get("fixtures", {}).items():
        if item.get("published"):
            continue
        for side, prompt in item.get("prompts", {}).items():
            if prompt.get("member_id") == message.author.id and not prompt.get("reply"):
                if not prompt.get("operation_ref"):
                    prompt["operation_ref"] = _outreach_operation_ref(
                        key, f"dm:{side}"
                    )
                    repaired_keys.add(key)
                if prompt.get("side") != side:
                    prompt["side"] = side
                    repaired_keys.add(key)
                choices.append((key, side, prompt))
    if not choices:
        return False
    for key in repaired_keys:
        await _outreach_state.update(
            key,
            prompts=_outreach_state.data["fixtures"][key]["prompts"],
        )
    selected = next((choice for choice in choices if choice[2].get("message_id") == referenced), None)
    if selected is None:
        await message.channel.send(
            "Choose the correct pre-match prompt below to open its response box.",
            view=_outreach_reply_choices_view(choices),
        )
        return True
    key, side, prompt = selected
    # Preserve the participant's wording while keeping stored/published input
    # bounded below Discord's message limit.
    reply = " ".join((message.content or "").strip().split())[:1800]
    if not reply:
        await message.channel.send("Please reply with your pre-match thoughts in text.")
        return True
    prompt["reply"] = reply
    prompt["reply_message_id"] = message.id
    await _outreach_state.update(key, prompts=_outreach_state.data["fixtures"][key]["prompts"])
    await message.channel.send(f"✅ Thanks — your {side.replace('side', 'Side ')} thoughts are recorded.")
    item = _outreach_state.data["fixtures"][key]
    if all(item["prompts"].get(side, {}).get("reply") for side in ("side1", "side2")):
        try:
            await _publish_outreach(key)
        except Exception as exc:
            print(f"[Outreach] publish deferred after saved reply: {exc}")
            await message.channel.send(
                "✅ Your response is safely recorded. Preview publishing will retry shortly."
            )
    return True


async def _pending_outreach_loop() -> None:
    """Retry publishing and wake at the next exact publication cutoff."""
    while True:
        sleep_seconds = 15 * 60
        try:
            now = datetime.now(timezone.utc).timestamp()
            for key, item in list(_outreach_state.data["fixtures"].items()):
                complete = all(
                    item.get("prompts", {}).get(side, {}).get("reply")
                    for side in ("side1", "side2")
                )
                deadline = item.get("deadline")
                deadline_due = (
                    key != FAKE_OUTREACH_KEY
                    and isinstance(deadline, (int, float))
                    and deadline <= now
                )
                if not item.get("published") and (complete or deadline_due):
                    try:
                        await _publish_outreach(key)
                    except Exception as exc:
                        print(f"[Outreach] pending publish retry failed: {exc}")
                elif (
                    not item.get("published")
                    and key != FAKE_OUTREACH_KEY
                    and isinstance(deadline, (int, float))
                    and deadline > now
                ):
                    sleep_seconds = min(
                        sleep_seconds, max(0.1, deadline - now)
                    )
        except Exception as exc:
            print(f"[Outreach] pending loop error: {exc}")
        await asyncio.sleep(sleep_seconds)


async def _fixture_outreach_loop() -> None:
    """Repeat homepage scanning after the deliberate immediate startup scan."""
    while True:
        await asyncio.sleep(15 * 60)
        try:
            await _scan_fixture_outreach_once()
        except Exception as exc:
            print(f"[Outreach] scanner error: {exc}")


def _outreach_draw_deadline(
    fixture: dict[str, typing.Any],
    draw_matches: list[dict[str, typing.Any]],
):
    match = _outreach_draw_match(fixture, draw_matches)
    return match.get("deadline") if match else None


def _wtsl_round_deadline(
    fixture: dict[str, typing.Any],
    draw_matches: list[dict[str, typing.Any]],
):
    """Use the exact draw's round cutoff for scheduled non-open entries."""
    def normalize_round(value: object) -> str:
        normalized = re.sub(
            r"[^a-z0-9]+",
            " ",
            str(value or "").casefold(),
        ).strip()
        normalized = re.sub(r"^round of (\d+)$", r"r\1", normalized)
        return {
            "quarter final": "quarter finals",
            "quarter finals": "quarter finals",
            "semi final": "semifinals",
            "semi finals": "semifinals",
            "final": "final",
        }.get(normalized, normalized)

    round_name = normalize_round(fixture.get("round"))
    if not round_name:
        return None
    deadlines = [
        match.get("deadline")
        for match in draw_matches
        if normalize_round(match.get("round")) == round_name
        and isinstance(match.get("deadline"), datetime)
    ]
    return min(deadlines) if deadlines else None


async def _fetch_exact_draw_source(
    session,
    tournament: dict[str, str],
) -> tuple[str, dict[str, str]] | None:
    """Fetch a draw source that contains Challonge's own round deadlines."""
    challonge_headers = {
        "User-Agent": (
            "Mozilla/5.0 (X11; Linux x86_64) "
            "AppleWebKit/537.36 Chrome/131.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    page_url = tournament.get("page_url")
    if not page_url:
        return None
    proxy_status = None
    async with session.get(
        page_url,
        timeout=aiohttp.ClientTimeout(total=30),
        headers=challonge_headers,
    ) as page_response:
        page_response.raise_for_status()
        svg_url = parse_challonge_svg_url(await page_response.text(), page_url)
    if not svg_url:
        print(
            f"[WTSL draws] no embedded Challonge SVG for {tournament['name']}; "
            f"proxy status {proxy_status}; skipping without estimating deadlines",
            flush=True,
        )
        return None

    # Challonge's public SVG endpoint can intermittently return a transient
    # Cloudflare 520. Try the canonical SVG first, then cache-busted retries;
    # all requests use the exact draw source and therefore preserve the
    # tournament's published round deadlines.
    request_urls = [svg_url]
    separator = "&" if "?" in svg_url else "?"
    request_urls.extend(
        f"{svg_url}{separator}wtsl_alert_scan={attempt}"
        for attempt in range(3)
    )
    for request_url in request_urls:
        async with session.get(
            request_url,
            timeout=aiohttp.ClientTimeout(total=30),
            headers=challonge_headers,
        ) as response:
            draw_html = await response.text()
            if response.status == 200 and 'class="match' in draw_html:
                source_tournament = {
                    **tournament,
                    "draw_url": svg_url,
                }
                return draw_html, source_tournament
    print(
        f"[WTSL draws] exact Challonge SVG unavailable for "
        f"{tournament['name']} (proxy status {proxy_status}); "
        "skipping without estimating deadlines",
        flush=True,
    )
    return None


async def _load_open_draw_matches(session) -> list[dict[str, typing.Any]]:
    tournaments = []
    seen_tournaments: set[str] = set()
    for tournaments_url, tour in (
        (ONGOING_TOURNAMENTS_URL, "TE4"),
        (ONGOING_TOURNAMENTS_WTA_URL, "TE4_(F)"),
    ):
        async with session.get(
            tournaments_url,
            timeout=aiohttp.ClientTimeout(total=30),
        ) as response:
            response.raise_for_status()
            for tournament in parse_ongoing_tournaments(
                await response.text(),
                tour=tour,
            ):
                if tournament["id"] not in seen_tournaments:
                    tournaments.append(tournament)
                    seen_tournaments.add(tournament["id"])
    matches = []
    for tournament in tournaments:
        source = await _fetch_exact_draw_source(session, tournament)
        if source is None:
            continue
        draw_html, source_tournament = source
        matches.extend(parse_draw_matches(draw_html, source_tournament))
    return matches


async def _run_one_time_dani_madferit_outreach(
    guild, members: list
) -> None:
    """Legacy one-time repair; never reset a preview that is already published."""
    now = datetime.now(timezone.utc).timestamp()
    async with aiohttp.ClientSession() as session:
        async with session.get("https://playwtsl.com/TE4") as response:
            response.raise_for_status()
            fixtures = parse_upcoming_fixtures(
                await response.text(),
                season=str(datetime.now(timezone.utc).year),
            )
    fixture = next(
        (
            candidate
            for candidate in fixtures
            if (
                (
                    normalize_matchlog_name(candidate.get("first_name"))
                    in {"dani21", "halapeno"}
                    and normalize_matchlog_name(
                        candidate.get("second_name")
                    )
                    == "madferit"
                )
                or (
                    normalize_matchlog_name(candidate.get("second_name"))
                    in {"dani21", "halapeno"}
                    and normalize_matchlog_name(
                        candidate.get("first_name")
                    )
                    == "madferit"
                )
            )
        ),
        None,
    )
    if fixture is None:
        print(
            "[Outreach] one-time Dani21/Madferit fixture not found",
            flush=True,
        )
        return
    key = fixture["key"]
    item = _outreach_state.data.get("fixtures", {}).get(key)
    if item and item.get("published"):
        print(
            "[Outreach] existing Dani21/Madferit preview is already published; "
            "skipping legacy retry",
            flush=True,
        )
        return
    if item and item.get("commentary_retry_version") == COMMENTARY_RETRY_VERSION:
        return
    if item:
        prompts = item.get("prompts") or {}
        if any(prompt.get("reply") for prompt in prompts.values()):
            print(
                "[Outreach] existing Dani21/Madferit commentary found; "
                "not replacing it",
                flush=True,
            )
            return
        fresh_prompts = {}
        for side in ("side1", "side2"):
            old_prompt = prompts.get(side) or {}
            fresh_prompts[side] = {
                "member_id": old_prompt.get("member_id"),
                "side": side,
                "operation_ref": _outreach_operation_ref(
                    key,
                    f"dm:{side}:commentary-retry:{COMMENTARY_RETRY_VERSION}",
                ),
                "force_new": True,
            }
        await _outreach_state.update(
            key,
            prompts=fresh_prompts,
            published=False,
            publish_status="pending",
            published_at=None,
            publishing_started_at=None,
            publish_operation_ref=None,
            thread_id=None,
            sent_units={},
            poll_message_id=None,
        )
    # The previous fixed cutoff has passed. Give this explicitly requested
    # retry the normal 12-hour response window from the fresh DM delivery.
    fixture["one_time_publish_deadline"] = now + 12 * 3600
    await _begin_outreach(fixture, guild, members=members)
    await _outreach_state.update(
        key,
        commentary_retry_version=COMMENTARY_RETRY_VERSION,
    )


async def _scan_fixture_outreach_once() -> None:
    async with aiohttp.ClientSession() as session:
        async with session.get("https://playwtsl.com/TE4") as response:
            response.raise_for_status()
            fixtures = parse_upcoming_fixtures(
                await response.text(),
                season=str(datetime.now(timezone.utc).year),
            )
        draw_matches = await _load_open_draw_matches(session)
    guild = client.get_guild(OUTREACH_GUILD_ID)
    if not guild:
        return
    members = await _outreach_guild_members(guild)
    for fixture in fixtures:
        draw_match = _outreach_draw_match(fixture, draw_matches)
        draw_deadline = draw_match.get("deadline") if draw_match else None
        if draw_deadline is None:
            print(
                "[Outreach] fixture could not be matched to an official draw "
                f"deadline: {fixture.get('first_name')} vs "
                f"{fixture.get('second_name')}",
                flush=True,
            )
            continue
        fixture["draw_deadline"] = draw_deadline.astimezone(
            timezone.utc
        ).isoformat()
        fixture["round"] = draw_match.get("round")
        fixture["event_category"] = draw_match.get("category")
        if (
            not _outreach_repair_complete
            and fixture["key"] in _outreach_preexisting_fixture_keys
        ):
            continue
        await _begin_outreach(fixture, guild, members=members)


async def _reset_requested_outreach_retry() -> None:
    """Let the requested Dani21/Madferit prompt retry without duplicating DMs."""
    target = {"dani21", "madferit"}
    for key, item in _outreach_state.data.get("fixtures", {}).items():
        fixture = item.get("fixture") or {}
        names = {
            normalize_matchlog_name(fixture.get("first_name")),
            normalize_matchlog_name(fixture.get("second_name")),
        }
        if names != target or item.get("published"):
            continue
        prompts = item.get("prompts") or {}
        changed = False
        for prompt in prompts.values():
            if prompt.get("reply"):
                continue
            prompt["attempts"] = 0
            prompt["status"] = "failed"
            prompt["failed_at"] = "2015-01-01T00:00:00+00:00"
            changed = True
        if changed:
            await _outreach_state.update(key, prompts=prompts)


async def _start_fixture_outreach() -> None:
    global _outreach_preexisting_fixture_keys, _outreach_repair_complete
    await _outreach_state.load()
    if await _outreach_state.remove(FAKE_OUTREACH_KEY):
        print(
            "[Outreach] removed retired Squeaky-vs-Squeaky test fixture",
            flush=True,
        )
    _outreach_preexisting_fixture_keys = set(
        _outreach_state.data.get("fixtures", {})
    )
    await _reset_requested_outreach_retry()
    _outreach_repair_complete = False
    await _clean_published_outreach_traces()
    guild = client.get_guild(OUTREACH_GUILD_ID)
    if guild:
        members = await _outreach_guild_members(guild)
        await _repair_persisted_outreach_prompts(guild, members)
        _outreach_repair_complete = True
        if FIXTURE_OUTREACH_ENABLED:
            # Do not run one-off preview/commentary repair logic on every bot
            # restart. Existing published fixtures are reconciled above and the
            # normal scanner below is idempotent through _outreach_state.
            await _scan_fixture_outreach_once()
        if not getattr(client, "_outreach_pending_started", False):
            client._outreach_pending_started = True
            asyncio.create_task(_pending_outreach_loop())
    else:
        _outreach_repair_complete = True
        if not getattr(client, "_outreach_pending_started", False):
            client._outreach_pending_started = True
            asyncio.create_task(_pending_outreach_loop())
    for key, item in _outreach_state.data.get("fixtures", {}).items():
        if not item.get("published"):
            _schedule_outreach_deadline(key)
    if (
        FIXTURE_OUTREACH_ENABLED
        and not getattr(client, "_fixture_outreach_started", False)
    ):
        client._fixture_outreach_started = True
        asyncio.create_task(_fixture_outreach_loop())


async def _safe_start_fixture_outreach() -> None:
    """Keep optional outreach startup isolated from Discord's ready event."""
    try:
        # Other on_ready work may be slow; isolate outreach startup from it.
        await asyncio.sleep(OUTREACH_STARTUP_DELAY_SECONDS)
        print("[Outreach] startup task running", flush=True)
        await _start_fixture_outreach()
        print("[Outreach] startup task completed", flush=True)
    except Exception as exc:
        print(f"[Outreach] startup error: {exc}", flush=True)


def _deadline_reminder_content(
    match: dict, recipient: str | None = None, window: str | None = None
) -> str:
    """Format the same factual deadline notice for the channel and each player."""
    deadline_stamp = int(match["deadline"].timestamp())
    opponent_line = (
        f"\n**Opponent:** {recipient}"
        if recipient else ""
    )
    scheduling_line = _deadline_scheduling_thread_line(match)
    heading = (
        "🚨 **WTSL match deadline overdue**"
        if str(window or "").startswith("overdue:")
        else "🎾 **WTSL draw deadline reminder**"
    )
    return (
        f"{heading}\n"
        f"**Tournament:** [{match['tournament']}]({match['draw_url']})\n"
        f"**Round:** {match['round']}\n"
        f"**Match:** {match['players'][0]} vs {match['players'][1]}"
        f"{opponent_line}\n"
        f"**Deadline:** <t:{deadline_stamp}:F> (<t:{deadline_stamp}:R>)\n"
        f"{scheduling_line}"
        f"**Draw:** [Open tournament draw]({match['draw_url']})"
    )


def _deadline_scheduling_record(match: dict) -> dict | None:
    wanted_players = {
        normalize_matchlog_name(player)
        for player in match.get("players") or []
    }
    for record in _match_scheduler_records.values():
        if (
            record.get("status") == "active"
            and not record.get("is_test")
            and str(record.get("tournament_id")) == str(match.get("tournament_id"))
            and str(record.get("source_match_id")) == str(match.get("match_id"))
            and {
                normalize_matchlog_name(record.get("player_one", "")),
                normalize_matchlog_name(record.get("player_two", "")),
            } == wanted_players
            and record.get("thread_id")
        ):
            return record
    return None


def _deadline_scheduling_thread_line(match: dict) -> str:
    """Link an active real-player scheduling thread when one exists."""
    record = _deadline_scheduling_record(match)
    if not record:
        return ""
    url = (
        f"https://discord.com/channels/{record['guild_id']}/"
        f"{MATCH_SCHEDULER_CHANNEL_ID}/{record['thread_id']}"
    )
    return f"**Scheduling Thread:** [Scheduling Thread]({url})\n"


def _deadline_scheduling_offer_view(match: dict) -> discord.ui.View | None:
    """Offer scheduling only while this draw encounter has no active thread."""
    if _deadline_scheduling_record(match):
        return None
    return _match_scheduler_offer_view(match)


def _admin_deadline_reminder_content(
    match: dict,
    window: str,
) -> str:
    """Format the adjudication alert sent to the admin scheduling log."""
    deadline_stamp = int(match["deadline"].timestamp())
    if window == "admin:6h":
        heading = "🔔 **Admin match-watch alert: deadline within 6 hours**"
    else:
        heading = "⚠️ **Admin match-watch alert: deadline overdue**"
    scheduling_line = _deadline_scheduling_thread_line(match)
    return (
        f"<@&{ADMIN_ROLE_ID}>\n"
        f"{heading}\n"
        f"**Tournament:** [{match['tournament']}]({match['draw_url']})\n"
        f"**Round:** {match['round']}\n"
        f"**Match:** {match['players'][0]} vs {match['players'][1]}\n"
        f"**Deadline:** <t:{deadline_stamp}:F> (<t:{deadline_stamp}:R>)\n"
        f"{scheduling_line}"
        f"**Draw:** [Open tournament draw]({match['draw_url']})\n"
        "Please be ready to adjudicate or resolve scheduling issues."
    )


async def _deliver_deadline_reminder(
    key: str,
    destination: str,
    target,
    content: str,
    allowed_mentions: discord.AllowedMentions,
    fresh_reconcile_after: datetime | None = None,
    view: discord.ui.View | None = None,
) -> None:
    """Deliver one destination crash-safely and reconcile uncertain sends."""
    if _deadline_reminder_state.sent(key, destination):
        return
    previous_delivery = _deadline_reminder_state.delivery(key, destination)
    try:
        operation_ref = _deadline_reminder_state.begin_delivery(key, destination)
    except (OSError, RuntimeError, ValueError) as exc:
        print(
            f"[Deadline reminders] ledger unavailable before {destination}: {exc}",
            flush=True,
        )
        return

    reference = f"deadline:{operation_ref}"
    history_channel = target
    if destination.startswith("dm:"):
        history_channel = getattr(target, "dm_channel", None)
        if history_channel is None and hasattr(target, "create_dm"):
            try:
                history_channel = await target.create_dm()
            except (discord.HTTPException, discord.Forbidden, asyncio.TimeoutError):
                history_channel = None
    try:
        started_at = fresh_reconcile_after
        if (
            isinstance(previous_delivery, dict)
            and previous_delivery.get("sending_started_at")
        ):
            try:
                started_at = datetime.fromisoformat(
                    previous_delivery["sending_started_at"]
                )
            except (TypeError, ValueError):
                started_at = fresh_reconcile_after
        found = await _find_message_with_ref(
            history_channel, reference, after=started_at
        )
    except (discord.HTTPException, discord.Forbidden, asyncio.TimeoutError):
        found = None
    if found:
        try:
            _deadline_reminder_state.mark_sent(key, destination)
        except (OSError, RuntimeError) as exc:
            print(
                f"[Deadline reminders] reconciled {destination}, ledger write failed: {exc}",
                flush=True,
            )
        return

    try:
        await target.send(
            content + _outreach_hidden_marker(reference),
            allowed_mentions=allowed_mentions,
            nonce=_outreach_nonce(reference),
            view=view,
        )
    except (discord.HTTPException, discord.Forbidden, asyncio.TimeoutError) as exc:
        print(f"[Deadline reminders] {destination} delivery failed: {exc}", flush=True)
        return
    try:
        _deadline_reminder_state.mark_sent(key, destination)
    except (OSError, RuntimeError) as exc:
        # The persisted state remains "sending"; the next scan reconciles the
        # durable marker before considering another send.
        print(
            f"[Deadline reminders] {destination} sent; ledger confirmation failed: {exc}",
            flush=True,
        )


async def _scan_deadline_reminders() -> None:
    """Deliver due draw notices conservatively; unresolved players send nothing."""
    now = datetime.now(timezone.utc)
    async with aiohttp.ClientSession() as session:
        due_matches = []
        admin_due_matches = []
        for match in await _load_open_draw_matches(session):
            window = reminder_window(match["deadline"], now)
            if window:
                due_matches.append((match, window))
            admin_window = admin_reminder_window(match["deadline"], now)
            if admin_window:
                admin_due_matches.append((match, admin_window))

    guild = client.get_guild(DEADLINE_REMINDER_GUILD_ID)
    if guild is None:
        print("[Deadline reminders] WTSL guild unavailable; retrying later", flush=True)
        return
    members = await _outreach_guild_members(guild)
    channel = await _resolve_deadline_reminder_channel(guild)
    if channel is None:
        print(
            f"[Deadline reminders] scheduling-issues channel "
            f"{DEADLINE_REMINDER_CHANNEL_ID} unavailable; "
            "DMs will continue and channel delivery will retry later",
            flush=True,
        )
    mentions = discord.AllowedMentions(users=True, roles=False, everyone=False)
    admin_channel = client.get_channel(MATCH_SCHEDULING_LOG_CHANNEL_ID)
    if admin_channel is None:
        try:
            admin_channel = await client.fetch_channel(
                MATCH_SCHEDULING_LOG_CHANNEL_ID
            )
        except (discord.HTTPException, discord.Forbidden):
            admin_channel = None
    admin_mentions = discord.AllowedMentions(
        users=False,
        roles=True,
        everyone=False,
    )
    if admin_channel is not None:
        for match, admin_window in admin_due_matches:
            admin_key = reminder_key(match, admin_window)
            await _deliver_deadline_reminder(
                admin_key,
                f"channel:{MATCH_SCHEDULING_LOG_CHANNEL_ID}",
                admin_channel,
                _admin_deadline_reminder_content(match, admin_window),
                admin_mentions,
            )
    for match, window in due_matches:
        first_lookup = discord_lookup_name(match["players"][0])
        second_lookup = discord_lookup_name(match["players"][1])
        first = resolve_member_exact(members, first_lookup)
        second = resolve_member_exact(members, second_lookup)
        if first is None or second is None:
            print(
                f"[Deadline reminders] unresolved/ambiguous players for "
                f"{match['match_key']}: "
                f"{match['players'][0]}=>{first_lookup}={'ok' if first else 'missing'}, "
                f"{match['players'][1]}=>{second_lookup}={'ok' if second else 'missing'}; "
                f"public reminder and resolved-player DMs will continue",
                flush=True,
            )
        key = reminder_key(match, window)
        reconcile_after = reminder_window_started_at(match, window)
        if channel is not None:
            resolved_mentions = " ".join(
                member.mention for member in (first, second) if member is not None
            )
            mention_prefix = f"{resolved_mentions}\n" if resolved_mentions else ""
            await _deliver_deadline_reminder(
                key,
                f"channel:{channel.id}",
                channel,
                mention_prefix
                + _deadline_reminder_content(match, window=window),
                mentions,
                reconcile_after,
                _deadline_scheduling_offer_view(match),
            )
        for member, opponent in (
            (first, match["players"][1]),
            (second, match["players"][0]),
        ):
            if member is None:
                continue
            destination = f"dm:{member.id}"
            await _deliver_deadline_reminder(
                key,
                destination,
                member,
                _deadline_reminder_content(match, opponent, window),
                mentions,
                reconcile_after,
                _deadline_scheduling_offer_view(match),
            )


async def _resolve_deadline_reminder_channel(guild):
    """Resolve only the user-confirmed scheduling-issues channel ID."""
    cached = client.get_channel(DEADLINE_REMINDER_CHANNEL_ID)
    if (
        cached is not None
        and getattr(getattr(cached, "guild", None), "id", None) == getattr(guild, "id", None)
    ):
        return cached
    candidates = [
        channel
        for channel in list(getattr(guild, "channels", []))
        if getattr(channel, "id", None) == DEADLINE_REMINDER_CHANNEL_ID
    ]
    if candidates:
        return candidates[0]
    if hasattr(guild, "fetch_channels"):
        try:
            fetched = await guild.fetch_channels()
        except (discord.HTTPException, discord.Forbidden) as exc:
            print(f"[Deadline reminders] channel discovery failed: {exc}", flush=True)
            return None
        candidates = [
            channel
            for channel in fetched
            if getattr(channel, "id", None) == DEADLINE_REMINDER_CHANNEL_ID
        ]
    return candidates[0] if candidates else None


async def _deadline_reminder_loop() -> None:
    """Scan immediately, then re-check WTSL draws every fifteen minutes."""
    while True:
        try:
            await _scan_deadline_reminders()
        except Exception as exc:
            print(f"[Deadline reminders] scan failed: {exc}", flush=True)
        await asyncio.sleep(15 * 60)


async def _start_deadline_reminders() -> None:
    """Load the ledger before the single startup loop is scheduled."""
    try:
        _deadline_reminder_state.load()
    except RuntimeError as exc:
        # A bad ledger must never be overwritten, since that could duplicate DMs.
        print(f"[Deadline reminders] disabled: {exc}", flush=True)
        return
    if not getattr(client, "_deadline_reminder_started", False):
        client._deadline_reminder_started = True
        asyncio.create_task(_deadline_reminder_loop())


def _matchpreview_poll_answer(name: str) -> str:
    """Keep a player name within Discord's native poll answer limit."""
    return name if len(name) <= 55 else name[:54].rstrip() + "…"


def _matchpreview_winner_poll(first_name: str, second_name: str) -> discord.Poll:
    """Build a restart-safe, single-choice winner poll managed by Discord."""
    poll = discord.Poll(
        question="Who will win?",
        duration=timedelta(days=7),
        multiple=False,
    )
    poll.add_answer(text=_matchpreview_poll_answer(first_name))
    poll.add_answer(text=_matchpreview_poll_answer(second_name))
    return poll


def _matchpreview_thread_name(first_name: str, second_name: str) -> str:
    """Build a readable Discord thread name within Discord's 100-character limit."""
    prefix = "Match Preview - "
    separator = " vs "
    first_name = str(first_name).strip()
    second_name = str(second_name).strip()
    available = 100 - len(prefix) - len(separator)
    if len(first_name) + len(second_name) <= available:
        return f"{prefix}{first_name}{separator}{second_name}"

    first_limit = max(1, available // 2)
    second_limit = max(1, available - first_limit)
    return (
        f"{prefix}{first_name[:first_limit].rstrip()}"
        f"{separator}{second_name[:second_limit].rstrip()}"
    )


def _matchpreview_avatar_embeds(preview_data):
    """Build optional visual player cards without making images mandatory."""
    embeds = []
    colours = (0x2ECC71, 0x3498DB)
    for player, colour in zip(
        (preview_data["first"], preview_data["second"]), colours
    ):
        avatar_url = player.get("avatar_url")
        if not avatar_url:
            continue
        rank = f"#{player['rank']}" if player.get("rank") else "Unranked"
        embed = discord.Embed(
            title=player["name"],
            url=player.get("profile_url"),
            description=(
                f"{rank} · WTSL Elo {player.get('wtsl_elo') or '—'} · "
                f"In-game Elo {player.get('in_game_elo') or '—'}"
            ),
            colour=colour,
        )
        embed.set_thumbnail(url=avatar_url)
        embeds.append(embed)
    return embeds


def _matchpreview_quote_context(preview_data: dict) -> dict:
    """Keep the quote prompt grounded in the same factual preview inputs."""
    players = []
    for player, form_key in (
        (preview_data["first"], "first_form"),
        (preview_data["second"], "second_form"),
    ):
        summary = preview_data["summaries"].get(
            str(player["name"]).strip().lower(), {}
        )
        players.append(
            {
                "name": player["name"],
                "rank": player.get("rank"),
                "wtsl_elo": player.get("wtsl_elo"),
                "recent_results": [
                    result.get("result", "")
                    for result in preview_data.get(form_key, [])[:5]
                ],
                "advanced_stats": {
                    key: value
                    for key, value in summary.items()
                    if isinstance(value, (int, float))
                },
            }
        )
    odds = preview_data.get("odds") or {}
    return {
        "tour": preview_data.get("tour_label"),
        "players": players,
        "head_to_head_record": preview_data.get("h2h_record"),
        "head_to_head_meetings": preview_data.get("h2h", [])[:5],
        "upcoming_fixture": {
            "tournament": odds.get("tournament"),
            "player1_price": odds.get("first"),
            "player2_price": odds.get("second"),
        },
        "prediction": {
            "favoured_name": (preview_data.get("prediction") or {}).get("favored_name"),
            "confidence": (preview_data.get("prediction") or {}).get("confidence"),
            "basis": (preview_data.get("prediction") or {}).get("basis"),
        },
        "conditions_note": (
            "No specific playing surface is available from the data. Do not invent "
            "a surface, venue, weather, or exact conditions; generic court conditions "
            "may be mentioned only if it sounds natural."
        ),
    }


def _generate_match_preview_copy_sync(preview_data: dict) -> dict[str, str]:
    client = OpenAI(
        base_url=os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL"),
        api_key=os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY"),
    )
    context = json.dumps(
        _matchpreview_quote_context(preview_data),
        ensure_ascii=False,
        default=str,
    )
    response = client.chat.completions.create(
        model=os.environ.get("MATCH_PREVIEW_QUOTE_MODEL", AI_MODEL),
        messages=[
            {
                "role": "system",
                "content": (
                    "You write fresh editorial copy for a tennis match preview. Return "
                    "JSON only with exactly three string fields: \"desk\", \"first\", "
                    "and \"second\". The desk field is a distinctive 1-2 sentence "
                    "WTSL Match Preview Desk observation about this specific matchup. "
                    "The first and second fields are imagined pre-match interview "
                    "responses for the two named players in order; they are editorial "
                    "copy, not verified real statements. Make all three responses "
                    "clearly different in idea, rhythm, and sentence structure. "
                    "Generate new wording for every request rather than reusing a "
                    "template. Each player response should be 2-3 natural first-person "
                    "sentences, concise enough for Discord. A player may touch on "
                    "rivalry, form, confidence, nerves, generic court conditions, or a "
                    "small part of their approach, but must sound like a player "
                    "answering a question—not like a statistics report. Use only the "
                    "supplied facts. Do not invent a surface, venue, weather, injury, "
                    "score, result, or quotation from a real person. Do not include "
                    "quotation marks, speaker labels, markdown, a disclaimer, or the "
                    "words fictional or imagined."
                ),
            },
            {
                "role": "user",
                "content": (
                    "Create a completely new Preview Desk observation and two "
                    "completely new player responses for this specific matchup. Use "
                    "the context as background rather than reciting it, and do not "
                    "force either player to mention tactics or the keys to the match."
                    "\n\n"
                    + context
                ),
            },
        ],
        max_completion_tokens=1800,
        response_format={
            "type": "json_schema",
            "json_schema": {
                "name": "match_preview_copy",
                "strict": True,
                "schema": {
                    "type": "object",
                    "properties": {
                        "desk": {"type": "string"},
                        "first": {"type": "string"},
                        "second": {"type": "string"},
                    },
                    "required": ["desk", "first", "second"],
                    "additionalProperties": False,
                },
            },
        },
    )
    if not response.choices:
        raise ValueError("preview copy generator returned no choices")
    parsed = json.loads(response.choices[0].message.content or "{}")
    fields = ("desk", "first", "second")
    if not all(
        isinstance(parsed.get(field), str) and parsed[field].strip()
        for field in fields
    ):
        raise ValueError("preview copy generator returned incomplete responses")
    cleaned = {
        field: " ".join(
            parsed[field].replace("“", "").replace("”", "").split()
        )
        for field in fields
    }
    if len({value.casefold() for value in cleaned.values()}) != len(fields):
        raise ValueError("preview copy generator returned duplicate responses")
    return cleaned


async def generate_match_preview_copy(
    preview_data: dict,
) -> dict[str, str] | None:
    """Generate fresh desk and player copy without blocking Discord's event loop."""
    if not os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY"):
        print(
            "[Match Preview] Preview copy generator unavailable: "
            "OpenAI key is not configured"
        )
        return None
    try:
        generated = await asyncio.to_thread(
            _generate_match_preview_copy_sync, preview_data
        )
        print("[Match Preview] Generated fresh Preview Desk and player responses")
        return generated
    except Exception as exc:
        print(
            "[Match Preview] Preview copy generation failed; using editorial fallback: "
            f"{type(exc).__name__}: {exc}"
        )
        return None


@client.tree.command(
    name="matchpreview",
    description="Preview two players using WTSL odds, form, H2H, and advanced stats",
)
@app_commands.describe(
    player1="First player's WTSL ranking name",
    player2="Second player's WTSL ranking name",
)
async def matchpreview_slash(
    interaction: discord.Interaction,
    player1: str,
    player2: str,
):
    await interaction.response.defer(ephemeral=True, thinking=True)
    posted_message_count = 0
    try:
        preview_data = await collect_match_data(
            player1,
            player2,
            MATCH_STATS_WORKBOOK,
        )
        if not _match_preview_allowed(preview_data):
            await interaction.followup.send(
                "ℹ️ Match previews are available from the semi-finals for "
                "WTSL 250 events, and from the quarter-finals for WTSL 500 "
                "events and above.",
                ephemeral=True,
            )
            return
        generated_copy = await generate_match_preview_copy(preview_data)
        if generated_copy:
            preview_data["preview_desk_quote"] = generated_copy["desk"]
            preview_data["player_quotes"] = [
                generated_copy["first"],
                generated_copy["second"],
            ]
        if interaction.channel is None or not hasattr(
            interaction.channel, "create_thread"
        ):
            raise discord.HTTPException(
                SimpleNamespace(status=400, reason="Unsupported channel", headers={}),
                "match previews must be run in a text channel",
            )
        preview_thread = await _publish_match_preview(preview_data, interaction.channel)
        posted_message_count = 1
        await interaction.followup.send(
            f"✅ The match preview has been posted in {getattr(preview_thread, 'mention', 'a new thread')}.",
            ephemeral=True,
        )
        print(
            f"[Match Preview] Generated {preview_data['tour_label']} preview "
            f"for {preview_data['first']['name']} vs {preview_data['second']['name']} "
            f"for {interaction.user}"
        )
    except PlayerResolutionError as exc:
        await interaction.followup.send(f"⚠️ {exc}", ephemeral=True)
    except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
        print(
            f"[Match Preview] WTSL request failed for {player1!r} vs {player2!r}: "
            f"{type(exc).__name__}: {exc}"
        )
        await interaction.followup.send(
            "❌ WTSL rankings or results could not be reached just now. "
            "Please try the command again shortly.",
            ephemeral=True,
        )
    except FileNotFoundError as exc:
        print(f"[Match Preview] Workbook missing: {exc}")
        await interaction.followup.send(
            "❌ The match-stat workbook is unavailable, so a preview cannot be "
            "generated right now.",
            ephemeral=True,
        )
    except discord.HTTPException as exc:
        posted_message_count = getattr(
            exc, "matchpreview_posted_message_count", posted_message_count
        )
        print(
            f"[Match Preview] Discord post failed for {player1!r} vs {player2!r} "
            f"after {posted_message_count} public message(s): "
            f"{type(exc).__name__}: {exc}"
        )
        partial_note = (
            " Part of the preview may already be visible in the channel."
            if posted_message_count
            else ""
        )
        await interaction.followup.send(
            "❌ Discord could not finish publishing the match preview."
            + partial_note
            + " Please try the command again.",
            ephemeral=True,
        )
    except Exception as exc:
        print(
            f"[Match Preview] Unexpected error for {player1!r} vs {player2!r}: "
            f"{type(exc).__name__}: {exc}"
        )
        await interaction.followup.send(
            "❌ The preview could not be generated because one of its data sources "
            "returned an unexpected response. The error has been logged.",
            ephemeral=True,
        )

@client.tree.command(name="testsupportwatch", description="[Owner only] Test the unanswered-message alert DM")
@app_commands.describe(channel="Which channel to simulate (support or tour-talk)")
@app_commands.choices(channel=[
    app_commands.Choice(name="te4-general", value=str(SUPPORT_WATCH_CHANNEL_ID)),
    app_commands.Choice(name="te4-tour-talk", value=str(TOUR_TALK_CHANNEL_ID)),
    app_commands.Choice(name="report-a-bug", value=str(REPORT_BUG_CHANNEL_ID)),
])
async def testsupportwatch_slash(interaction: discord.Interaction, channel: app_commands.Choice[str]):
    if interaction.user.id != OWNER_ID:
        await interaction.response.send_message("This command is owner-only.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    ch_id = int(channel.value)
    ch_label = WATCHED_SUPPORT_CHANNELS.get(ch_id, "unknown")
    guild = interaction.guild
    admin_role = guild.get_role(ADMIN_ROLE_ID)
    mod_role   = guild.get_role(MODERATOR_ROLE_ID)
    recipients = {}
    for role in filter(None, [admin_role, mod_role]):
        for member in role.members:
            if not member.bot:
                recipients[member.id] = member
    msg_link = f"https://discord.com/channels/{guild.id}/{ch_id}"
    dm_text = (
        f"👋 **[TEST]** Unanswered message alert for **#{ch_label}**:\n"
        f"{msg_link}\n\n"
        f"> This is a test message to verify the support watch DM is working.\n\n"
        f"Could someone take a look? 🙏"
    )
    sent = 0
    for member in recipients.values():
        try:
            await member.send(dm_text)
            sent += 1
        except Exception:
            pass
    await interaction.followup.send(f"✅ Test DM sent to {sent} staff member(s).", ephemeral=True)


DMO_SUBMIT_CHANNEL_ID = 1507754042770719002
DMO_ADMIN_CHANNEL_ID = 1055277431398866995

@client.tree.command(name="submit", description="Submit a match recording to the admins")
@app_commands.describe(
    tournament="Tournament name (e.g. Wimbledon)",
    round="Round (e.g. Final, Semi-Final, R16)",
    player1="First player's name",
    player2="Second player's name",
    recording="The .dmo match recording file (optional if providing a link)",
    link="Google Drive or other file hosting link (optional if attaching a file)"
)
async def submit_slash(interaction: discord.Interaction, tournament: str, round: str, player1: str, player2: str, recording: discord.Attachment = None, link: str = None):
    await interaction.response.defer(ephemeral=True)
    if interaction.channel_id != DMO_SUBMIT_CHANNEL_ID:
        await interaction.followup.send(
            f"This command can only be used in <#{DMO_SUBMIT_CHANNEL_ID}>.", ephemeral=True
        )
        return
    if not recording and not link:
        await interaction.followup.send(
            "⚠️ Please provide either a `.dmo` file attachment or a link to the recording.", ephemeral=True
        )
        return
    if recording and not recording.filename.lower().endswith(".dmo"):
        await interaction.followup.send(
            "⚠️ The attached file must be a `.dmo` match recording. Please try again with the correct file.", ephemeral=True
        )
        return
    match_label = f"{tournament} — {round}: {player1} vs {player2}"
    forward_msg = (
        f"📼 **Match Recording Submitted**\n"
        f"**From:** {interaction.user.mention} ({interaction.user})\n"
        f"**Tournament:** {tournament}\n"
        f"**Round:** {round}\n"
        f"**Players:** {player1} vs {player2}"
    )
    if recording:
        forward_msg += f"\n**File:** [{recording.filename}]({recording.url})"
    if link:
        forward_msg += f"\n**Link:** {link}"
    try:
        admin_channel = client.get_channel(DMO_ADMIN_CHANNEL_ID) or await client.fetch_channel(DMO_ADMIN_CHANNEL_ID)
        await admin_channel.send(forward_msg)
    except Exception as e:
        print(f"[DMO Submit] Error forwarding to admin channel: {e}")
    try:
        owner = await client.fetch_user(859691230941282304)
        await owner.send(forward_msg)
    except Exception as e:
        print(f"[DMO Submit] Error DMing owner: {e}")
    await interaction.followup.send(
        f"✅ Your recording for **{match_label}** has been submitted. Thank you!", ephemeral=True
    )
    print(f"[DMO Submit] {interaction.user} submitted recording for {match_label}")


# Keep legacy prefix command for backwards compatibility
@client.command(pass_context = True, name="dm_legacy")
async def dm(ctx, user: discord.User, *, message):
    try:
        print("{} {}".format(user, message))
        await ctx.message.delete()
    except:
        subprocess.run("kill 1", shell=True, check=True)
        system("python3 main.py")
    try:
        await user.send(message)
        await ctx.author.send("**To {}:** {}".format(user, message))
    except:
        await ctx.author.send('**{} is not accepting private messages from wtet bot, send him a private message instead**'.format(user.name))
votes = []
users = []
pollresults = (votes, users)
@client.command(pass_context = True)
async def vote(ctx, message):
    #now = datetime.datetime.now()
    #now = datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S')
    channel  = client.get_channel(1003793830585323670)
    message_channel = client.get_channel(1003787574130774137)
    print("{}".format(message))
    await ctx.message.delete()
    message = hash(message)
    author = hash(ctx.author.name)
    votes.append(message)
    users.append(author)
    await channel.send(pollresults)
          
@client.command(pass_context = True)
async def walkover(ctx, tournament, user: discord.User, user2: discord.User, P1, P2):
    print("{}{}{}".format(tournament,P1,P2))
    #await client.delete_message(ctx.message)
    await ctx.message.delete()
    kory = await client.fetch_user(643545093961416725) 
    ls21 = await client.fetch_user(566355346013028362)
    willito = await client.fetch_user(188524743488438273)
    barboza = await client.fetch_user(485273807360360448)
    mystery = await client.fetch_user(787379133666557963)
    nogian = await client.fetch_user(349168254050369536)
    ptacek = await client.fetch_user(213224853686321152)
    kingofcans = await client.fetch_user(275693559783620610)
    bash = await client.fetch_user(254627273712336899)
    djokorer = await client.fetch_user(859691230941282304)
    admins = [djokorer, ls21, willito, barboza, mystery, nogian, ptacek, kingofcans, bash]
    await ctx.send("{}".format(tournament))
    await ctx.send("{} def. {} via walkover".format(P1,P2))
    await user.send("{}".format(tournament))
    await user2.send("{}".format(tournament))
    await user.send("{} def. {} via walkover".format(P1,P2))
    await user2.send("{} def. {} via walkover".format(P1,P2))
    for i in range(len(admins)):
      await admins[i].send("{}".format(tournament))
      await admins[i].send("{} def. {} via walkover".format(P1,P2))
      await admins[i].send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))
@client.command(pass_context = True)
async def cointoss(ctx, tournament,                   
user: discord.User, user2: discord.User, P1, P2):
    #channel = client.get_channel(989190263584985108)
    import datetime
    now = datetime.datetime.now()
    print("{}{}{}".format(tournament,P1,P2))
    #await client.delete_message(ctx.message)
    await ctx.message.delete()
    barboza = await client.fetch_user(485273807360360448)
    mystery = await client.fetch_user(787379133666557963)
    ptacek = await client.fetch_user(213224853686321152)
    djokorer = await client.fetch_user(859691230941282304)
    oserkos = await client.fetch_user(694626703376384081)
    admins = [djokorer, barboza, mystery, ptacek, oserkos]
    await ctx.send("{}".format(tournament))
    await ctx.send("{} is Heads and {} is Tails".format(P1,P2))
    await user.send("{}".format(tournament))
    await user2.send("{}".format(tournament))
    await user.send("{} is Heads and {} is Tails".format(P1,P2))
    await user2.send("{} is Heads and {} is Tails".format(P1,P2))
    for i in range(len(admins)):
      await admins[i].send("{}".format(tournament))
      await admins[i].send("{} is Heads and {} is Tails".format(P1,P2))
    #await sendtowtettour.com.send("{} is Heads and {} is Tails".format(P1,P2))
    h = [] #create list for storing heads
    t = [] #create list for storing tails
    for i in range(9): #loop through 9 numbers'
        c = random.random() #random number generator, from uniform distribution
        if c>0.5: #if random num > 0.5 => heads'
            h.append('Heads') #append heads to heads list
            await ctx.send('Heads')
            await user.send('Heads')
            await user2.send('Heads')
            #for i in range(len(admins)):
            #  await admins[i].send('Heads')
            #await sendtowtettour.com.send('Heads')
        else:
            t.append('Tails')  #if random num > 0.5 => heads, append tails to tails list
            await ctx.send('Tails')
            await user.send('Tails')
            await user2.send('Tails')
            #for i in range(len(admins)):
            #  await admins[i].send('Tails')
            #await sendtowtettour.com.send('Tails')
    await ctx.send("{} Heads and {} Tails".format(len(h),len(t)))  #print (size of heads list) Heads and (size of tails list) Tails
    await user.send("{} Heads and {} Tails".format(len(h),len(t)))
    await user2.send("{} Heads and {} Tails".format(len(h),len(t)))
    for i in range(len(admins)):
      await admins[i].send("{} Heads and {} Tails".format(len(h),len(t)))
    #await sendtowtettour.com.send("{} Heads and {} Tails".format(len(h),len(t)))
    if len(h) > len(t): #if size of heads list > size of tails list, P1 wins
        await ctx.send("{} wins".format(P1))
        await user.send("{} wins".format(P1))
        await user2.send("{} wins".format(P1))
        for i in range(len(admins)):
          await admins[i].send("{} wins".format(P1))
          await admins[i].send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))
        #await sendtowtettour.com.send("{} wins".format(P1))
    else:
        await ctx.send("{} wins".format(P2))
        await user.send("{} wins".format(P2))
        await user2.send("{} wins".format(P2))
        for i in range(len(admins)):
          await admins[i].send("{} wins".format(P2))
          await admins[i].send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))
        #await sendtowtettour.com.send("{} wins".format(P2))

#@client.command()
#async def DM(ctx, user: discord.User, user2: discord.User, *, message=None):
#    message = message or "This Message is sent via DM"
#    await user.send(message)
#    await user2.send(message)
@client.command()
async def RL(ctx, tournament, user: discord.User, user2: discord.User, P1, P2): #random luck function of player1, players 2
    print("{}{}{}".format(tournament,P1,P2))
    await ctx.message.delete()
    import datetime
    now = datetime.datetime.now()
    kory = await client.fetch_user(643545093961416725)
    ls21 = await client.fetch_user(566355346013028362)
    willito = await client.fetch_user(188524743488438273)
    barboza = await client.fetch_user(485273807360360448)
    mystery = await client.fetch_user(787379133666557963)
    nogian = await client.fetch_user(349168254050369536)
    ptacek = await client.fetch_user(213224853686321152)
    djokorer = await client.fetch_user(859691230941282304)
    oserkos = await client.fetch_user(694626703376384081)
    admins = [djokorer, barboza, mystery, ptacek, oserkos]
    #admins = [djokorer]
    await ctx.send("{}".format(tournament))
    await user.send("{}".format(tournament))
   # await user2.send("{}".format(tournament))
    for i in range(len(admins)):
      await admins[i].send("{}".format(tournament))
    P1 == 'Heads' #set p1 = heads'
    P2 == 'Tails' #set p2 = tails'
    max = 101 #maximum difference in rank is 101 minus 1 = 100
    P1_rank = int(rankings[rankings.index == P1].iloc[0][6]) #fetch player1 rank from rankings table, u can determine this however needed, probably through database, i used the csv to fetch it
    P2_rank = int(rankings[rankings.index == P2].iloc[0][6]) #fetch player2 rank from rankings table, u can determine this however needed, probably through database, i used the csv to fetch it
    c = random.random() #generate random number between 0 and 1
    await ctx.send("{} is Heads and {} is Tails".format(user.mention,user2.mention))
    await user.send("{} is Heads and {} is Tails".format(user.mention,user2.mention))
    await user2.send("{} is Heads and {} is Tails".format(user.mention,user2.mention))
    for i in range(len(admins)):
      await admins[i].send("{} is Heads and {} is Tails".format(user.mention,user2.mention))
      #Print player 1 is heads and player 2 is tails
    if abs(P1_rank - P2_rank) <=100:
        if P1_rank < P2_rank: #if player 1's rank is a smaller number (higher ranked) than player 2's rank, proceed with code block below (has to do with the logarithm)
            RL = 0.5 + (math.log(1+((P2_rank - P1_rank)**0.6)*((np.exp(1)**(0.8-0.5)-1)/(max-1)**0.6))) #RL coefficient
            if c<RL: #if randnum < RL coefficient
                result = 'Heads' #result is heads
            else:                 
                result = 'Tails' #if not result is Tails
            await ctx.send('Chance of winning: {}%'.format(round(RL*100,3))) #print chance of winning is RL coefficient * 100%        
            await user.send('Chance of winning: {}%'.format(round(RL*100,3)))
            await user2.send('Chance of winning: {}%'.format(round(RL*100,3)))
            for i in range(len(admins)):
              await admins[i].send('Chance of winning: {}%'.format(round(RL*100,3)))
            await ctx.send('Heads is number < {}'.format(RL))
            await user.send('Heads is number < {}'.format(RL))
            await user2.send('Heads is number < {}'.format(RL))
            for i in range(len(admins)):
              await admins[i].send('Heads is number < {}'.format(RL))
            await ctx.send('Result: {} ({})'.format(result, c)) 
            await user.send('Result: {} ({})'.format(result, c)) 
            await user2.send('Result: {} ({})'.format(result, c))
            for i in range(len(admins)):
              await admins[i].send('Result: {} ({})'.format(result, c))#print the result (Heads, or tails, depending on whether randnum < RL coefficient, and the number in brackets, which determines the result)
            if result == 'Heads':
                await ctx.send("{} wins".format(user.mention))
                await user.send("{} wins".format(user.mention))
                await user2.send("{} wins".format(user.mention))
                for i in range(len(admins)):
                  await admins[i].send("{} wins".format(user.mention))
                  await admins[i].send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))#if result is heads, print Player 1 wins
            else:
                await ctx.send("{} wins".format(user2.mention))
                await user.send("{} wins".format(user2.mention))
                await user2.send("{} wins".format(user2.mention))
                for i in range(len(admins)):
                  await admins[i].send("{} wins".format(user2.mention))
                  await admins[i].send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))#if result is tails, print Player 2 wins
        else:
            if P2_rank < P1_rank: #if player 1's rank is a higher number (lower ranked) than player 2's rank, proceed with code block below (has to do with the logarithm)
                RL = 1-(0.5 + (math.log(1+((P1_rank - P2_rank)**0.6)*((np.exp(1)**(0.8-0.5)-1)/(max-1)**0.6)))) #RL coefficient
                if c<RL:
                    result = 'Heads'  #result is heads
                else:
                    result = 'Tails'  #if not result is Tails
                await ctx.send('Chance of winning: {}%'.format(round(RL*100,3)))
                await user.send('Chance of winning: {}%'.format(round(RL*100,3)))
                await user2.send('Chance of winning: {}%'.format(round(RL*100,3)))
                for i in range(len(admins)):
                  await admins[i].send('Chance of winning: {}%'.format(round(RL*100,3)))#print chance of winning is RL coefficient * 100%
                await ctx.send('Heads is number < {}'.format(RL))
                await ctx.send('Result: {} ({})'.format(result, c)) 
                await user.send('Heads is number < {}'.format(RL))
                await user.send('Result: {} ({})'.format(result, c)) 
                await user2.send('Heads is number < {}'.format(RL))
                await user2.send('Result: {} ({})'.format(result, c))
                for i in range(len(admins)):
                  await admins[i].send('Heads is number < {}'.format(RL))
                for i in range(len(admins)):
                  await admins[i].send('Result: {} ({})'.format(result, c)) 
              #print the result (Heads, or tails, depending on whether randnum < RL coefficient, and the number in brackets, which determines the result)
                if result == 'Heads':
                    await ctx.send("{} wins".format(user.mention)) 
                    await user.send("{} wins".format(user.mention)) 
                    await user2.send("{} wins".format(user.mention)) 
                    for i in range(len(admins)):
                      await admins[i].send("{} wins".format(user.mention))
                      await admins[i].send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))
                  #if result is heads, print Player 1 wins
                else:
                    await ctx.send("{} wins".format(user2.mention)) 
                    await user.send("{} wins".format(user2.mention))
                    await user2.send("{} wins".format(user2.mention))
                    for i in range(len(admins)):
                      await admins[i].send("{} wins".format(user2.mention))
                      await admins[i].send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))
                  #if result is tails, print Player 2 wins
    else:
        if P1_rank < P2_rank: #if player 1's rank is a smaller number (higher ranked) than player 2's rank, proceed with code block below (has to do with the logarithm)
            RL = 0.8 #RL coefficient
            if c<RL: #if randnum < RL coefficient
                result = 'Heads' #result is heads
            else:                 
                result = 'Tails' #if not result is Tails
            await ctx.send('Chance of winning: {}%'.format(round(RL*100,3))) #print chance of winning is RL coefficient * 100%
            await ctx.send('Heads is number < {}'.format(RL))
            await ctx.send('Result: {} ({})'.format(result, c)) 
            await user.send('Chance of winning: {}%'.format(round(RL*100,3))) #print chance of winning is RL coefficient * 100%
            await user.send('Heads is number < {}'.format(RL))
            await user.send('Result: {} ({})'.format(result, c)) 
            await user2.send('Chance of winning: {}%'.format(round(RL*100,3))) #print chance of winning is RL coefficient * 100%
            await user2.send('Heads is number < {}'.format(RL))
            await user2.send('Result: {} ({})'.format(result, c)) 
            for i in range(len(admins)):
              await admins[i].send('Chance of winning: {}%'.format(round(RL*100,3))) #print chance of winning is RL coefficient * 100%
            for i in range(len(admins)):
              await admins[i].send('Heads is number < {}'.format(RL))
            for i in range(len(admins)):
              await admins[i].send('Result: {} ({})'.format(result, c))
          
          #print the result (Heads, or tails, depending on whether randnum < RL coefficient, and the number in brackets, which determines the result)
            if result == 'Heads':
                await ctx.send("{} wins".format(user.mention))
                await user.send("{} wins".format(user.mention))
                await user2.send("{} wins".format(user.mention))
                for i in range(len(admins)):
                  await admins[i].send("{} wins".format(user.mention))
                  await admins[i].send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))
              #if result is heads, print Player 1 wins
            else:
                await ctx.send("{} wins".format(user2.mention)) 
                await user.send("{} wins".format(user2.mention)) 
                await user2.send("{} wins".format(user2.mention)) 
                for i in range(len(admins)):
                  await admins[i].send("{} wins".format(user2.mention))
                  await admins[i].send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))
              #if result is tails, print Player 2 wins
        else:
            if P2_rank < P1_rank: #if player 1's rank is a higher number (lower ranked) than player 2's rank, proceed with code block below (has to do with the logarithm)
                RL = 1-0.8 #RL coefficient
                if c<RL:
                    result = 'Heads'  #result is heads
                else:
                    result = 'Tails'  #if not result is Tails
                await ctx.send('Chance of winning: {}%'.format(round(RL*100,3)))
                await ctx.send('Heads is number < {}'.format(RL))#print chance of winning is RL coefficient * 100%
                await ctx.send('Result: {} ({})'.format(result, c)) 
                await user.send('Chance of winning: {}%'.format(round(RL*100,3)))
                await user.send('Heads is number < {}'.format(RL))#print chance of winning is RL coefficient * 100%
                await user.send('Result: {} ({})'.format(result, c)) 
                await user2.send('Chance of winning: {}%'.format(round(RL*100,3)))
                await user2.send('Heads is number < {}'.format(RL))#print chance of winning is RL coefficient * 100%
                await user2.send('Result: {} ({})'.format(result, c))
                for i in range(len(admins)):
                  await admins[i].send('Chance of winning: {}%'.format(round(RL*100,3)))
                for i in range(len(admins)):
                  await admins[i].send('Heads is number < {}'.format(RL))#print chance of winning is RL coefficient * 100%
                for i in range(len(admins)):
                  await admins[i].send('Result: {} ({})'.format(result, c))
              #print the result (Heads, or tails, depending on whether randnum < RL coefficient, and the number in brackets, which determines the result)
                if result == 'Heads':
                    await ctx.send("{} wins".format(user.mention)) 
                    await user.send("{} wins".format(user.mention)) 
                    await user2.send("{} wins".format(user.mention))
                    for i in range(len(admins)):
                      await admins[i].send("{} wins".format(user.mention))
                      await admins[i].send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))
                  #if result is heads, print Player 1 wins
                else:
                    await ctx.send("{} wins".format(user2.mention)) 
                    await user.send("{} wins".format(user2.mention)) 
                    await user2.send("{} wins".format(user2.mention)) 
                    for i in range(len(admins)):
                      await admins[i].send("{} wins".format(user2.mention))
                      await admins[i].send(datetime.datetime.strftime(now, '%d/%m/%Y %H:%M:%S'))
                  #if result is tails, print Player 2 wins
#keep_alive()
intents = discord.Intents.all()
intents.members = True

import subprocess
from os import system

@client.command()
async def restart(ctx):
    subprocess.run("kill 1", shell=True, check=True)
    system("python3 main.py")   
@client.command(pass_context = True)
async def calcyWp(ctx, P3, P4, P1, P2, sets):
    #channel = client.get_channel(812742338669576252)
    print("{} {} {} {} {}".format(P3, P4, P1, P2, sets))
    await ctx.message.delete()
    wins = headtohead(P1, P2)[0]*(unplayed(P1, P2)[0]+ unplayed(P1, P2)[2] * 0.5)
    losses = headtohead(P1, P2)[1]*(unplayed(P1, P2)[1] + unplayed(P1, P2)[3] * 0.5)
    x = float(rankings[rankings.index == P1].iloc[0][2]) 
    y = float(rankings[rankings.index == P2].iloc[0][2])
    qa = 10**(x/1500)
    qb = 10**(y/1500)
    win1 = qa/(qa + qb)
    #win2 = qb/(qa + qb)
    threeset1 = (3 * (win1**2))-(2 * (win1**3))
    #threeset2 = (3 * (win2**2))-(2 * (win2**3))
    fiveset1 = (win1**3)*(1 + 3*(1-win1) + 6*((1-win1)**2))
    #fiveset2 = (win2**3)*(1 + 3*(1-win2) + 6*((1-win2)**2))
    if sets == '1':
        if wins + losses > 0:
            factor1 = wins/(wins + losses)
            #factor2 = losses/(wins + losses)
            #prob1 = (0.3 * factor1 * win1) + (0.7 * win1)
            #prob2 = (0.3 * factor2 * win2) + (0.7 * win2)
            #prob = ((1-(prob2 + prob1)))*win1 + prob1 
            prob = 0.6*factor1*win1 + (0.3*(win1**2))-(0.6*factor1*(win1**2)) + 0.7*win1#)*unplayed(P1, P2)[0] + ((1-unplayed(P1, P2)[0])*0.5)
            await ctx.send("{} has a {} % chance of winning against {}".format(P3,(round(prob*100,3)),P4))
            #await ctx.send(round(prob,2)) 
        else:
            await ctx.send("{} has a {} % chance of winning against {}".format(P3,(round(win1*100,3)),P4))        
    if sets == '3':
        if wins + losses > 0:
            factor1 = wins/(wins + losses)
           # factor2 = losses/(wins + losses)
           # prob1 = (0.3 * factor1 * threeset1) + (0.7 * threeset1)
           # prob2 = (0.3 * factor2 * threeset2) + (0.7 * threeset2)
           # prob = ((1-(prob2 + prob1)))*threeset1 + prob1 
            prob = 0.6*factor1*threeset1 + (0.3*(threeset1**2))-(0.6*factor1*(threeset1**2)) + 0.7*threeset1#)*unplayed(P1, P2)[0] + ((1-unplayed(P1, P2)[0])*0.5)
            await ctx.send("{} has a {} % chance of winning against {}".format(P3,round(prob*100,3),P4))     
        else:
            await ctx.send("{} has a {} % chance of winning against {}".format(P3,(round(threeset1*100,3)),P4))
            
             
    if sets == '5':
        if wins + losses > 0:
            factor1 = wins/(wins + losses)
           # factor2 = losses/(wins + losses)
           # prob1 = (0.3 * factor1 * fiveset1) + (0.7 * fiveset1)
           # prob2 = (0.3 * factor2 * fiveset2) + (0.7 * fiveset2)
           # prob = ((1-(prob2 + prob1)))*fiveset1 + prob1 
            prob = 0.6*factor1*fiveset1 + (0.3*(fiveset1**2))-(0.6*factor1*(fiveset1**2)) + 0.7*fiveset1#)*unplayed(P1, P2)[0] + ((1-unplayed(P1, P2)[0])*0.5)
            await ctx.send("{} has a {} % chance of winning against {}".format(P3,(round(prob*100,3)),P4))
        else:
            await ctx.send("{} has a {} % chance of winning against {}".format(P3,(round(fiveset1*100,3)),P4))        
             
@client.command(pass_context = True)  
async def headyhead(ctx, P3, P4, P1, P2):
    print("{}{}".format(P1,P2))
    await ctx.message.delete()
    wins = []
    losses = []
    for x in range(len(data2)):
        if data2[x][3] == (P1 + P2 + 'W'): 
            wins.append(data2[x][6])
        if data2[x][3] == (P1 + P2 + 'L'): 
            losses.append(data2[x][6])
    wins = len (wins)
    losses = len (losses)
    await ctx.send("Head to Head")
    await ctx.send("{} {} - {} {}".format(P3, wins, losses, P4)) 
def findRoundWinners(roundPlayers, sets, display, pointDict):
    ## get each pair of players, return list of 'winners'
    nextRound = []
    roundMatches = int(len(roundPlayers)/2)
    draw = createTuple('drawsim.csv')

    firstRound = []
    resultDict = {}

    for i in range(roundMatches):
        j = i*2
        playerOne = roundPlayers[j]
        playerTwo = roundPlayers[j+1]
        if playerOne == 'Bye':
            oneWp = 0
        else:
            if playerTwo == 'Bye':
                oneWp = 1
            else:
                oneWp = calcWp(pointDict[playerOne], pointDict[playerTwo], playerOne, playerTwo, sets)
        winnum = random.random() 
        if winnum < oneWp: 
            winner = playerOne
            if pointDict[playerOne] > 2400:
                f = 16
            else:
                if pointDict[playerOne] > 2100 and (pointDict[playerOne] < 2400):
                    f = 24
                else:
                    if pointDict[playerOne] < 2100:
                        f = 32
            if pointDict[playerTwo] > 2400:
                g = 16
            else:
                if pointDict[playerTwo] > 2100 and (pointDict[playerTwo] < 2400):
                    g = 24
                else:
                    if pointDict[playerTwo] < 2100:
                        g = 32
            pointDict[playerOne] = pointDict[playerOne] + (f*(oneWp-winnum))
            pointDict[playerTwo] = pointDict[playerTwo] + (g*(winnum - oneWp))
        else:   
            winner = playerTwo
            if pointDict[playerOne] > 2400:
                f = 16
            else:
                if pointDict[playerOne] > 2100 and (pointDict[playerOne] < 2400):
                    f = 24
                else:
                    if pointDict[playerOne] < 2100:
                        f = 32
            if pointDict[playerTwo] > 2400:
                g = 16
            else:
                if pointDict[playerTwo] > 2100 and (pointDict[playerTwo] < 2400):
                    g = 24
                else:
                    if pointDict[playerTwo] < 2100:
                        g = 32
            pointDict[playerOne] = pointDict[playerOne] + (f*(oneWp-winnum))
            pointDict[playerTwo] = pointDict[playerTwo] + (g*(winnum-oneWp))  
        #if display == 1:
          #  print(pointDict)
        nextRound.append(winner)
   # for pl in draw:
   #     pointDict[pl[0]] = int(float(pl[2]))
    if display == 1:
        print(pointDict['Dani21'])
        print(nextRound)
    else:
        pass

    return nextRound
#sims = 2000
draw = createTuple('drawsim.csv') 

@client.command(pass_context = True)
async def printdraw(ctx, x):
    print("{}".format(x))
    await ctx.send(['Name', 'Seed', 'Elo'])
    for i in range(len(draw)):
      await ctx.send(draw[i])
blankResults = {1: 0,
                2: 0,
                4: 0,
                8: 0
                }

for z in [17, 33, 65]:
    if len(draw) > z:
        dsize = (z-1)
        blankResults[dsize] = 0

pointDict = {}
firstRound = []
resultDict = {}
for pl in draw:
    pointDict[pl[0]] = int(float(pl[2]))
    firstRound.append(pl[0])
    resultDict[pl[0]] = copy.deepcopy(blankResults)
  
@client.command(pass_context = True)
async def sim(ctx, x, simmy):
    print("{}{}".format(x, simmy))
    await ctx.message.delete()
    await ctx.send("**{} projections - {} run simulation**".format(x, simmy))
    simmy = int(float(simmy))
    djokorer = await client.fetch_user(859691230941282304)

    # initialise Elo dict and first round players
    pointDict = {pl[0]: int(float(pl[2])) for pl in draw}
    firstRound = [pl[0] for pl in draw]

    # initialise resultDict: each player gets a blank round record
    max_round = len(firstRound)
    blankResults = {r: 0 for r in [64, 32, 16, 8, 4, 2, 1] if r <= max_round}
    resultDict = {pl[0]: copy.deepcopy(blankResults) for pl in draw if pl[0] != "Bye"}

    for run in range(simmy):
        # --- progress reporting every 10% ---
        if run % (simmy // 10) == 0:
            await djokorer.send(run)

        # fresh Elo values for each run
        simPointDict = copy.deepcopy(pointDict)
        nextRound = firstRound[:]

        # 🔍 Debug actual calcWp outputs (only once, on first run)
        if run == 0:
            try:
                pA, pB = "JiJo", "TheLittleNinjai1"
                pDeb = "Debuffy"
                prob_A = calcWp(simPointDict[pA], simPointDict[pB], pA, pB, 5)
                prob_D_vs_A = calcWp(simPointDict[pDeb], simPointDict[pA], pDeb, pA, 5)
                prob_D_vs_B = calcWp(simPointDict[pDeb], simPointDict[pB], pDeb, pB, 5)
                await djokorer.send(
                    f"Check probabilities:\n"
                    f"  JiJo vs Ninjai (R1): {prob_A:.3f} / {1-prob_A:.3f}\n"
                    f"  Debuffy vs JiJo: {prob_D_vs_A:.3f}\n"
                    f"  Debuffy vs Ninjai: {prob_D_vs_B:.3f}"
                )
            except Exception as e:
                await djokorer.send(f"Debug error: {e}")

        # mark initial participation (all players in starting draw)
        if len(nextRound) in blankResults:
            for p in nextRound:
                if p != "Bye":
                    resultDict[p][len(nextRound)] += 1

        while len(nextRound) > 1:
            winners = []
            for i in range(0, len(nextRound), 2):
                p1, p2 = nextRound[i], nextRound[i+1]
                if p1 == "Bye":
                    winner = p2
                elif p2 == "Bye":
                    winner = p1
                else:
                    prob_p1 = calcWp(simPointDict[p1], simPointDict[p2], p1, p2, 5)
                    winnum = random.random()
                    if winnum < prob_p1:
                        winner = p1
                        score1, score2 = 1, 0
                    else:
                        winner = p2
                        score1, score2 = 0, 1

                    # --- Elo updates ---
                    for player, score, expected in [
                        (p1, score1, prob_p1),
                        (p2, score2, 1 - prob_p1)
                    ]:
                        if simPointDict[player] > 2400:
                            k = 16
                        elif simPointDict[player] > 2100:
                            k = 24
                        else:
                            k = 32
                        simPointDict[player] += k * (score - expected)

                winners.append(winner)

            # ✅ only winners get credited for the next round
            if len(winners) in blankResults:
                for w in winners:
                    if w != "Bye":
                        resultDict[w][len(winners)] += 1

            nextRound = winners

    # build result table
    header = ['Player', 'Seed', 'Elo'] + [f"R{r}" for r in sorted(blankResults.keys(), reverse=True)]
    resultTable = [header]

    for pl in draw:
        if pl[0] != 'Bye':
            p = pl[0]
            row = list(pl[:3])
            for r in sorted(blankResults.keys(), reverse=True):
                perc = resultDict[p][r] / float(simmy)
                row.append(round(perc, 3))
            resultTable.append(row)

    # save to CSV and send
    writeMatrixCSV(resultTable, 'drawsimresults.csv')
    predictions = pd.read_csv('drawsimresults.csv').sort_values(by=['R1'], ascending=False).round(3)
    await djokorer.send('predictions.csv', file=discord.File('drawsimresults.csv'))

    # --- Debug: R16 chances for Debuffy, JiJo, Ninjai ---
    debug_players = ["Debuffy", "JiJo", "TheLittleNinjai1"]
    msg = "R16 chances:\n"
    for p in debug_players:
        if p in resultDict:
            r16_chance = resultDict[p].get(16, 0) / simmy
            msg += f"  {p}: {r16_chance:.3%}\n"
    await djokorer.send(msg)


@client.command()
async def ping(ctx):
    await ctx.send("🏓 Pong!")

#@client.event
#async def on_ready():
#    print(f"[✅ BOT ONLINE] Logged in as: {client.user} (ID: {client.user.id})")

def _dashboard_event_category(
    value: typing.Any,
    explicit: typing.Any = None,
) -> str:
    category = str(explicit or "").strip().casefold()
    if category:
        return category
    return tournament_category(value)


def _dashboard_event_start(
    value: typing.Any,
    fallback: typing.Any = None,
) -> tuple[int, int, int]:
    for candidate in (value, fallback):
        date_key = _dashboard_date_key(candidate)
        if date_key != (0, 0, 0):
            return date_key
    return (0, 0, 0)


def _dashboard_cross_category_court_match(
    screenshot_category: str,
    official_category: str,
    screenshot_start: tuple[int, int, int],
    official_start: tuple[int, int, int],
) -> bool:
    """Allow only challenger/futures ↔ numbered main-tour court sharing."""
    lower_categories = {"challenger", "futures"}
    main_categories = {"250", "500", "1000"}
    return (
        screenshot_start != (0, 0, 0)
        and screenshot_start == official_start
        and (
            (
                screenshot_category in lower_categories
                and official_category in main_categories
            )
            or (
                official_category in lower_categories
                and screenshot_category in main_categories
            )
        )
    )


def run_bot():
    """Acquire the deployment singleton lease and run the Discord client."""
    if os.getenv("DISCORD_BOT_ENABLED", "").strip().lower() not in {
        "1",
        "true",
        "yes",
        "on",
    }:
        print(
            "[Discord] Bot disabled for this environment; "
            "health endpoint remains active.",
            flush=True,
        )
        return
    token = os.getenv("TOKEN")
    if token:
        bot_lease = None
        try:
            while bot_lease is None:
                bot_lease = try_acquire_bot_lease()
                if bot_lease is None:
                    print(
                        "[Discord singleton] Another deployed bot session is "
                        "active; retrying in 15 seconds.",
                        flush=True,
                    )
                    time.sleep(15)
            print("[Discord singleton] Acquired deployment lease.", flush=True)
            stats_store = restore_screenshot_stats_store(
                MATCH_STATS_WORKBOOK,
                MATCH_STATS_RECEIPTS_FILE,
            )
            counts = stats_store["counts"]
            print(
                "[Screenshot Stats] Durable workbook ready "
                f"(ATP {counts['atp']}, WTA {counts['wta']}, "
                f"doubles {counts['dubs']}; "
                f"{stats_store['receipt_count']} receipts; "
                f"revision {stats_store['revision']}; "
                f"migrated={stats_store['migrated']}).",
                flush=True,
            )
            client.run(token)
        except Exception as e:
            print(
                f"Discord bot startup/runtime error: {e}",
                flush=True,
            )
            raise
        finally:
            release_bot_lease(bot_lease)
    else:
        print("❌ TOKEN is missing.")


 # print(f"An error occurred: {e}")
    
    #system('kill 1')


#client = MyClient(intents=intents)
#client2.run(os.getenv('TOKEN'))
#try:
#  client.run(os.getenv('TOKEN'))
#except Exception as e:
#  print(f"An error occurred: {e}")


async def _screenshot_review_delivery_loop():
    """Deliver a missed or newly due review CSV, retrying after failed sends."""
    await asyncio.sleep(30)
    while True:
        try:
            async with _stats_scrape_lock:
                await _send_daily_screenshot_review_csv()
        except Exception as exc:
            print(f"[Screenshot Review] Daily delivery error: {exc}")
        await asyncio.sleep(60)

def _screenshot_review_reason(
    detail: dict[str, typing.Any],
) -> str | None:
    """Return the human-actionable reconciliation reason for one screenshot."""
    screenshot = detail.get("screenshot") or {}
    official = detail.get("official") or {}
    screenshot_score = str(screenshot.get("result") or "").strip()
    official_score = str(official.get("result") or "").strip()
    status = detail.get("status")
    if (
        status == "matched"
        and str(detail.get("match_method") or "").startswith(
            ("trusted ATP Cup", "manual Squeaky verification")
        )
    ):
        return None
    if status == "unmatched":
        reason = detail.get("review_reason") or "No unique official match found"
        return (
            "No unique official match found"
            if reason == "No compatible official WTSL result."
            else reason
        )
    if status == "davis_cup":
        return detail.get("review_reason") or (
            "Davis Cup — results are hosted separately"
        )
    if status != "matched":
        return None
    if not _dashboard_score_key(screenshot_score):
        return "Screenshot score unavailable"
    if not _dashboard_score_key(official_score):
        return "Official score unavailable"
    if _dashboard_score_is_partial(
        _dashboard_score_key(screenshot_score),
        _dashboard_score_key(official_score),
        screenshot_score,
    ):
        return None
    if _dashboard_score_key(screenshot_score) != _dashboard_score_key(official_score):
        return "Score discrepancy"
    return None


def _screenshot_review_annotations(
    summaries: list[dict[str, typing.Any]],
    official_results: list[dict[str, typing.Any]],
) -> dict[str, dict[tuple[str, str], dict[str, str]]]:
    """Map raw screenshot match keys to their workbook review labels."""
    annotations: dict[str, dict[tuple[str, str], dict[str, str]]] = {
        "atp": {},
        "wta": {},
    }
    official_by_player = _screenshot_official_results_by_player(official_results)
    for summary in summaries:
        player = str(summary.get("player") or "").strip()
        tour = str(summary.get("tour") or "").casefold()
        if not player or tour not in annotations or not summary.get("match_records"):
            continue
        details: list[dict[str, typing.Any]] = []
        _screenshot_coverage_lines(
            summary,
            {
                "player_name": player,
                "official_results": official_by_player.get(
                    (tour, _dashboard_player_key(player)),
                    [],
                ),
            },
            details,
            include_unavailable_official_scores=True,
        )
        matched_count = sum(
            detail.get("status") == "matched" for detail in details
        )
        unmatched_count = sum(
            detail.get("status") == "unmatched" for detail in details
        )
        reconciliation_count = matched_count + unmatched_count
        unmatched_review_is_reliable = (
            reconciliation_count > 0
            and matched_count / reconciliation_count >= 0.70
        )
        for detail in details:
            screenshot = detail.get("screenshot") or {}
            match_key = str(screenshot.get("match_key") or "").strip()
            reason = _screenshot_review_reason(detail)
            if not match_key or not reason:
                continue
            if (
                detail.get("status") == "unmatched"
                and not unmatched_review_is_reliable
            ):
                continue
            status = (
                "DAVIS CUP"
                if detail.get("status") == "davis_cup"
                else "FOR REVIEW"
            )
            locator = (_dashboard_player_key(player), match_key.casefold())
            existing = annotations[tour].get(locator)
            if existing and existing["status"] == "FOR REVIEW":
                continue
            annotations[tour][locator] = {
                "status": status,
                "reason": reason,
            }
    return annotations


def _build_screenshot_review_csv(
    summaries: list[dict[str, typing.Any]],
    official_results: list[dict[str, typing.Any]],
) -> tuple[bytes, int]:
    """Build actionable screenshot reconciliation records for admin review."""
    fields = [
        "Tour",
        "Player",
        "Date",
        "Screenshot tournament",
        "Official or inferred tournament",
        "Opponent",
        "Screenshot score",
        "Official score",
        "Review reason",
    ]
    review_rows = []
    official_by_player = _screenshot_official_results_by_player(official_results)
    for summary in summaries:
        player = str(summary.get("player") or "").strip()
        tour = str(summary.get("tour") or "").casefold()
        if not player or not summary.get("match_records"):
            continue
        details: list[dict[str, typing.Any]] = []
        _screenshot_coverage_lines(
            summary,
            {
                "player_name": player,
                "official_results": official_by_player.get(
                    (tour, _dashboard_player_key(player)),
                    [],
                ),
            },
            details,
            include_unavailable_official_scores=True,
        )
        if not details:
            seen_records = set()
            for record in summary.get("match_records") or []:
                if _dashboard_record_is_exhibition(record):
                    continue
                record_key = (
                    _dashboard_year_key(record.get("date")),
                    _dashboard_event_identity(record.get("tournament")),
                    _dashboard_event_category(
                        record.get("tournament"),
                        record.get("event_category") or record.get("category"),
                    ),
                    _dashboard_score_key(record.get("result")),
                    *_dashboard_pair_key(player, record.get("opponent")),
                )
                if record_key in seen_records:
                    continue
                seen_records.add(record_key)
                details.append({
                    "status": (
                        "davis_cup"
                        if _dashboard_record_is_davis_cup(record)
                        else "unmatched"
                    ),
                    "screenshot": record,
                    "official_candidates": [],
                    "review_reason": (
                        "Davis Cup — included in screenshot statistics; "
                        "results are hosted separately from the WTSL "
                        "tournament feed."
                        if _dashboard_record_is_davis_cup(record)
                        else None
                    ),
                })
        for detail in details:
            screenshot = detail.get("screenshot") or {}
            official = detail.get("official")
            screenshot_score = str(screenshot.get("result") or "").strip()
            official_score = str((official or {}).get("result") or "").strip()
            reason = _screenshot_review_reason(detail)
            if not reason:
                continue
            review_rows.append({
                "Tour": str(summary.get("tour") or "").upper(),
                "Player": player,
                "Date": _screenshot_review_date(screenshot.get("date")),
                "Screenshot tournament": str(
                    screenshot.get("tournament") or ""
                ).strip(),
                "Official or inferred tournament": _screenshot_review_tournament(
                    detail
                ),
                "Opponent": _screenshot_review_opponent(
                    player, screenshot, official
                ),
                "Screenshot score": screenshot_score,
                "Official score": official_score,
                "Review reason": reason,
            })
    review_rows.sort(
        key=lambda row: (
            row["Tour"],
            _dashboard_player_key(row["Player"]),
            row["Date"],
            row["Screenshot tournament"].casefold(),
            row["Opponent"].casefold(),
            row["Review reason"],
        )
    )
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    writer.writerows(review_rows)
    return output.getvalue().encode("utf-8"), len(review_rows)

def _screenshot_review_opponent(
    player: str,
    screenshot: dict[str, typing.Any],
    official: dict[str, typing.Any] | None,
) -> str:
    opponent = str(screenshot.get("opponent") or "").strip()
    if opponent or not official:
        return opponent
    player_key = _dashboard_player_key(player)
    first = str(official.get("p1") or official.get("player1") or "").strip()
    second = str(official.get("p2") or official.get("player2") or "").strip()
    return second if _dashboard_player_key(first) == player_key else first

async def _screenshot_review_receipt_exists(
    owner: typing.Any, delivery_date: str
) -> bool:
    """Check recent owner-DM receipts before retrying an uncertain daily send."""
    create_dm = getattr(owner, "create_dm", None)
    if not callable(create_dm):
        return False
    try:
        channel = getattr(owner, "dm_channel", None) or await create_dm()
        if channel is None:
            return False
        start = datetime.combine(
            _dt.date.fromisoformat(delivery_date),
            _dt.time.min,
            tzinfo=STATS_TIMEZONE,
        ).astimezone(timezone.utc)
        bot_id = getattr(getattr(client, "user", None), "id", None)
        receipt = _screenshot_review_receipt(delivery_date)
        async for message in channel.history(limit=250, after=start):
            if (
                receipt in str(getattr(message, "content", ""))
                and (
                    bot_id is None
                    or getattr(getattr(message, "author", None), "id", None)
                    == bot_id
                )
            ):
                return True
    except Exception as exc:
        print(f"[Screenshot Review] Receipt recovery check failed: {exc}")
    return False

def _screenshot_review_tournament(
    detail: dict[str, typing.Any],
) -> str:
    official = detail.get("official")
    if official:
        return str(official.get("tournament") or "").strip()
    candidates = detail.get("official_candidates") or []
    names = sorted({
        str(candidate.get("tournament") or "").strip()
        for candidate in candidates
        if str(candidate.get("tournament") or "").strip()
    })
    return " | ".join(names)

async def _send_daily_screenshot_review_csv() -> bool:
    """Send the all-player screenshot reconciliation CSV once per local day."""
    today = datetime.now(STATS_TIMEZONE).date().isoformat()
    state = _load_stats_delivery_state()
    if state.get("screenshot_review_last_sent_date") == today:
        return False
    if not MATCH_STATS_WORKBOOK.exists():
        raise RuntimeError(
            "Screenshot review CSV could not be built because the workbook is missing"
        )
    owner = await client.fetch_user(OWNER_ID)
    if await _screenshot_review_receipt_exists(owner, today):
        state["screenshot_review_last_sent_date"] = today
        _save_stats_delivery_state(state)
        print("[Screenshot Review] Recovered prior daily delivery from owner DM")
        return False
    official_results = await _get_matchlog_official_results()
    summaries = await asyncio.to_thread(
        get_screenshot_match_record_summaries, MATCH_STATS_WORKBOOK
    )
    csv_bytes, row_count = await asyncio.to_thread(
        _build_screenshot_review_csv, summaries, official_results
    )
    await owner.send(
        "📋 **Daily screenshot match review**\n"
        f"{row_count} record{' needs' if row_count == 1 else 's need'} review. "
        "This export excludes exhibition matches.\n"
        + _screenshot_review_receipt(today),
        file=discord.File(
            io.BytesIO(csv_bytes),
            filename=SCREENSHOT_REVIEW_CSV_FILENAME,
        ),
    )
    state["screenshot_review_last_sent_date"] = today
    _save_stats_delivery_state(state)
    print(
        f"[Screenshot Review] Sent daily CSV with {row_count} review record(s)"
    )
    return True


if __name__ == "__main__":
    run_bot()
