import json
from pathlib import Path
import tempfile
import unittest
from collections import Counter

from openpyxl import Workbook, load_workbook

from screenshot_stats_store import (
    _analyze_workbook,
    _contains_all,
    _read_processed,
)
from tennis_stats_scraper import REQUIRED_SOURCE_HEADERS


def make_snapshot_workbook(path: Path) -> None:
    workbook = Workbook()
    atp = workbook.active
    atp.title = "atp"
    wta = workbook.create_sheet("wta")
    workbook.create_sheet("ATP Summary")
    workbook.create_sheet("WTA Summary")
    dubs = workbook.create_sheet("dubs")
    for sheet, player in ((atp, "Alpha"), (wta, "Bravo")):
        sheet.append(list(REQUIRED_SOURCE_HEADERS))
        row = [None] * len(REQUIRED_SOURCE_HEADERS)
        values = {
            "ID": 1,
            "Player": player,
            "Opponent": "Opponent",
            "Tournament": "Test Open",
            "Date": "2026-09-25",
            "Result": "6-4 6-4",
        }
        for index, header in enumerate(REQUIRED_SOURCE_HEADERS):
            if header in values:
                row[index] = values[header]
        sheet.append(row)
    dubs.append(["ID", "Player", "Opponent", "Tournament", "Date", "Result"])
    dubs.append([1, "Pair One & Pair Two", "Pair Three & Pair Four", "Test Open", "2026-09-25", "6-4 6-4"])
    workbook.save(path)
    workbook.close()


class ScreenshotStatsStoreTests(unittest.TestCase):
    def test_workbook_validation_counts_all_three_tours(self):
        with tempfile.TemporaryDirectory() as directory:
            workbook_path = Path(directory) / "stats.xlsx"
            make_snapshot_workbook(workbook_path)

            analysis = _analyze_workbook(workbook_path)

            self.assertEqual(
                analysis["counts"],
                {"atp": 1, "wta": 1, "dubs": 1},
            )
            self.assertEqual(set(analysis["records"]), {"atp", "wta", "dubs"})

    def test_analysis_counts_nonempty_legacy_rows_without_player_names(self):
        with tempfile.TemporaryDirectory() as directory:
            workbook_path = Path(directory) / "stats.xlsx"
            make_snapshot_workbook(workbook_path)
            workbook = load_workbook(workbook_path)
            atp = workbook["atp"]
            legacy_atp_row = [None] * len(REQUIRED_SOURCE_HEADERS)
            for index, header in enumerate(REQUIRED_SOURCE_HEADERS):
                if header == "Opponent":
                    legacy_atp_row[index] = "Legacy opponent"
                elif header == "Tournament":
                    legacy_atp_row[index] = "Test Open"
                elif header == "Date":
                    legacy_atp_row[index] = "2026-09-24"
                elif header == "Result":
                    legacy_atp_row[index] = "6-4 6-4"
            atp.append(legacy_atp_row)
            workbook["dubs"].append(
                [2, None, "Legacy pair", "Test Open", "2026-09-24", "6-4 6-4"]
            )
            workbook.save(workbook_path)
            workbook.close()

            analysis = _analyze_workbook(workbook_path)

            self.assertEqual(
                analysis["counts"],
                {"atp": 2, "wta": 1, "dubs": 2},
            )

    def test_missing_doubles_sheet_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            workbook_path = Path(directory) / "stats.xlsx"
            make_snapshot_workbook(workbook_path)
            workbook = load_workbook(workbook_path)
            workbook.remove(workbook["dubs"])
            workbook.save(workbook_path)
            workbook.close()

            with self.assertRaisesRegex(RuntimeError, "doubles sheet"):
                _analyze_workbook(workbook_path)

    def test_receipts_are_deduplicated_and_malformed_ledger_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            ledger = Path(directory) / "receipts.json"
            ledger.write_text(
                json.dumps(["100:201", "100:201", "101:202"]),
                encoding="utf-8",
            )
            self.assertEqual(
                _read_processed(ledger),
                ["100:201", "101:202"],
            )
            ledger.write_text(json.dumps([None]), encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError, "JSON list"):
                _read_processed(ledger)

    def test_record_superset_check_keeps_sheet_identity(self):
        atp_row = ("id=1", "player=alpha")
        dubs_row = ("id=1", "player=pair")
        complete = {
            "atp": Counter({atp_row: 1}),
            "wta": Counter(),
            "dubs": Counter({dubs_row: 1}),
        }
        missing_atp = {
            "atp": Counter(),
            "wta": Counter(),
            "dubs": Counter({dubs_row: 1}),
        }
        self.assertTrue(_contains_all(complete, missing_atp))
        self.assertFalse(_contains_all(missing_atp, complete))


if __name__ == "__main__":
    unittest.main()