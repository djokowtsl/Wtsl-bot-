"""Production VM entrypoint with an independent early health server."""

import signal
import subprocess
import sys


health_process = subprocess.Popen([sys.executable, "health_server.py"])


def _stop_health_server(_signum, _frame):
    if health_process.poll() is None:
        health_process.terminate()
    raise SystemExit(0)


signal.signal(signal.SIGTERM, _stop_health_server)
signal.signal(signal.SIGINT, _stop_health_server)

try:
    from main import run_bot

    run_bot()
finally:
    if health_process.poll() is None:
        health_process.terminate()
        health_process.wait(timeout=10)