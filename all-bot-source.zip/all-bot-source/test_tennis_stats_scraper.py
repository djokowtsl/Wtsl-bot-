import tempfile
import unittest
import unittest.mock
import csv
from datetime import date
from pathlib import Path
from types import SimpleNamespace

from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils import get_column_letter

from tennis_stats_scraper import (
    SINGLES_COLUMNS,
    apply_review_annotations,
    append_rows,
    build_rows,
    canonicalize_match,
    correct_existing_match_tours,
    export_atp_columns_csv,
    extract_match,
    leaderboard_rows,
    MODEL,
    VISION_MAX_COMPLETION_TOKENS,
    player_summary,
    promote_statistics_workbook,
    query_match_stat_values,
    recalculate_summary_sheets,
    reconcile_workbook_tours,
    validate_statistics_workbook,
)
from overall_ratings import OVERALL_RATING_COLUMNS


SOURCE_HEADERS = [
    "ID", "Image Name", "Player", "ELO", "Crc", "Result", "Opponent",
    "Opponent ELO", "Opponent Crc", "Tournament", "Date",
    *SINGLES_COLUMNS[10:33], "", "Unique ID A", "Unique ID B",
    "Full Unique ID", "Unique ID", "Notes",
]
SUMMARY_HEADERS = [
    "Player",
    "Unique matches",
    *[f"{metric} matches used" for metric in SINGLES_COLUMNS[10:33]],
    *SINGLES_COLUMNS[10:33],
]


def source_row(
    row_id,
    image,
    player,
    complete=True,
    opponent="Opponent",
    tournament="Tournament",
    match_date=date(2025, 1, 1),
):
    row = {header: None for header in SOURCE_HEADERS}
    row.update(
        {
            "ID": row_id,
            "Image Name": image,
            "Player": player,
            "Opponent": opponent,
            "Result": "6-4 6-4",
            "Tournament": tournament,
            "Date": match_date,
            "Unique ID": f"=B{row_id + 1}&C{row_id + 1}",
        }
    )
    if complete:
        for index, metric in enumerate(SINGLES_COLUMNS[10:33], start=1):
            row[metric] = float(index)
    return row


def make_workbook(path: Path):
    workbook = Workbook()
    atp = workbook.active
    atp.title = "atp"
    wta = workbook.create_sheet("wta")
    workbook.create_sheet("ATP Summary")
    workbook.create_sheet("WTA Summary")
    for sheet in (atp, wta):
        sheet.append(SOURCE_HEADERS)
    for index, sheet in enumerate((workbook["ATP Summary"], workbook["WTA Summary"])):
        sheet.append(["Summary"])
        sheet.append(["Match-level averages; each metric uses only populated matches."])
        sheet.append(["Players represented: 0 | Unique matches: 0"])
        sheet.append([])
        sheet.append(SUMMARY_HEADERS)
        sheet.append(["Stale player", 0, 0, *([0] * len(SINGLES_COLUMNS[10:33]))])
        for cell in sheet[6]:
            cell.fill = PatternFill(fill_type="solid", fgColor="D9EAF7")
        table = Table(
            displayName=("ATPSummaryTable" if index == 0 else "WTASummaryTable"),
            ref=f"A5:{get_column_letter(len(SUMMARY_HEADERS))}6",
        )
        table.tableStyleInfo = TableStyleInfo(
            name="TableStyleMedium2",
            showRowStripes=True,
        )
        sheet.add_table(table)
    workbook.save(path)


class VisionExtractionTests(unittest.IsolatedAsyncioTestCase):
    async def test_extract_match_leaves_reasoning_headroom(self):
        response = SimpleNamespace(
            choices=[
                SimpleNamespace(
                    finish_reason="stop",
                    message=SimpleNamespace(
                        content='{"is_doubles": false, "player": {"name": "Alpha"}}'
                    ),
                )
            ]
        )
        create = unittest.mock.AsyncMock(return_value=response)
        client = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace(create=create))
        )

        with unittest.mock.patch(
            "tennis_stats_scraper.AsyncOpenAI",
            return_value=client,
        ):
            result = await extract_match(
                [("match.png", "image/png", b"image-bytes")],
                "Alpha beat Beta",
                "https://example.test/v1",
                "test-key",
            )

        self.assertEqual(result["player"]["name"], "Alpha")
        self.assertEqual(create.call_args.kwargs["model"], MODEL)
        self.assertEqual(
            create.call_args.kwargs["max_completion_tokens"],
            VISION_MAX_COMPLETION_TOKENS,
        )

    async def test_extract_match_reports_empty_response_metadata(self):
        response = SimpleNamespace(
            choices=[
                SimpleNamespace(
                    finish_reason="length",
                    message=SimpleNamespace(content="", refusal=None),
                )
            ]
        )
        create = unittest.mock.AsyncMock(return_value=response)
        client = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace(create=create))
        )

        with unittest.mock.patch(
            "tennis_stats_scraper.AsyncOpenAI",
            return_value=client,
        ):
            with self.assertRaisesRegex(
                RuntimeError,
                r"Vision model returned no content \(finish_reason='length'\)",
            ):
                await extract_match(
                    [("match.png", "image/png", b"image-bytes")],
                    "",
                    "https://example.test/v1",
                    "test-key",
                )


class WorkbookSummaryTests(unittest.TestCase):
    def test_query_match_stat_values_filters_exact_set_count(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            make_workbook(path)
            workbook = load_workbook(path)
            row = source_row(
                1,
                "three-set.png",
                "Alpha",
                match_date=date(2025, 1, 2),
            )
            row["Result"] = "6-4 4-6 6-2"
            row["Aces"] = 17
            row["Unique ID B"] = "three-set"
            workbook["atp"].append([
                row.get(header) for header in SOURCE_HEADERS
            ])
            workbook.save(path)
            workbook.close()

            values = query_match_stat_values(path, "Aces", set_count=3)

            self.assertEqual(len(values), 1)
            self.assertEqual(values[0]["value"], 17)
            self.assertEqual(values[0]["sets"], 3)
            opponent_values = query_match_stat_values(
                path,
                "Aces",
                opponent_name="Opponent",
            )
            self.assertEqual(len(opponent_values), 1)
            self.assertEqual(opponent_values[0]["opponent"], "Opponent")

    def test_review_annotations_are_filterable_and_clear_stale_flags(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            workbook = Workbook()
            atp = workbook.active
            atp.title = "atp"
            wta = workbook.create_sheet("wta")
            for sheet in (atp, wta):
                sheet.append([
                    "Player", "Opponent", "Tournament", "Date", "Result",
                    "Unique ID B",
                ])
            atp.append([
                "Alpha", "Beta", "US Open", "2026-09-07", "6-0 6-0",
                "alpha-us-open",
            ])
            atp.append([
                "Alpha", "Beta", "US Open", "2026-09-07", "6-0 6-0",
                "alpha-us-open",
            ])
            atp.append([
                "Gamma", "Delta", "Rome", "2026-09-08", "6-4 6-4",
                "stale-flag",
            ])
            wta.append([
                "Epsilon", "Zeta", "Davis Cup", "2026-09-09", "6-4 6-4",
                "davis-cup",
            ])
            workbook.save(path)
            workbook.close()

            marked = apply_review_annotations({
                "atp": {
                    "alpha-us-open": {
                        "status": "FOR REVIEW",
                        "reason": "Score discrepancy",
                    },
                },
                "wta": {
                    "davis-cup": {
                        "status": "DAVIS CUP",
                        "reason": "Results are hosted separately",
                    },
                },
            }, path)

            workbook = load_workbook(path, data_only=True)
            try:
                atp = workbook["atp"]
                wta = workbook["wta"]
                atp_headers = {
                    cell.value: cell.column for cell in atp[1] if cell.value
                }
                wta_headers = {
                    cell.value: cell.column for cell in wta[1] if cell.value
                }
                self.assertEqual(marked, 3)
                self.assertEqual(
                    atp.cell(2, atp_headers["Review Status"]).value,
                    "FOR REVIEW",
                )
                self.assertEqual(
                    atp.cell(2, atp_headers["Review Reason"]).value,
                    "Score discrepancy",
                )
                self.assertEqual(
                    atp.cell(3, atp_headers["Review Status"]).value,
                    "DUPLICATE",
                )
                self.assertIn(
                    "review the first row",
                    atp.cell(3, atp_headers["Review Reason"]).value,
                )
                self.assertIsNone(
                    atp.cell(4, atp_headers["Review Status"]).value
                )
                self.assertEqual(
                    wta.cell(2, wta_headers["Review Status"]).value,
                    "DAVIS CUP",
                )
                self.assertIn(
                    "Results are hosted separately",
                    wta.cell(2, wta_headers["Review Reason"]).value,
                )
            finally:
                workbook.close()

    def test_promotes_valid_workbook_with_backup_and_rebuilt_summaries(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            active = directory / "active.xlsx"
            candidate = directory / "TE4_HUB_new.xlsx"
            make_workbook(active)
            make_workbook(candidate)
            active_bytes = active.read_bytes()
            workbook = load_workbook(candidate)
            for sheet_name, player in (("atp", "Alpha"), ("wta", "Beta")):
                row = source_row(1, f"{sheet_name}.png", player)
                workbook[sheet_name].append(
                    [row.get(header) for header in SOURCE_HEADERS]
                )
            workbook.save(candidate)
            workbook.close()

            result = promote_statistics_workbook(candidate, active)

            self.assertEqual(result["rows"], {"atp": 1, "wta": 1})
            self.assertEqual(result["backup"].read_bytes(), active_bytes)
            promoted = load_workbook(active, data_only=True)
            self.assertEqual(promoted["ATP Summary"]["A6"].value, "Alpha")
            self.assertEqual(promoted["WTA Summary"]["A6"].value, "Beta")
            promoted.close()

    def test_invalid_candidate_leaves_active_workbook_unchanged(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            active = directory / "active.xlsx"
            candidate = directory / "TE4_HUB_invalid.xlsx"
            make_workbook(active)
            before = active.read_bytes()
            workbook = load_workbook(active)
            workbook.remove(workbook["wta"])
            workbook.save(candidate)
            workbook.close()

            with self.assertRaisesRegex(ValueError, "missing required sheets: wta"):
                promote_statistics_workbook(candidate, active)

            self.assertEqual(active.read_bytes(), before)
            self.assertEqual(list(directory.glob("*.backup-*.xlsx")), [])

    def test_validation_rejects_empty_required_source_sheet(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "candidate.xlsx"
            make_workbook(path)
            workbook = load_workbook(path)
            row = source_row(1, "atp.png", "Alpha")
            workbook["atp"].append([row.get(header) for header in SOURCE_HEADERS])
            workbook.save(path)
            workbook.close()

            with self.assertRaisesRegex(ValueError, "WTA sheet has no nonempty"):
                validate_statistics_workbook(path)

    def test_validation_streams_thousands_of_source_rows(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "large-candidate.xlsx"
            make_workbook(path)
            workbook = load_workbook(path)
            row = source_row(1, "bulk.png", "Bulk Player")
            values = [row.get(header) for header in SOURCE_HEADERS]
            for sheet_name in ("atp", "wta"):
                sheet = workbook[sheet_name]
                for _ in range(4000):
                    sheet.append(values)
            workbook.save(path)
            workbook.close()

            self.assertEqual(
                validate_statistics_workbook(path),
                {"atp": 4000, "wta": 4000},
            )

    def test_player_summary_filters_raw_rows_by_period_and_collapses_duplicates(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            make_workbook(path)
            workbook = load_workbook(path)
            atp = workbook["atp"]

            def add(row_id, player, match_date, aces, key):
                row = source_row(row_id, f"{row_id}.png", player, complete=False,
                                 match_date=match_date)
                row["Aces"] = aces
                row["Unique ID B"] = key
                atp.append([row.get(header) for header in SOURCE_HEADERS])

            # The two February rows are partial screenshots of one match and
            # must become one match value (the mean of 40 and 60).
            add(1, "Alpha", date(2024, 12, 31), 10.0, "old")
            add(2, "Alpha", date(2025, 1, 15), 20.0, "january")
            add(3, "Alpha", date(2025, 2, 15), 40.0, "february")
            add(4, "Alpha", date(2025, 2, 15), 60.0, "february")
            add(5, "Alpha", None, 80.0, "undated")
            add(6, "Beta", date(2025, 2, 15), 1.0, "beta")
            unresolved = (
                "Scheduled for 20:00",
                "TBD - awaiting opponent",
                "Pending confirmation",
                "Cancelled due to weather",
                "Postponed until Friday",
            )
            for offset, result in enumerate(unresolved, start=7):
                scheduled = source_row(
                    offset, f"scheduled-{offset}.png", "Alpha",
                    complete=False, match_date=date(2025, 2, 20),
                )
                scheduled["Aces"] = 999.0
                scheduled["Result"] = result
                scheduled["Unique ID B"] = f"scheduled-{offset}"
                atp.append([scheduled.get(header) for header in SOURCE_HEADERS])
            workbook.save(path)
            workbook.close()

            thirty_days = player_summary(path, "Alpha", "atp", "30d", "2025-03-01")
            self.assertEqual(thirty_days["period"], "30d")
            self.assertEqual(thirty_days["period_key"], "30d")
            self.assertEqual(thirty_days["period_label"], "Last 30 days")
            self.assertEqual(thirty_days["matches"], 1)
            metrics = {label: (value, count) for label, value, count in thirty_days["metrics"]}
            self.assertEqual(metrics["Aces"], (50.0, 1))
            self.assertEqual(dict(thirty_days["ratings"])["Serve Rating"], 50.0)
            self.assertEqual(thirty_days["relative_profile"]["serve"]["metrics"][0]["players"], 2)

            year = player_summary(path, "Alpha", "atp", "year", date(2025, 3, 1))
            self.assertEqual(year["matches"], 2)
            self.assertEqual(
                {label: value for label, value, _ in year["metrics"]}["Aces"], 35.0
            )

            ninety_days = player_summary(path, "Alpha", "atp", "90d", "2025-03-01")
            self.assertEqual(ninety_days["matches"], 3)
            self.assertAlmostEqual(
                {label: value for label, value, _ in ninety_days["metrics"]}["Aces"],
                80 / 3,
            )
            fifty_two_weeks = player_summary(path, "Alpha", "atp", "52w", "2025-03-01")
            self.assertEqual(fifty_two_weeks["matches"], 3)
            self.assertAlmostEqual(
                {label: value for label, value, _ in fifty_two_weeks["metrics"]}["Aces"],
                80 / 3,
            )

            career = player_summary(path, "Alpha", "atp")
            self.assertEqual(career["period"], "career")
            self.assertEqual(career["matches"], 4)
            self.assertEqual(
                {label: value for label, value, _ in career["metrics"]}["Aces"], 40.0
            )
            filtered = player_summary(
                path,
                "Alpha",
                "atp",
                excluded_match_keys_by_player={
                    "Alpha": {"february", "undated"},
                },
            )
            self.assertEqual(filtered["matches"], 2)
            self.assertEqual(
                {label: value for label, value, _ in filtered["metrics"]}["Aces"],
                15.0,
            )
            filtered_leaderboard = leaderboard_rows(
                path,
                "atp",
                excluded_match_keys_by_player={
                    "Alpha": {"february", "undated"},
                },
            )
            alpha = next(
                row for row in filtered_leaderboard if row["player"] == "Alpha"
            )
            self.assertEqual(alpha["matches"], 2)
            self.assertEqual(alpha["metrics"]["Aces"], 15.0)

    def test_player_summary_rejects_unknown_period_and_invalid_as_of(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            make_workbook(path)
            with self.assertRaisesRegex(ValueError, "period"):
                player_summary(path, "Alpha", "atp", "week")
            with self.assertRaisesRegex(ValueError, "as_of"):
                player_summary(path, "Alpha", "atp", "30d", "not-a-date")

    def test_export_atp_columns_csv_writes_only_a_ah_and_ak(self):
        with tempfile.TemporaryDirectory() as directory:
            workbook_path = Path(directory) / "stats.xlsx"
            output_path = Path(directory) / "atp.csv"
            make_workbook(workbook_path)
            workbook = load_workbook(workbook_path)
            sheet = workbook["atp"]
            sheet["A2"] = 42
            sheet["B2"] = "must be exported"
            sheet["AH2"] = 0.375
            sheet["AK2"] = "match-key"
            sheet["AI2"] = "must not be exported"
            sheet["AJ2"] = "must not be exported"
            workbook.save(workbook_path)
            workbook.close()

            with unittest.mock.patch(
                "tennis_stats_scraper.MASTER_WORKBOOK", workbook_path
            ):
                rows_written = export_atp_columns_csv(output_path)

            self.assertEqual(rows_written, 1)
            with output_path.open(newline="", encoding="utf-8") as handle:
                rows = list(csv.reader(handle))
            self.assertEqual(len(rows[0]), 35)
            self.assertEqual(rows[0][:3], ["ID", "Image Name", "Player"])
            self.assertEqual(rows[0][33:], ["Breaks / Games %", "Unique ID B"])
            self.assertEqual(len(rows[1]), 35)
            self.assertEqual(rows[1][0], "42")
            self.assertEqual(rows[1][1], "must be exported")
            self.assertEqual(rows[1][33:], ["0.375", "match-key"])
            self.assertNotIn("must not be exported", rows[1][34])

    def test_known_name_aliases_are_canonicalized(self):
        rankings = {
            "atp": {
                "hsm09": "HSM09",
                "itsruze": "itsruze",
                "opponent": "Opponent",
            },
            "wta": {},
        }
        for observed, expected in (
            ("HSM88", "HSM09"),
            ("ruze", "itsruze"),
            ("Squeaky94", "Squeaky"),
        ):
            extracted = {
                "player": {"name": observed},
                "opponent": {"name": "Opponent"},
                "is_doubles": False,
            }
            sheet, result = canonicalize_match(extracted, rankings)
            self.assertEqual(sheet, "atp")
            self.assertEqual(result["player"]["name"], expected)

    def test_wta_court_label_does_not_override_atp_match(self):
        rankings = {
            "atp": {
                "hsm09": "HSM09",
                "elmanzanas": "elmanzanas",
            },
            "wta": {},
        }
        extracted = {
            "player": {"name": "elmanzanas"},
            "opponent": {"name": "HSM09"},
            "stadium": "WTA Court 1",
            "tour_hint": None,
        }

        sheet, _ = canonicalize_match(extracted, rankings)

        self.assertEqual(sheet, "atp")

    def test_reconcile_workbook_tours_moves_unique_official_match(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            make_workbook(path)
            rows = [
                source_row(
                    1,
                    "match.png",
                    "elmanzanas",
                    opponent="HSM09",
                    tournament="Guangzhou WTA 250",
                    match_date=date(2026, 9, 19),
                ),
                source_row(
                    2,
                    "match.png",
                    "HSM09",
                    opponent="elmanzanas",
                    tournament="Guangzhou WTA 250",
                    match_date=date(2026, 9, 19),
                ),
            ]
            rows[0]["Result"] = "6-3 6-7(5) 7-6(5)"
            rows[1]["Result"] = "3-6 7-6(5) 6-7(5)"
            append_rows(
                [{"Sheet": "wta", **row} for row in rows],
                path,
                recalculate_summaries=False,
            )

            result = reconcile_workbook_tours(
                [{
                    "p1": "elmanzanas",
                    "p2": "HSM09",
                    "date": "19.09.2026",
                    "result": "6-3,6-7,7-6",
                    "tour": "atp",
                }],
                path,
            )

            self.assertEqual(len(result["moved"]), 2)
            workbook = load_workbook(path, data_only=True)
            self.assertEqual(workbook["wta"].max_row, 1)
            atp_rows = list(workbook["atp"].iter_rows(min_row=2, values_only=True))
            self.assertEqual(len(atp_rows), 2)
            self.assertTrue(all(row[9] == "Guangzhou ATP 250" for row in atp_rows))
            workbook.close()

    def test_append_maps_image_name_to_verbose_workbook_header(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            make_workbook(path)
            workbook = load_workbook(path)
            workbook["atp"]["B1"] = "Image Name (source file note)"
            workbook["ATP Summary"]["A2"] = "Summary must remain unchanged"
            # Real workbooks can contain formatted blank rows below the data.
            workbook["atp"]["B20"].fill = PatternFill(
                fill_type="solid", fgColor="D9EAF7"
            )
            workbook.save(path)
            workbook.close()

            row = source_row(1, "new-image.png", "Alpha")
            append_rows([{"Sheet": "atp", **row}], path, recalculate_summaries=False)

            workbook = load_workbook(path, data_only=True)
            self.assertEqual(workbook["atp"]["B2"].value, "new-image.png")
            self.assertEqual(
                workbook["ATP Summary"]["A2"].value,
                "Summary must remain unchanged",
            )
            workbook.close()

    def test_summary_collapses_ak_matches_and_uses_metric_specific_denominators(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            make_workbook(path)
            workbook = load_workbook(path)
            atp = workbook["atp"]
            first = source_row(1, "old.png", "  Alpha  ", complete=True)
            duplicate = source_row(2, "duplicate.png", "Alpha", complete=False)
            duplicate["Aces"] = 3.0
            missing = source_row(
                3, "missing.png", "Alpha", complete=False, tournament="Tournament 3"
            )
            missing["Aces"] = 7.0
            beta = source_row(4, "beta.png", "Beta", complete=True)
            atp.append([first.get(header) for header in SOURCE_HEADERS])
            atp.append([duplicate.get(header) for header in SOURCE_HEADERS])
            atp.append([missing.get(header) for header in SOURCE_HEADERS])
            atp.append([beta.get(header) for header in SOURCE_HEADERS])
            workbook.save(path)
            workbook.close()

            new_row = source_row(
                5, "new.png", "Alpha", complete=True, tournament="Tournament 2"
            )
            new_row["Aces"] = 99.0
            append_rows([{"Sheet": "atp", **new_row}], path)

            workbook = load_workbook(path, data_only=True)
            summary = workbook["ATP Summary"]
            alpha_values = {
                summary.cell(5, column).value: summary.cell(6, column).value
                for column in range(1, summary.max_column + 1)
            }
            self.assertEqual(alpha_values["Player"], "Alpha")
            self.assertEqual(alpha_values["Unique matches"], 3)
            self.assertEqual(alpha_values["Aces matches used"], 3)
            self.assertAlmostEqual(alpha_values["Aces"], 36.16666666666666)
            self.assertEqual(alpha_values["1st Serve % matches used"], 2)
            self.assertAlmostEqual(
                alpha_values["Serve (Overall)"],
                (
                    alpha_values["1st Serve %"]
                    + alpha_values["1st Serve Won %"]
                    + alpha_values["2nd Serve Won %"]
                ) * 100
                + alpha_values["Aces"]
                - alpha_values["Double Faults"],
            )
            self.assertAlmostEqual(
                alpha_values["Return (Overall)"],
                alpha_values["Break Points Won %"] * 100,
            )
            self.assertAlmostEqual(
                alpha_values["Under Pressure"],
                alpha_values["Break Points Won %"] * 100,
            )
            self.assertEqual(
                [
                    summary.cell(5, column).value
                    for column in range(
                        summary.max_column - len(OVERALL_RATING_COLUMNS) + 1,
                        summary.max_column + 1,
                    )
                ],
                list(OVERALL_RATING_COLUMNS),
            )
            self.assertEqual(
                summary["A3"].value,
                "Players represented: 2 | Unique matches: 4",
            )
            self.assertIn("AK Unique ID B defines one match", summary["A2"].value)
            self.assertEqual(summary.tables["ATPSummaryTable"].ref, "A5:BL7")
            self.assertEqual(
                len(summary.tables["ATPSummaryTable"].tableColumns), 64
            )
            self.assertEqual(
                [
                    column.name
                    for column in summary.tables["ATPSummaryTable"].tableColumns[-3:]
                ],
                list(OVERALL_RATING_COLUMNS),
            )
            self.assertEqual([summary.cell(row, 1).value for row in range(6, 8)], ["Alpha", "Beta"])
            self.assertEqual(summary.cell(6, 1).style_id, summary.cell(7, 1).style_id)
            self.assertEqual(
                workbook["WTA Summary"]["A3"].value,
                "Players represented: 0 | Unique matches: 0",
            )
            self.assertEqual(workbook["wta"]["AK1"].value, "Unique ID B")
            self.assertEqual(workbook["WTA Summary"].tables["WTASummaryTable"].ref, "A5:BL5")
            self.assertEqual(workbook["WTA Summary"].max_row, 5)
            workbook.close()

            workbook = load_workbook(path, data_only=True)
            reloaded_table = workbook["ATP Summary"].tables["ATPSummaryTable"]
            self.assertEqual(reloaded_table.ref, "A5:BL7")
            self.assertEqual(len(reloaded_table.tableColumns), 64)
            self.assertEqual(
                [column.name for column in reloaded_table.tableColumns[-3:]],
                list(OVERALL_RATING_COLUMNS),
            )
            workbook.close()

    def test_character_columns_and_favorites_preserve_ak(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            make_workbook(path)
            rows = []
            for row_id, character in enumerate(("Sampras", "Agassi", "Sampras"), 1):
                row = source_row(
                    row_id, f"{row_id}.png", "Alpha", complete=True,
                    tournament=f"Tournament {row_id}",
                )
                rows.append({"Sheet": "atp", **row, "Character": character})
            appended = source_row(4, "new.png", "Beta", complete=True)
            rows.append(
                {"Sheet": "atp", **appended, "Character": "Federer",
                 "Opponent Character": "Nadal"}
            )
            append_rows(rows, path)

            workbook = load_workbook(path, data_only=True)
            atp = workbook["atp"]
            headers = {cell.value: cell.column for cell in atp[1] if cell.value}
            self.assertEqual(headers["Unique ID B"], 37)
            self.assertEqual(headers["Character"], 35)  # reusable blank AI
            self.assertNotEqual(headers["Opponent Character"], 37)
            self.assertEqual(atp.cell(5, headers["Character"]).value, "Federer")
            summary_headers = {
                cell.value: cell.column for cell in workbook["ATP Summary"][5] if cell.value
            }
            alpha = {
                header: workbook["ATP Summary"].cell(6, column).value
                for header, column in summary_headers.items()
            }
            self.assertEqual(alpha["Most Picked Character"], "Sampras")
            self.assertEqual(alpha["Character Picks"], 2)
            self.assertAlmostEqual(alpha["Character Pick %"], 2 / 3)
            workbook.close()

            export_path = Path(directory) / "atp.csv"
            with unittest.mock.patch("tennis_stats_scraper.MASTER_WORKBOOK", path):
                export_atp_columns_csv(export_path)
            with export_path.open(newline="", encoding="utf-8") as handle:
                exported_headers = next(csv.reader(handle))
            self.assertIn("Character", exported_headers)
            self.assertIn("Opponent Character", exported_headers)
            self.assertEqual(exported_headers[34], "Unique ID B")

            favorite = player_summary(path, "Alpha", "atp", "career")["favorite_character"]
            self.assertEqual(favorite["character"], "Sampras")
            self.assertEqual(favorite["count"], 2)
            self.assertAlmostEqual(favorite["percentage"], 2 / 3)
            self.assertEqual(
                leaderboard_rows(path, "atp")[0]["favorite_character"]["character"],
                "Sampras",
            )

    def test_build_rows_accepts_character_values(self):
        extracted = {
            "player": {"name": "Alpha"},
            "opponent": {"name": "Beta"},
            "result": "6-4 6-4",
            "tournament": "Tournament",
            "date": "2025-01-01",
        }
        rows = build_rows(
            extracted, "atp", ["match.png"], character="Sampras",
            opponent_character="Agassi",
        )
        self.assertEqual(rows[0]["Character"], "Sampras")
        self.assertEqual(rows[0]["Opponent Character"], "Agassi")
        self.assertEqual(rows[1]["Character"], "Agassi")

    def test_build_rows_derives_reciprocal_return_and_pressure_components(self):
        extracted = {
            "player": {
                "name": "Alpha", "first_serve_won_pct": 0.8,
                "second_serve_won_pct": 0.6, "break_points_won_pct": 0.4,
            },
            "opponent": {
                "name": "Beta", "first_serve_won_pct": 0.7,
                "second_serve_won_pct": 0.5, "break_points_won_pct": 0.25,
            },
            "result": "6-7(5) 6-4 7-6(3)",
            "tournament": "Tournament", "date": "2025-01-01",
        }
        alpha, beta = build_rows(extracted, "atp", ["match.png"])
        self.assertAlmostEqual(alpha["1st Serve Return Points Won %"], 0.3)
        self.assertEqual(alpha["2nd Serve Return Points Won %"], 0.5)
        self.assertEqual(alpha["Break Points Saved %"], 0.75)
        self.assertEqual(alpha["Tie-breaks Won %"], 0.5)
        self.assertEqual(alpha["Deciding Sets Won %"], 1.0)
        self.assertEqual(beta["Result"], "7-6(5) 4-6 6-7(3)")
        self.assertAlmostEqual(beta["1st Serve Return Points Won %"], 0.2)
        self.assertEqual(beta["Break Points Saved %"], 0.6)
        self.assertEqual(beta["Tie-breaks Won %"], 0.5)
        self.assertEqual(beta["Deciding Sets Won %"], 0.0)

    def test_recalculation_persists_derived_metrics_for_period_and_leaderboard(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            make_workbook(path)
            workbook = load_workbook(path)
            alpha = source_row(1, "alpha.png", "Alpha", complete=False,
                               opponent="Beta", match_date=date(2025, 2, 15))
            alpha.update({
                "Result": "6-7 6-4 7-6", "1st Serve Won %": 0.8,
                "2nd Serve Won %": 0.6, "Break Points Won %": 0.4,
            })
            beta = source_row(2, "beta.png", "Beta", complete=False,
                              opponent="Alpha", match_date=date(2025, 2, 15))
            beta.update({
                "Result": "7-6 4-6 6-7", "1st Serve Won %": 0.7,
                "2nd Serve Won %": 0.5, "Break Points Won %": 0.25,
            })
            for row in (alpha, beta):
                workbook["atp"].append([row.get(header) for header in SOURCE_HEADERS])
            recalculate_summary_sheets(workbook)
            workbook.save(path)
            workbook.close()

            summary = player_summary(path, "Alpha", "atp", "30d", "2025-03-01")
            metrics = {label: (value, count) for label, value, count in summary["metrics"]}
            self.assertEqual(metrics["1st Serve Return Points Won %"], (0.3, 1))
            self.assertEqual(metrics["2nd Serve Return Points Won %"], (0.5, 1))
            self.assertEqual(metrics["Break Points Saved %"], (0.75, 1))
            self.assertEqual(metrics["Tie-breaks Won %"], (0.5, 1))
            self.assertEqual(metrics["Deciding Sets Won %"], (1.0, 1))
            leaderboard = leaderboard_rows(path, "atp")
            self.assertEqual(
                leaderboard[0]["metrics"]["Break Points Saved %"], 0.75
            )

    def test_recalculation_replaces_stale_deciding_set_win_with_loss(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            make_workbook(path)
            workbook = load_workbook(path)
            alpha = source_row(
                1, "alpha.png", "Alpha", complete=False,
                opponent="Beta", match_date=date(2025, 2, 15),
            )
            alpha["Result"] = "6-4 3-6 4-6"
            beta = source_row(
                2, "beta.png", "Beta", complete=False,
                opponent="Alpha", match_date=date(2025, 2, 15),
            )
            beta["Result"] = "4-6 6-3 6-4"
            for row in (alpha, beta):
                workbook["atp"].append([
                    row.get(header) for header in SOURCE_HEADERS
                ])
            recalculate_summary_sheets(workbook)
            headers = {
                cell.value: cell.column for cell in workbook["atp"][1]
                if cell.value
            }
            workbook["atp"].cell(
                2, headers["Deciding Sets Won %"]
            ).value = 1.0
            recalculate_summary_sheets(workbook)
            self.assertEqual(
                workbook["atp"].cell(
                    2, headers["Deciding Sets Won %"]
                ).value,
                0.0,
            )
            workbook.close()

    def test_correct_existing_match_tours_moves_guangzhou_reciprocals(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            make_workbook(path)
            workbook = load_workbook(path)
            wta = workbook["wta"]
            review_status_column = len(SOURCE_HEADERS) + 1
            review_reason_column = len(SOURCE_HEADERS) + 2
            wta.cell(1, review_status_column).value = "Review Status"
            wta.cell(1, review_reason_column).value = "Review Reason"
            first = source_row(
                1, "guangzhou-1.png", "elmanzanas", opponent="HSM09",
                tournament="Guangzhou WTA 250", match_date=date(2026, 9, 19),
            )
            first.update({
                "Result": "6-3 6-7(5) 7-6(5)",
                "Review Status": "FOR REVIEW",
                "Review Reason": "Tour requires official verification",
            })
            second = source_row(
                2, "guangzhou-2.png", "HSM09", opponent="elmanzanas",
                tournament="Guangzhou WTA 250", match_date=date(2026, 9, 19),
            )
            second["Result"] = "3-6 7-6(5) 6-7(5)"
            for row in (first, second):
                values = [row.get(header) for header in SOURCE_HEADERS]
                values.extend([
                    row.get("Review Status"),
                    row.get("Review Reason"),
                ])
                wta.append(values)
            workbook.save(path)
            workbook.close()

            result = correct_existing_match_tours(
                [{
                    "tournament": "Tennis Elbow 4 (ATP Characters) - Guangzhou 2026",
                    "player1": "elmanzanas",
                    "player2": "HSM09",
                    "date": "19.09.2026",
                    "result": "6-3,6-7,7-6",
                    "tour": "atp",
                }],
                path,
            )

            self.assertEqual(result["moved_rows"], 2)
            self.assertEqual(result["moved_matches"], 1)
            workbook = load_workbook(path, data_only=False)
            self.assertEqual(workbook["wta"].max_row, 1)
            self.assertEqual(workbook["atp"].max_row, 3)
            headers = {
                cell.value: cell.column for cell in workbook["atp"][1]
                if cell.value
            }
            rows = [
                {
                    header: workbook["atp"].cell(row_number, column).value
                    for header, column in headers.items()
                }
                for row_number in (2, 3)
            ]
            self.assertEqual(
                {row["Player"] for row in rows},
                {"elmanzanas", "HSM09"},
            )
            self.assertEqual(rows[0]["Review Status"], "FOR REVIEW")
            self.assertEqual(
                rows[0]["Review Reason"],
                "Tour requires official verification",
            )
            summary_headers = {
                workbook["ATP Summary"].cell(5, column).value: column
                for column in range(1, workbook["ATP Summary"].max_column + 1)
                if workbook["ATP Summary"].cell(5, column).value
            }
            summary_players = {
                workbook["ATP Summary"].cell(row_number, summary_headers["Player"]).value
                for row_number in range(6, workbook["ATP Summary"].max_row + 1)
                if workbook["ATP Summary"].cell(
                    row_number, summary_headers["Player"]
                ).value
            }
            self.assertEqual(summary_players, {"elmanzanas", "HSM09"})
            workbook.close()


if __name__ == "__main__":
    unittest.main()
