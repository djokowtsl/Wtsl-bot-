"""Minimal HTTP process used by the VM deployment readiness check."""

from keep_alive import run


if __name__ == "__main__":
    run()