from flask import Flask
from threading import Thread
import os

app = Flask('')

@app.route('/')
def home():
    return "Hello. I am alive!"

def run():
    # Set Flask debug environment variable properly
    os.environ['FLASK_DEBUG'] = '0'
    # Remove any deprecated FLASK_ENV if it exists
    if 'FLASK_ENV' in os.environ:
        del os.environ['FLASK_ENV']

    try:
        port = int(os.environ.get("PORT", "8080"))
        app.run(host='0.0.0.0', port=port, debug=False)
    except Exception as e:
        print(f"Keep-alive Flask error: {e}")

def keep_alive():
    t = Thread(target=run)
    t.start()