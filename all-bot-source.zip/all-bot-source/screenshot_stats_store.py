"""Durable PostgreSQL snapshots for screenshot-derived match statistics."""

from __future__ import annotations

from collections import Counter
from datetime import date, datetime
import hashlib
import json
import os
from pathlib import Path
import tempfile
from typing import Any

import psycopg
from openpyxl import load_workbook

from tennis_stats_scraper import validate_statistics_workbook

_STORE_TABLE = "screenshot_stats_snapshot_store"
_BACKUP_TABLE = "screenshot_stats_snapshot_backup"
_STORE_KEY = "master"
_SHEETS = ("atp", "wta", "dubs")
_SELECT_COLUMNS = (
    "workbook, processed_messages, workbook_sha256, "
    "atp_rows, wta_rows, doubles_rows, revision"
)


class ScreenshotStatsStoreError(RuntimeError):
    """A durable screenshot workbook could not be read or safely updated."""


def _connect():
    database_url = os.environ.get("DATABASE_URL")
    if not database_url:
        raise ScreenshotStatsStoreError("DATABASE_URL is not available")
    return psycopg.connect(database_url)


def _normalized_cell(value: Any) -> str:
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if value is None:
        return ""
    return str(value).strip()


def _analyze_workbook(path: Path) -> dict[str, Any]:
    """Validate all source sheets and collect stable match identities."""
    validated_counts = validate_statistics_workbook(path)
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        if "dubs" not in workbook.sheetnames:
            raise ScreenshotStatsStoreError(
                "Statistics workbook is missing the required doubles sheet"
            )

        counters: dict[str, Counter[tuple[str, ...]]] = {}
        counts: dict[str, int] = {}
        for sheet_name in _SHEETS:
            sheet = workbook[sheet_name]
            rows = sheet.iter_rows(values_only=True)
            headers = [
                str(value).strip().casefold() if value is not None else ""
                for value in next(rows, ())
            ]

            def find_header(name: str) -> int | None:
                for index, value in enumerate(headers):
                    if value == name or (
                        name == "image name" and value.startswith("image name ")
                    ):
                        return index
                return None

            player_column = find_header("player")
            if player_column is None:
                raise ScreenshotStatsStoreError(
                    f"{sheet_name.upper()} sheet has no Player column"
                )
            identity_fields = [
                (name, find_header(name))
                for name in (
                    "id",
                    "image name",
                    "player",
                    "opponent",
                    "tournament",
                    "date",
                    "result",
                )
            ]
            identity_fields = [
                (name, index)
                for name, index in identity_fields
                if index is not None
            ]
            row_counter: Counter[tuple[str, ...]] = Counter()
            for row_number, row in enumerate(rows, start=2):
                if not any(value not in (None, "") for value in row):
                    continue
                player = row[player_column] if player_column < len(row) else None
                if player in (None, ""):
                    identity = tuple(
                        f"column_{index}={_normalized_cell(value)}"
                        for index, value in enumerate(row)
                        if value not in (None, "")
                    ) or (f"row={row_number}",)
                else:
                    identity = tuple(
                        f"{name}={_normalized_cell(row[index] if index < len(row) else None)}"
                        for name, index in identity_fields
                    )
                row_counter[identity] += 1
            counters[sheet_name] = row_counter
            counts[sheet_name] = sum(row_counter.values())

        if counts["atp"] < validated_counts["atp"]:
            raise ScreenshotStatsStoreError(
                "ATP row count changed during workbook validation"
            )
        if counts["wta"] < validated_counts["wta"]:
            raise ScreenshotStatsStoreError(
                "WTA row count changed during workbook validation"
            )
        if counts["dubs"] == 0:
            raise ScreenshotStatsStoreError(
                "Doubles sheet contains no match records"
            )

        return {"counts": counts, "records": counters}
    finally:
        workbook.close()


def _read_processed(path: Path) -> list[str]:
    if not path.is_file():
        raise ScreenshotStatsStoreError(
            f"Screenshot receipt ledger is missing: {path}"
        )
    try:
        values = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ScreenshotStatsStoreError(
            f"Screenshot receipt ledger cannot be read: {path.name}: {exc}"
        ) from exc
    if not isinstance(values, list) or any(
        not isinstance(value, str) or not value.strip() for value in values
    ):
        raise ScreenshotStatsStoreError(
            "Screenshot receipt ledger must be a JSON list of nonempty strings"
        )
    return sorted(set(values))


def _capture_files(workbook_path: Path, receipts_path: Path) -> dict[str, Any]:
    workbook_path = Path(workbook_path)
    if not workbook_path.is_file() or workbook_path.stat().st_size == 0:
        raise ScreenshotStatsStoreError(
            f"Screenshot statistics workbook is missing or empty: {workbook_path}"
        )
    analysis = _analyze_workbook(workbook_path)
    workbook_bytes = workbook_path.read_bytes()
    return {
        "workbook": workbook_bytes,
        "receipts": _read_processed(Path(receipts_path)),
        "sha256": hashlib.sha256(workbook_bytes).hexdigest(),
        "counts": analysis["counts"],
        "records": analysis["records"],
    }


def _write_temp_workbook(payload: bytes, destination: Path) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(
        mode="wb",
        prefix=f".{destination.stem}.",
        suffix=".xlsx",
        dir=destination.parent,
        delete=False,
    )
    temporary = Path(handle.name)
    try:
        with handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    return temporary


def _atomic_write_json(path: Path, values: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    try:
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(values, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def _record_from_row(row: tuple[Any, ...]) -> dict[str, Any]:
    workbook, receipts, digest, atp_rows, wta_rows, doubles_rows, revision = row
    return {
        "workbook": bytes(workbook),
        "receipts": list(receipts or []),
        "sha256": str(digest).strip(),
        "counts": {
            "atp": int(atp_rows),
            "wta": int(wta_rows),
            "dubs": int(doubles_rows),
        },
        "revision": int(revision),
    }


def _read_store_row(cursor, *, lock: bool) -> dict[str, Any] | None:
    suffix = " FOR UPDATE" if lock else ""
    cursor.execute(
        f"SELECT {_SELECT_COLUMNS} FROM {_STORE_TABLE} "
        "WHERE store_key = %s" + suffix,
        (_STORE_KEY,),
    )
    row = cursor.fetchone()
    return _record_from_row(row) if row else None


def _insert_snapshot(cursor, snapshot: dict[str, Any]) -> None:
    counts = snapshot["counts"]
    cursor.execute(
        f"""
        INSERT INTO {_STORE_TABLE} (
            store_key, workbook, processed_messages, workbook_sha256,
            atp_rows, wta_rows, doubles_rows
        )
        VALUES (%s, %s, %s::jsonb, %s, %s, %s, %s)
        ON CONFLICT (store_key) DO NOTHING
        RETURNING revision
        """,
        (
            _STORE_KEY,
            snapshot["workbook"],
            json.dumps(snapshot["receipts"], ensure_ascii=False),
            snapshot["sha256"],
            counts["atp"],
            counts["wta"],
            counts["dubs"],
        ),
    )


def _backup_current_row(cursor, reason: str) -> None:
    cursor.execute(
        f"""
        INSERT INTO {_BACKUP_TABLE} (
            store_key, workbook, processed_messages, workbook_sha256,
            atp_rows, wta_rows, doubles_rows, source_revision, backup_reason
        )
        SELECT
            store_key, workbook, processed_messages, workbook_sha256,
            atp_rows, wta_rows, doubles_rows, revision, %s
        FROM {_STORE_TABLE}
        WHERE store_key = %s
        ON CONFLICT (store_key) DO UPDATE SET
            workbook = EXCLUDED.workbook,
            processed_messages = EXCLUDED.processed_messages,
            workbook_sha256 = EXCLUDED.workbook_sha256,
            atp_rows = EXCLUDED.atp_rows,
            wta_rows = EXCLUDED.wta_rows,
            doubles_rows = EXCLUDED.doubles_rows,
            source_revision = EXCLUDED.source_revision,
            backup_reason = EXCLUDED.backup_reason,
            backed_up_at = now()
        """,
        (reason, _STORE_KEY),
    )


def _store_snapshot(
    snapshot: dict[str, Any],
    *,
    require_superset: bool,
) -> dict[str, Any]:
    counts = snapshot["counts"]
    with _connect() as connection:
        with connection.cursor() as cursor:
            current = _read_store_row(cursor, lock=True)
            if current is None:
                raise ScreenshotStatsStoreError(
                    "Screenshot snapshot store is empty; run startup migration first"
                )

            if current["sha256"] != hashlib.sha256(
                current["workbook"]
            ).hexdigest():
                raise ScreenshotStatsStoreError(
                    "Stored screenshot workbook failed its SHA-256 integrity check"
                )

            if require_superset:
                current_path = _write_temp_workbook(
                    current["workbook"], Path.cwd() / ".screenshot-current.xlsx"
                )
                try:
                    current_analysis = _analyze_workbook(current_path)
                finally:
                    current_path.unlink(missing_ok=True)
                if not _contains_all(snapshot["records"], current_analysis["records"]):
                    raise ScreenshotStatsStoreError(
                        "Refusing to save a screenshot workbook that drops existing "
                        "ATP, WTA, or doubles match rows"
                    )

            if current["sha256"] == snapshot["sha256"]:
                cursor.execute(
                    f"""
                    UPDATE {_STORE_TABLE}
                    SET processed_messages = %s::jsonb,
                        atp_rows = %s,
                        wta_rows = %s,
                        doubles_rows = %s,
                        revision = revision + 1,
                        updated_at = now()
                    WHERE store_key = %s
                    RETURNING revision
                    """,
                    (
                        json.dumps(snapshot["receipts"], ensure_ascii=False),
                        counts["atp"],
                        counts["wta"],
                        counts["dubs"],
                        _STORE_KEY,
                    ),
                )
            else:
                _backup_current_row(cursor, "previous workbook snapshot")
                cursor.execute(
                    f"""
                    UPDATE {_STORE_TABLE}
                    SET workbook = %s,
                        processed_messages = %s::jsonb,
                        workbook_sha256 = %s,
                        atp_rows = %s,
                        wta_rows = %s,
                        doubles_rows = %s,
                        revision = revision + 1,
                        updated_at = now()
                    WHERE store_key = %s
                    RETURNING revision
                    """,
                    (
                        snapshot["workbook"],
                        json.dumps(snapshot["receipts"], ensure_ascii=False),
                        snapshot["sha256"],
                        counts["atp"],
                        counts["wta"],
                        counts["dubs"],
                        _STORE_KEY,
                    ),
                )
            revision = int(cursor.fetchone()[0])
    return {
        "sha256": snapshot["sha256"],
        "counts": counts,
        "receipt_count": len(snapshot["receipts"]),
        "revision": revision,
    }


def _contains_all(
    candidate: dict[str, Counter[tuple[str, ...]]],
    existing: dict[str, Counter[tuple[str, ...]]],
) -> bool:
    return all(
        not (existing[sheet] - candidate[sheet])
        for sheet in _SHEETS
    )


def _message_ids_in_workbook(path: Path) -> set[str]:
    workbook = load_workbook(path, read_only=True, data_only=True)
    message_ids: set[str] = set()
    try:
        for sheet_name in _SHEETS:
            sheet = workbook[sheet_name]
            headers = [
                str(cell.value).strip().casefold()
                if cell.value is not None else ""
                for cell in sheet[1]
            ]
            image_column = next(
                (
                    index
                    for index, header in enumerate(headers)
                    if header == "image name" or header.startswith("image name ")
                ),
                None,
            )
            if image_column is None:
                continue
            for row in sheet.iter_rows(min_row=2, values_only=True):
                value = (
                    row[image_column]
                    if image_column < len(row)
                    else None
                )
                if isinstance(value, str) and "_" in value:
                    prefix = value.split("_", 1)[0]
                    if prefix.isdigit():
                        message_ids.add(prefix)
    finally:
        workbook.close()
    return message_ids


def _validate_stored_snapshot(
    snapshot: dict[str, Any],
    workbook_path: Path,
) -> dict[str, Any]:
    actual_sha256 = hashlib.sha256(snapshot["workbook"]).hexdigest()
    if actual_sha256 != snapshot["sha256"]:
        raise ScreenshotStatsStoreError(
            "Stored screenshot workbook failed its SHA-256 integrity check"
        )
    temporary = _write_temp_workbook(snapshot["workbook"], workbook_path)
    try:
        analysis = _analyze_workbook(temporary)
        snapshot["metadata_counts"] = snapshot["counts"]
        snapshot["counts"] = analysis["counts"]
        snapshot["records"] = analysis["records"]
    finally:
        temporary.unlink(missing_ok=True)
    return snapshot


def _refresh_snapshot_counts(snapshot: dict[str, Any]) -> None:
    """Align row-count metadata and its rollback copy with the stored workbook."""
    if snapshot.get("metadata_counts") == snapshot["counts"]:
        return
    counts = snapshot["counts"]
    with _connect() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                f"""
                UPDATE {_STORE_TABLE}
                SET atp_rows = %s,
                    wta_rows = %s,
                    doubles_rows = %s,
                    revision = revision + 1,
                    updated_at = now()
                WHERE store_key = %s AND workbook_sha256 = %s
                RETURNING revision
                """,
                (
                    counts["atp"],
                    counts["wta"],
                    counts["dubs"],
                    _STORE_KEY,
                    snapshot["sha256"],
                ),
            )
            row = cursor.fetchone()
            if not row:
                raise ScreenshotStatsStoreError(
                    "Screenshot workbook changed while row counts were refreshed"
                )
            cursor.execute(
                f"""
                UPDATE {_BACKUP_TABLE}
                SET atp_rows = %s, wta_rows = %s, doubles_rows = %s
                WHERE store_key = %s AND workbook_sha256 = %s
                """,
                (
                    counts["atp"],
                    counts["wta"],
                    counts["dubs"],
                    _STORE_KEY,
                    snapshot["sha256"],
                ),
            )
            snapshot["revision"] = int(row[0])
            snapshot["metadata_counts"] = counts.copy()


def _restore_snapshot(
    snapshot: dict[str, Any],
    workbook_path: Path,
    receipts_path: Path,
) -> None:
    temporary = _write_temp_workbook(
        snapshot["workbook"], Path(workbook_path)
    )
    try:
        analysis = _analyze_workbook(temporary)
        if analysis["counts"] != snapshot["counts"]:
            raise ScreenshotStatsStoreError(
                "Stored screenshot workbook row counts do not match metadata"
            )
        os.replace(temporary, workbook_path)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    _atomic_write_json(Path(receipts_path), snapshot["receipts"])


def restore_or_seed(
    workbook_path: Path,
    receipts_path: Path,
) -> dict[str, Any]:
    """Restore durable data, safely adopt a newer local superset, or seed once."""
    workbook_path = Path(workbook_path)
    receipts_path = Path(receipts_path)
    seeded = False
    local_snapshot = None
    local_error = None
    try:
        local_snapshot = _capture_files(workbook_path, receipts_path)
    except Exception as exc:
        local_error = exc

    with _connect() as connection:
        with connection.cursor() as cursor:
            stored = _read_store_row(cursor, lock=True)
            if stored is None:
                if local_snapshot is None:
                    raise ScreenshotStatsStoreError(
                        "No durable screenshot workbook exists and the bundled "
                        f"migration files are invalid: {local_error}"
                    )
                _insert_snapshot(cursor, local_snapshot)
                inserted = cursor.fetchone()
                if inserted:
                    seeded = True
                    cursor.execute(
                        f"""
                        INSERT INTO {_BACKUP_TABLE} (
                            store_key, workbook, processed_messages,
                            workbook_sha256, atp_rows, wta_rows, doubles_rows,
                            source_revision, backup_reason
                        )
                        SELECT
                            store_key, workbook, processed_messages,
                            workbook_sha256, atp_rows, wta_rows, doubles_rows,
                            revision, 'rollback copy of initial migration'
                        FROM {_STORE_TABLE}
                        WHERE store_key = %s
                        ON CONFLICT (store_key) DO NOTHING
                        """,
                        (_STORE_KEY,),
                    )
                    stored = {
                        "workbook": local_snapshot["workbook"],
                        "receipts": local_snapshot["receipts"],
                        "sha256": local_snapshot["sha256"],
                        "counts": local_snapshot["counts"],
                        "records": local_snapshot["records"],
                        "revision": int(inserted[0]),
                    }
                else:
                    stored = _read_store_row(cursor, lock=True)

    if stored is None:
        raise ScreenshotStatsStoreError(
            "Screenshot workbook migration did not create a durable snapshot"
        )
    stored = _validate_stored_snapshot(stored, workbook_path)
    _refresh_snapshot_counts(stored)

    if local_snapshot is not None and (
        local_snapshot["sha256"] != stored["sha256"]
    ):
        local_contains_stored = _contains_all(
            local_snapshot["records"], stored["records"]
        )
        stored_contains_local = _contains_all(
            stored["records"], local_snapshot["records"]
        )
        if local_contains_stored and not stored_contains_local:
            # Recover a crash between the local workbook replacement and its
            # database save, without dropping anything already stored.
            local_ids = _message_ids_in_workbook(workbook_path)
            local_receipts = [
                receipt
                for receipt in local_snapshot["receipts"]
                if receipt.partition(":")[0] in local_ids
            ]
            local_snapshot["receipts"] = sorted(
                set(stored["receipts"]) | set(local_receipts)
            )
            _store_snapshot(local_snapshot, require_superset=True)
            stored["workbook"] = local_snapshot["workbook"]
            stored["receipts"] = local_snapshot["receipts"]
            stored["sha256"] = local_snapshot["sha256"]
            stored["counts"] = local_snapshot["counts"]
            stored["records"] = local_snapshot["records"]
            stored["revision"] += 1
        elif not stored_contains_local:
            raise ScreenshotStatsStoreError(
                "Local and durable screenshot workbooks contain different match "
                "rows. Both versions were left untouched; reconcile them before "
                "starting the bot."
            )

    if local_snapshot is not None:
        local_ids = _message_ids_in_workbook(workbook_path)
        local_receipts = [
            receipt
            for receipt in local_snapshot["receipts"]
            if receipt.partition(":")[0] in local_ids
        ]
        merged_receipts = sorted(set(stored["receipts"]) | set(local_receipts))
        if merged_receipts != sorted(set(stored["receipts"])):
            with _connect() as connection:
                with connection.cursor() as cursor:
                    cursor.execute(
                        f"""
                        UPDATE {_STORE_TABLE}
                        SET processed_messages = %s::jsonb,
                            revision = revision + 1,
                            updated_at = now()
                        WHERE store_key = %s
                        RETURNING revision
                        """,
                        (
                            json.dumps(merged_receipts, ensure_ascii=False),
                            _STORE_KEY,
                        ),
                    )
                    row = cursor.fetchone()
                    if not row:
                        raise ScreenshotStatsStoreError(
                            "Screenshot receipt ledger could not be reconciled"
                        )
                    stored["revision"] = int(row[0])
            stored["receipts"] = merged_receipts

    # The database is authoritative after the comparison/reconciliation above.
    _restore_snapshot(stored, workbook_path, receipts_path)
    return {
        "counts": stored["counts"],
        "receipt_count": len(stored["receipts"]),
        "revision": stored["revision"],
        "sha256": stored["sha256"],
        "migrated": seeded,
    }


def persist_workbook(workbook_path: Path, receipts_path: Path) -> dict[str, Any]:
    """Persist a new workbook only if it retains every previously saved match."""
    snapshot = _capture_files(Path(workbook_path), Path(receipts_path))
    return _store_snapshot(snapshot, require_superset=True)


def persist_processed_messages(receipts: set[str] | list[str]) -> int:
    """Persist the receipt ledger after the corresponding workbook is durable."""
    normalized = sorted(
        {
            str(receipt).strip()
            for receipt in receipts
            if str(receipt).strip()
        }
    )
    with _connect() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                f"""
                UPDATE {_STORE_TABLE}
                SET processed_messages = %s::jsonb,
                    revision = revision + 1,
                    updated_at = now()
                WHERE store_key = %s
                RETURNING revision
                """,
                (json.dumps(normalized, ensure_ascii=False), _STORE_KEY),
            )
            row = cursor.fetchone()
            if not row:
                raise ScreenshotStatsStoreError(
                    "Screenshot receipt ledger has no durable workbook snapshot"
                )
            return int(row[0])


def restore_current_snapshot(
    workbook_path: Path,
    receipts_path: Path,
) -> dict[str, Any]:
    """Restore the current database snapshot without comparing local files."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            snapshot = _read_store_row(cursor, lock=True)
    if snapshot is None:
        raise ScreenshotStatsStoreError(
            "Screenshot snapshot store has no current workbook"
        )
    snapshot = _validate_stored_snapshot(snapshot, Path(workbook_path))
    _refresh_snapshot_counts(snapshot)
    _restore_snapshot(snapshot, Path(workbook_path), Path(receipts_path))
    return {
        "counts": snapshot["counts"],
        "receipt_count": len(snapshot["receipts"]),
        "revision": snapshot["revision"],
        "sha256": snapshot["sha256"],
    }