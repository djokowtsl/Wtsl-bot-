
import pandas as pd
import os, types
import numpy as np
import warnings
import datetime 
from datetime import date
warnings.filterwarnings("ignore")

def generator(rankingscsv, entrylisting):
    from scipy.stats import rankdata
    import random
    playerrank = pd.read_csv(rankingscsv).set_index('name')[['Rank']]
    #entrylist = pd.DataFrame(np.array(pd.read_csv(entrylisting)), columns = ['Player', 'Ranking'])
    entrylist = pd.DataFrame(np.array(pd.read_csv(entrylisting)), columns = ['Player'])
    entrylist['Rank'] = 0
    entrylist['Seed'] = 0
    for i in range(len(entrylist)):
        entrylist['Rank'][i] =playerrank.Rank[playerrank.index == entrylist.Player[i]]
    entrylist['Seed'] = rankdata(entrylist.Rank).astype(int)
    entrylist.sort_values(by = 'Seed', inplace = True)
    entrylist.set_index('Seed', inplace = True)
    entrylist['Seed'] = entrylist.index
    entrylist.to_csv('entry_seeds.csv')
    #characterlist = pd.read_csv('characters.csv')
    #entrylistfinals = pd.DataFrame(np.array(pd.read_csv(entrylistingfinals)), columns = ['Player'])
    #entrylistfinals['Rank'] = 0
    #entrylistfinals['Seed'] = 0
    #for i in range(len(entrylist)):
    #    entrylistfinals['Rank'][i] =playerrank.Rank[playerrank.index == entrylistfinals.Player[i]]
    #entrylistfinals['Seed'] = rankdata(entrylistfinals.Rank).astype(int)
    #entrylistfinals.sort_values(by = 'Seed', inplace = True)
    #entrylistfinals.set_index('Seed', inplace = True)
    #entrylistfinals['Seed'] = entrylist.index
    #entrylistfinals.to_csv('entry_finalsseeds.csv')
    #entrylistfinals = pd.read_csv('entry_finalsseeds.csv')
    #entrylistfinals = entrylistfinals.set_index('Player')
    '''if len(entrylist) == 8:
        seeds = 4
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entryall = list(entrylist[4:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entryall'''
    if len(entrylist) == 8:
        seeds = 4
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entryall = list(entrylist[4:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entryall
    elif len(entrylist) == 9:
        seeds = 4
        for i in range(1,seeds+1):
            entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry57 = list(entrylist[4:7].Player)
        random.shuffle(entry57)
        entry89 = list(entrylist[7:9].Player)
        random.shuffle(entry89)
    #entryall = list(entrylist[4:len(entrylist)].Player)
    #random.shuffle(entryall)
        bracket = entry12 + entry34 + entry57 + entry89
    elif len(entrylist) == 10:
        seeds = 4
        for i in range(1,seeds+1):
            entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry56 = list(entrylist[4:6].Player)
        random.shuffle(entry56)
        entry710 = list(entrylist[6:10].Player)
        random.shuffle(entry710)
    #entryall = list(entrylist[4:len(entrylist)].Player)
    #random.shuffle(entryall)
        bracket = entry12 + entry34 + entry56 + entry710
    elif len(entrylist) == 11:
        seeds = 4
        for i in range(1,seeds+1):
            entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry5 = list(entrylist[4:5].Player)
        entry611 = list(entrylist[5:11].Player)
        random.shuffle(entry611)
    #entryall = list(entrylist[4:len(entrylist)].Player)
    #random.shuffle(entryall)
        bracket = entry12 + entry34 + entry5 + entry611
    elif len(entrylist) == 12:
        seeds = 4
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entryall = list(entrylist[4:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entryall
        
    elif len(entrylist) == 13:
        seeds = 4
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry3 = list(entrylist[2:3].Player)
        random.shuffle(entry3)
        entry4 = list(entrylist[3:4].Player)
        random.shuffle(entry4)
        entry512 = list(entrylist[4:12].Player)
        random.shuffle(entry512)
        entryall = list(entrylist[12:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry3 + entry4 + entry512 + entryall
    #elif len(entrylist) == 14:
    #    seeds = 4
    #    for i in range(1,seeds+1):
    #            entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
    #    entry12 = list(entrylist[:2].Player)
    #    random.shuffle(entry12)
    #    entry34 = list(entrylist[2:4].Player)
    #    random.shuffle(entry34)
    #    entry512 = list(entrylist[4:13].Player)
    #    random.shuffle(entry512)
    #    entryall = list(entrylist[13:len(entrylist)].Player)
    #    random.shuffle(entryall)
    #    bracket = entry12 + entry34 + entry512 + entryall
    elif len(entrylist) == 14:
        seeds = 4
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry512 = list(entrylist[4:12].Player)
        random.shuffle(entry512)
        entryall = list(entrylist[12:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entry512 + entryall
    elif len(entrylist) == 15:
        seeds = 4
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry1 = list(entrylist[:1].Player)
        random.shuffle(entry1)
        entry2 = list(entrylist[1:2].Player)
        random.shuffle(entry2)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry511 = list(entrylist[4:12].Player)
        random.shuffle(entry511)
        entryall = list(entrylist[12:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry1 + entry2 + entry34 + entry511 + entryall
    elif len(entrylist) == 16:
        seeds = 4
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entryall = list(entrylist[4:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entryall
    elif len(entrylist) == 17:
        seeds = 4
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry1 = list(entrylist[:1].Player)
        random.shuffle(entry1)
        entry2 = list(entrylist[1:2].Player)
        random.shuffle(entry2)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry515 = list(entrylist[4:15].Player)
        random.shuffle(entry515)
        entryall = list(entrylist[15:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry1 + entry2 + entry34 + entry515 + entryall
      
 #   elif len(entrylist) == 17:
 #       seeds = 8
        #for i in range(2,seeds-3):
        #        entrylist['Player'][i] = '(' + (entrylist.Seed[i]-1).astype(str) + ')' + entrylist['Player'][i]
 #       entrylist['Player'][2] = '(' + (entrylist.Seed[2]-1).astype(str) + ')' + entrylist['Player'][2]
 #       entrylist['Player'][3] = '(' + (entrylist.Seed[4]-1).astype(str) + ')' + entrylist['Player'][3]
 #       entrylist['Player'][4] = '(' + (entrylist.Seed[3]-1).astype(str) + ')' + entrylist['Player'][4]
 #       entrylist['Player'][8] = '(' + (entrylist.Seed[8]-4).astype(str) + ')' + entrylist['Player'][8]
 #       entry1 = list(entrylist[:1].Player)
 #       random.shuffle(entry1)
 #       entry24= [entrylist.iloc[1].Player, entrylist.iloc[3].Player]
 #       random.shuffle(entry24)
 #       entry57 = list(entrylist[4:7].Player)
 #       random.shuffle(entry57)
 #       entry38 = [entrylist.iloc[2].Player, entrylist.iloc[7].Player]
 #       random.shuffle(entry38)
 #       entry9 = list(entrylist[8:9].Player)
 #       random.shuffle(entry9)
 #       entry1012 = list(entrylist[9:12].Player)
 #       random.shuffle(entry1012)
 #       entry1315 = list(entrylist[12:15].Player)
 #       random.shuffle(entry1315)
 #       entryall = list(entrylist[15:len(entrylist)].Player)
 #       random.shuffle(entryall)
  #      bracket = ((((entry1 + entry23).append(str(entry48[0]))) + entry57).append(str(entry48[1])))+ entry9 + entry1012 + entry1315 + entryall
#        bracket = entry1 + entry24[0].split() + entry38[0].split() + entry24[1].split()  + entry57 + entry38[1].split() + entry9 + entry1012 + entry1315 + entryall

   # elif len(entrylist) == 19:
   #     seeds = 8
   #     #for i in range(1,seeds-3):
   #     #        entrylist['Player'][i] = '(' + (entrylist.Seed[i]+8).astype(str) + ')' + entrylist['Player'][i]
   #     entrylist['Player'][9] = '(' + (entrylist.Seed[9]-4).astype(str) + ')' + entrylist['Player'][9]
   #     entrylist['Player'][10] = '(' + (entrylist.Seed[10]-4).astype(str) + ')' + entrylist['Player'][10]
   #     entrylist['Player'][11] = '(' + (entrylist.Seed[11]-4).astype(str) + ')' + entrylist['Player'][11]
   #     entrylist['Player'][12] = '(' + (entrylist.Seed[12]-4).astype(str) + ')' + entrylist['Player'][12]
   #     entry12 = list(entrylist[:2].Player)
   #     random.shuffle(entry12)
   #     entry3 = list(entrylist[2:3].Player)
    #    random.shuffle(entry3)
    #    entry4 = list(entrylist[3:4].Player)
    #    random.shuffle(entry4)
    #    entry58 = list(entrylist[4:8].Player)
    #    random.shuffle(entry58)
      #  entry910 = list(entrylist[8:10].Player)
      #  random.shuffle(entry910)
      #  entry1112 = list(entrylist[10:12].Player)
      #  random.shuffle(entry1112)
      #  entry13b = list(entrylist[12:13].Player)
     #   random.shuffle(entry13b)
     #   entryall = list(entrylist[13:len(entrylist)].Player)
     #   random.shuffle(entryall)
  #      bracket = ((((entry1 + entry23).append(str(entry48[0]))) + entry57).append(str(entry48[1])))+ entry9 + entry1012 + entry1315 + entryall
  #      bracket = entry1 + entry24[0].split() + entry38[0].split() + entry24[1].split()  + entry57 + entry38[1].split() + entry9 + entry1012 + #entry1315 + entryall
     #   bracket = entry12 + entry3 + entry4 + entry58 + entry910 + entry1112 + entry13b + entryall
    elif len(entrylist) == 8:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry56 = list(entrylist[4:6].Player)
        random.shuffle(entry56)
        entryall = list(entrylist[6:len(entrylist)].Player)
        random.shuffle(entryall)
        #entryall = list(entrylist[4:len(entrylist)].Player)
        #random.shuffle(entryall)
        bracket = entry12 + entry34 + entry56 + entryall 
    
    
    elif len(entrylist) == 18:
        seeds = 4
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entryall = list(entrylist[4:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entryall

   # elif len(entrylist) == 20:
   #     seeds = 4
    #    for i in range(1,seeds+1):
   #         entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
   #     entry12 = list(entrylist[:2].Player)
   #     random.shuffle(entry12)
   #     entry34 = list(entrylist[2:4].Player)
   #     random.shuffle(entry34)
   #     entry512 = list(entrylist[4:12].Player)
   #     random.shuffle(entry512)
   #     entry1316 = list(entrylist[12:16].Player)
   #     random.shuffle(entry1316)
   #     entryall = list(entrylist[16:len(entrylist)].Player)
   #     random.shuffle(entryall)
   #     bracket = entry12 + entry34 + entry512 + entry1316 + entryall
    elif len(entrylist) == 19:
        seeds = 4
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry3 = list(entrylist[2:3].Player)
        random.shuffle(entry3)
        entry4 = list(entrylist[3:4].Player)
        random.shuffle(entry4)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry913 = list(entrylist[8:13].Player)
        random.shuffle(entry913)
        entry1416 = list(entrylist[13:16].Player)
        random.shuffle(entry1416)
        entryall = list(entrylist[16:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry3 + entry4 + entry58 + entry913 + entry1416 + entryall

    elif len(entrylist) == 20:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry912 = list(entrylist[8:12].Player)
        random.shuffle(entry912)
        entryall = list(entrylist[12:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entry58 + entry912 + entryall
    #elif len(entrylist) == 21:
    #    seeds = 8
    #    for i in range(1,seeds+1):
    #            entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
    #    entry12 = list(entrylist[:2].Player)
    #    random.shuffle(entry12)
    #    entry34 = list(entrylist[2:4].Player)
    #    random.shuffle(entry34)
    #    entry5 = list(entrylist[4:5].Player)
    #    random.shuffle(entry5)
    #    entry68 = list(entrylist[5:8].Player)
    #    random.shuffle(entry68)
    #    entry911 = list(entrylist[8:11].Player)
    #    random.shuffle(entry911)
    #    entryall = list(entrylist[11:len(entrylist)].Player)
    #    random.shuffle(entryall)
    #    bracket = entry12 + entry34 + entry5 + entry68 + entry911 + entryall
      
    elif len(entrylist) == 21:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry5 = list(entrylist[4:5].Player)
        random.shuffle(entry5)
        entry68 = list(entrylist[5:8].Player)
        random.shuffle(entry68)
        entry911 = list(entrylist[8:11].Player)
        random.shuffle(entry911)
        entryall = list(entrylist[11:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entry5 + entry68 + entry911 + entryall
      
    elif len(entrylist) == 22:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry56 = list(entrylist[4:6].Player)
        random.shuffle(entry56)
        entry78 = list(entrylist[6:8].Player)
        random.shuffle(entry78)
        entry910 = list(entrylist[8:10].Player)
        random.shuffle(entry910)
        entryall = list(entrylist[10:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entry56 + entry78 + entry910 + entryall
    elif len(entrylist) == 23:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry57 = list(entrylist[4:7].Player)
        random.shuffle(entry57)
        entry89 = list(entrylist[7:9].Player)
        random.shuffle(entry89)
        entryall = list(entrylist[9:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entry57 + entry89 + entryall
    elif len(entrylist) == 24:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entryall = list(entrylist[8:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entry58 + entryall
    elif len(entrylist) == 25:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry57 = list(entrylist[4:7].Player)
        random.shuffle(entry57)
        entry8 = list(entrylist[7:8].Player)
        random.shuffle(entry8)
        entry924 = list(entrylist[8:24].Player)
        random.shuffle(entry924)
        entryall = list(entrylist[24:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entry57 + entry8 + entry924 + entryall
    elif len(entrylist) == 26:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry56 = list(entrylist[4:6].Player)
        random.shuffle(entry56)
        entry78 = list(entrylist[6:8].Player)
        random.shuffle(entry78)
        entry924 = list(entrylist[8:24].Player)
        random.shuffle(entry924)
        entryall = list(entrylist[24:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entry56 + entry78 + entry924 + entryall
    elif len(entrylist) == 27:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry5 = list(entrylist[4:5].Player)
        random.shuffle(entry5)
        entry68 = list(entrylist[5:8].Player)
        random.shuffle(entry68)
        entry924 = list(entrylist[8:24].Player)
        random.shuffle(entry924)
        entryall = list(entrylist[24:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34 + entry5 + entry68 + entry924 + entryall
    elif len(entrylist) == 28:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry924 = list(entrylist[8:24].Player)
        random.shuffle(entry924)
        entryall = list(entrylist[24:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entry58 + entry924 + entryall
    elif len(entrylist) == 29:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry3 = list(entrylist[2:3].Player)
        random.shuffle(entry3)
        entry4 = list(entrylist[3:4].Player)
        random.shuffle(entry4)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry924 = list(entrylist[8:24].Player)
        random.shuffle(entry924)
        entry2528 = list(entrylist[24:28].Player)
        random.shuffle(entry2528)
        entryall = list(entrylist[28:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry3 + entry4  + entry58 + entry924 + entry2528 + entryall
    elif len(entrylist) == 30:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry924 = list(entrylist[8:24].Player)
        random.shuffle(entry924)
        entry2528 = list(entrylist[24:28].Player)
        random.shuffle(entry2528)
        entryall = list(entrylist[28:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entry58 + entry924 + entry2528 + entryall
    elif len(entrylist) == 31:
        seeds = 8
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry1 = list(entrylist[:1].Player)
        random.shuffle(entry1)
        entry2 = list(entrylist[1:2].Player)
        random.shuffle(entry2)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry924 = list(entrylist[8:24].Player)
        random.shuffle(entry924)
        entry2528 = list(entrylist[24:28].Player)
        random.shuffle(entry2528)
        entry2930 = list(entrylist[28:30].Player)
        random.shuffle(entry2930)
        entryall = list(entrylist[30:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry1 + entry2 + entry34  + entry58 + entry924 + entry2528 + entry2930 + entryall
    elif len(entrylist) == 32:
        seeds = 16
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry916 = list(entrylist[8:16].Player)
        random.shuffle(entry916)
        entryall = list(entrylist[16:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entry58 + entry916 + entryall
    elif len(entrylist) == 33:
        seeds = 16
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry1 = list(entrylist[:1].Player)
        random.shuffle(entry1)
        entry2 = list(entrylist[1:2].Player)
        random.shuffle(entry2)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry916 = list(entrylist[8:16].Player)
        random.shuffle(entry916)
        entry1731 = list(entrylist[16:31].Player)
        random.shuffle(entry1731)
        entryall = list(entrylist[31:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry1 + entry2 + entry34  + entry58 + entry916 + entry1731 + entryall   
    elif len(entrylist) == 34:
        seeds = 16
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry916 = list(entrylist[8:16].Player)
        random.shuffle(entry916)
        entry1730 = list(entrylist[16:30].Player)
        random.shuffle(entry1730)
        entryall = list(entrylist[30:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entry58 + entry916 + entry1730 + entryall 
    elif len(entrylist) == 35:
        seeds = 16
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry916 = list(entrylist[8:16].Player)
        random.shuffle(entry916)
        entry1729 = list(entrylist[16:29].Player)
        random.shuffle(entry1729)
        entryall = list(entrylist[29:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entry58 + entry916 + entry1729 + entryall 

    elif len(entrylist) == 36:
        seeds = 16
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry916 = list(entrylist[8:16].Player)
        random.shuffle(entry916)
        entry1728 = list(entrylist[16:28].Player)
        random.shuffle(entry1728)
        entryall = list(entrylist[28:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entry58 + entry916 + entry1728 + entryall  
    elif len(entrylist) == 37:
        seeds = 16
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry5 = list(entrylist[4:5].Player)
        random.shuffle(entry5)
        entry68 = list(entrylist[5:8].Player)
        random.shuffle(entry68)
        entry916 = list(entrylist[8:16].Player)
        random.shuffle(entry916)
        entry1727 = list(entrylist[16:27].Player)
        random.shuffle(entry1727)
        entryall = list(entrylist[27:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entry5 + entry68 + entry916 + entry1727 + entryall
    elif len(entrylist) == 69:
        seeds = 16
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry5 = list(entrylist[4:5].Player)
        random.shuffle(entry5)
        entry68 = list(entrylist[5:8].Player)
        random.shuffle(entry68)
        entry916 = list(entrylist[8:16].Player)
        random.shuffle(entry916)
        entry1759 = list(entrylist[16:59].Player)
        random.shuffle(entry1759)
        entryall = list(entrylist[59:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entry5 + entry68 + entry916 + entry1759 + entryall
    elif len(entrylist) == 42:
        seeds = 16
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry5 = list(entrylist[4:5].Player)
        random.shuffle(entry5)
        entry68 = list(entrylist[5:8].Player)
        random.shuffle(entry68)
        entry910 = list(entrylist[8:10].Player)
        random.shuffle(entry910)
        entry1116 = list(entrylist[10:16].Player)
        random.shuffle(entry1116)
        entry1722 = list(entrylist[16:22].Player)
        random.shuffle(entry1722)
        entryall = list(entrylist[22:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entry5 + entry68 + entry910 + entry1116 + entry1722 + entryall
    elif len(entrylist) == 48:
        seeds = 16
        for i in range(1,seeds+1):
                entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
        entry12 = list(entrylist[:2].Player)
        random.shuffle(entry12)
        entry34 = list(entrylist[2:4].Player)
        random.shuffle(entry34)
        entry58 = list(entrylist[4:8].Player)
        random.shuffle(entry58)
        entry916 = list(entrylist[8:16].Player)
        random.shuffle(entry916)
        entryall = list(entrylist[16:len(entrylist)].Player)
        random.shuffle(entryall)
        bracket = entry12 + entry34  + entry58 + entry916 + entryall

        
 #   elif len(entrylist) >=32:
 #           seeds = 16
 #           for i in range(1,seeds+1):
 #               entrylist['Player'][i] = '(' + entrylist.Seed[i].astype(str) + ')' + entrylist['Player'][i]
 #           entry12 = list(entrylist[:2].Player)
            #random.shuffle(entry12)
 #           entry34 = list(entrylist[2:4].Player)
 #           random.shuffle(entry34)
 #           entry58 = list(entrylist[4:8].Player)
 #           random.shuffle(entry58)
 #           entry916 = list(entrylist[8:16].Player)
 #           random.shuffle(entry916)
 #           entry1631 = list(entrylist[16:31].Player)
 #           random.shuffle(entry1631)
 #           entryall = list(entrylist[31:len(entrylist)].Player)
 #           random.shuffle(entryall)
 #           bracket = entry12 + entry34 + entry58 + entry916  + entry1631 + entryall
    return 'Entry List', entrylist.set_index('Player'), 'Input Bracket List', bracket
    