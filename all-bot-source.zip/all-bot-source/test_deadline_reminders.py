import json
import tempfile
import unittest
from types import SimpleNamespace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import AsyncMock, Mock, PropertyMock, patch

import main
from deadline_reminders import (
    DeadlineReminderState,
    clean_player_name,
    discord_lookup_name,
    parse_deadline,
    parse_completed_draw_matches,
    parse_challonge_svg_url,
    parse_draw_matches,
    admin_reminder_window,
    parse_ongoing_tournaments,
    parse_tournament_directory,
    reminder_key,
    reminder_window,
    reminder_window_started_at,
)


HOME = """<tbody id="ongoing"><tr><td><a href="draw.php?tournament=42">London Cup</a></td></tr></tbody>"""
CURRENT_TOURNAMENTS_PAGE = """<table class="table table-hover">
<tr><th>Tournament</th><th>Status</th></tr>
<tr><td class="event-name"><a href="../pages/tournament_page.php?tournament=Jingshan_2026_TE4">Jingshan</a></td>
<td><a class="btn btn-info" href="../pages/tournament_page.php?tournament=Jingshan_2026_TE4">Ongoing</a></td></tr>
<tr><td class="event-name"><a href="../pages/tournament_page.php?tournament=Guiyang_2026_TE4">Guiyang</a></td>
<td><a class="btn btn-info" href="../pages/tournament_page.php?tournament=Guiyang_2026_TE4">Ongoing</a></td></tr>
<tr><td class="event-name"><a href="../pages/tournament_page.php?tournament=Beijing_2026_TE4">Beijing</a></td>
<td><a class="btn btn-primary" href="../pages/login.php">SignUp</a></td></tr>
</table>"""
TOURNAMENT_PAGE = """<iframe src="https://91d510368cb4170cd5ac3776.challonge.com/Guiyang_2026_TE4/module"></iframe>"""
DRAW = """<svg>
 <svg class="round" x="220">
  <text class="round-label">Round of 16 - Until 07/09/26 at 23:59 BST</text>
 </svg>
 <g class="match -open" data-match-id="9" transform="translate(220 100)">
  <svg class="match--player" data-participant-id="1"><title>(16) Lampjavel (R. Federer)</title></svg>
  <svg class="match--player" data-participant-id="2"><title>Squeaky (N. Djokovic)</title></svg>
 </g>
 <g class="match -complete" data-match-id="10" transform="translate(220 200)">
  <svg class="match--player" data-participant-id="3"><title>A</title></svg>
  <svg class="match--player" data-participant-id="4"><title>B</title></svg>
 </g>
</svg>"""
WINNER_AND_LOSER_DRAW = """<svg>
  <g class="rounds" transform="translate(0,0)">
    <svg class="round" x="0">
      <text class="round-label">Round 1 - Until 07/09/26 at 23:59 BST</text>
    </svg>
    <g class="match -open" data-match-id="11" transform="translate(0 100)">
      <svg class="match--player" data-participant-id="1"><title>Riachsoup</title></svg>
      <svg class="match--player" data-participant-id="2"><title>Vayanara</title></svg>
    </g>
  </g>
  <g class="rounds" transform="translate(0,534)">
    <svg class="round" x="0">
      <text class="round-label">Losers Round 1 - Until 08/09/26 at 23:59 BST</text>
    </svg>
    <g class="match -open" data-match-id="12" transform="translate(0 100)">
      <svg class="match--player" data-participant-id="3"><title>Ypsilandis_7000</title></svg>
      <svg class="match--player" data-participant-id="4"><title>ruze</title></svg>
    </g>
  </g>
</svg>"""
UNSCOPED_WINNER_AND_LOSER_DRAW = """<svg>
  <g class="rounds" transform="translate(0,0)">
    <svg class="round" x="0">
      <text class="round-label">Round 1 - Until 07/09/26 at 23:59 BST</text>
    </svg>
  </g>
  <g class="rounds" transform="translate(0,534)">
    <svg class="round" x="0">
      <text class="round-label">Losers Round 1 - Until 08/09/26 at 23:59 BST</text>
    </svg>
  </g>
  <g class="match -open" data-match-id="21" transform="translate(0 100)">
    <svg class="match--player" data-participant-id="1"><title>Riachsoup</title></svg>
    <svg class="match--player" data-participant-id="2"><title>Vayanara</title></svg>
  </g>
  <g class="match -open" data-match-id="22" transform="translate(0 650)">
    <svg class="match--player" data-participant-id="3"><title>Ypsilandis_7000</title></svg>
    <svg class="match--player" data-participant-id="4"><title>ruze</title></svg>
  </g>
</svg>"""


class DeadlineReminderTests(unittest.IsolatedAsyncioTestCase):
    def test_home_and_open_draw_parsing(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        matches = parse_draw_matches(DRAW, tournament)
        self.assertEqual(tournament["id"], "42")
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0]["players"], ["Lampjavel", "Squeaky"])
        self.assertEqual(matches[0]["round"], "Round of 16")
        self.assertEqual(matches[0]["match_id"], "9")

    def test_round_labels_are_scoped_to_the_challonge_bracket(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        matches = parse_draw_matches(WINNER_AND_LOSER_DRAW, tournament)
        self.assertEqual(
            {match["match_id"]: match["round"] for match in matches},
            {
                "11": "Round 1",
                "12": "Losers Round 1",
            },
        )

    def test_round_labels_match_challonge_sections_when_matches_are_siblings(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        matches = parse_draw_matches(UNSCOPED_WINNER_AND_LOSER_DRAW, tournament)
        self.assertEqual(
            {match["match_id"]: match["round"] for match in matches},
            {
                "21": "Round 1",
                "22": "Losers Round 1",
            },
        )

    def test_current_tournaments_table_fallback_finds_only_ongoing_rows(self):
        tournaments = parse_ongoing_tournaments(CURRENT_TOURNAMENTS_PAGE)
        self.assertEqual(
            [(item["id"], item["name"]) for item in tournaments],
            [
                ("Jingshan_2026_TE4", "Jingshan"),
                ("Guiyang_2026_TE4", "Guiyang"),
            ],
        )

    def test_tournament_directory_includes_finished_rows_for_open_fixture_cleanup(self):
        html = CURRENT_TOURNAMENTS_PAGE.replace(
            ">Ongoing<", ">Finished<", 1
        )
        tournaments = parse_tournament_directory(html)
        self.assertEqual(
            [(item["id"], item["name"]) for item in tournaments],
            [
                ("Jingshan_2026_TE4", "Jingshan"),
                ("Guiyang_2026_TE4", "Guiyang"),
                ("Beijing_2026_TE4", "Beijing"),
            ],
        )

    def test_current_tournaments_table_fallback_preserves_event_category(self):
        html = """
        <table>
          <tr><th>Name</th><th>Location</th><th>Category</th><th>Draw</th><th>Status</th></tr>
          <tr>
            <td class="event-name"><a href="../pages/tournament_page.php?tournament=One_2026_TE4">One</a></td>
            <td>London</td><td>WTSL 250</td><td>32</td>
            <td><a href="../pages/tournament_page.php?tournament=One_2026_TE4">Ongoing</a></td>
          </tr>
          <tr>
            <td class="event-name"><a href="../pages/tournament_page.php?tournament=Two_2026_TE4">Two</a></td>
            <td>Paris</td><td>WTSL 250</td><td>32</td>
            <td><a href="../pages/tournament_page.php?tournament=Two_2026_TE4">Ongoing</a></td>
          </tr>
        </table>
        """
        tournaments = parse_ongoing_tournaments(html)
        self.assertEqual(
            [item["category"] for item in tournaments],
            ["WTSL 250", "WTSL 250"],
        )

    def test_current_wta_tournaments_keep_f_tour_tag(self):
        tournaments = parse_ongoing_tournaments(
            CURRENT_TOURNAMENTS_PAGE.replace(
                "Jingshan_2026_TE4", "US_Open_2026_TE4_F"
            ).replace(
                "Guiyang_2026_TE4", "Wimbledon_2026_TE4_F"
            ),
            tour="TE4_(F)",
        )
        self.assertEqual(
            [item["tour"] for item in tournaments],
            ["TE4_(F)", "TE4_(F)"],
        )

    def test_tournament_page_exposes_exact_challonge_svg_source(self):
        self.assertEqual(
            parse_challonge_svg_url(
                TOURNAMENT_PAGE,
                "https://playwtsl.com/TE4/pages/tournament_page.php?tournament=Guiyang_2026_TE4",
            ),
            "https://91d510368cb4170cd5ac3776.challonge.com/Guiyang_2026_TE4.svg",
        )

    def test_completed_draw_parsing_supports_scheduler_cleanup(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        matches = parse_completed_draw_matches(DRAW, tournament)
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0]["match_id"], "10")
        self.assertEqual(matches[0]["players"], ["A", "B"])

    def test_completed_draw_parsing_supports_challonge_embedded_json(self):
        state = {
            "rounds": [
                {
                    "number": 1,
                    "title": "Round 1 - Until 19/09/26 at 23:59 BST",
                },
            ],
            "matches_by_round": {
                "1": [
                    {
                        "id": 472683347,
                        "round": 1,
                        "state": "complete",
                        "player1": {
                            "display_name": "(1) Halapeno (J. Henin)",
                        },
                        "player2": {
                            "display_name": "Iakumi (M. Sharapova)",
                        },
                    },
                ],
            },
        }
        html = (
            "window._initialStoreState['TournamentStore'] = "
            f"{json.dumps(state)}; "
            "window._initialStoreState['ThemeStore'] = {};"
        )
        tournament = {
            "id": "US_Open_2026_TE4_F",
            "name": "US Open",
            "category": "",
            "draw_url": "https://example.test/draw.svg",
        }
        matches = parse_completed_draw_matches(html, tournament)
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0]["match_id"], "472683347")
        self.assertEqual(matches[0]["players"], ["Halapeno", "Iakumi"])
        self.assertEqual(matches[0]["round"], "Round 1")

    def test_timezone_and_player_cleanup(self):
        self.assertEqual(clean_player_name("(16) Lampjavel (R. Federer)"), "Lampjavel")
        self.assertEqual(discord_lookup_name("fakefederer"), "fakefederer")
        self.assertEqual(discord_lookup_name("evannoteven"), "evannoteven")
        deadline = parse_deadline("Round - Until 07/09/26 at 23:59 BST")
        self.assertEqual(deadline, datetime(2026, 9, 7, 22, 59, tzinfo=timezone.utc))
        self.assertIsNone(parse_deadline("Round of 16"))

    def test_round_label_without_dash_is_cleaned(self):
        draw = DRAW.replace(
            "Round of 16 - Until", "Semifinals (50 pts) Until"
        )
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(draw, tournament)[0]
        self.assertEqual(match["round"], "Semifinals")

    def test_strict_reminder_windows(self):
        now = datetime(2026, 1, 1, tzinfo=timezone.utc)
        self.assertEqual(reminder_window(now + timedelta(hours=24), now), "24h")
        self.assertEqual(reminder_window(now + timedelta(hours=12, seconds=1), now), "24h")
        self.assertEqual(reminder_window(now + timedelta(hours=12), now), "12h")
        self.assertEqual(reminder_window(now, now), "overdue:0")
        self.assertEqual(reminder_window(now - timedelta(hours=23), now), "overdue:0")
        self.assertEqual(reminder_window(now - timedelta(hours=24), now), "overdue:1")
        self.assertEqual(reminder_window(now - timedelta(days=2), now), "overdue:2")
        self.assertIsNone(reminder_window(now + timedelta(hours=25), now))

    def test_admin_reminder_windows(self):
        now = datetime(2026, 1, 1, tzinfo=timezone.utc)
        self.assertEqual(
            admin_reminder_window(now + timedelta(hours=6), now),
            "admin:6h",
        )
        self.assertEqual(
            admin_reminder_window(now - timedelta(hours=12), now),
            "admin:overdue12h",
        )
        self.assertEqual(
            admin_reminder_window(now - timedelta(hours=1), now),
            "admin:overdue12h",
        )
        self.assertIsNone(admin_reminder_window(now + timedelta(hours=6, seconds=1), now))

    def test_ledger_survives_restart_and_partial_retry(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.json"
            state = DeadlineReminderState(path)
            state.load()
            state.mark_sent("match:24h", "channel")
            state.mark_sent("match:24h", "dm:1")
            restarted = DeadlineReminderState(path)
            restarted.load()
            self.assertTrue(restarted.sent("match:24h", "channel"))
            self.assertTrue(restarted.sent("match:24h", "dm:1"))
            self.assertFalse(restarted.sent("match:24h", "dm:2"))
            restarted.mark_sent("match:24h", "dm:2")
            self.assertTrue(restarted.sent("match:24h", "dm:2"))

    def test_channel_delivery_is_bound_to_actual_channel_id(self):
        with tempfile.TemporaryDirectory() as directory:
            state = DeadlineReminderState(Path(directory) / "state.json")
            state.load()
            state.begin_delivery("match:24h", "channel:123")
            state.mark_sent("match:24h", "channel:123")
            self.assertTrue(state.sent("match:24h", "channel:123"))
            self.assertFalse(state.sent("match:24h", "channel:456"))

    def test_sending_operation_survives_restart_for_reconciliation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.json"
            state = DeadlineReminderState(path)
            state.load()
            operation_ref = state.begin_delivery("match:24h", "dm:1")
            restarted = DeadlineReminderState(path)
            restarted.load()
            self.assertFalse(restarted.sent("match:24h", "dm:1"))
            self.assertEqual(
                restarted.delivery("match:24h", "dm:1")["operation_ref"],
                operation_ref,
            )

    def test_bad_ledger_fails_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.json"
            path.write_text("{bad json", encoding="utf8")
            with self.assertRaises(RuntimeError):
                DeadlineReminderState(path).load()

    def test_deadline_revisions_and_windows_have_distinct_keys(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(DRAW, tournament)[0]
        self.assertNotEqual(reminder_key(match, "24h"), reminder_key(match, "12h"))
        changed = {**match, "match_key": match["match_key"] + ":changed"}
        self.assertNotEqual(reminder_key(match, "24h"), reminder_key(changed, "24h"))

    def test_reconciliation_starts_at_each_reminder_window(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(DRAW, tournament)[0]
        deadline = match["deadline"]
        self.assertEqual(
            reminder_window_started_at(match, "24h"),
            deadline - timedelta(hours=24),
        )
        self.assertEqual(
            reminder_window_started_at(match, "12h"),
            deadline - timedelta(hours=12),
        )
        self.assertEqual(
            reminder_window_started_at(match, "overdue:2"),
            deadline + timedelta(hours=48),
        )

    def test_destination_content_has_deadline_opponent_and_draw(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(DRAW, tournament)[0]
        content = main._deadline_reminder_content(match, "Squeaky")
        self.assertIn("London Cup", content)
        self.assertIn("Round of 16", content)
        self.assertIn("Opponent:** Squeaky", content)
        self.assertIn("<t:", content)
        self.assertIn(
            "**Tournament:** [London Cup]"
            "(https://playwtsl.com/TE4/draw.php?tournament=42)",
            content,
        )

    def test_deadline_content_links_active_real_schedule(self):
        original = main._match_scheduler_records
        try:
            main._match_scheduler_records = {
                "MS-internal": {
                    "status": "active",
                    "is_test": False,
                    "tournament_id": "42",
                    "source_match_id": "9",
                    "player_one": "Lampjavel",
                    "player_two": "Squeaky",
                    "thread_id": 777,
                    "guild_id": main.MATCH_SCHEDULER_GUILD_ID,
                }
            }
            tournament = parse_ongoing_tournaments(HOME)[0]
            match = parse_draw_matches(DRAW, tournament)[0]
            content = main._deadline_reminder_content(match)
            self.assertIn("**Scheduling Thread:** [Scheduling Thread]", content)
            self.assertNotIn("Open private thread", content)
            self.assertIn("/1003787574130774137/777", content)
        finally:
            main._match_scheduler_records = original
        self.assertIn(
            "**Draw:** [Open tournament draw]"
            "(https://playwtsl.com/TE4/draw.php?tournament=42)",
            content,
        )
        overdue = main._deadline_reminder_content(match, "Squeaky", "overdue:1")
        self.assertIn("deadline overdue", overdue)

    def test_deadline_schedule_button_only_appears_without_open_thread(self):
        original = main._match_scheduler_records
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(DRAW, tournament)[0]
        try:
            main._match_scheduler_records = {}
            view = main._deadline_scheduling_offer_view(match)
            self.assertIsNotNone(view)
            self.assertEqual(
                view.children[0].custom_id,
                "match_scheduler:offer:42:9",
            )

            main._match_scheduler_records = {
                "MS-internal": {
                    "status": "active",
                    "is_test": False,
                    "tournament_id": "42",
                    "source_match_id": "9",
                    "player_one": "Lampjavel",
                    "player_two": "Squeaky",
                    "thread_id": 777,
                }
            }
            self.assertIsNone(main._deadline_scheduling_offer_view(match))
        finally:
            main._match_scheduler_records = original

    async def test_uncertain_send_is_reconciled_without_duplicate(self):
        old = main._deadline_reminder_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                state = DeadlineReminderState(Path(directory) / "state.json")
                state.load()
                main._deadline_reminder_state = state
                target = SimpleNamespace(send=AsyncMock())
                allowed = main.discord.AllowedMentions(users=True)
                with patch.object(
                    main, "_find_message_with_ref",
                    new=AsyncMock(return_value=SimpleNamespace(id=99)),
                ):
                    await main._deliver_deadline_reminder(
                        "match:24h", "channel", target, "Reminder", allowed
                    )
                target.send.assert_not_awaited()
                self.assertTrue(state.sent("match:24h", "channel"))
        finally:
            main._deadline_reminder_state = old

    async def test_fresh_deployment_reconciles_prior_delivery_without_resend(self):
        old = main._deadline_reminder_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                state = DeadlineReminderState(Path(directory) / "state.json")
                state.load()
                main._deadline_reminder_state = state
                target = SimpleNamespace(send=AsyncMock())
                allowed = main.discord.AllowedMentions(users=True)
                window_start = datetime(2026, 9, 7, tzinfo=timezone.utc)
                finder = AsyncMock(return_value=SimpleNamespace(id=99))
                with patch.object(main, "_find_message_with_ref", new=finder):
                    await main._deliver_deadline_reminder(
                        "match:24h",
                        "channel:123",
                        target,
                        "Reminder",
                        allowed,
                        window_start,
                    )
                target.send.assert_not_awaited()
                self.assertEqual(finder.await_args.kwargs["after"], window_start)
                self.assertTrue(state.sent("match:24h", "channel:123"))
        finally:
            main._deadline_reminder_state = old

    async def test_post_send_ledger_failure_leaves_reconcilable_state(self):
        old = main._deadline_reminder_state
        try:
            state = SimpleNamespace(
                sent=lambda key, destination: False,
                delivery=lambda key, destination: {},
                begin_delivery=lambda key, destination: "ABC123",
                mark_sent=unittest.mock.Mock(side_effect=OSError("disk")),
            )
            main._deadline_reminder_state = state
            target = SimpleNamespace(send=AsyncMock())
            allowed = main.discord.AllowedMentions(users=True)
            with patch.object(
                main, "_find_message_with_ref", new=AsyncMock(return_value=None)
            ):
                await main._deliver_deadline_reminder(
                    "match:24h", "channel", target, "Reminder", allowed
                )
            target.send.assert_awaited_once()
            sent_content = target.send.await_args.args[0]
            self.assertIn(main._outreach_hidden_marker("deadline:ABC123"), sent_content)
        finally:
            main._deadline_reminder_state = old

    async def test_pre_send_write_failure_never_creates_unpersisted_send(self):
        old = main._deadline_reminder_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "state.json"
                state = DeadlineReminderState(path)
                state.load()
                target = SimpleNamespace(send=AsyncMock())
                allowed = main.discord.AllowedMentions(users=True)

                with patch.object(state, "_save", side_effect=OSError("disk")):
                    main._deadline_reminder_state = state
                    await main._deliver_deadline_reminder(
                        "match:24h", "channel", target, "Reminder", allowed
                    )
                target.send.assert_not_awaited()
                self.assertEqual(state.delivery("match:24h", "channel"), {})

                main._deadline_reminder_state = state
                with patch.object(
                    main, "_find_message_with_ref", new=AsyncMock(return_value=None)
                ), patch.object(state, "mark_sent", side_effect=OSError("disk")):
                    await main._deliver_deadline_reminder(
                        "match:24h", "channel", target, "Reminder", allowed
                    )
                target.send.assert_awaited_once()

                restarted = DeadlineReminderState(path)
                restarted.load()
                self.assertEqual(
                    restarted.delivery("match:24h", "channel")["status"], "sending"
                )
                main._deadline_reminder_state = restarted
                with patch.object(
                    main,
                    "_find_message_with_ref",
                    new=AsyncMock(return_value=SimpleNamespace(id=99)),
                ):
                    await main._deliver_deadline_reminder(
                        "match:24h", "channel", target, "Reminder", allowed
                    )
                target.send.assert_awaited_once()
                self.assertTrue(restarted.sent("match:24h", "channel"))
        finally:
            main._deadline_reminder_state = old

    async def test_reconciliation_searches_beyond_latest_hundred_messages(self):
        old = main._deadline_reminder_state
        try:
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "state.json"
                state = DeadlineReminderState(path)
                state.load()
                operation_ref = state.begin_delivery("match:24h", "channel")
                reference = f"deadline:{operation_ref}"
                marked = SimpleNamespace(
                    author=SimpleNamespace(id=1),
                    content="Reminder" + main._outreach_hidden_marker(reference),
                    nonce=None,
                )
                noise = [
                    SimpleNamespace(
                        author=SimpleNamespace(id=1),
                        content=f"later message {index}",
                        nonce=None,
                    )
                    for index in range(101)
                ]

                class BusyChannel:
                    send = AsyncMock()

                    def history(self, **kwargs):
                        self.history_kwargs = kwargs

                        async def iterator():
                            messages = [marked, *noise]
                            if kwargs.get("limit") == 100:
                                messages = noise[-100:]
                            for message in messages:
                                yield message

                        return iterator()

                channel = BusyChannel()
                main._deadline_reminder_state = state
                with patch.object(
                    type(main.client), "user", new_callable=PropertyMock,
                    return_value=SimpleNamespace(id=1),
                ):
                    await main._deliver_deadline_reminder(
                        "match:24h",
                        "channel",
                        channel,
                        "Reminder",
                        main.discord.AllowedMentions(users=True),
                    )
                channel.send.assert_not_awaited()
                self.assertIsNone(channel.history_kwargs["limit"])
                self.assertIn("after", channel.history_kwargs)
                self.assertTrue(state.sent("match:24h", "channel"))
        finally:
            main._deadline_reminder_state = old

    async def test_scheduling_channel_is_resolved_by_confirmed_id(self):
        wanted = SimpleNamespace(
            id=main.DEADLINE_REMINDER_CHANNEL_ID,
            name="scheduling-issues",
        )
        wrong = SimpleNamespace(id=321, name="scheduling-issues")
        guild = SimpleNamespace(id=main.OUTREACH_GUILD_ID, channels=[wrong, wanted])
        with patch.object(main.client, "get_channel", return_value=None):
            self.assertIs(await main._resolve_deadline_reminder_channel(guild), wanted)

    def test_public_reminder_content_keeps_both_draw_names(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(DRAW, tournament)[0]
        content = main._deadline_reminder_content(match, window="24h")
        self.assertIn("**Match:** Lampjavel vs Squeaky", content)

    async def test_match_scheduler_notice_contains_offer_details_and_button(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(DRAW, tournament)[0]
        user = SimpleNamespace(send=AsyncMock())
        with patch.object(
            main,
            "claim_match_scheduler_notice",
            return_value=True,
        ) as claim, patch.object(
            main,
            "mark_match_scheduler_notice_sent",
        ) as mark, patch.object(
            main,
            "release_match_scheduler_notice",
        ) as release, patch.object(
            main.client,
            "fetch_user",
            new=AsyncMock(return_value=user),
        ):
            sent = await main._send_match_scheduler_notice(
                match, 123, "Squeaky"
            )

        self.assertTrue(sent)
        claim.assert_called_once_with(
            main._match_scheduler_notice_key(match, 123), 123
        )
        mark.assert_called_once_with(main._match_scheduler_notice_key(match, 123))
        release.assert_not_called()
        user.send.assert_awaited_once()
        content = user.send.await_args.args[0]
        self.assertIn("London Cup", content)
        self.assertIn("Round of 16", content)
        self.assertIn("Opponent:** Squeaky", content)
        self.assertIn("Deadline:", content)
        self.assertIn("draw.php?tournament=42", content)
        button = user.send.await_args.kwargs["view"].children[0]
        self.assertEqual(button.label, "Schedule this match")
        self.assertEqual(button.custom_id, "match_scheduler:offer:42:9")

    async def test_match_scheduler_notice_failure_releases_and_can_retry(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(DRAW, tournament)[0]
        user = SimpleNamespace(
            send=AsyncMock(side_effect=[RuntimeError("DM closed"), None])
        )
        with patch.object(
            main,
            "claim_match_scheduler_notice",
            return_value=True,
        ) as claim, patch.object(
            main,
            "mark_match_scheduler_notice_sent",
        ) as mark, patch.object(
            main,
            "release_match_scheduler_notice",
        ) as release, patch.object(
            main.client,
            "fetch_user",
            new=AsyncMock(return_value=user),
        ):
            first = await main._send_match_scheduler_notice(match, 123, "Squeaky")
            second = await main._send_match_scheduler_notice(match, 123, "Squeaky")

        self.assertFalse(first)
        self.assertTrue(second)
        self.assertEqual(claim.call_count, 2)
        release.assert_called_once_with(main._match_scheduler_notice_key(match, 123))
        mark.assert_called_once_with(main._match_scheduler_notice_key(match, 123))

    async def test_round_correction_is_sent_once_for_old_bracket_collision(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(WINNER_AND_LOSER_DRAW, tournament)[0]
        user = SimpleNamespace(send=AsyncMock())
        with patch.object(
            main,
            "match_scheduler_notice_was_sent",
            return_value=True,
        ) as was_sent, patch.object(
            main,
            "claim_match_scheduler_notice",
            return_value=True,
        ) as claim, patch.object(
            main,
            "mark_match_scheduler_notice_sent",
        ) as mark, patch.object(
            main.client,
            "fetch_user",
            new=AsyncMock(return_value=user),
        ):
            sent = await main._send_match_scheduler_round_correction(
                match, 123, "Vayanara"
            )

        self.assertTrue(sent)
        was_sent.assert_called_once_with(main._match_scheduler_notice_key(match, 123))
        correction_key = main._match_scheduler_round_correction_key(match, 123)
        claim.assert_called_once_with(correction_key, 123)
        mark.assert_called_once_with(correction_key)
        content = user.send.await_args.args[0]
        self.assertIn("**Round (Corrected):** Round 1", content)
        self.assertIn("Challonge is the source of truth", content)

    async def test_round_correction_skips_already_correct_notice(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(WINNER_AND_LOSER_DRAW, tournament)[1]
        with patch.object(
            main,
            "match_scheduler_notice_was_sent",
        ) as was_sent, patch.object(
            main,
            "claim_match_scheduler_notice",
        ) as claim:
            sent = await main._send_match_scheduler_round_correction(
                match, 123, "ruze"
            )

        self.assertFalse(sent)
        was_sent.assert_not_called()
        claim.assert_not_called()

    async def test_new_match_scan_notifies_each_verified_player_once(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(DRAW, tournament)[0]
        old_index = main._matchlog_identity_index
        try:
            main._matchlog_identity_index = {
                101: {"atp": "Lampjavel"},
                202: {"atp": "Squeaky"},
            }
            users = {
                101: SimpleNamespace(send=AsyncMock()),
                202: SimpleNamespace(send=AsyncMock()),
            }
            with patch.object(
                main,
                "claim_match_scheduler_notice",
                side_effect=[True, True, False, False],
            ) as claim, patch.object(
                main,
                "mark_match_scheduler_notice_sent",
            ) as mark, patch.object(
                main.client,
                "fetch_user",
                new=AsyncMock(side_effect=lambda user_id: users[user_id]),
            ):
                await main._notify_match_scheduler_matches([match])
                await main._notify_match_scheduler_matches([match])
        finally:
            main._matchlog_identity_index = old_index

        self.assertEqual(users[101].send.await_count, 1)
        self.assertEqual(users[202].send.await_count, 1)
        # The second scan is suppressed by the durable claim response.
        self.assertEqual(claim.call_count, 4)
        self.assertEqual(mark.call_count, 2)

    async def test_new_match_scan_skips_unverified_players(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(DRAW, tournament)[0]
        old_index = main._matchlog_identity_index
        try:
            main._matchlog_identity_index = {101: {"atp": "Lampjavel"}}
            user = SimpleNamespace(send=AsyncMock())
            with patch.object(
                main,
                "claim_match_scheduler_notice",
                return_value=True,
            ), patch.object(
                main,
                "mark_match_scheduler_notice_sent",
            ), patch.object(
                main.client,
                "fetch_user",
                new=AsyncMock(return_value=user),
            ):
                await main._notify_match_scheduler_matches([match])
        finally:
            main._matchlog_identity_index = old_index

        user.send.assert_awaited_once()
        self.assertIn("Opponent:** Squeaky", user.send.await_args.args[0])

    async def test_offer_button_revalidates_current_open_match(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_draw_matches(DRAW, tournament)[0]
        response = SimpleNamespace(
            defer=AsyncMock(),
            is_done=Mock(return_value=True),
        )
        interaction = SimpleNamespace(response=response)
        with patch.object(
            main,
            "_fetch_match_scheduler_matches",
            new=AsyncMock(return_value=[match]),
        ), patch.object(
            main,
            "_create_match_scheduler_record",
            new=AsyncMock(),
        ) as create:
            await main._route_match_scheduler_offer(interaction, "42", "9")

        response.defer.assert_awaited_once()
        create.assert_awaited_once_with(interaction, match, test_mode=False)

    async def test_offer_button_rejects_match_removed_from_current_draw(self):
        response = SimpleNamespace(
            defer=AsyncMock(),
            is_done=Mock(return_value=True),
        )
        interaction = SimpleNamespace(
            response=response,
            edit_original_response=AsyncMock(),
        )
        with patch.object(
            main,
            "_fetch_match_scheduler_matches",
            new=AsyncMock(return_value=[]),
        ), patch.object(
            main,
            "_create_match_scheduler_record",
            new=AsyncMock(),
        ) as create:
            await main._route_match_scheduler_offer(interaction, "42", "9")

        create.assert_not_awaited()
        self.assertIn("no longer open", interaction.edit_original_response.await_args.kwargs["content"])

    async def test_persistent_offer_component_routes_after_restart(self):
        interaction = SimpleNamespace(
            type=main.discord.InteractionType.component,
            data={"custom_id": "match_scheduler:offer:42:9"},
        )
        with patch.object(
            main,
            "_route_match_scheduler_offer",
            new=AsyncMock(),
        ) as route:
            await main.on_interaction(interaction)
        route.assert_awaited_once_with(interaction, "42", "9")

    def test_scheduler_log_header_starts_with_conversation_thread_link(self):
        record = {
            "guild_id": main.MATCH_SCHEDULER_GUILD_ID,
            "thread_id": 777,
            "player_one": "Lampjavel",
            "player_two": "Squeaky",
            "tournament_name": "London Cup",
            "round_name": "Round of 16",
            "is_test": False,
        }
        content = main._scheduler_log_header(
            record,
            SimpleNamespace(
                jump_url="https://discord.com/channels/1/2/777"
            ),
        )
        self.assertTrue(
            content.startswith(
                "🧵 **Thread:** [Open scheduling thread]"
                "(https://discord.com/channels/1/2/777)"
            )
        )
        self.assertNotIn("Match completed", content)

    async def test_scheduler_transcript_uses_from_and_thread_link(self):
        record = {
            "guild_id": main.MATCH_SCHEDULER_GUILD_ID,
            "thread_id": 777,
            "player_one": "Lampjavel",
            "player_two": "Squeaky",
        }
        log_channel = SimpleNamespace(send=AsyncMock())
        author = SimpleNamespace(display_name="Lampjavel", name="Lampjavel")
        with patch.object(main.client, "get_channel", return_value=log_channel):
            await main._log_match_scheduler_message(
                record,
                author=author,
                content="Can you play tomorrow?",
                message_id=987654,
                source="reply",
            )

        content = log_channel.send.await_args.args[0]
        self.assertTrue(content.startswith("🧵 **Thread:**"))
        self.assertIn("**From:** Lampjavel", content)
        self.assertNotIn("**Author:**", content)
        self.assertNotIn("DM reply", content)

    async def test_scheduler_reply_names_sender_and_mentions_recipient(self):
        record = {
            "schedule_id": "MS-REPLY",
            "thread_id": 777,
            "player_one_user_id": 100,
            "player_two_user_id": 200,
            "status": "active",
            "is_test": False,
        }
        sent = SimpleNamespace(id=888, created_at=None)
        thread = SimpleNamespace(send=AsyncMock(return_value=sent))
        interaction = SimpleNamespace(
            user=SimpleNamespace(
                id=100,
                display_name="Franky Franchicha",
                name="thejohnmachete",
            ),
            response=SimpleNamespace(defer=AsyncMock()),
            edit_original_response=AsyncMock(),
        )
        modal = main.MatchSchedulerReplyModal("MS-REPLY", "side1")
        modal.reply_text = SimpleNamespace(value="I can play tomorrow.")

        with (
            patch.object(main, "_scheduler_record_for_id", return_value=record),
            patch.object(main.client, "get_channel", return_value=thread),
            patch.object(main, "_log_match_scheduler_message", new=AsyncMock()),
            patch.object(main, "_send_match_scheduler_reply_dms", new=AsyncMock()),
        ):
            await modal.on_submit(interaction)

        content = thread.send.await_args.args[0]
        self.assertEqual(
            content,
            "**Franky Franchicha:** <@200> I can play tomorrow.",
        )

    async def test_duplicate_schedule_links_open_thread_and_keeps_reply_button(self):
        old_records = main._match_scheduler_records
        main._match_scheduler_records = {
            "MS-OPEN": {
                "schedule_id": "MS-OPEN",
                "guild_id": main.MATCH_SCHEDULER_GUILD_ID,
                "tournament_id": "42",
                "source_match_id": "9",
                "player_one": "Squeaky",
                "player_two": "Squeaky",
                "player_one_user_id": 123,
                "player_two_user_id": 123,
                "thread_id": 777,
                "status": "active",
                "is_test": True,
            }
        }
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=123),
            response=SimpleNamespace(is_done=Mock(return_value=True)),
            edit_original_response=AsyncMock(),
        )
        source_match = parse_draw_matches(
            DRAW,
            parse_ongoing_tournaments(HOME)[0],
        )[0]
        try:
            await main._create_match_scheduler_record(
                interaction,
                source_match,
                test_mode=True,
            )
        finally:
            main._match_scheduler_records = old_records

        kwargs = interaction.edit_original_response.await_args.kwargs
        self.assertIn("open scheduling thread", kwargs["content"])
        self.assertIn("/777", kwargs["content"])
        self.assertIn("reply to the scheduling conversation", kwargs["content"])
        self.assertEqual(
            kwargs["view"].children[0].custom_id,
            "match_scheduler:reply:MS-OPEN:test",
        )

    async def test_finalizing_transcribes_then_archives_without_completion_message(self):
        record = {
            "schedule_id": "MS-CLOSE",
            "guild_id": main.MATCH_SCHEDULER_GUILD_ID,
            "thread_id": 777,
            "player_one": "gifu",
            "player_two": "Madferit",
            "status": "active",
            "is_test": False,
        }
        messages = [
            SimpleNamespace(
                id=1,
                author=SimpleNamespace(display_name="WTSL"),
                content="Match scheduling",
                attachments=[],
                created_at=datetime(2026, 9, 13, tzinfo=timezone.utc),
            ),
            SimpleNamespace(
                id=2,
                author=SimpleNamespace(display_name="gifu"),
                content="I can play tomorrow.",
                attachments=[],
                created_at=datetime(2026, 9, 13, 1, tzinfo=timezone.utc),
            ),
        ]

        async def history(**_kwargs):
            for message in messages:
                yield message

        thread = SimpleNamespace(
            history=history,
            edit=AsyncMock(),
            delete=AsyncMock(),
        )
        with patch.object(
            main.client,
            "get_channel",
            return_value=thread,
        ), patch.object(
            main,
            "_log_match_scheduler_message",
            new=AsyncMock(),
        ) as log, patch.object(
            main,
            "update_match_schedule",
        ) as update:
            await main._finalize_match_scheduler(
                record,
                source="tournament result",
            )

        self.assertEqual(log.await_count, 2)
        self.assertEqual(update.call_args.kwargs["status"], "completed")
        thread.edit.assert_awaited_once_with(
            archived=True,
            locked=True,
            reason="MS-CLOSE completed",
        )
        thread.delete.assert_not_awaited()
        self.assertEqual(record["status"], "completed")

    def test_scheduler_completion_key_is_hashable(self):
        tournament = parse_ongoing_tournaments(HOME)[0]
        match = parse_completed_draw_matches(DRAW, tournament)[0]
        key = main._match_scheduler_completion_key(match)
        self.assertIn(key, {key})