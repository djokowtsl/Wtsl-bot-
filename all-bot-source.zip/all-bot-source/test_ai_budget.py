import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from ai_budget import (
    AIBudget,
    AIBudgetExceeded,
    AIBudgetStateError,
    BudgetedAsyncOpenAI,
    BudgetedOpenAI,
    UnsupportedAIModel,
    _BudgetedAsyncCompletions,
    _BudgetedCompletions,
    estimate_request_cost,
)


class AIBudgetTests(unittest.TestCase):
    def test_configured_budget_cannot_exceed_twenty_dollars(self):
        with TemporaryDirectory() as directory:
            budget = AIBudget(Path(directory) / "usage.json", budget_usd=100)

            self.assertEqual(budget.snapshot()["budget_usd"], 20)

    def test_non_finite_environment_budget_fails_closed(self):
        with TemporaryDirectory() as directory, patch.dict(
            "os.environ",
            {"AI_MONTHLY_BUDGET_USD": "nan"},
        ):
            budget = AIBudget(Path(directory) / "usage.json")

            self.assertEqual(budget.snapshot()["budget_usd"], 0)
            with self.assertRaises(AIBudgetExceeded):
                budget.reserve(
                    "gpt-4o-mini",
                    [{"role": "user", "content": "hello"}],
                    100,
                )

    def test_explicit_non_finite_budget_is_rejected(self):
        with TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, "finite"):
                AIBudget(Path(directory) / "usage.json", budget_usd=float("nan"))

    def test_estimate_uses_model_pricing_and_conservative_multiplier(self):
        estimate = estimate_request_cost(
            "gpt-4o-mini",
            [{"role": "user", "content": "hello"}],
            1000,
        )

        self.assertAlmostEqual(
            estimate,
            21 / 1_000_000 * 0.15 + 1000 / 1_000_000 * 0.60,
        )

    def test_reservation_settlement_records_provider_tokens(self):
        with TemporaryDirectory() as directory:
            budget = AIBudget(Path(directory) / "usage.json", budget_usd=1)
            reservation = budget.reserve(
                "gpt-4o-mini",
                [{"role": "user", "content": "hello"}],
                1000,
            )
            cost = budget.settle(
                reservation,
                SimpleNamespace(
                    prompt_tokens=100,
                    completion_tokens=200,
                    total_tokens=300,
                ),
            )

            state = budget.snapshot()
            self.assertAlmostEqual(cost, 100 / 1_000_000 * 0.15 + 200 / 1_000_000 * 0.60)
            self.assertEqual(state["requests"], 1)
            self.assertEqual(state["reserved_usd"], 0)
            self.assertAlmostEqual(
                state["budget_debited_usd"],
                reservation.estimated_usd,
            )
            self.assertEqual(state["by_model"]["gpt-4o-mini"]["prompt_tokens"], 100)
            self.assertEqual(
                state["by_model"]["gpt-4o-mini"]["usage_available_requests"], 1
            )

    def test_missing_usage_keeps_conservative_reservation_as_spend(self):
        with TemporaryDirectory() as directory:
            budget = AIBudget(Path(directory) / "usage.json", budget_usd=1)
            reservation = budget.reserve("gpt-5-mini", [], 1000)
            budget.settle(reservation, None)

            state = budget.snapshot()
            self.assertAlmostEqual(state["spent_usd"], reservation.estimated_usd)
            self.assertEqual(state["by_model"]["gpt-5-mini"]["total_tokens"], 0)

    def test_unknown_model_is_rejected_before_provider_request(self):
        with TemporaryDirectory() as directory:
            budget = AIBudget(Path(directory) / "usage.json", budget_usd=1)
            create = unittest.mock.Mock()
            completions = _BudgetedCompletions(
                SimpleNamespace(create=create),
                budget,
            )

            with self.assertRaises(UnsupportedAIModel):
                completions.create(
                    model="gpt-5",
                    messages=[{"role": "user", "content": "hello"}],
                    max_completion_tokens=100,
                )

            create.assert_not_called()

    def test_budget_exhaustion_blocks_before_provider_request(self):
        with TemporaryDirectory() as directory:
            budget = AIBudget(Path(directory) / "usage.json", budget_usd=0.01)
            with self.assertRaises(AIBudgetExceeded):
                budget.reserve(
                    "gpt-5-mini",
                    [{"role": "user", "content": "hello"}],
                    10_000,
                )

            state = budget.snapshot()
            self.assertEqual(state["blocked_requests"], 1)
            self.assertEqual(state["requests"], 0)

    def test_old_month_is_reset_on_first_read_of_new_month(self):
        with TemporaryDirectory() as directory:
            state_path = Path(directory) / "usage.json"
            state_path.write_text(
                json.dumps(
                    {
                        "month": "2026-01",
                        "spent_usd": 9,
                        "reserved_usd": 1,
                        "requests": 99,
                    }
                ),
                encoding="utf-8",
            )
            with patch("ai_budget._month_key", return_value="2026-02"):
                state = AIBudget(state_path, budget_usd=1).snapshot()

            self.assertEqual(state["month"], "2026-02")
            self.assertEqual(state["spent_usd"], 0)
            self.assertEqual(state["requests"], 0)

    def test_concurrent_reservations_cannot_bypass_ceiling(self):
        with TemporaryDirectory() as directory:
            state_path = Path(directory) / "usage.json"
            budgets = [
                AIBudget(state_path, budget_usd=1),
                AIBudget(state_path, budget_usd=1),
            ]

            def reserve(index):
                try:
                    return budgets[index % len(budgets)].reserve(
                        "gpt-5-mini",
                        [{"role": "user", "content": "hello"}],
                        100_000,
                    )
                except AIBudgetExceeded:
                    return None

            with ThreadPoolExecutor(max_workers=8) as executor:
                reservations = list(executor.map(reserve, range(8)))

            successful = [item for item in reservations if item is not None]
            self.assertEqual(len(successful), 1)
            self.assertLessEqual(budgets[0].snapshot()["reserved_usd"], 1)

    def test_corrupt_initialized_ledger_fails_closed(self):
        with TemporaryDirectory() as directory:
            state_path = Path(directory) / "usage.json"
            budget = AIBudget(state_path, budget_usd=1)
            budget.snapshot()
            state_path.write_text("{not json", encoding="utf-8")

            with self.assertRaises(AIBudgetStateError):
                budget.reserve(
                    "gpt-4o-mini",
                    [{"role": "user", "content": "hello"}],
                    100,
                )

    def test_invalid_ledger_numbers_fail_closed(self):
        with TemporaryDirectory() as directory:
            state_path = Path(directory) / "usage.json"
            budget = AIBudget(state_path, budget_usd=1)
            clean_state = budget.snapshot()

            for field, value in (
                ("budget_debited_usd", float("nan")),
                ("reserved_usd", float("inf")),
                ("spent_usd", -1),
            ):
                with self.subTest(field=field):
                    state = {
                        key: item
                        for key, item in clean_state.items()
                        if key != "remaining_usd"
                    }
                    state[field] = value
                    state_path.write_text(json.dumps(state), encoding="utf-8")
                    with self.assertRaises(AIBudgetStateError):
                        budget.reserve(
                            "gpt-4o-mini",
                            [{"role": "user", "content": "hello"}],
                            100,
                        )

    def test_budgeted_completion_settles_successful_response(self):
        with TemporaryDirectory() as directory:
            budget = AIBudget(Path(directory) / "usage.json", budget_usd=1)
            response = SimpleNamespace(
                usage=SimpleNamespace(
                    prompt_tokens=10,
                    completion_tokens=20,
                    total_tokens=30,
                )
            )
            create = unittest.mock.Mock(return_value=response)
            completions = _BudgetedCompletions(
                SimpleNamespace(create=create),
                budget,
            )

            self.assertIs(completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "hello"}],
                max_completion_tokens=100,
            ), response)
            self.assertEqual(budget.snapshot()["requests"], 1)
            create.assert_called_once()

    def test_failed_completion_debits_reservation_without_retrying(self):
        with TemporaryDirectory() as directory:
            budget = AIBudget(Path(directory) / "usage.json", budget_usd=1)
            create = unittest.mock.Mock(side_effect=RuntimeError("provider down"))
            completions = _BudgetedCompletions(
                SimpleNamespace(create=create),
                budget,
            )

            with self.assertRaisesRegex(RuntimeError, "provider down"):
                completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": "hello"}],
                    max_completion_tokens=100,
                )

            state = budget.snapshot()
            self.assertEqual(state["reserved_usd"], 0)
            self.assertGreater(state["spent_usd"], 0)
            self.assertGreater(state["budget_debited_usd"], 0)
            self.assertEqual(state["requests"], 1)
            create.assert_called_once()

    def test_clients_force_sdk_retries_off(self):
        raw_sync = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace())
        )
        raw_async = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace())
        )
        with (
            patch("ai_budget._RawOpenAI", return_value=raw_sync) as sync_constructor,
            patch(
                "ai_budget._RawAsyncOpenAI",
                return_value=raw_async,
            ) as async_constructor,
        ):
            BudgetedOpenAI(api_key="test", max_retries=2)
            BudgetedAsyncOpenAI(api_key="test", max_retries=2)

        self.assertEqual(sync_constructor.call_args.kwargs["max_retries"], 0)
        self.assertEqual(async_constructor.call_args.kwargs["max_retries"], 0)

    def test_missing_completion_limit_is_rejected_before_provider_request(self):
        with TemporaryDirectory() as directory:
            budget = AIBudget(Path(directory) / "usage.json", budget_usd=1)
            create = unittest.mock.Mock()
            completions = _BudgetedCompletions(
                SimpleNamespace(create=create),
                budget,
            )

            with self.assertRaisesRegex(ValueError, "max_completion_tokens"):
                completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": "hello"}],
                )

            create.assert_not_called()


class AsyncAIBudgetTests(unittest.IsolatedAsyncioTestCase):
    async def test_async_completion_uses_same_budget_guard(self):
        with TemporaryDirectory() as directory:
            budget = AIBudget(Path(directory) / "usage.json", budget_usd=1)
            response = SimpleNamespace(
                usage={
                    "prompt_tokens": 10,
                    "completion_tokens": 20,
                    "total_tokens": 30,
                }
            )
            create = unittest.mock.AsyncMock(return_value=response)
            completions = _BudgetedAsyncCompletions(
                SimpleNamespace(create=create),
                budget,
            )

            result = await completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "hello"}],
                max_completion_tokens=100,
            )

            self.assertIs(result, response)
            self.assertEqual(budget.snapshot()["requests"], 1)
            create.assert_awaited_once()


if __name__ == "__main__":
    unittest.main()