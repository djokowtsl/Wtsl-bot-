import unittest
from unittest.mock import Mock

from twitter_bridge import (
    TwitterConfigurationError,
    TwitterPoster,
    build_tweet_text,
    is_image_attachment,
)


class TwitterBridgeTests(unittest.TestCase):
    def test_image_detection_accepts_content_type_and_extension(self):
        self.assertTrue(is_image_attachment("photo.bin", "image/jpeg"))
        self.assertTrue(is_image_attachment("photo.PNG", None))
        self.assertFalse(is_image_attachment("rules.pdf", "application/pdf"))

    def test_tweet_text_preserves_formatting_and_adds_source(self):
        text = build_tweet_text(
            "**Final result**\nPlayer A 6–4, 6–3",
            source_url="https://discord.com/channels/1/2/3",
        )
        self.assertEqual(
            text,
            "**Final result**\nPlayer A 6–4, 6–3\n\n"
            "https://discord.com/channels/1/2/3",
        )

    def test_tweet_text_keeps_source_when_body_is_too_long(self):
        source = "https://discord.com/channels/1/2/3"
        text = build_tweet_text("A" * 400, source_url=source)
        self.assertLessEqual(len(text), 280)
        self.assertTrue(text.endswith(source))
        self.assertIn("…", text)

    def test_missing_credentials_fail_explicitly(self):
        poster = TwitterPoster({})
        with self.assertRaises(TwitterConfigurationError):
            poster.post_sync("Test")

    def test_post_sync_uploads_media_and_returns_url(self):
        poster = TwitterPoster(
            {
                "TWITTER_CONSUMER_KEY": "key",
                "TWITTER_CONSUMER_SECRET": "secret",
                "TWITTER_ACCESS_TOKEN": "token",
                "TWITTER_ACCESS_TOKEN_SECRET": "token-secret",
            }
        )
        client = Mock()
        client.create_tweet.return_value.data = {"id": "123"}
        api_v1 = Mock()
        api_v1.media_upload.return_value.media_id = "456"
        poster._clients = Mock(return_value=(client, api_v1))

        result = poster.post_sync("Hello", [("photo.png", b"image")])

        self.assertEqual(result["url"], "https://twitter.com/wtsl_tennis/status/123")
        api_v1.media_upload.assert_called_once()
        client.create_tweet.assert_called_once_with(
            text="Hello",
            media_ids=["456"],
        )


if __name__ == "__main__":
    unittest.main()