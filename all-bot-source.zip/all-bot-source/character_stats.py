"""Character attribute profiles and roster-relative rankings."""

from __future__ import annotations

import asyncio
import math
import os
import re
import tempfile
import time
from pathlib import Path
from typing import Any
from urllib.parse import quote, urljoin, urlparse

import aiohttp
from bs4 import BeautifulSoup
from openpyxl import load_workbook


WORKBOOK_NAME = "WTSL_Stats_20260912_1789232118806.xlsx"
CANONICAL_WORKBOOK_NAME = "WTSL_Character_Stats_Roster.xlsx"
MAX_ATTRIBUTE_COLUMN = 43  # AQ
EXPECTED_ATTRIBUTE_HEADERS = (
    "name",
    "Sex (0: male; 1: female)",
    "Height",
    "Weight",
    "Country",
    "Playing Hand (0 or 1: right; -1: left)",
    "Double handed backhand (0: one-handed; 1: double-handed)",
    "Double handed forehand (0: one-handed; 1: double-handed)",
    "Player Style (0: Defender; 1: Power Baseliner; 2: Puncher; "
    "3: All-Court Attacker; 4: Volleyer; 5: Counter; "
    "6: Counter-Puncher; 7: All-Rounder; 8: Bulldog)",
    "Acceleration Trait",
    "Forehand Power",
    "Forehand Consistency",
    "Forehand Precision",
    "Backhand Power",
    "Backhand Consistency",
    "Backhand Precision",
    "Spinny Backhand",
    "Flat Backhand",
    "Slice mastery",
    "Early Ball",
    "Net Presence",
    "Forehand Volley",
    "Backhand Volley",
    "Smash",
    "Ball Feeling",
    "Service Power",
    "Service Consistency",
    "Service Precision",
    "Slice serve",
    "Topspin serve",
    "Twist serve",
    "Boom Boom Server",
    "On-Time Server",
    "Speed",
    "Muscle Tone",
    "Stamina",
    "Clay Mover",
    "Slider",
    "Lob",
    "Dropshot",
    "Focus",
    "Counter",
    "Topspin",
)

PLAYER_STYLE_LABELS = {
    0: "Defender",
    1: "Power Baseliner",
    2: "Puncher",
    3: "All-Court Attacker",
    4: "Volleyer",
    5: "Counter",
    6: "Counter-Puncher",
    7: "All-Rounder",
    8: "Bulldog",
}
PLAYER_STYLE_DESCRIPTIONS = {
    "Defender": (
        "Wins by extending rallies, recovering behind the ball, and waiting for "
        "a short or loose reply before attacking."
    ),
    "Power Baseliner": (
        "Tries to take control from behind the baseline, usually by creating a "
        "forehand and finishing before the rally becomes a patience test."
    ),
    "Puncher": (
        "Takes time away with compact, early strikes, absorbs pace well, and "
        "uses a short opening to move forward."
    ),
    "All-Court Attacker": (
        "Builds a baseline advantage and then follows it forward, changing court "
        "position instead of trading from one spot."
    ),
    "Volleyer": (
        "Creates pressure by getting forward early and finishing at net; the "
        "serve or approach must give enough time to close."
    ),
    "Counter": (
        "Uses the opponent's pace to redirect the ball early, but must create "
        "the speed itself when the incoming ball is slow."
    ),
    "Counter-Puncher": (
        "Defends with movement and margin, then turns the opponent's first loose "
        "ball into an attack."
    ),
    "All-Rounder": (
        "Can play deep, take the ball early, or come forward, choosing the best "
        "court position instead of forcing one pattern."
    ),
    "Bulldog": (
        "Stays in difficult exchanges, refuses to give up court, and becomes "
        "aggressive as soon as the opponent leaves a shorter ball."
    ),
}
PLAYER_STYLE_MECHANICS = {
    "Defender": (
        "This is the patient back-court option: use height, depth, and recovery to "
        "make the opponent hit another ball, then attack the short reply. It gets "
        "unlimited attack lobs and a topspin benefit, but one fewer acceleration."
    ),
    "Power Baseliner": (
        "This is the baseline-dictating option: create forehands, keep the opponent "
        "deep, and finish before patience becomes the deciding skill. It gets three "
        "extra accelerations and a large shoulder-height acceleration speed bonus."
    ),
    "Puncher": (
        "This is the time-taking option: meet the ball early, redirect pace, and "
        "move forward when the opponent is off balance. It gets two extra "
        "accelerations, bigger net jumps, and a large shoulder-height bonus."
    ),
    "All-Court Attacker": (
        "This is the transition option: build the opening from the baseline, then "
        "use the short ball to take the net. It gets one extra acceleration, bigger "
        "net jumps, a shoulder-height bonus, and extra forehand speed."
    ),
    "Volleyer": (
        "This is the front-court option: serve or approach with enough quality to "
        "close, then finish before the opponent can pass. It gets the biggest "
        "net-jump benefit and is designed to avoid long baseline rallies."
    ),
    "Counter": (
        "This is the reaction-based option: stand ready for the opponent's pace, "
        "redirect early, and step in when they leave the ball short. It accelerates "
        "freely but gets less attacking benefit against slow balls."
    ),
    "Counter-Puncher": (
        "This is the pressure-absorption option: defend with margin, recover to "
        "position, and attack the first ball that sits up. It gets two extra "
        "accelerations and is better on rising-ball attacks than on late attacks."
    ),
    "All-Rounder": (
        "This is the adaptable option: stay deep when that is safest, take the ball "
        "early when time is available, and come forward behind a real opening. It "
        "gets one extra acceleration, bigger net jumps, and broad shoulder-height "
        "speed help."
    ),
    "Bulldog": (
        "This is the stubborn pressure option: stay in the exchange, hold court "
        "under pressure, and turn the opponent's first short ball into attack. It "
        "gets one extra acceleration, a small topspin benefit, and a lower topspin "
        "length/speed handicap."
    ),
}
ACCELERATION_MECHANICS = {
    "None": (
        "has no acceleration-specific modifier, so point construction depends "
        "more directly on the character's movement, timing, and shot attributes"
    ),
    "HeavyHitter": (
        "rewards committing to forceful accelerations and turning a prepared "
        "ball into a heavy first strike, but is less useful when rushed or "
        "defending without time to set the feet"
    ),
    "Panzer": (
        "favours stable, forceful acceleration through contact, helping the "
        "character hold ground and redirect pace rather than relying on sudden "
        "changes of rhythm"
    ),
    "InstantAccelerator": (
        "makes immediate acceleration the tactical identity: take the ball "
        "early, attack before the defence resets, and avoid drifting into "
        "neutral exchanges where the trait creates less separation"
    ),
    "Momentum": (
        "becomes more valuable once the character has established forward or "
        "lateral momentum, so recovery footwork should flow into the next "
        "attacking shot instead of stopping and restarting"
    ),
    "SlowBallBigSpeed": (
        "is especially dangerous against slow or short balls, converting weak "
        "pace into a much faster attack; step inside the court and punish "
        "floaters rather than waiting for them to reach a comfortable height"
    ),
    "InFlowAccelerator": (
        "rewards accelerating within the natural rhythm of the rally, making "
        "well-timed direction changes more reliable than abrupt low-percentage "
        "attacks from a static position"
    ),
    "RapidFire": (
        "supports repeated accelerations in quick succession, so the best "
        "pattern is sustained pressure across several attacking balls rather "
        "than expecting one strike to finish every point"
    ),
    "SporadicAccelerator": (
        "creates intermittent attacking bursts rather than constant access to "
        "the same acceleration level, so patience and shot selection matter "
        "more than forcing the trait on every ball"
    ),
}
ATTRIBUTE_MECHANICS = {
    "Forehand Power": (
        "raises forehand speed and first-strike damage; it is most valuable when "
        "you can create a short ball or dictate from the baseline"
    ),
    "Backhand Power": (
        "raises backhand speed and first-strike damage, especially useful when "
        "the opponent can target that wing"
    ),
    "Forehand Consistency": (
        "helps handle difficult or fast balls, reduce errors, and keep normal "
        "shots deep or short without giving away control"
    ),
    "Backhand Consistency": (
        "helps absorb pressure on the backhand, reduce errors, and maintain "
        "depth when the opponent attacks that side"
    ),
    "Forehand Precision": (
        "improves accuracy relative to forehand power; raising power without "
        "precision can give back some of the accuracy gained"
    ),
    "Backhand Precision": (
        "improves accuracy relative to backhand power; it matters when you want "
        "to use pace without expanding your error pattern"
    ),
    "Service Power": (
        "primarily raises maximum serve speed, so it creates more free points "
        "only when service consistency can support the chosen risk"
    ),
    "Service Consistency": (
        "controls serve reliability and balances service power; a power-heavy "
        "serve loses success, while higher consistency can improve second-serve speed"
    ),
    "Service Precision": (
        "improves serve placement relative to service power, making a powerful "
        "serve more usable rather than merely faster"
    ),
    "Topspin": (
        "is context-dependent rather than universally higher-is-better: 50% is "
        "neutral, higher values help clay and slow courts but handicap fast-court "
        "speed, and lower values do the opposite. It also raises the spin and "
        "slows the speed of normal, topspin, short, acceleration, and attack-lob "
        "strikes while increasing fatigue."
    ),
    "Net Presence": (
        "combines with the relevant volley or smash skill to define precision "
        "and consistency, but it does not add raw power; it also lets the "
        "player move farther while volleying without as much penalty"
    ),
    "Forehand Volley": (
        "sets the base forehand-volley power while combining with Net Presence "
        "for precision and consistency; it matters after the character has "
        "created a reason to move forward"
    ),
    "Backhand Volley": (
        "sets the base backhand-volley power while combining with Net Presence "
        "for precision and consistency, especially in serve-and-volley or "
        "transition patterns"
    ),
    "Smash": (
        "sets the base smash power while combining with Net Presence for "
        "precision and consistency; it is more valuable when movement creates "
        "frequent finishing chances"
    ),
    "Ball Feeling": (
        "improves soft control, especially at the net, so it supports touch "
        "finishes rather than raw baseline power"
    ),
    "Early Ball": (
        "helps strike on the rise, taking time away from the opponent and "
        "supporting aggressive countering before the ball drops"
    ),
    "Counter": (
        "uses incoming ball speed on normal and topspin strikes to add up to "
        "7.5 km/h of return pace. Higher Counter also reduces the constraint "
        "of fast incoming balls, but makes slow incoming balls slightly less "
        "automatically easy"
    ),
    "Lob": (
        "defines defensive and attacking lobs, but the result is balanced with "
        "the forehand or backhand skill used for the shot; it is especially "
        "useful when the opponent closes the net or leaves space behind"
    ),
    "Dropshot": (
        "defines drop-shot control, but the result is balanced with the "
        "forehand or backhand skill used for the shot, especially when handling "
        "a fast incoming ball"
    ),
    "Speed": (
        "sets maximum running speed, while its average with Muscle Tone "
        "determines running acceleration and how quickly the player reaches "
        "difficult balls"
    ),
    "Muscle Tone": (
        "combines with speed to determine running acceleration, so it affects "
        "how quickly the player reaches difficult balls"
    ),
    "Stamina": (
        "works relative to the Speed/Muscle Tone running baseline to reduce "
        "fatigue and sets the maximum number of good accelerations per point, "
        "from 1 to 5"
    ),
    "Focus": (
        "is compared with the average of Speed and Muscle Tone: above that "
        "baseline it prepares strikes faster for better accuracy, depth, and "
        "early attacks, while below it does the opposite"
    ),
    "Slice mastery": (
        "improves control of slice during rallies, making variation and lower "
        "skidding trajectories more dependable"
    ),
    "Spinny Backhand": (
        "raises the topspin contribution on the backhand, which is more valuable "
        "on slow courts and in high-margin rally patterns"
    ),
    "Flat Backhand": (
        "reduces backhand topspin, favouring a flatter, faster trajectory when "
        "court speed and early ball striking reward it"
    ),
}
TECHNICAL_SKILL_INTERACTIONS = (
    (
        "Serve",
        "Power sets maximum speed. Consistency balances power: when they match, "
        "a Strong serve is about 70% successful and a Normal serve about 85%; "
        "higher consistency improves second-serve speed. Precision is relative "
        "to power and controls usable placement.",
    ),
    (
        "Forehand / Backhand",
        "Power sets pace, Precision is relative to that power, and Consistency "
        "handles difficult incoming balls, lowers fault risk, and supports "
        "deeper normal strikes or shorter short strikes.",
    ),
    (
        "Topspin",
        "50% is neutral. Higher topspin helps on clay and slow courts but "
        "handicaps fast-court speed; lower topspin reverses that trade-off. It "
        "adds spin, slows several strike types, and increases fatigue.",
    ),
    (
        "Counter",
        "Fast incoming balls can add up to 7.5 km/h to normal and topspin "
        "strikes. Counter reduces the fast-ball constraint, but makes slow balls "
        "slightly less easy.",
    ),
    (
        "Volley / Smash",
        "Net Presence combines with the relevant volley or smash skill for "
        "precision and consistency, not raw power. Higher Net Presence also "
        "allows more movement while volleying without a handicap.",
    ),
    (
        "Lob / Drop Shot",
        "The Lob or Dropshot skill is balanced with the Forehand or Backhand "
        "used for the shot, including when controlling a fast incoming ball.",
    ),
)
TALENT_MECHANICS = {
    "Slice serve": "adds slice to serve and is most useful on fast surfaces",
    "Topspin serve": "adds topspin to serve and is most useful on slow surfaces",
    "Twist serve": "acts like a kick/twist serve and is most useful on normal surfaces",
    "Boom Boom Server": "can produce a faster first serve, including under break-point pressure at higher talent strength",
    "On-Time Server": "reduces first-serve misses under break-point pressure",
    "Clay Mover": "slows down and changes direction faster on clay",
    "Slider": "allows sliding to begin at lower running speed",
    "Ball Feeling": "adds soft-control ability, especially around the net",
    "Early Ball": "adds ability to take the ball on the rise",
    "Slice mastery": "improves control and use of slice during rallies",
}
ATTRIBUTE_GROUP_RULES = (
    (
        "Serve",
        ("serve",),
        "serve pressure and starting points",
        "Choose this when you want to win more points through the serve and first ball.",
        "The trade-off is less help in extended rallies if the serve does not create an advantage.",
    ),
    (
        "Power",
        ("power", "smash"),
        "first-strike power",
        "Choose this when you want to take control early and finish points before long exchanges.",
        "The trade-off is that power is less valuable when you are forced into patient, low-error rallies.",
    ),
    (
        "Consistency",
        ("consistency", "focus"),
        "rally reliability",
        "Choose this when you want a dependable game that holds up in long exchanges and pressure points.",
        "The trade-off is less immediate damage against opponents who give you short balls.",
    ),
    (
        "Precision",
        ("precision", "ball feeling"),
        "placement and control",
        "Choose this when you win by changing direction, finding targets, and controlling margins.",
        "The trade-off is that precision needs time and does not replace raw pace against a dominant attacker.",
    ),
    (
        "Net & Feel",
        ("volley", "net presence", "ball feeling", "smash"),
        "net conversion and touch",
        "Choose this when you want to finish points at the net or turn short balls into easy points.",
        "The trade-off is less benefit if your matches stay deep behind the baseline.",
    ),
    (
        "Movement",
        ("speed", "stamina", "muscle tone", "counter"),
        "court coverage and recovery",
        "Choose this when you expect long points, wide movement, and repeated defensive recoveries.",
        "The trade-off is less direct point-ending ability when you have to create all the pace yourself.",
    ),
    (
        "Variety",
        ("slice", "early ball", "lob", "dropshot", "topspin"),
        "variation and disruption",
        "Choose this when you want to change height, speed, and timing to disrupt a predictable opponent.",
        "The trade-off is that variety is matchup-dependent and may not matter against a player who dictates every rally.",
    ),
)
PLAYER_GROUP_CHARACTER_WEIGHTS = {
    "serve": {"Serve": 0.70, "Power": 0.15, "Precision": 0.15},
    "return": {
        "Movement": 0.30,
        "Consistency": 0.25,
        "Precision": 0.25,
        "Variety": 0.20,
    },
    "rally": {
        "Consistency": 0.30,
        "Power": 0.20,
        "Precision": 0.20,
        "Movement": 0.15,
        "Variety": 0.15,
    },
}

CHARACTER_NAME_ALIASES = {
    "clay mover old": "Clay Mover",
}
ATTRIBUTE_NAME_ALIASES = {
    "clay mover old": "Clay Mover",
}

COMBINED_SKILL_COMPONENTS = {
    "Serve Rating": (
        "Service Power",
        "Service Consistency",
        "Service Precision",
    ),
    "Forehand Rating": (
        "Forehand Power",
        "Forehand Consistency",
        "Forehand Precision",
    ),
    "Backhand Rating": (
        "Backhand Power",
        "Backhand Consistency",
        "Backhand Precision",
    ),
}
SERVICE_SPEED_TABLES_KMH = {
    "ATP": ((0, 102), (25, 128), (50, 153), (75, 179), (100, 204)),
    "WTA": ((0, 92), (25, 112), (50, 133), (75, 153), (100, 173)),
}

_WORKBOOK_CACHE: tuple[int, list[dict[str, Any]]] | None = None
_ROSTER_VECTOR_CACHE: dict[tuple[int, str], list[dict[str, Any]]] = {}
_SIMULATION_CACHE: dict[
    tuple[str, ...],
    dict[str, dict[str, Any]],
] = {}
_AVATAR_CACHE: dict[str, tuple[float, dict[str, str | None]]] = {}
_AVATAR_CACHE_TTL = 60 * 60 * 12
_DIRECTORY_CACHE: dict[str, tuple[float, BeautifulSoup]] = {}
_DIRECTORY_CACHE_TTL = 60 * 60
_CACHE_LOCK = asyncio.Lock()


def _safe_http_url(value: Any) -> str | None:
    url = str(value or "").strip()
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None
    return url


def _workbook_path() -> Path:
    configured = os.getenv("CHARACTER_STATS_WORKBOOK")
    if configured:
        return Path(configured)
    root = Path(__file__).resolve().parent
    canonical = root / "attached_assets" / CANONICAL_WORKBOOK_NAME
    if canonical.exists():
        return canonical
    exact = root / "attached_assets" / WORKBOOK_NAME
    if exact.exists():
        return exact
    candidates = sorted(
        (root / "attached_assets").glob("WTSL_Stats_*.xlsx"),
        key=lambda path: path.stat().st_mtime_ns,
        reverse=True,
    )
    if candidates:
        return candidates[0]
    return exact


def canonical_workbook_path() -> Path:
    return Path(__file__).resolve().parent / "attached_assets" / CANONICAL_WORKBOOK_NAME


def current_workbook_path() -> Path:
    return _workbook_path()


def reset_roster_cache() -> None:
    global _WORKBOOK_CACHE
    _WORKBOOK_CACHE = None
    _ROSTER_VECTOR_CACHE.clear()
    _SIMULATION_CACHE.clear()


def _validate_workbook(path: Path) -> dict[str, int]:
    workbook = load_workbook(path, read_only=True, data_only=True)
    worksheet = workbook.active
    headers = [
        str(value).strip() if value is not None else ""
        for value in next(worksheet.iter_rows(values_only=True))
    ][:MAX_ATTRIBUTE_COLUMN]
    if tuple(headers) != EXPECTED_ATTRIBUTE_HEADERS:
        missing = [
            header for header in EXPECTED_ATTRIBUTE_HEADERS
            if header not in headers
        ]
        detail = (
            " Missing: " + ", ".join(missing)
            if missing else " The A–AQ columns are not in the expected order."
        )
        raise ValueError(
            "The workbook must contain the complete character schema from "
            f"A through AQ.{detail}"
        )
    row_count = 0
    canonical_names = set()
    for row_number, values in enumerate(
        worksheet.iter_rows(min_row=2, values_only=True),
        start=2,
    ):
        values = values[:MAX_ATTRIBUTE_COLUMN]
        if not any(value not in (None, "") for value in values):
            continue
        name = _canonical_name(values[0] if values else None)
        if not name:
            raise ValueError(f"Row {row_number} has no character name.")
        if values[1] not in (0, 1):
            raise ValueError(
                f"Row {row_number} has an invalid sex value; expected 0 or 1."
            )
        style = _numeric(values[8])
        if style not in PLAYER_STYLE_LABELS:
            raise ValueError(
                f"Row {row_number} has an invalid player style; expected 0–8."
            )
        acceleration = str(values[9] or "None")
        if acceleration not in ACCELERATION_MECHANICS:
            raise ValueError(
                f"Row {row_number} has an unknown acceleration trait: "
                f"{acceleration}."
            )
        canonical_names.add(_key(name))
        row_count += 1
    if row_count == 0:
        raise ValueError("The workbook contains no character rows.")
    if not canonical_names:
        raise ValueError("The workbook contains no usable character names.")
    return {
        "rows": row_count,
        "characters": len(canonical_names),
        "columns": len(headers),
    }


def install_workbook(data: bytes) -> dict[str, int | str]:
    """Validate and atomically install a future workbook upload."""
    if not data:
        raise ValueError("The uploaded workbook is empty.")
    path = canonical_workbook_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        prefix=".character-stats-",
        suffix=".xlsx",
        dir=path.parent,
        delete=False,
    ) as temporary:
        temporary.write(data)
        temporary_path = Path(temporary.name)
    try:
        summary = _validate_workbook(temporary_path)
        os.replace(temporary_path, path)
    except Exception:
        temporary_path.unlink(missing_ok=True)
        raise
    reset_roster_cache()
    return {
        "filename": CANONICAL_WORKBOOK_NAME,
        **summary,
    }


def _canonical_name(value: Any) -> str:
    name = str(value or "").strip()
    name = re.sub(r"\s+v\d+\s*$", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\s+", " ", name).strip()
    return CHARACTER_NAME_ALIASES.get(name.casefold(), name)


def _attribute_name(value: Any) -> str:
    name = str(value or "").strip()
    return ATTRIBUTE_NAME_ALIASES.get(name.casefold(), name)


def _key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").casefold()).strip()


def _player_key(value: Any) -> str:
    """Match result-feed initials to full player names.

    WTSL commonly emits ``J. Sinner`` while other sources use
    ``Jannik Sinner``.  First-initial plus surname keeps those as one picker
    without relying on the character workbook's unrelated names.
    """
    parts = _key(value).split()
    if len(parts) < 2:
        return " ".join(parts)
    return f"{parts[0][0]} {parts[-1]}"


def _character_key(value: Any) -> str:
    """Match abbreviated result characters to full workbook names."""
    return _player_key(value)


def _numeric(value: Any) -> float | int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return value
    try:
        number = float(str(value).strip())
    except (TypeError, ValueError):
        return None
    return int(number) if number.is_integer() else number


def _load_rows() -> list[dict[str, Any]]:
    global _WORKBOOK_CACHE
    path = _workbook_path()
    stamp = path.stat().st_mtime_ns
    if _WORKBOOK_CACHE and _WORKBOOK_CACHE[0] == stamp:
        return _WORKBOOK_CACHE[1]
    workbook = load_workbook(path, read_only=True, data_only=True)
    worksheet = workbook.active
    headers = [
        _attribute_name(value)
        for value in next(worksheet.iter_rows(values_only=True))
    ][:MAX_ATTRIBUTE_COLUMN]
    groups: dict[str, list[dict[str, Any]]] = {}
    for values in worksheet.iter_rows(min_row=2, values_only=True):
        row = dict(zip(headers, values[:MAX_ATTRIBUTE_COLUMN]))
        canonical = _canonical_name(row.get("name clean") or row.get("name"))
        if not canonical:
            continue
        row["_canonical"] = canonical
        groups.setdefault(_key(canonical), []).append(row)

    rows: list[dict[str, Any]] = []
    for candidates in groups.values():
        selected = min(
            candidates,
            key=lambda row: (
                bool(re.search(r"\s+v\d+\s*$", str(row.get("name") or ""), re.I)),
                str(row.get("name") or "").casefold(),
            ),
        )
        rows.append(selected)
    rows.sort(key=lambda row: str(row["_canonical"]).casefold())
    _WORKBOOK_CACHE = (stamp, rows)
    return rows


def load_roster(tour: str = "all") -> list[dict[str, Any]]:
    """Return one canonical row per character, optionally filtered by tour."""
    wanted = str(tour or "all").casefold()
    rows = _load_rows()
    if wanted not in {"atp", "wta"}:
        return list(rows)
    sex = 0 if wanted == "atp" else 1
    return [row for row in rows if row.get("Sex (0: male; 1: female)") == sex]


def character_names(tour: str = "all") -> list[str]:
    return [str(row["_canonical"]) for row in load_roster(tour)]


def attribute_names() -> list[str]:
    rows = _load_rows()
    if not rows:
        return []
    excluded = {
        "name",
        "name clean",
        "Sex (0: male; 1: female)",
        "Country",
        "Playing Hand (0 or 1: right; -1: left)",
        "Double handed backhand (0: one-handed; 1: double-handed)",
        "Double handed forehand (0: one-handed; 1: double-handed)",
        "Player Style (0: Defender; 1: Power Baseliner; 2: Puncher; "
        "3: All-Court Attacker; 4: Volleyer; 5: Counter; "
        "6: Counter-Puncher; 7: All-Rounder; 8: Bulldog)",
        "Acceleration Trait",
    }
    attributes: list[str] = []
    for header in rows[0]:
        if header.startswith("_") or header in excluded:
            continue
        if any(_numeric(row.get(header)) is not None for row in rows):
            attributes.append(header)
    return attributes


def resolve_character(value: str, tour: str = "all") -> dict[str, Any] | None:
    wanted = _key(_canonical_name(value))
    rows = load_roster(tour)
    exact = [row for row in rows if _key(row["_canonical"]) == wanted]
    if exact:
        return exact[0]
    partial = [
        row for row in rows
        if wanted and wanted in _key(row["_canonical"])
    ]
    return partial[0] if len(partial) == 1 else None


def resolve_attribute(value: str) -> str | None:
    wanted = _key(value)
    names = attribute_names()
    exact = [name for name in names if _key(name) == wanted]
    if exact:
        return exact[0]
    partial = [name for name in names if wanted and wanted in _key(name)]
    return partial[0] if len(partial) == 1 else None


def _attribute_values(
    attribute: str,
    tour: str,
) -> list[tuple[dict[str, Any], float | int]]:
    values = []
    for row in load_roster(tour):
        value = _numeric(row.get(attribute))
        if value is not None:
            values.append((row, value))
    return values


def _rank_and_percentile(
    values: list[tuple[dict[str, Any], float | int]],
    value: float | int,
) -> tuple[int | None, float]:
    ordered = sorted(float(item[1]) for item in values)
    if not ordered or ordered[0] == ordered[-1]:
        return None, 0.5
    rank = 1 + sum(candidate > float(value) for candidate in ordered)
    return rank, (len(ordered) - rank) / (len(ordered) - 1)


def _clamp_percentage(value: float) -> float:
    return max(0.0, min(100.0, float(value)))


def calculate_max_serve_speed(
    power: float | int,
    sex: str | int,
) -> float:
    """Interpolate the documented sex-specific maximum serve-speed table."""
    tour = "WTA" if str(sex).casefold() in {"wta", "1", "female"} else "ATP"
    points = SERVICE_SPEED_TABLES_KMH[tour]
    power_value = _clamp_percentage(float(power))
    for (left_power, left_speed), (right_power, right_speed) in zip(
        points,
        points[1:],
    ):
        if power_value <= right_power:
            fraction = (power_value - left_power) / (right_power - left_power)
            return round(
                left_speed + fraction * (right_speed - left_speed),
                1,
            )
    return float(points[-1][1])


def calculate_combined_skill_rating(
    power: float | int,
    consistency: float | int,
    precision: float | int,
    *,
    service: bool = False,
) -> dict[str, float]:
    """Calculate a transparent 0–100 rating for one technical skill.

    Power mainly changes the maximum speed ceiling. Consistency and precision
    have more influence on whether a serve or groundstroke is repeatable,
    controllable, and useful under pressure. Power still contributes, and the
    precision effect retains a reduced version of the documented relationship
    between power and precision.
    """
    power_value = _clamp_percentage(float(power))
    consistency_value = _clamp_percentage(float(consistency))
    precision_value = _clamp_percentage(float(precision))
    precision_effect = max(
        0.0,
        min(135.0, 100.0 + (precision_value - power_value) * 0.35),
    )
    base_rating = (
        consistency_value * 0.55
        + precision_value * 0.30
        + power_value * 0.15
    )
    rating = _clamp_percentage(
        base_rating * precision_effect / 100.0
    )
    return {
        "value": round(rating, 1),
        "power": round(power_value, 1),
        "consistency": round(consistency_value, 1),
        "precision": round(precision_value, 1),
        "precision_effect": round(precision_effect, 1),
        "precision_balance": round(precision_value - power_value, 1),
        "consistency_balance": round(consistency_value - power_value, 1),
    }


SIMULATION_SURFACES = (
    ("fast", 0.30),
    ("normal", 0.40),
    ("slow", 0.30),
)


def country_flag(country: Any) -> str:
    """Return an emoji flag for the workbook's ISO-3166 alpha-2 code."""
    code = str(country or "").strip().upper()
    if len(code) != 2 or not code.isalpha():
        return "🏳️"
    return "".join(chr(0x1F1E6 + ord(letter) - ord("A")) for letter in code)


def _simulation_value(row: dict[str, Any], attribute: str, default: float = 50.0) -> float:
    value = _numeric(row.get(attribute))
    return _clamp_percentage(default if value is None else float(value))


def _surface_topspin_adjustment(row: dict[str, Any], surface: str) -> float:
    topspin = _simulation_value(row, "Topspin")
    if surface == "slow":
        return (topspin - 50.0) * 0.10
    if surface == "fast":
        return (50.0 - topspin) * 0.08
    return 0.0


def _serve_pressure(row: dict[str, Any]) -> float:
    return (
        _simulation_value(row, "Service Power") * 0.20
        + _simulation_value(row, "Service Consistency") * 0.45
        + _simulation_value(row, "Service Precision") * 0.35
    )


def _return_pressure(row: dict[str, Any]) -> float:
    ground_consistency = (
        _simulation_value(row, "Forehand Consistency")
        + _simulation_value(row, "Backhand Consistency")
    ) / 2
    ground_precision = (
        _simulation_value(row, "Forehand Precision")
        + _simulation_value(row, "Backhand Precision")
    ) / 2
    return (
        ground_consistency * 0.25
        + ground_precision * 0.18
        + _simulation_value(row, "Counter") * 0.16
        + _simulation_value(row, "Early Ball") * 0.11
        + _simulation_value(row, "Speed") * 0.12
        + _simulation_value(row, "Muscle Tone") * 0.09
        + _simulation_value(row, "Focus") * 0.09
    )


def _shot_matchup(
    attacker: dict[str, Any],
    defender: dict[str, Any],
    wing: str,
    surface: str,
) -> dict[str, float]:
    prefix = "Forehand" if wing == "forehand" else "Backhand"
    opponent_prefix = "Backhand" if wing == "forehand" else "Forehand"
    power = _simulation_value(attacker, f"{prefix} Power")
    consistency = _simulation_value(attacker, f"{prefix} Consistency")
    precision = _simulation_value(attacker, f"{prefix} Precision")
    focus = _simulation_value(attacker, "Focus")
    early_ball = _simulation_value(attacker, "Early Ball")
    quality = (
        power * 0.18
        + consistency * 0.42
        + precision * 0.30
        + focus * 0.10
        + _surface_topspin_adjustment(attacker, surface)
    )
    defence = (
        _simulation_value(defender, f"{opponent_prefix} Consistency") * 0.36
        + _simulation_value(defender, "Speed") * 0.20
        + _simulation_value(defender, "Muscle Tone") * 0.12
        + _simulation_value(defender, "Counter") * 0.14
        + _simulation_value(defender, "Focus") * 0.10
        + _simulation_value(defender, "Stamina") * 0.08
    )
    edge = quality - defence
    shot_score = _clamp_percentage(quality + edge * 0.16)
    winners = max(
        1.0,
        min(
            35.0,
            6.0
            + (shot_score - 50.0) * 0.105
            + max(0.0, edge) * 0.10
            + (power - 50.0) * 0.020
            + (early_ball - 50.0) * 0.008,
        ),
    )
    errors = max(
        1.5,
        min(
            30.0,
            5.0
            + max(0.0, 50.0 - consistency) * 0.07
            + max(0.0, -edge) * 0.06
            + max(0.0, power - precision) * 0.015
            + max(0.0, 50.0 - focus) * 0.02,
        ),
    )
    return {
        "score": shot_score,
        "winners": winners,
        "errors": errors,
        "edge": edge,
    }


def _simulate_matchup(
    first: dict[str, Any],
    second: dict[str, Any],
    surface: str,
) -> dict[str, float]:
    """Project an expected matchup from the attributes, not the hidden game code.

    This is deliberately an expected-value model rather than a random Monte Carlo
    run. It lets ratings be repeatable while still reflecting interactions between
    the two characters: who serves, who returns, which wing is targeted, and
    whether rallies finish quickly or continue under pressure.
    """
    first_serve = _clamp_percentage(
        57.0 + (_serve_pressure(first) - _return_pressure(second)) * 0.20
        + _surface_topspin_adjustment(first, surface) * 0.08,
    )
    second_serve = _clamp_percentage(
        57.0 + (_serve_pressure(second) - _return_pressure(first)) * 0.20
        + _surface_topspin_adjustment(second, surface) * 0.08,
    )
    first_return = 100.0 - second_serve
    second_return = 100.0 - first_serve
    first_forehand = _shot_matchup(first, second, "forehand", surface)
    first_backhand = _shot_matchup(first, second, "backhand", surface)
    second_forehand = _shot_matchup(second, first, "forehand", surface)
    second_backhand = _shot_matchup(second, first, "backhand", surface)
    first_rally_score = (first_forehand["score"] + first_backhand["score"]) / 2
    second_rally_score = (second_forehand["score"] + second_backhand["score"]) / 2
    first_point_edge = (
        (first_serve - second_serve) * 0.018
        + (first_return - second_return) * 0.018
        + (first_rally_score - second_rally_score) * 0.014
    )
    first_match_win = 1.0 / (1.0 + math.exp(-first_point_edge))
    first_consistency = (
        _simulation_value(first, "Forehand Consistency")
        + _simulation_value(first, "Backhand Consistency")
    ) / 2
    second_consistency = (
        _simulation_value(second, "Forehand Consistency")
        + _simulation_value(second, "Backhand Consistency")
    ) / 2
    rally_length = max(
        2.0,
        min(
            14.0,
            2.0
            + (first_consistency + second_consistency) * 0.035
            + (
                _simulation_value(first, "Stamina")
                + _simulation_value(second, "Stamina")
            ) * 0.012
            + (
                _simulation_value(first, "Topspin")
                + _simulation_value(second, "Topspin")
            ) * 0.006
            - abs(first_rally_score - second_rally_score) * 0.025,
        ),
    )
    first_winners = (
        first_forehand["winners"] + first_backhand["winners"]
    ) / 2 + max(0.0, first_serve - 50.0) * 0.06
    first_errors = (first_forehand["errors"] + first_backhand["errors"]) / 2
    second_winners = (
        second_forehand["winners"] + second_backhand["winners"]
    ) / 2 + max(0.0, second_serve - 50.0) * 0.06
    second_errors = (second_forehand["errors"] + second_backhand["errors"]) / 2
    return {
        "first_match_win_pct": first_match_win * 100.0,
        "second_match_win_pct": (1.0 - first_match_win) * 100.0,
        "first_serve_points_won_pct": first_serve,
        "second_serve_points_won_pct": second_serve,
        "first_return_points_won_pct": first_return,
        "second_return_points_won_pct": second_return,
        "first_forehand_score": first_forehand["score"],
        "first_backhand_score": first_backhand["score"],
        "second_forehand_score": second_forehand["score"],
        "second_backhand_score": second_backhand["score"],
        "first_forehand_winners": first_forehand["winners"],
        "first_backhand_winners": first_backhand["winners"],
        "first_forehand_errors": first_forehand["errors"],
        "first_backhand_errors": first_backhand["errors"],
        "first_winners_per_100": first_winners,
        "second_winners_per_100": second_winners,
        "first_unforced_errors_per_100": first_errors,
        "second_unforced_errors_per_100": second_errors,
        "average_rally_length": rally_length,
    }


def _simulated_roster_profiles(
    roster: list[dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    cache_key = (
        str(_workbook_path().stat().st_mtime_ns),
        *(str(row["_canonical"]) for row in roster),
    )
    cached = _SIMULATION_CACHE.get(cache_key)
    if cached is not None:
        return cached
    profiles: dict[str, dict[str, Any]] = {}
    for candidate in roster:
        name = str(candidate["_canonical"])
        totals: dict[str, float] = {}
        weight_total = 0.0
        for opponent in roster:
            if opponent is candidate:
                continue
            for surface, weight in SIMULATION_SURFACES:
                result = _simulate_matchup(candidate, opponent, surface)
                weight_total += weight
                for key, value in result.items():
                    if key.startswith("first_") or key == "average_rally_length":
                        totals[key] = totals.get(key, 0.0) + value * weight
        averages = {
            key: value / weight_total
            for key, value in totals.items()
        } if weight_total else {}
        forehand_quality = (
            _simulation_value(candidate, "Forehand Power") * 0.15
            + _simulation_value(candidate, "Forehand Consistency") * 0.45
            + _simulation_value(candidate, "Forehand Precision") * 0.30
            + _simulation_value(candidate, "Focus") * 0.10
        )
        backhand_quality = (
            _simulation_value(candidate, "Backhand Power") * 0.15
            + _simulation_value(candidate, "Backhand Consistency") * 0.45
            + _simulation_value(candidate, "Backhand Precision") * 0.30
            + _simulation_value(candidate, "Focus") * 0.10
        )
        serve_simulation_rating = _clamp_percentage(
            50.0
            + (averages.get("first_serve_points_won_pct", 50.0) - 50.0)
            * 3.0,
        )
        profiles[name] = {
            "serve": _clamp_percentage(
                serve_simulation_rating * 0.50
                + _serve_pressure(candidate) * 0.50,
            ),
            "forehand": _clamp_percentage(
                averages.get("first_forehand_score", 50.0) * 0.70
                + forehand_quality * 0.30,
            ),
            "backhand": _clamp_percentage(
                averages.get("first_backhand_score", 50.0) * 0.70
                + backhand_quality * 0.30,
            ),
            "simulation": {
                "match_win_pct": averages.get("first_match_win_pct", 50.0),
                "serve_points_won_pct": averages.get(
                    "first_serve_points_won_pct", 50.0,
                ),
                "return_points_won_pct": averages.get(
                    "first_return_points_won_pct", 50.0,
                ),
                "winners_per_100": averages.get("first_winners_per_100", 0.0),
                "unforced_errors_per_100": averages.get(
                    "first_unforced_errors_per_100", 0.0,
                ),
                "average_rally_length": averages.get(
                    "average_rally_length", 0.0,
                ),
                "forehand_winners_per_100": averages.get(
                    "first_forehand_winners", 0.0,
                ),
                "backhand_winners_per_100": averages.get(
                    "first_backhand_winners", 0.0,
                ),
                "forehand_unforced_errors_per_100": averages.get(
                    "first_forehand_errors", 0.0,
                ),
                "backhand_unforced_errors_per_100": averages.get(
                    "first_backhand_errors", 0.0,
                ),
            },
        }
    _SIMULATION_CACHE[cache_key] = profiles
    return profiles


def _combined_skill_value(
    row: dict[str, Any],
    components: tuple[str, str, str],
    *,
    service: bool = False,
) -> dict[str, float] | None:
    values = [_numeric(row.get(attribute)) for attribute in components]
    if any(value is None for value in values):
        return None
    return calculate_combined_skill_rating(
        values[0],
        values[1],
        values[2],
        service=service,
    )


def _combined_skill_profiles(
    row: dict[str, Any],
    roster: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Return ratings derived from repeatable expected matches across the roster."""
    simulated = _simulated_roster_profiles(roster)
    current_simulation = simulated.get(str(row["_canonical"]), {})
    simulated_values = {
        "Serve Rating": current_simulation.get("serve", 50.0),
        "Forehand Rating": current_simulation.get("forehand", 50.0),
        "Backhand Rating": current_simulation.get("backhand", 50.0),
    }
    profiles: list[dict[str, Any]] = []
    for label, components in COMBINED_SKILL_COMPONENTS.items():
        service = label == "Serve Rating"
        raw_current = _combined_skill_value(row, components, service=service)
        values = [
            (candidate, simulated.get(str(candidate["_canonical"]), {}).get(
                "serve" if service else (
                    "forehand" if label == "Forehand Rating" else "backhand"
                ),
                50.0,
            ))
            for candidate in roster
        ]
        if raw_current is None or not values:
            continue
        simulation_value = simulated_values[label]
        rank, percentile = _rank_and_percentile(values, simulation_value)
        profiles.append({
            "attribute": label,
            "value": round(simulation_value, 1),
            "rank": rank,
            "count": len(values),
            "percentile": percentile,
            "bar": _bar(percentile),
            "components": {
                "Power": raw_current["power"],
                "Consistency": raw_current["consistency"],
                "Precision": raw_current["precision"],
                "Precision effect": raw_current["precision_effect"],
            },
            "precision_balance": raw_current["precision_balance"],
            "consistency_balance": raw_current["consistency_balance"],
            "simulation": current_simulation.get("simulation", {}),
        })
        if service:
            profiles[-1]["max_serve_speed_kmh"] = calculate_max_serve_speed(
                raw_current["power"],
                row.get("Sex (0: male; 1: female)"),
            )
    return profiles


def attribute_ranking(
    attribute: str,
    tour: str = "all",
) -> dict[str, Any]:
    values = _attribute_values(attribute, tour)
    ranked = sorted(
        values,
        key=lambda item: (-float(item[1]), str(item[0]["_canonical"]).casefold()),
    )
    minimum = min(float(value) for _, value in values)
    maximum = max(float(value) for _, value in values)
    ranked_rows = []
    previous_value = None
    previous_rank = 0
    for position, (row, value) in enumerate(ranked, 1):
        numeric_value = float(value)
        if previous_value is None or numeric_value != previous_value:
            previous_rank = position
            previous_value = numeric_value
        ranked_rows.append({
            "character": row["_canonical"],
            "value": value,
            "rank": previous_rank,
        })
    return {
        "attribute": attribute,
        "tour": tour,
        "count": len(values),
        "minimum": minimum,
        "maximum": maximum,
        "ranked": ranked_rows,
    }


def _bar(percentile: float, width: int = 5) -> str:
    filled = max(0, min(width, round(percentile * width)))
    return "🟩" * filled + "⬜" * (width - filled)


def _attribute_group(attribute: str) -> str:
    lowered = _key(attribute)
    for group, tokens, _, _, _ in ATTRIBUTE_GROUP_RULES:
        if any(token in lowered for token in tokens):
            return group
    return "Overall"


def _style_label_from_row(row: dict[str, Any]) -> str:
    style = _numeric(row.get(
        "Player Style (0: Defender; 1: Power Baseliner; 2: Puncher; "
        "3: All-Court Attacker; 4: Volleyer; 5: Counter; "
        "6: Counter-Puncher; 7: All-Rounder; 8: Bulldog)"
    ))
    return PLAYER_STYLE_LABELS.get(style, "Unknown")


def _stat_by_attribute(
    stats: list[dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    return {
        str(stat["attribute"]): stat
        for stat in stats
        if stat.get("rank") is not None
    }


def _mechanics_insights(
    row: dict[str, Any],
    stats: list[dict[str, Any]],
    combined_ratings: list[dict[str, Any]],
) -> dict[str, Any]:
    """Turn documented interactions into character-specific tennis advice.

    The workbook contains the inputs, not a complete public game simulator.
    These explanations therefore describe directional advantages and trade-offs
    without pretending to reproduce hidden point-by-point calculations.
    """
    stat_map = _stat_by_attribute(stats)
    combined_map = {
        str(item["attribute"]): item
        for item in combined_ratings
        if item.get("rank") is not None
    }

    def value(attribute: str, default: float = 50.0) -> float:
        numeric = _numeric(row.get(attribute))
        return float(numeric) if numeric is not None else default

    def percentile(attribute: str, default: float = 0.5) -> float:
        item = stat_map.get(attribute)
        return float(item["percentile"]) if item else default

    def combined(attribute: str, default: float = 50.0) -> float:
        item = combined_map.get(attribute)
        return float(item["value"]) if item else default

    service_power = value("Service Power")
    service_consistency = value("Service Consistency")
    service_precision = value("Service Precision")
    service_speed = (
        float(combined_map["Serve Rating"].get("max_serve_speed_kmh") or 0)
        if "Serve Rating" in combined_map else 0
    )
    service_precision_gap = service_precision - service_power
    service_consistency_gap = service_consistency - service_power
    if service_power >= service_consistency + 12:
        serve = (
            f"The serve has a {service_speed:.1f} km/h ceiling and can create free "
            "points, but its power-heavy balance makes Strong serves riskier: the "
            "success and aiming penalties make the second serve the pressure point. "
            "Use the extra pace selectively and build a first-ball plan behind it."
        )
        serve_mode = "power with second-serve risk"
    elif service_consistency >= service_power + 12:
        serve = (
            f"The serve is reliable but its {service_speed:.1f} km/h ceiling gives "
            "less free-point pressure. Consistency supports safer second serves, so "
            "use placement and the first groundstroke rather than chasing maximum "
            "pace."
        )
        serve_mode = "reliable placement serve"
    else:
        precision_note = (
            " Precision is ahead of power, so placement makes the pace more usable."
            if service_precision_gap >= 8
            else (
                " Precision trails power, so maximum pace gives back some placement "
                "margin."
                if service_precision_gap <= -8 else ""
            )
        )
        serve = (
            f"The serve balances a {service_speed:.1f} km/h ceiling with power and "
            "consistency close enough to support both aggressive and safer patterns."
            f"{precision_note} Use the serve to start the point on your terms: "
            "change the target between the body, wide, and the backhand, then play "
            "the first groundstroke into the space the return creates."
        )
        serve_mode = "balanced serve"

    forehand = combined("Forehand Rating")
    backhand = combined("Backhand Rating")
    forehand_power = value("Forehand Power")
    backhand_power = value("Backhand Power")
    forehand_consistency = value("Forehand Consistency")
    backhand_consistency = value("Backhand Consistency")
    if forehand >= backhand + 5:
        groundstrokes = (
            f"Forehand is the clearer pressure wing ({forehand:.1f} combined vs "
            f"{backhand:.1f} backhand): create forehands from the middle, use "
            "cross-court depth to move the opponent, then change direction once "
            "the reply is short. The backhand should absorb and redirect rather "
            "than carry every first-strike exchange."
        )
        groundstroke_edge = "forehand"
    elif backhand >= forehand + 5:
        groundstrokes = (
            f"Backhand is the steadier pressure wing ({backhand:.1f} combined vs "
            f"{forehand:.1f} forehand): hold that corner against targeting, "
            "redirect pace when balanced, and use the cross-court ball to open "
            "the forehand or the net. Avoid forcing forehand winners from poor "
            "court position."
        )
        groundstroke_edge = "backhand"
    else:
        groundstrokes = (
            f"Forehand and backhand are close ({forehand:.1f} vs {backhand:.1f}), "
            "so the point is built through movement and target selection rather "
            "than hiding one wing. Use the more consistent side to absorb pace, "
            "then change direction from a balanced position."
        )
        groundstroke_edge = "balanced"

    topspin = value("Topspin")
    if topspin >= 60:
        surface_fit = (
            f"Topspin at {topspin:.0f}% fits clay and slow courts: it adds rally "
            "margin and heavier shape. On fast courts it costs strike speed and "
            "fatigue, so shorten the swing and attack earlier instead of relying "
            "on endless heavy exchanges."
        )
        surface_mode = "slow-court topspin"
    elif topspin <= 40:
        surface_fit = (
            f"Topspin at {topspin:.0f}% fits fast courts: flatter strikes retain "
            "speed and take time away. On clay or slow courts the lower spin gives "
            "less net margin and defensive height, so use bigger targets and "
            "avoid making every ball a low-percentage finish."
        )
        surface_mode = "fast-court pace"
    else:
        surface_fit = (
            f"Topspin at {topspin:.0f}% is close to the 50% neutral point, so the "
            "character can move between surfaces without a major built-in spin "
            "trade-off. Raise margin on slow courts and flatten selectively on "
            "fast courts."
        )
        surface_mode = "surface-flexible"

    counter = value("Counter")
    if counter >= 65:
        counter_insight = (
            f"Counter at {counter:.0f}% is valuable when opponents supply pace: "
            "normal or topspin strikes can borrow up to 7.5 km/h and the fast-ball "
            "constraint is reduced. It is less automatic against slow floaters, "
            "so step in and create pace rather than waiting passively."
        )
        counter_mode = "pace-dependent counter"
    elif counter <= 35:
        counter_insight = (
            f"Counter at {counter:.0f}% is not a reliable identity: against fast "
            "incoming balls, use consistency, height, or a prepared wing instead "
            "of expecting borrowed pace. The character is better when it creates "
            "the rally speed itself."
        )
        counter_mode = "self-created pace"
    else:
        counter_insight = (
            f"Counter at {counter:.0f}% gives situational value against incoming "
            "pace, but it is not a complete plan against slow balls. Mix early "
            "redirection with a deliberate first strike when the opponent's ball "
            "does not supply enough speed."
        )
        counter_mode = "situational counter"

    net_presence = value("Net Presence")
    volley_average = (
        value("Forehand Volley") + value("Backhand Volley")
    ) / 2
    smash = value("Smash")
    net_base = (volley_average + smash) / 2
    if net_presence >= 65 and net_base >= 65:
        net_insight = (
            f"Net Presence at {net_presence:.0f}% complements the {volley_average:.0f}% "
            f"average volley and {smash:.0f}% smash: approach behind a short or "
            "forced reply, close diagonally, and trust movement plus placement to "
            "finish instead of staying in baseline exchanges."
        )
        net_mode = "supported net finisher"
    elif net_presence >= 65:
        net_insight = (
            f"Net Presence at {net_presence:.0f}% provides movement and net "
            f"precision, but the {volley_average:.0f}% volley average and "
            f"{smash:.0f}% smash do not fully support it. Move forward selectively "
            "behind a high-quality approach rather than treating presence alone "
            "as finishing power."
        )
        net_mode = "net access without full finish"
    elif net_base >= 65:
        net_insight = (
            f"Volley and smash skill is available ({net_base:.0f}% combined net "
            f"base), but Net Presence at {net_presence:.0f}% limits the movement "
            "and consistency support. The best net points start from a strong "
            "approach with time to set, not emergency rushing."
        )
        net_mode = "powerful but selective net play"
    else:
        net_insight = (
            f"Net Presence at {net_presence:.0f}% and the {net_base:.0f}% volley/"
            "smash base do not make frequent net exchanges the safest default. "
            "Use the net as a finish after a short ball, not as the primary point "
            "construction."
        )
        net_mode = "baseline-first"

    lob = value("Lob")
    dropshot = value("Dropshot")
    if max(lob, dropshot) >= 65:
        variation = (
            f"Lob ({lob:.0f}%) and drop shot ({dropshot:.0f}%) add a real change-up: "
            "use them after establishing depth or when the opponent closes space, "
            "remembering that the selected forehand/backhand still helps determine "
            "control against a fast incoming ball."
        )
    else:
        variation = (
            f"Lob ({lob:.0f}%) and drop shot ({dropshot:.0f}%) are supporting tools "
            "rather than the main identity; establish depth first and use variation "
            "only when court position makes the risk worthwhile."
        )

    simulation = {}
    for item in combined_ratings:
        simulation.update(item.get("simulation") or {})
    match_play = (
        f"Across simulated matches against the {len(combined_ratings) and 'roster'} "
        f"on mixed surfaces, the character projects "
        f"{simulation.get('winners_per_100', 0.0):.1f} winners and "
        f"{simulation.get('unforced_errors_per_100', 0.0):.1f} unforced errors "
        f"per 100 points, with {simulation.get('average_rally_length', 0.0):.1f} "
        f"shots per rally and {simulation.get('return_points_won_pct', 0.0):.1f}% "
        "return points won."
    )
    if simulation.get("winners_per_100", 0.0) >= simulation.get(
        "unforced_errors_per_100", 0.0
    ) + 5:
        match_mode = "winner-led pressure"
    elif simulation.get("unforced_errors_per_100", 0.0) >= simulation.get(
        "winners_per_100", 0.0
    ) - 2:
        match_mode = "error-controlled pressure"
    else:
        match_mode = "balanced point pressure"

    advantages = [
        serve,
        groundstrokes,
        surface_fit,
        counter_insight,
        net_insight,
    ]
    vulnerabilities = [
        (
            "The power-heavy serve balance makes Strong-serve success and the "
            "second-serve recovery more fragile."
            if service_power >= service_consistency + 12
            else (
                "The lower serve ceiling means the first ball must do more work "
                "after a reliable delivery."
                if service_consistency >= service_power + 12
                else "The serve is balanced, so it creates more value through the "
                "first-ball pattern than through a single maximum-pace weapon."
            )
        ),
        (
            "The weaker groundstroke wing can be isolated with height and repeated "
            "direction changes."
            if groundstroke_edge != "balanced"
            else "Neither wing is a clear shortcut, so rushed direction changes "
            "remain the main risk."
        ),
        (
            "Fast courts tax high topspin with lower strike speed and more fatigue."
            if topspin >= 60
            else (
                "Slow courts expose lower topspin to reduced margin and defensive "
                "height."
                if topspin <= 40
                else "Surface changes require deliberate spin selection rather than "
                "one default trajectory."
            )
        ),
        (
            "Counter cannot replace creating pace against slow incoming balls."
            if counter >= 65
            else "Fast incoming pace is harder to redirect without relying on Counter."
        ),
        (
            "Net Presence does not add raw power, so a weak volley or smash base "
            "still limits emergency finishing."
            if net_presence >= 65 and net_base < 65
            else (
                "Strong volley or smash numbers need a quality approach because "
                "Net Presence does not fully support movement and consistency."
                if net_base >= 65 and net_presence < 65
                else "The net is a finish condition, not the safest default pattern."
            )
        ),
    ]
    point_patterns = [
        (
            "Serve, use the first groundstroke to target the weaker wing, then "
            "move forward only after earning a short reply."
        ),
        (
            "On return, use the "
            + (
                "stronger " + groundstroke_edge
                if groundstroke_edge != "balanced"
                else "more balanced groundstroke pair"
            )
            + " to absorb pressure and change direction from a stable position."
        ),
    ]
    return {
        "serve": serve,
        "serve_mode": serve_mode,
        "groundstrokes": groundstrokes,
        "groundstroke_edge": groundstroke_edge,
        "surface_fit": surface_fit,
        "surface_mode": surface_mode,
        "counter": counter_insight,
        "counter_mode": counter_mode,
        "net": net_insight,
        "net_mode": net_mode,
        "variation": variation,
        "match_play": match_play,
        "match_mode": match_mode,
        "simulation": simulation,
        "advantages": advantages,
        "vulnerabilities": vulnerabilities,
        "point_patterns": point_patterns,
        "signals": {
            "serve_power": service_power,
            "serve_consistency": service_consistency,
            "serve_precision": service_precision,
            "serve_precision_gap": service_precision_gap,
            "serve_consistency_gap": service_consistency_gap,
            "max_serve_speed_kmh": service_speed,
            "forehand_rating": forehand,
            "backhand_rating": backhand,
            "forehand_power": forehand_power,
            "backhand_power": backhand_power,
            "forehand_consistency": forehand_consistency,
            "backhand_consistency": backhand_consistency,
            "topspin": topspin,
            "counter": counter,
            "net_presence": net_presence,
            "net_base": net_base,
            "lob": lob,
            "dropshot": dropshot,
            "match_win_pct": simulation.get("match_win_pct", 50.0),
            "serve_points_won_pct": simulation.get(
                "serve_points_won_pct", 50.0
            ),
            "return_points_won_pct": simulation.get(
                "return_points_won_pct", 50.0
            ),
            "winners_per_100": simulation.get("winners_per_100", 0.0),
            "unforced_errors_per_100": simulation.get(
                "unforced_errors_per_100", 0.0
            ),
            "average_rally_length": simulation.get(
                "average_rally_length", 0.0
            ),
        },
    }


def _selection_guidance(
    stats: list[dict[str, Any]],
    *,
    style: str = "Unknown",
    acceleration: str = "None",
    character: str = "",
    row: dict[str, Any] | None = None,
    combined_ratings: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    def attacking_pattern(stat: dict[str, Any]) -> str:
        attribute = str(stat["attribute"])
        lowered = attribute.casefold()
        if "service power" in lowered:
            return (
                "Use pace selectively to push the returner back or draw a shorter "
                "reply; follow the returner's recovery with the first groundstroke "
                "rather than trying to end the point with the serve."
            )
        if "service consistency" in lowered:
            return (
                "Use a repeatable target—body or backhand is usually safer than "
                "chasing the corner—then make the first groundstroke the attacking "
                "shot before the returner can step inside the baseline."
            )
        if "service precision" in lowered:
            return (
                "Move the returner with body, wide, and backhand targets, then "
                "attack the court they have left open instead of repeating the same "
                "serve direction."
            )
        if "volley" in lowered or "net presence" in lowered or "ball feeling" in lowered:
            if "ball feeling" in lowered:
                return (
                    "Use touch after moving the opponent back: a drop shot when they "
                    "are deep or a soft angle when they are pulled wide. Do not start "
                    "the point with a low-percentage touch shot from a neutral ball."
                )
            return (
                "Approach behind a deep ball through the middle or into the weaker "
                "wing, close diagonally, and finish with controlled placement."
            )
        if "forehand power" in lowered:
            return "Create forehands from the middle, drive into the weaker corner, and use the next forehand rather than forcing the first one."
        if "backhand power" in lowered:
            return "Hold the backhand baseline position, redirect pace down the line when balanced, and use cross-court shape when stretched."
        if "forehand consistency" in lowered:
            return "Use the forehand cross-court to keep depth, make the opponent defend another ball, and change direction only after the reply is short."
        if "backhand consistency" in lowered:
            return "Use the backhand cross-court to absorb pressure and keep the opponent deep, then redirect down the line when the court is open."
        if "forehand precision" in lowered:
            return "Use the forehand to move the opponent before going for the open court; direction changes are most valuable after you have created space."
        if "backhand precision" in lowered:
            return "Use the backhand to change direction deliberately, especially down the line when the opponent is leaning cross-court."
        if "precision" in lowered:
            return "Open the court with two measured direction changes before attempting the finishing angle."
        if "consistency" in lowered:
            return "Use repeatable cross-court depth to draw a short reply, then change direction only from a balanced position."
        if "speed" in lowered or "stamina" in lowered or "muscle tone" in lowered:
            return "Defend with height and depth, recover through the centre, and counter into space after making the opponent hit one extra ball."
        if "counter" in lowered:
            return "Stand close enough to borrow fast incoming pace, use normal or topspin strikes to redirect before recovery, and avoid relying on Counter alone against slow balls."
        if "early ball" in lowered:
            return "Stand close enough to borrow the opponent's pace, meet the ball early, and redirect before they recover."
        if "focus" in lowered:
            return (
                "Prepare early, take the ball in front of the body, and use that "
                "time to choose direction instead of reacting late."
            )
        if "topspin" in lowered:
            if style == "Defender":
                return "Use higher topspin on clay or slow courts to build a heavy, safe rally ball; reduce it on fast courts where the speed handicap matters."
            if style == "Volleyer":
                return "Keep topspin closer to or below neutral on fast courts so baseline shots do not lose speed before you move forward."
            return "Treat 50% topspin as neutral: raise it for clay and slow-court margin, lower it for fast-court speed, and account for the extra fatigue."
        if "clay mover" in lowered:
            return "Use heavy cross-court shape to push the opponent back, recover aggressively, and attack the shorter reply."
        if "slice" in lowered or "dropshot" in lowered or "lob" in lowered:
            return "Change trajectory after establishing baseline depth, using variation to alter court position rather than as a standalone trick shot."
        return f"Use {attribute} to create the first clear positional advantage, then finish through the open court."

    def protection_pattern(stat: dict[str, Any]) -> str:
        attribute = str(stat["attribute"])
        lowered = attribute.casefold()
        if "service consistency" in lowered:
            return (
                "If the opponent starts stepping in on the second serve, add margin "
                "and use the body or backhand target; be ready for the returner's "
                "first attack instead of giving away the middle."
            )
        if "service precision" in lowered:
            return (
                "Do not repeat a predictable serve location. Use the body and "
                "backhand with larger margins, then cover the returner's most likely "
                "direction with the first groundstroke."
            )
        if "service power" in lowered:
            return (
                "Do not rely on maximum pace to rescue a loose service game. Move "
                "the returner with location and spin, then win the point with the "
                "first two groundstrokes."
            )
        if "service" in lowered:
            return (
                "Use bigger serve targets and a clear first-ball plan when the "
                "returner is able to attack the delivery."
            )
        if "volley" in lowered or "net presence" in lowered or "smash" in lowered:
            return "Approach only behind a ball that has already forced a defensive reply; do not volunteer a passing-shot opportunity."
        if "forehand" in lowered or "backhand" in lowered:
            wing = "forehand" if "forehand" in lowered else "backhand"
            return (
                f"Do not let the opponent isolate the {wing}: use height and "
                "cross-court margin, recover early, and change direction only when "
                "the next ball is comfortable."
            )
        if "speed" in lowered or "stamina" in lowered or "muscle tone" in lowered:
            return f"Compensate for {attribute} by shortening recovery distance, defending through the middle, and avoiding unnecessary changes of direction."
        if "precision" in lowered or "consistency" in lowered:
            return (
                "Use larger targets and structured cross-court patterns before "
                "changing direction; make the opponent create the first opening."
            )
        return f"Protect {attribute} by changing height, direction, or court position before the opponent can test it repeatedly."

    groups: dict[str, list[dict[str, Any]]] = {}
    for stat in stats:
        if stat["rank"] is not None:
            groups.setdefault(_attribute_group(stat["attribute"]), []).append(stat)
    scores = {
        group: sum(stat["percentile"] for stat in values) / len(values)
        for group, values in groups.items()
        if values
    }
    ranked_groups = sorted(scores.items(), key=lambda item: (-item[1], item[0]))
    strongest_group = ranked_groups[0][0] if ranked_groups else "Overall"
    weakest_group = ranked_groups[-1][0] if ranked_groups else "Overall"
    guidance = {
        group: {
            "score": scores.get(group, 0.5),
            "edges": sorted(
                groups.get(group, []),
                key=lambda item: (-item["percentile"], item["attribute"]),
            )[:3],
        }
        for group, _, _, _, _ in ATTRIBUTE_GROUP_RULES
    }
    descriptions = {
        group: {
            "label": label,
            "benefit": benefit,
            "tradeoff": tradeoff,
        }
        for group, _, label, benefit, tradeoff in ATTRIBUTE_GROUP_RULES
    }
    strongest = descriptions.get(
        strongest_group,
        {
            "label": "overall balance",
            "benefit": "Choose this when you want a flexible profile without committing to one tactical identity.",
            "tradeoff": "The trade-off is that it may not have a decisive answer to a specialist with a clear matchup advantage.",
        },
    )
    weakest = descriptions.get(weakest_group, strongest)
    top_edges = sorted(
        (stat for stat in stats if stat["rank"] is not None),
        key=lambda item: (-item["percentile"], item["attribute"]),
    )[:5]
    weak_edges = sorted(
        (stat for stat in stats if stat["rank"] is not None),
        key=lambda item: (item["percentile"], item["attribute"]),
    )[:3]
    edge_text = ", ".join(
        f"{stat['attribute']} ({stat['percentile']:.0%})"
        for stat in top_edges[:3]
    )
    exposure_text = ", ".join(
        f"{stat['attribute']} ({stat['percentile']:.0%})"
        for stat in weak_edges
    )
    primary_edge = top_edges[0] if top_edges else None
    secondary_edge = top_edges[1] if len(top_edges) > 1 else None
    main_exposure = weak_edges[0] if weak_edges else None
    game_plans = {
        "Serve": (
            "Build points around serve plus the first aggressive ball; "
            "do not waste the advantage with a passive second shot."
        ),
        "Power": (
            "Take control early and shorten neutral exchanges; use height "
            "and margin when the first strike does not land."
        ),
        "Consistency": (
            "Make the opponent play one more ball and attack the short reply; "
            "win through repeatable depth rather than low-percentage winners."
        ),
        "Precision": (
            "Move the opponent with direction changes and target selection; "
            "create the opening before trying to finish."
        ),
        "Net & Feel": (
            "Use short balls to move forward and finish at the net; avoid "
            "staying in a predictable baseline exchange."
        ),
        "Movement": (
            "Extend rallies, defend wide positions, and turn recovery speed "
            "into counterattacks when the opponent overreaches."
        ),
        "Variety": (
            "Change height, spin, speed, and court position to disrupt rhythm; "
            "do not let the match become a single-pattern exchange."
        ),
    }
    mechanics = (
        _mechanics_insights(row, stats, combined_ratings or [])
        if row is not None
        else {}
    )
    mechanic_advantages = mechanics.get("advantages") or []
    mechanic_vulnerabilities = mechanics.get("vulnerabilities") or []
    mechanic_patterns = mechanics.get("point_patterns") or []
    mechanic_indexes = {
        "Serve": 0,
        "Power": 1,
        "Consistency": 1,
        "Precision": 1,
        "Net & Feel": 4,
        "Movement": 3,
        "Variety": 2,
    }
    primary_mechanic_index = mechanic_indexes.get(strongest_group, 0)
    primary_vulnerability_index = mechanic_indexes.get(weakest_group, 0)
    primary_advantage = (
        mechanic_advantages[primary_mechanic_index]
        if len(mechanic_advantages) > primary_mechanic_index
        else (mechanic_advantages[0] if mechanic_advantages else "")
    )
    primary_vulnerability = (
        mechanic_vulnerabilities[primary_vulnerability_index]
        if len(mechanic_vulnerabilities) > primary_vulnerability_index
        else (
            mechanic_vulnerabilities[0]
            if mechanic_vulnerabilities else ""
        )
    )
    def tactical_target(stat: dict[str, Any]) -> str:
        lowered = str(stat["attribute"]).casefold()
        if "service" in lowered:
            return "the serve with aggressive returns, especially the second delivery"
        if "forehand" in lowered:
            return "the forehand corner with height and repeated cross-court pressure"
        if "backhand" in lowered:
            return "the backhand corner with height and repeated cross-court pressure"
        if "volley" in lowered or "net presence" in lowered or "smash" in lowered:
            return "forward movement and passing-shot situations"
        if "speed" in lowered or "stamina" in lowered or "muscle tone" in lowered:
            return "wide court positions and repeated changes of direction"
        if "precision" in lowered:
            return "the edges of the court with changes of direction"
        if "consistency" in lowered:
            return "long exchanges that force one more ball under pressure"
        return "that part of the game repeatedly"

    style_description = PLAYER_STYLE_DESCRIPTIONS.get(
        style,
        "Plays a flexible game without one dominant tactical identity.",
    )
    if edge_text:
        why_select = (
            f"Pick {character or 'this character'} as an {style} if you want this "
            f"style: "
            f"{style_description} Main route: {attacking_pattern(primary_edge)}"
        )
    else:
        why_select = (
            f"Pick {character or 'this character'} when you want "
            f"{strongest['label']} without relying on one extreme attribute."
            + (
                f" {primary_advantage}"
                if primary_advantage else ""
            )
        )
    if exposure_text:
        why_not = (
            f"Avoid {character or 'this character'} when the opponent can repeatedly "
            f"attack {tactical_target(main_exposure)}. "
            f"{protection_pattern(main_exposure)}"
        )
    else:
        why_not = (
            f"Avoid making {character or 'this character'} your default when the "
            f"match demands {weakest['label']}."
            + (
                f" {primary_vulnerability}"
                if primary_vulnerability else ""
            )
        )
    documented_edges = [
        f"{stat['attribute']}: {ATTRIBUTE_MECHANICS[stat['attribute']]}"
        for stat in top_edges[:3]
        if stat["attribute"] in ATTRIBUTE_MECHANICS
    ]
    documented_exposures = [
        f"{stat['attribute']}: {ATTRIBUTE_MECHANICS[stat['attribute']]}"
        for stat in weak_edges
        if stat["attribute"] in ATTRIBUTE_MECHANICS
    ]
    documented_talents = [
        f"{stat['attribute']}: {TALENT_MECHANICS[stat['attribute']]}"
        for stat in stats
        if stat["attribute"] in TALENT_MECHANICS
        and _numeric(stat.get("value")) not in (None, 0)
    ][:4]
    base_plan = game_plans.get(
        strongest_group,
        "Use the strongest attributes to create a repeatable point pattern "
        "rather than playing every point the same way.",
    )
    secondary_edge = top_edges[1] if len(top_edges) > 1 else None
    plan_parts = [base_plan]
    if primary_edge:
        plan_parts.append(attacking_pattern(primary_edge))
        if secondary_edge:
            secondary_pattern = attacking_pattern(secondary_edge)
            if secondary_pattern != plan_parts[-1]:
                plan_parts.append(secondary_pattern)
    if main_exposure:
        plan_parts.append(protection_pattern(main_exposure))
    return {
        "strongest_group": strongest_group,
        "weakest_group": weakest_group,
        "strongest_label": strongest["label"],
        "benefit": strongest["benefit"],
        "tradeoff": weakest["tradeoff"],
        "why_select": why_select,
        "why_not_select": why_not,
        "game_plan": " ".join(plan_parts),
        "best_for": (
            f"{style}: {style_description} Choose this character if that is "
            f"how you want to win points, especially when you want {strongest['label']}. "
            f"Expect to work harder in {weakest_group.lower()} situations."
        ),
        "style_description": style_description,
        "style_mechanics": PLAYER_STYLE_MECHANICS.get(
            style,
            "No documented style mechanic is available for this roster entry.",
        ),
        "acceleration_mechanics": ACCELERATION_MECHANICS.get(
            acceleration,
            (
                f"The {acceleration} acceleration changes how attacking bursts "
                "should be timed, but no more specific mechanic is available."
            ),
        ),
        "documented_edges": documented_edges,
        "documented_exposures": documented_exposures,
        "documented_talents": documented_talents,
        "top_edges": top_edges,
        "weak_edges": weak_edges,
        "group_scores": guidance,
        "mechanics_insights": mechanics,
        "primary_advantage": primary_advantage,
        "primary_vulnerability": primary_vulnerability,
    }


def compare_characters(
    first: str,
    second: str,
    tour: str = "all",
) -> dict[str, Any] | None:
    first_profile = character_profile(first, tour)
    second_profile = character_profile(second, tour)
    if first_profile is None or second_profile is None:
        return None
    first_stats = {
        stat["attribute"]: stat
        for stat in first_profile["stats"]
        if stat["rank"] is not None
    }
    second_stats = {
        stat["attribute"]: stat
        for stat in second_profile["stats"]
        if stat["rank"] is not None
    }
    differences = []
    for attribute in sorted(first_stats.keys() & second_stats.keys()):
        left = first_stats[attribute]
        right = second_stats[attribute]
        delta = left["percentile"] - right["percentile"]
        if abs(delta) < 0.05:
            continue
        differences.append({
            "attribute": attribute,
            "group": _attribute_group(attribute),
            "first_value": left["value"],
            "second_value": right["value"],
            "first_percentile": left["percentile"],
            "second_percentile": right["percentile"],
            "delta": delta,
        })
    first_combined = {
        stat["attribute"]: stat
        for stat in first_profile["combined_ratings"]
        if stat["rank"] is not None
    }
    second_combined = {
        stat["attribute"]: stat
        for stat in second_profile["combined_ratings"]
        if stat["rank"] is not None
    }
    for attribute in sorted(first_combined.keys() & second_combined.keys()):
        left = first_combined[attribute]
        right = second_combined[attribute]
        delta = left["percentile"] - right["percentile"]
        if abs(delta) < 0.05:
            continue
        differences.append({
            "attribute": attribute,
            "group": "Combined skills",
            "first_value": left["value"],
            "second_value": right["value"],
            "first_percentile": left["percentile"],
            "second_percentile": right["percentile"],
            "delta": delta,
        })
    first_edges = sorted(
        (item for item in differences if item["delta"] > 0),
        key=lambda item: (-item["delta"], item["attribute"]),
    )[:4]
    second_edges = sorted(
        (item for item in differences if item["delta"] < 0),
        key=lambda item: (item["delta"], item["attribute"]),
    )[:4]
    first_guidance = first_profile["selection_guidance"]
    second_guidance = second_profile["selection_guidance"]
    first_mechanics = first_guidance.get("mechanics_insights") or {}
    second_mechanics = second_guidance.get("mechanics_insights") or {}
    first_signals = first_mechanics.get("signals") or {}
    second_signals = second_mechanics.get("signals") or {}
    first_mechanics_edges: list[str] = []
    second_mechanics_edges: list[str] = []

    def compare_signal(
        signal: str,
        threshold: float,
        first_text: str,
        second_text: str,
    ) -> None:
        first_value = float(first_signals.get(signal, 0))
        second_value = float(second_signals.get(signal, 0))
        if first_value >= second_value + threshold:
            first_mechanics_edges.append(first_text)
        elif second_value >= first_value + threshold:
            second_mechanics_edges.append(second_text)

    compare_signal(
        "max_serve_speed_kmh",
        8,
        (
            f"{first_profile['character']} has the higher serve ceiling "
            f"({first_signals.get('max_serve_speed_kmh', 0):.1f} km/h), so the "
            "first-ball pressure is greater if its consistency can support it."
        ),
        (
            f"{second_profile['character']} has the higher serve ceiling "
            f"({second_signals.get('max_serve_speed_kmh', 0):.1f} km/h), so the "
            "first-ball pressure is greater if its consistency can support it."
        ),
    )
    compare_signal(
        "forehand_rating",
        5,
        (
            f"{first_profile['character']} has the stronger forehand route: "
            "create it from the middle and use the next ball to finish."
        ),
        (
            f"{second_profile['character']} has the stronger forehand route: "
            "create it from the middle and use the next ball to finish."
        ),
    )
    compare_signal(
        "backhand_rating",
        5,
        (
            f"{first_profile['character']} has the stronger backhand route: "
            "it can absorb targeting and redirect pace without hiding that wing."
        ),
        (
            f"{second_profile['character']} has the stronger backhand route: "
            "it can absorb targeting and redirect pace without hiding that wing."
        ),
    )
    compare_signal(
        "topspin",
        12,
        (
            f"{first_profile['character']} is the better slow-court/heavy-spin "
            f"fit ({first_signals.get('topspin', 0):.0f}% topspin), while fast "
            "courts impose more speed and fatigue cost."
        ),
        (
            f"{second_profile['character']} is the better slow-court/heavy-spin "
            f"fit ({second_signals.get('topspin', 0):.0f}% topspin), while fast "
            "courts impose more speed and fatigue cost."
        ),
    )
    compare_signal(
        "counter",
        12,
        (
            f"{first_profile['character']} gains more from opponents who supply "
            f"pace ({first_signals.get('counter', 0):.0f}% Counter), including the "
            "documented fast-ball redirection benefit."
        ),
        (
            f"{second_profile['character']} gains more from opponents who supply "
            f"pace ({second_signals.get('counter', 0):.0f}% Counter), including the "
            "documented fast-ball redirection benefit."
        ),
    )
    compare_signal(
        "net_presence",
        12,
        (
            f"{first_profile['character']} has more Net Presence support for "
            "closing after a short ball; it still depends on the volley/smash base."
        ),
        (
            f"{second_profile['character']} has more Net Presence support for "
            "closing after a short ball; it still depends on the volley/smash base."
        ),
    )
    return {
        "first": first_profile["character"],
        "second": second_profile["character"],
        "first_edges": first_edges,
        "second_edges": second_edges,
        "first_guidance": first_guidance,
        "second_guidance": second_guidance,
        "first_mechanics": first_mechanics_edges,
        "second_mechanics": second_mechanics_edges,
    }


def character_profile(
    character: str,
    tour: str = "all",
    results: list[dict[str, Any]] | None = None,
) -> dict[str, Any] | None:
    row = resolve_character(character, tour)
    if row is None:
        return None
    roster = load_roster(tour)
    numeric_attributes = [
        attribute for attribute in attribute_names()
        if attribute not in {"Height", "Weight"}
    ]
    stats = []
    for attribute in numeric_attributes:
        value = _numeric(row.get(attribute))
        values = _attribute_values(attribute, tour)
        if value is None or not values:
            continue
        rank, percentile = _rank_and_percentile(values, value)
        stats.append({
            "attribute": attribute,
            "value": value,
            "rank": rank,
            "count": len(values),
            "percentile": percentile,
            "bar": _bar(percentile),
        })
    comparable_stats = [stat for stat in stats if stat["rank"] is not None]
    strengths = sorted(
        comparable_stats,
        key=lambda item: (-item["percentile"], item["attribute"]),
    )[:5]
    weaknesses = sorted(
        comparable_stats,
        key=lambda item: (item["percentile"], item["attribute"]),
    )[:5]
    picks: dict[str, int] = {}
    picker_labels: dict[str, str] = {}
    total_picks = 0
    for result in results or []:
        if str(result.get("tour") or "").casefold() != (
            tour.casefold() if tour != "all" else str(result.get("tour") or "").casefold()
        ):
            continue
        for player_field, character_field in (
            ("p1", "p1_character"),
            ("p2", "p2_character"),
        ):
            if _character_key(result.get(character_field)) != _character_key(
                row["_canonical"]
            ):
                continue
            picker = str(result.get(player_field) or "").strip()
            if picker:
                picker_key = _player_key(picker)
                picks[picker_key] = picks.get(picker_key, 0) + 1
                picker_labels.setdefault(picker_key, picker)
                total_picks += 1
    top_pickers = sorted(
        picks.items(), key=lambda item: (-item[1], item[0])
    )[:3]
    style = _style_label_from_row(row)
    acceleration = str(row.get("Acceleration Trait") or "None")
    combined_ratings = _combined_skill_profiles(row, roster)
    selection_guidance = _selection_guidance(
        stats,
        style=style,
        acceleration=acceleration,
        character=str(row["_canonical"]),
        row=row,
        combined_ratings=combined_ratings,
    )
    return {
        "character": row["_canonical"],
        "tour": tour,
        "roster_count": len(roster),
        "country": str(row.get("Country") or ""),
        "country_flag": country_flag(row.get("Country")),
        "sex": "WTA" if row.get("Sex (0: male; 1: female)") == 1 else "ATP",
        "height": row.get("Height"),
        "weight": row.get("Weight"),
        "style": style,
        "style_description": PLAYER_STYLE_DESCRIPTIONS.get(
            style,
            "",
        ),
        "acceleration": acceleration,
        "stats": stats,
        "combined_ratings": combined_ratings,
        "technical_interactions": TECHNICAL_SKILL_INTERACTIONS,
        "strengths": strengths,
        "weaknesses": weaknesses,
        "selection_guidance": selection_guidance,
        "mechanics_insights": selection_guidance.get(
            "mechanics_insights"
        ) or {},
        "pick_count": total_picks,
        "top_pickers": [
            (picker_labels[key], count) for key, count in top_pickers
        ],
    }


def _roster_character_vectors(tour: str) -> list[dict[str, Any]]:
    """Build roster-relative group scores once for recommendation ranking."""
    path = _workbook_path()
    cache_key = (path.stat().st_mtime_ns, str(tour or "all").casefold())
    cached = _ROSTER_VECTOR_CACHE.get(cache_key)
    if cached is not None:
        return cached
    roster = load_roster(tour)
    attributes = [
        attribute for attribute in attribute_names()
        if attribute not in {"Height", "Weight"}
    ]
    stats_by_character: dict[str, list[dict[str, Any]]] = {
        str(row["_canonical"]): [] for row in roster
    }
    for attribute in attributes:
        values = _attribute_values(attribute, tour)
        for row, value in values:
            rank, percentile = _rank_and_percentile(values, value)
            if rank is None:
                continue
            stats_by_character[str(row["_canonical"])].append({
                "attribute": attribute,
                "value": value,
                "rank": rank,
                "count": len(values),
                "percentile": percentile,
                "bar": _bar(percentile),
            })
    vectors = []
    for row in roster:
        character = str(row["_canonical"])
        stats = stats_by_character[character]
        combined_ratings = _combined_skill_profiles(row, roster)
        guidance = _selection_guidance(
            stats,
            style=_style_label_from_row(row),
            acceleration=str(row.get("Acceleration Trait") or "None"),
            character=character,
            row=row,
            combined_ratings=combined_ratings,
        )
        vectors.append({
            "character": character,
            "stats": stats,
            "combined_ratings": combined_ratings,
            "guidance": guidance,
            "group_scores": {
                group: values["score"]
                for group, values in guidance["group_scores"].items()
            },
        })
    _ROSTER_VECTOR_CACHE[cache_key] = vectors
    return vectors


def _player_group_character_score(
    group_scores: dict[str, float],
    player_group: str,
) -> float:
    weights = PLAYER_GROUP_CHARACTER_WEIGHTS.get(
        str(player_group or "").casefold(),
    )
    if not weights:
        return sum(group_scores.values()) / len(group_scores) if group_scores else 0.5
    available = [
        (group_scores.get(group, 0.5), weight)
        for group, weight in weights.items()
    ]
    return sum(score * weight for score, weight in available) / sum(
        weight for _, weight in available
    )


def _mechanics_group_score(
    vector: dict[str, Any],
    group: str,
) -> float:
    """Score a character against a player area using technical interactions."""
    guidance = vector.get("guidance") or {}
    mechanics = guidance.get("mechanics_insights") or {}
    stats = _stat_by_attribute(vector.get("stats") or [])
    combined = {
        str(item["attribute"]): item
        for item in vector.get("combined_ratings") or []
        if item.get("rank") is not None
    }

    def stat_percentile(attribute: str, default: float = 0.5) -> float:
        item = stats.get(attribute)
        return float(item["percentile"]) if item else default

    def combined_percentile(attribute: str, default: float = 0.5) -> float:
        item = combined.get(attribute)
        return float(item["percentile"]) if item else default

    normalized = str(group or "").casefold()
    if normalized == "serve":
        return combined_percentile("Serve Rating")
    if normalized == "return":
        return sum(
            (
                combined_percentile("Forehand Rating"),
                combined_percentile("Backhand Rating"),
                stat_percentile("Counter"),
                stat_percentile("Early Ball"),
                stat_percentile("Speed"),
            )
        ) / 5
    if normalized == "rally":
        return sum(
            (
                combined_percentile("Forehand Rating"),
                combined_percentile("Backhand Rating"),
                stat_percentile("Forehand Consistency"),
                stat_percentile("Backhand Consistency"),
                stat_percentile("Topspin"),
            )
        ) / 5
    if normalized == "net":
        return sum(
            (
                stat_percentile("Net Presence"),
                stat_percentile("Forehand Volley"),
                stat_percentile("Backhand Volley"),
                stat_percentile("Smash"),
            )
        ) / 4
    return float(
        (vector.get("group_scores") or {}).get(
            next(
                (
                    key for key in (vector.get("group_scores") or {})
                    if key.casefold() == normalized
                ),
                "Overall",
            ),
            0.5,
        )
    )


def _recommendation_mechanics_text(
    guidance: dict[str, Any],
    strength_group: str,
    development_group: str,
    player_strength_metric: dict[str, Any] | None,
    player_development_metric: dict[str, Any] | None,
) -> tuple[str, str]:
    mechanics = guidance.get("mechanics_insights") or {}
    strength_metric = (
        str(player_strength_metric.get("metric"))
        if player_strength_metric else f"{strength_group} profile"
    )
    development_metric = (
        str(player_development_metric.get("metric"))
        if player_development_metric else f"{development_group} profile"
    )
    strength_percentile = (
        f"{float(player_strength_metric.get('percentile')):.0f}th percentile"
        if player_strength_metric
        and isinstance(player_strength_metric.get("percentile"), (int, float))
        else "your measured strength"
    )
    development_percentile = (
        f"{float(player_development_metric.get('percentile')):.0f}th percentile"
        if player_development_metric
        and isinstance(player_development_metric.get("percentile"), (int, float))
        else "your development area"
    )
    strength_route = {
        "serve": mechanics.get("serve"),
        "return": (
            f"{mechanics.get('counter', '')} {mechanics.get('groundstrokes', '')}"
        ),
        "rally": mechanics.get("groundstrokes"),
        "net": mechanics.get("net"),
    }.get(strength_group) or mechanics.get("groundstrokes") or ""
    development_route = {
        "serve": mechanics.get("serve"),
        "return": (
            f"{mechanics.get('counter', '')} {mechanics.get('groundstrokes', '')}"
        ),
        "rally": f"{mechanics.get('surface_fit', '')} {mechanics.get('groundstrokes', '')}",
        "net": mechanics.get("net"),
    }.get(development_group) or mechanics.get("point_patterns", [""])[0]
    rationale = (
        f"Your {strength_metric} ({strength_percentile}) connects to this "
        f"character's {mechanics.get('serve_mode') if strength_group == 'serve' else mechanics.get('groundstroke_edge', 'technical pattern')}: "
        f"{strength_route}"
    )
    development = (
        f"For {development_metric} ({development_percentile}), the useful route is "
        f"{development_route}"
    )
    return rationale, development


def recommend_characters(
    summary: dict[str, Any],
    insights: dict[str, Any] | None,
    tour: str = "all",
    limit: int = 3,
) -> list[dict[str, Any]]:
    """Recommend characters from a player's strengths and training needs."""
    relative = summary.get("relative_profile") or {}
    if not relative or not insights:
        return []
    strength_group = str(
        insights.get("strength_group")
        or max(
            relative,
            key=lambda group: (relative[group].get("percentile", -1), group),
        ),
    ).casefold()
    development_group = str(
        insights.get("development_group")
        or min(
            relative,
            key=lambda group: (relative[group].get("percentile", 101), group),
        ),
    ).casefold()
    training_group = str(
        insights.get("training_group") or development_group
    ).casefold()
    def player_metric(group: str, *, strongest: bool) -> dict[str, Any] | None:
        metrics = (relative.get(group) or {}).get("metrics") or []
        if not metrics:
            return None
        return sorted(
            metrics,
            key=lambda item: item.get("percentile", -1),
            reverse=strongest,
        )[0]
    player_strength_metric = player_metric(strength_group, strongest=True)
    player_development_metric = player_metric(
        development_group,
        strongest=False,
    )
    vectors = _roster_character_vectors(tour)
    scored = []
    for vector in vectors:
        strength_score = _player_group_character_score(
            vector["group_scores"], strength_group
        )
        development_score = _player_group_character_score(
            vector["group_scores"], development_group
        )
        training_score = _player_group_character_score(
            vector["group_scores"], training_group
        )
        strength_mechanics_score = _mechanics_group_score(
            vector, strength_group
        )
        development_mechanics_score = _mechanics_group_score(
            vector, development_group
        )
        training_mechanics_score = _mechanics_group_score(
            vector, training_group
        )
        mechanics_score = (
            strength_mechanics_score * 0.25
            + development_mechanics_score * 0.50
            + training_mechanics_score * 0.25
        )
        score = (
            strength_score * 0.15
            + development_score * 0.20
            + training_score * 0.15
            + mechanics_score * 0.50
        )
        guidance = vector["guidance"]
        mechanics_reason, development_route = _recommendation_mechanics_text(
            guidance,
            strength_group,
            development_group,
            player_strength_metric,
            player_development_metric,
        )
        mechanic_vulnerabilities = (
            guidance.get("mechanics_insights", {}).get("vulnerabilities") or []
        )
        scored.append({
            "character": vector["character"],
            "score": score,
            "strength_score": strength_score,
            "development_score": development_score,
            "training_score": training_score,
            "mechanics_score": mechanics_score,
            "edge_attributes": [
                stat["attribute"] for stat in guidance["top_edges"][:3]
            ],
            "edge_details": [
                {
                    "attribute": stat["attribute"],
                    "value": stat["value"],
                    "percentile": stat["percentile"],
                }
                for stat in guidance["top_edges"][:3]
            ],
            "tradeoff": (
                guidance.get("primary_vulnerability")
                or (
                    mechanic_vulnerabilities[0]
                    if mechanic_vulnerabilities else ""
                )
                or guidance["tradeoff"]
            ),
            "mechanics_reason": mechanics_reason,
            "development_route": development_route,
            "mechanics_insights": guidance.get("mechanics_insights") or {},
            "style": guidance["strongest_label"],
            "strength_group": strength_group,
            "development_group": development_group,
            "training_group": training_group,
            "player_strength_metric": player_strength_metric,
            "player_development_metric": player_development_metric,
        })
    scored.sort(key=lambda item: (-item["score"], item["character"].casefold()))
    return scored[:max(1, min(int(limit or 3), 5))]


def format_value(value: float | int) -> str:
    number = float(value)
    return str(int(number)) if number.is_integer() else f"{number:.1f}"


def format_ranked_line(item: dict[str, Any]) -> str:
    return (
        f"**#{item['rank']}** {item['character']} — "
        f"**{format_value(item['value'])}**"
    )


def _normalise_profile_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.casefold()).strip()


async def fetch_official_profile(
    character: str,
    sex: str,
) -> dict[str, str | None]:
    """Best-effort ATP/WTA directory lookup with a bounded cache.

    WTA exposes player IDs and profile links in its server-rendered directory.
    ATP may challenge automated directory requests, so a missing ATP result is
    treated as unavailable rather than replaced with a non-official image.
    """
    cache_key = f"{sex}:{_normalise_profile_name(character)}"
    now = time.time()
    cached = _AVATAR_CACHE.get(cache_key)
    if cached and now - cached[0] < _AVATAR_CACHE_TTL:
        return cached[1]
    if sex == "WTA":
        directory_url = "https://www.wtatennis.com/players"
        profile_selector = "a.players-list__url"
        name_attribute = "aria-label"
    else:
        directory_url = (
            "https://www.atptour.com/en/players"
        )
        profile_selector = "a[href*='/en/players/']"
        name_attribute = None
    result: dict[str, str | None] = {
        "profile_url": None,
        "avatar_url": None,
        "source": None,
    }
    try:
        timeout = aiohttp.ClientTimeout(total=4, connect=2)
        async with aiohttp.ClientSession(
            timeout=timeout,
            headers={"User-Agent": "WTSL Stats Bot/1.0"},
        ) as session:
            async with session.get(directory_url) as response:
                if response.status != 200:
                    raise RuntimeError(
                        f"{sex} player directory returned {response.status}"
                    )
                soup = BeautifulSoup(await response.text(), "html.parser")
            wanted = _normalise_profile_name(character)
            link = None
            for candidate in soup.select(profile_selector):
                label = (
                    candidate.get(name_attribute)
                    if name_attribute else candidate.get_text(" ", strip=True)
                )
                if _normalise_profile_name(str(label or "")) == wanted:
                    link = candidate
                    break
            if link is None:
                raise LookupError(f"{character} was not found in the {sex} directory")
            profile_url = _safe_http_url(
                urljoin(directory_url, str(link.get("href") or ""))
            )
            if not profile_url:
                raise ValueError("The player directory returned an invalid URL")
            result["profile_url"] = profile_url
            result["source"] = "WTA" if sex == "WTA" else "ATP"
            async with session.get(profile_url) as response:
                if response.status == 200:
                    profile_soup = BeautifulSoup(
                        await response.text(), "html.parser"
                    )
                    image = profile_soup.find(
                        "meta", attrs={"property": "og:image"}
                    )
                    image_url = _safe_http_url(
                        image.get("content") if image else None
                    )
                    if image_url:
                        result["avatar_url"] = image_url
    except Exception:
        pass
    if not result["avatar_url"]:
        try:
            summary_url = (
                "https://en.wikipedia.org/api/rest_v1/page/summary/"
                + quote(character.replace(" ", "_"))
            )
            timeout = aiohttp.ClientTimeout(total=3, connect=2)
            async with aiohttp.ClientSession(
                timeout=timeout,
                headers={"User-Agent": "WTSL Stats Bot/1.0"},
            ) as session:
                async with session.get(summary_url) as response:
                    if response.status == 200:
                        data = await response.json()
                        image = (
                            (data.get("originalimage") or {}).get("source")
                            or (data.get("thumbnail") or {}).get("source")
                        )
                        image_url = _safe_http_url(image)
                        if image_url:
                            result["avatar_url"] = image_url
                            result["source"] = result["source"] or "Wikipedia"
                        if not result["profile_url"]:
                            page = (
                                ((data.get("content_urls") or {}).get("desktop") or {})
                                .get("page")
                            )
                            page_url = _safe_http_url(page)
                            if page_url:
                                result["profile_url"] = page_url
        except Exception:
            pass
    _AVATAR_CACHE[cache_key] = (now, result)
    return result