from time import sleep
import os
from os import system
sleep(7)
system("python main.py")