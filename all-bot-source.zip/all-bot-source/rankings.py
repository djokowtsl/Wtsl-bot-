import pandas as pd
import os, types
import numpy as np
import warnings
import datetime 
from datetime import date
warnings.filterwarnings("ignore")

#tournaments = ['Madrid', 'Rome', 'Roland Garros', 'Queens/Halle', 'Hertogenbosch/Stuttgart/Eastbourne', 'Summer Cup/Newport', 'Wimbledon', 'Hamburg/Gstaad/Atlanta', 'Washington', 'Acapulco', 'Toronto/Montreal'
#]

tournaments = ['Auckland', 'Madrid', 'Rome', 'Roland_Garros',	'Queens',	'Halle',	'Hertogenbosch',	'Stuttgart',	'Eastbourne',	'Newport',	'Summer Cup', 'Wimbledon',	'Hamburg',	'Gstaad',	'Atlanta',	'Washington',	'Acapulco',	'Toronto',	'Montreal',	'Cincinnati',	'US_Open',	'Moselle', 'Wuhan', 'Astana', 'Beijing', 'Tokyo',	'Shanghai', 'Chengdu',	'Shenzen',	'Winston_Salem',	'Antwerp',	'Moscow',	'Vienna',	'Basel',	'Paris',	'Stockholm',	'Doha',	'Sydney', 'Adelaide',	'Australian_Open',	'Montpellier',	'Cordoba',	'Dallas',	'Marseille',	'Buenos_Aires',	'Rotterdam',	'Dubai', 'Rio',	'Indian_Wells',	'Miami', 'Kitzbuhel', 'Houston',	'Monte_Carlo',	'Barcelona',	'Munich',	'Belgrade',	'Marrakech',	'Delray_Beach',	'Nice',	'Estoril',	'Geneva', 'Lyon','World_Tour_Finals', 'Next_Gen_Finals', 'Warm_Up_I', 'Warm_Up_II', 'Mallorca', 'Rafa_Nadal' 
]

categories = ['250', '1000', '1000',	'2000',	'500',	'500',	'250',	'250',	'250',	'250',	'250', '2000','500', '250',	'500',	'500',	'500',	'1000',	'1000',	'1000',	'2000',	'250', '250', '250', '500', '500', '1000', '250',	'250',	'250',	'250',	'250',	'500',	'500',	'1000',	'250',	'250',	'250',	'250',	'2000', '250', '250',	'250',	'250',	'250',	'500',	'500',	'500',	'1000',	'1000',	'250',	'250',	'1000',	'500',	'250',	'250',	'250',	'250',	'250',	'250',	'250',	'250', '1500',	'300', '250', '250', '250', '75' 
]

#categories = ['1000', '1000', '2000', '500', '250', '250', '2000', '500', '500', '500', '1000']
rounds = ['W', 'F', 'SF', 'QF', 'R16', 'R32', 'R64', 'First Round','Q', 'na']
finalsrounds = ['W', 'W1L', 'W2L', 'F', 'F1L', 'F2L', 'SF', 'SF1L', 'SF2L', 'G1L', 'G2L', 'G3L', 'na']
slams = [2000, 1300, 800, 400, 200, 100, 50, 50, 10, 0]
slams_rounds = [6, 6, 5, 4, 3, 2, 1, 1, 1, 0]
masters1000 = [1000, 650, 400, 200, 100, 50, 50, 50, 30, 0]
atp500 = [500, 330, 200, 100, 50, 25, 25, 25, 13, 0]
atp250 = [250, 165, 100, 50, 25, 25, 25, 25, 13, 0]
challenger75 = [75, 44, 22, 12, 0, 0, 0, 0, 0, 0]
atpfinals = [1500, 1300, 1100, 1000, 800, 600, 600, 400, 200, 400, 200, 0, 0]
nextgen = [300, 260, 220, 200, 160, 120, 120, 80, 40, 80, 40, 0, 0]
def ranks(latest_tournament_csv, latest_tournament_name, latest_tournament_name2, tournament_list_csv, last_week_csv, elos_csv):
    latest_tournament = pd.read_csv(latest_tournament_csv)
    latest_tournament.set_index('Player', inplace = True)
    #latest_tournament.drop(columns = 'New Points', inplace = True)
    latest_tournament.fillna('na', inplace = True)
    dict = {}
    for i, j in enumerate(zip(tournaments, categories)):
        dict[tournaments[i]]= categories[i]

    if dict[latest_tournament.columns[0]] == '2000':
        slamsdict = {}
        for i, j in enumerate(zip(rounds, slams)):
            slamsdict[rounds[i]]= slams[i]
        points = []
        for i in range(len(latest_tournament)):
            points.append(slamsdict[latest_tournament.iloc[i][0]])
        #print(len(points))
       # latest_tournament['Points'] = points
    else:
        if dict[latest_tournament.columns[0]] == '1000':
            mastersdict = {}
            for i, j in enumerate(zip(rounds, masters1000)):
                mastersdict[rounds[i]]= masters1000[i]
            points = []
            for i in range(len(latest_tournament)):
                points.append(mastersdict[latest_tournament.iloc[i][0]])
        #    latest_tournament['Points'] = points
        else:
            if dict[latest_tournament.columns[0]] == '500':
                atp500dict = {}
                for i, j in enumerate(zip(rounds, atp500)):
                    atp500dict[rounds[i]]= atp500[i]
                points = []
                for i in range(len(latest_tournament)):
                    points.append(atp500dict[latest_tournament.iloc[i][0]])
          #      latest_tournament['Points'] = points
            else:
                if dict[latest_tournament.columns[0]] == '250':
                    atp250dict = {}
                    for i, j in enumerate(zip(rounds, atp250)):
                        atp250dict[rounds[i]]= atp250[i]
                    points = []
                    for i in range(len(latest_tournament)):
                        points.append(atp250dict[latest_tournament.iloc[i][0]])
                else:
                    if dict[latest_tournament.columns[0]] == '1500':
                      atpfinalsdict = {}
                      for i, j in enumerate(zip(finalsrounds, atpfinals)):
                          atpfinalsdict[finalsrounds[i]]= atpfinals[i]
                      points = []
                      for i in range(len(latest_tournament)):
                          points.append(atpfinalsdict[latest_tournament.iloc[i][0]])
                    else:
                        if dict[latest_tournament.columns[0]] == '300':
                            nextgendict = {}
                            for i, j in enumerate(zip(finalsrounds, nextgen)):
                                nextgendict[finalsrounds[i]]= nextgen[i]
                            points = []
                            for i in range(len(latest_tournament)):
                                points.append(nextgendict[latest_tournament.iloc[i][0]])
                        else:
                            if dict[latest_tournament.columns[0]] == '75':
                                challengerdict = {}
                                for i, j in enumerate(zip(rounds, challenger75)):
                                    challengerdict[rounds[i]]= challenger75[i]
                                points = []
                                for i in range(len(latest_tournament)):
                                    points.append(challengerdict[latest_tournament.iloc[i][0]])
    if latest_tournament_name2 == 'na':
        pointsb = 0
        pass
    elif dict[latest_tournament.columns[1]] == '2000':
        slamsdict = {}
        for i, j in enumerate(zip(rounds, slams)):
            slamsdict[rounds[i]]= slams[i]
        pointsb = []
        for i in range(len(latest_tournament)):
            pointsb.append(slamsdict[latest_tournament.iloc[i][1]])
    elif dict[latest_tournament.columns[1]] == '1000':
            mastersdict = {}
            for i, j in enumerate(zip(rounds, masters1000)):
                mastersdict[rounds[i]]= masters1000[i]
            pointsb = []
            for i in range(len(latest_tournament)):
                pointsb.append(mastersdict[latest_tournament.iloc[i][1]])
    elif dict[latest_tournament.columns[1]] == '500':
            atp500dict = {}
            for i, j in enumerate(zip(rounds, atp500)):
                atp500dict[rounds[i]]= atp500[i]
            pointsb = []
            for i in range(len(latest_tournament)):
                pointsb.append(atp500dict[latest_tournament.iloc[i][1]])
    elif dict[latest_tournament.columns[1]] == '250':
            atp250dict = {}
            for i, j in enumerate(zip(rounds, atp250)):
                atp250dict[rounds[i]]= atp250[i]
            pointsb = []
            for i in range(len(latest_tournament)):
                pointsb.append(atp250dict[latest_tournament.iloc[i][1]])  
    elif dict[latest_tournament.columns[1]] == '1500':
            atpfinalsdict = {}
            for i, j in enumerate(zip(finalsrounds, atpfinals)):
                atpfinalsdict[finalsrounds[i]]= atpfinals[i]
            pointsb = []
            for i in range(len(latest_tournament)):
                pointsb.append(atpfinalsdict[latest_tournament.iloc[i][1]])
    elif dict[latest_tournament.columns[1]] == '300':
            nextgendict = {}
            for i, j in enumerate(zip(finalsrounds, nextgen)):
                nextgendict[finalsrounds[i]]= nextgen[i]
            pointsb = []
            for i in range(len(latest_tournament)):
                pointsb.append(nextgendict[latest_tournament.iloc[i][1]])    
    '''elif dict[latest_tournament.columns[0]] == '75':
            challengerdict = {}
            for i, j in enumerate(zip(rounds, challenger75)):
                challengerdict[rounds[i]]= challenger75[i]
            pointsb = []
            for i in range(len(latest_tournament)):
                pointsb.append(challengerdict[latest_tournament.iloc[i]'''
    latest_tournament['Points'] = points
    print(len(latest_tournament))#latest_tournament['Pointsb'] = pointsb
    latest_tournament.drop(columns = [latest_tournament_name, latest_tournament_name2], inplace = True)
    tournament_list = pd.read_csv(tournament_list_csv)
    tournament_list.set_index(['pl_id'], inplace = True)
    def tournament_index(tournament):
        for i in range(len(tournament_list.columns)):
            if latest_tournament_name2 != 'na':
                if tournament_list.columns[i] == latest_tournament_name2:
                    return i
            elif tournament_list.columns[i] == latest_tournament_name:
                    return i
    best18 = []
   # additional = []
    yeadditional = []
    playernum = []
    arr = latest_tournament.index.values
    for i in range(len(tournament_list)):
        mask = arr == tournament_list.name.iloc[i]
        tournament_list[latest_tournament_name].iloc[i] = latest_tournament['Points'][mask]
        #list = tournament_list[latest_tournament_name].iloc[i] 
        if latest_tournament_name2 != 'na':
            tournament_list[latest_tournament_name2].iloc[i] = np.array(latest_tournament['Pointsb'])[mask]#updating points for latest tournament
    tournament_list.to_csv('52weeks_tournaments_{}.csv'.format(date.today().strftime('%d%m%y')))
    for i in range(len(tournament_list)):
        if latest_tournament_name != 'World_Tour_Finals':
          best18.append(tournament_list.iloc[i,6:66].sort_values(ascending = False)[:18])
          yeadditional.append(tournament_list.iloc[i, 66:])
        elif latest_tournament_name == 'World_Tour_Finals': #and latest_tournament_name2 == 'Next_Gen_Finals':
          best18.append(tournament_list.iloc[i,6:66].sort_values(ascending = False)[:18]) 
          yeadditional.append(tournament_list.iloc[i,66:])
        #elif latest_tournament_name == 'Next_Gen_Finals':  
        #elif latest_tournament_name2 != 'na' and latest_tournament_name2 != 'Next_Gen_Finals':
        #  best18.append(tournament_list.iloc[i,6:tournament_index(latest_tournament_name2)+1].sort_values(ascending = False)[:18])
        #  yeadditional.append(tournament_list.iloc[tournament_index('World_Tour_Finals'),tournament_index('Next_Gen_Finals')-1:])
        #elif latest_tournament_name == 'na':
          
        #best18.append(tournament_list.iloc[i,6:].sort_values(ascending = False)[:18]) 
       # additional.append(tournament_list.iloc[i,[2,3]])
                          #.sort_values(ascending = False)[:18]) 
    best18 = pd.DataFrame(np.array(best18), index = tournament_list.name)
   # additional = pd.DataFrame(np.array(additional), index = tournament_list.name)
    #if latest_tournament_name == 'World_Tour_Finals' and latest_tournament_name2 == 'Next_Gen_Finals':
    yeadditional = pd.DataFrame(np.array(yeadditional), index = tournament_list.name)
    #  best18['Points'] = best18.sum(1) + yeadditional.sum(1)
    #else:
    best18['Points'] = best18.sum(1) + yeadditional.sum(1) #
    elos = pd.read_csv(elos_csv)
    elos.set_index('Player', inplace = True)
    ytd = []
    played = []
    for i in range(len(tournament_list)):
        if latest_tournament_name2 != 'na': 
            ytd18 = tournament_list.iloc[i,6:tournament_index(latest_tournament_name2)+1].sort_values(ascending = False)[:18]
            ytd.append(ytd18.sum())
            #ytd.append(tournament_list.iloc[i,6:tournament_index(latest_tournament_name2)+1].sum())
    #ytd.append(tournament_list.iloc[i,6:tournament_index(latest_tournament_name2)+1].sort_values(ascending = False)[:18].sum())
            played.append(tournament_list.iloc[i,6:tournament_index(latest_tournament_name2)+1][tournament_list.iloc[i,6:tournament_index(latest_tournament_name2)+1]>0].count())
        elif latest_tournament_name != 'World_Tour_Finals':
            ytd18 = tournament_list.iloc[i,6:tournament_index(latest_tournament_name)+1].sort_values(ascending = False)[:18]
            #ytd.append(tournament_list.iloc[i,6:tournament_index(latest_tournament_name)+1].sum())
            ytd.append(ytd18.sum())
            played.append(tournament_list.iloc[i,6:tournament_index(latest_tournament_name)+1][tournament_list.iloc[i,6:tournament_index(latest_tournament_name)+1]>0].count())
        elif latest_tournament_name == 'World_Tour_Finals':
            ytd18 = tournament_list.iloc[i,6:66].sort_values(ascending = False)[:18]
            #ytd.append(tournament_list.iloc[i,6:tournament_index(latest_tournament_name)+1].sum())
            ytd.append(ytd18.sum())
            played.append(tournament_list.iloc[i,6:tournament_index(latest_tournament_name)+1][tournament_list.iloc[i,6:tournament_index(latest_tournament_name)+1]>0].count())
    ytd = pd.DataFrame(ytd, columns =['Race Points'])
    ytd.index = tournament_list.name.values
    played = pd.DataFrame(played, columns =['Tournaments Played'])
    played.index = tournament_list.name.values
    total = []
    for i in range(len(tournament_list)):
       # if latest_tournament_name2 != 'na':
        total.append(tournament_list.iloc[i,6:tournament_index('World Tour Finals')].sort_values(ascending = False)[:18].sum()+(tournament_list.iloc[i,-2:].sum()))
        #total.append(tournament_list.iloc[i,6:].sort_values(ascending = False)[:18])
    total = pd.DataFrame(total, columns =['Max Points'])
    total.index = tournament_list.name.values
    #total= pd.DataFrame(np.array(total), index = tournament_list.name)
    #additional = pd.DataFrame(np.array(additional), index = tournament_list.name)
    #total = total.sum(1) + additional.sum(1)
    lastweek = pd.read_csv(last_week_csv)
    lastweek.set_index('name', inplace = True)
    lastweek = lastweek['Rank']
    arr = elos.index.values
    arr2 = ytd.index.values
    arr3 = lastweek.index.values
    arr4 = total.index.values
    arr5 = played.index.values
    rank = pd.DataFrame(best18.Points, columns = ['Points', 'Elo', 'Race Points', 'LastWeek', 'Tournaments Played','Rank']) # 'Max Points'
    for i in range(len(rank)):
        mask = arr == rank.index[i]
        rank.iloc[:,1][i] = np.array(elos)[mask]
        rank.iloc[:,1][i] = rank['Elo'][i][0][0]
        mask = arr2 == rank.index[i]
        rank.iloc[:,2][i] = np.array(ytd)[mask]
        rank.iloc[:,2][i] = rank['Race Points'][i][0][0]
        mask = arr3 == rank.index[i]
        rank.iloc[:,3][i] = np.array(lastweek)[mask]
        rank.iloc[:,3][i] = str(rank.LastWeek[i].astype(int))
        #mask = arr4 == rank.index[i]
       # rank.iloc[:,4][i] = np.array(total)[mask]
       # rank.iloc[:,4][i] = rank['Max Points'][i][0][0]
        mask = arr5 == rank.index[i]
        rank.iloc[:,4][i] = np.array(played)[mask]
        rank.iloc[:,4][i] = rank['Tournaments Played'][i][0][0]
    rank.sort_values(['Points', 'Elo'], ascending = False, inplace = True)
    for i in range(len(rank)):
        rank['Rank'][i] = i+1
    #return tournament_list[['name',latest_tournament_name]]
    rank['LastWeek'] = rank['LastWeek'].str.strip('[]')
    rank.replace(r'^\s*$', np.nan, regex = True, inplace = True)
    rank.fillna(len(lastweek)+1, inplace = True)
    for i in range(len(rank)):
        rank['LastWeek'][i] = int(rank['LastWeek'][i])
    rank['Spots Moved'] = -(rank.Rank - rank.LastWeek)
    for i in range(len(rank)):
        if rank['Spots Moved'][i] < 0:
            rank['Spots Moved'][i] = '⇓' + '  ' + str(rank['Spots Moved'][i])
        else:
            if rank['Spots Moved'][i] > 0:
                rank['Spots Moved'][i] = '⇑' + '  ' + '+' + str(rank['Spots Moved'][i])
    rank['Spots Moved'] = rank['Spots Moved'].astype(str)
    rank.insert(0, 'Player', rank.index)
    rank.to_csv('rankings_update_{}.csv'.format(date.today().strftime('%d%m%y')))
    return rank