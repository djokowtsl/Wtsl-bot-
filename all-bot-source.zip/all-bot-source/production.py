"""Production entry point that exposes health checks before heavy bot imports."""

from keep_alive import keep_alive


keep_alive()

from main import run_bot


run_bot()