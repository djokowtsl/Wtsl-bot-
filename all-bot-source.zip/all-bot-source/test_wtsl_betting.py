import unittest
from decimal import Decimal

from wtsl_betting import (
    bet_return_breakdown,
    fixture_tour,
    house_adjusted_odds,
    hybrid_guaranteed_odds,
    hybrid_reserve_liability,
    hybrid_settlement_return,
    pool_decimal_odds,
    self_match_reason,
)


class WTSLBettingTests(unittest.TestCase):
    def test_bet_return_breakdown_shows_official_floor_house_cut(self):
        self.assertEqual(
            bet_return_breakdown(
                Decimal("100.00"),
                Decimal("1.80"),
                Decimal("1.00"),
                Decimal("1.71"),
            ),
            {
                "gross_return": Decimal("180.00"),
                "house_cut": Decimal("9.00"),
                "guaranteed_return": Decimal("171.00"),
            },
        )

    def test_bet_return_breakdown_shows_pool_takeout(self):
        self.assertEqual(
            bet_return_breakdown(
                Decimal("100.00"),
                Decimal("1.80"),
                Decimal("2.50"),
                Decimal("2.50"),
            ),
            {
                "gross_return": Decimal("263.16"),
                "house_cut": Decimal("13.16"),
                "guaranteed_return": Decimal("250.00"),
            },
        )

    def test_house_adjusted_odds_are_rounded_to_the_displayed_cents(self):
        self.assertEqual(
            house_adjusted_odds(Decimal("2.510")),
            Decimal("2.39"),
        )
        self.assertEqual(
            house_adjusted_odds(Decimal("1.660")),
            Decimal("1.58"),
        )

    def test_pool_odds_are_rounded_to_the_displayed_cents(self):
        self.assertEqual(
            pool_decimal_odds(Decimal("115.00"), Decimal("100.00")),
            Decimal("1.09"),
        )
        self.assertEqual(
            pool_decimal_odds(Decimal("215.00"), Decimal("15.00")),
            Decimal("13.62"),
        )

    def test_hybrid_reserve_covers_only_the_guaranteed_profit_exposure(self):
        self.assertEqual(
            hybrid_reserve_liability(Decimal("100.00"), Decimal("239.00")),
            Decimal("139.00"),
        )
        self.assertEqual(
            hybrid_reserve_liability(Decimal("100.00"), Decimal("100.00")),
            Decimal("0.00"),
        )

    def test_hybrid_pays_guarantee_or_pool_upside(self):
        self.assertEqual(
            hybrid_settlement_return(
                Decimal("100.00"),
                Decimal("239.00"),
                Decimal("210.00"),
            ),
            Decimal("239.00"),
        )
        self.assertEqual(
            hybrid_settlement_return(
                Decimal("100.00"),
                Decimal("239.00"),
                Decimal("260.00"),
            ),
            Decimal("260.00"),
        )

    def test_hybrid_guarantee_uses_official_floor_before_pool_upside(self):
        self.assertEqual(
            hybrid_guaranteed_odds(Decimal("1.80"), Decimal("1.00")),
            Decimal("1.71"),
        )
        self.assertEqual(
            hybrid_guaranteed_odds(Decimal("1.80"), Decimal("2.10")),
            Decimal("2.10"),
        )

    def test_fixture_tour_distinguishes_wta_draws(self):
        self.assertEqual(fixture_tour("TE4_(F)"), "wta")
        self.assertEqual(fixture_tour("atp"), "atp")

    def test_self_match_protection_uses_the_matching_tour_only(self):
        self.assertIn(
            "own WTSL match",
            self_match_reason(
                {"atp": "Alice Smith", "wta": "WTA Alice"},
                "atp",
                "Alice Smith",
                "Opponent",
            ),
        )
        self.assertIsNone(
            self_match_reason(
                {"atp": "Alice Smith"},
                "wta",
                "Alice Smith",
                "Opponent",
            )
        )
        self.assertIsNone(
            self_match_reason(
                {"atp": "Alice Smith"},
                "atp",
                "Different Player",
                "Opponent",
            )
        )


if __name__ == "__main__":
    unittest.main()