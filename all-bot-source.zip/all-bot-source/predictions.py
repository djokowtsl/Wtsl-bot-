#from keep_alive import keep_alive
import discord 
import pandas as pd
import os, types
import numpy as np
import xlwt
import xlrd
#from botocore.client import Config
#import ibm_boto3
import datetime as dt

data = pd.read_csv('draw.csv')
data = data.replace(r'^\s*$', np.nan, regex = True)
data = data.replace(np.nan, 1, regex = True)
#data.rename(columns = {'2523':2900}, inplace = True)
data.to_csv('drawsim.csv', index = False)
data2 = pd.read_csv('matchresults.csv')
results = pd.read_csv('matchresults.csv')
#from discord.ext import commands
#intents = discord.Intents.all()
#client = commands.Bot(command_prefix="!", intents = intents)

#@client.event
#async def on_ready():
#    print(f'{client.user} succesfully logged in!')
#arr = np.array(results.Player)


def fixText(text):
    row = []
    z = text.find(',')
    if z == 0:  row.append('')
    else:   row.append(text[:z])
    for x in range(len(text)):
        if text[x] != ',':  pass
        else:
            if x == (len(text)-1):  row.append('')
            else:
                if ',' in text[(x+1):]:
                    y = text.find(',', (x+1))
                    c = text[(x+1):y]
                else:   c = text[(x+1):]
                row.append(c)
    return row
def createTuple(oldFile):
    ## oldFile is filename (e.g. 'sheet.csv')
    f1 = open(oldFile, "r")
    tup = []
    while 1:
        text = f1.readline()
        if text == "":  break
        else:   pass
        if text[-1] == '\n':
            text = text[:-1]
        else:   pass
        row = fixText(text)
        tup.append(row)
    return tup

def writeMatrixCSV(mx, fname):
    ## mx is a 2-d python matrix
    ## fname is the desired output filename
    f = open(fname, 'w')
    for r in mx:
        tx = ''
        i = 0
        while i < (len(r)-1):
            tx += str(r[i])
            tx += ','
            i += 1
        try:    tx += str(r[(len(r)-1)])
        except: pass
        if tx == '':    pass
        else:   tx += '\n'
        f.write(tx)
    f.close()
import random, copy
#from createTuple import createTuple ## gist: 778481
#from writeMatrixCSV import writeMatrixCSV ## gist: 778484
data2 = np.array(data2) 
#3 is combo data2[x][3] 
#1 is playerdata2[x][1] 
 #4 is opponent data2[x][4]
#6 is score data2[x][6] 
arr = np.array(results.Player)
   
def headtohead(P1, P2):
    wins = []
    losses = []
    for x in range(len(data2)):
        if data2[x][3] == (P1 + P2 + 'W'): 
            wins.append(data2[x][6])
        if data2[x][3] == (P1 + P2 + 'L'): 
            losses.append(data2[x][6])
    wins = len (wins)
    losses = len (losses)
    return [wins, losses]
  
#@client.command(pass_context = True)  
#async def headyhead(ctx, P1, P2):
#    print("{}{}".format(P1,P2))
 #   wins = []
 #   losses = []
 #   for x in range(len(data2)):
  #      if data2[x][3] == (P1 + P2 + 'W'): 
   #         wins.append(data2[x][6])
   #     if data2[x][3] == (P1 + P2 + 'L'): 
   #         losses.append(data2[x][6])
  #  wins = len (wins)
  #  losses = len (losses)
  #  await ctx.send("{} - {}".format(wins, losses)) 
def unplayed (P1, P2):
    mask = arr == P1
    mask2 = arr == P2
    if len(arr[mask])==0 and len(arr[mask2])==0:
        played1 = 1
        unplayed1 = 0
        cointoss1 = 0
        cointoss2 = 0
        played2 = 1
        unplayed2 = 0
        return played1, played2, unplayed1, unplayed2
    else: 
        played4 = []
        unplayed4 = []
        cointoss4 = []  
        if len(arr[mask])!=0 and len(arr[mask2])==0:
           
            for x in range(len(data2)):
                if (data2[x][1] == P1 and (((data2[x][3])  == (P1  + (data2[x][4]) + 'L' + 'Walkover')) or ((data2[x][3])  == (P1  + (data2[x][4]) + 'L' + 'Coin Toss')) or ((data2[x][3])  == (P1  + (data2[x][4]) + 'W' + 'Coin Toss')) or ((data2[x][3])  == (P1  + (data2[x][4]) + 'L' + 'RL')) or ((data2[x][3])  == (P1 + (data2[x][4])  + 'W' + 'RL')) or ((data2[x][3])  == (P1 + (data2[x][4])  + 'L' + 'DQ')))): 
                    unplayed4.append(data2[x][3])
                else:
                    if data2[x][1] == P1: 
                        played4.append(data2[x][3])
                if (data2[x][1] == P1 and (((data2[x][3])  == (P1  + (data2[x][4]) + 'L' + 'Coin Toss')) or ((data2[x][3])  == (P1  + (data2[x][4]) + 'W' + 'Coin Toss')))): 
                    cointoss4.append(data2[x][3])
            if len(played4)!=0 and len(unplayed4) != 0 :
                return (len(played4)/(len(played4)+ len(unplayed4)), 1, len(cointoss4)/len(unplayed4), 0) 
            else:
                if len(played4)==0 and len(unplayed4) != 0:
                    return (0,1, len(cointoss4)/len(unplayed4), 0)
                else:
                    if len(played4)!=0 and len(unplayed4) == 0 :
                        return (1,1,0,0)
        else:
            cointoss3 = []
            played3 = []
            unplayed3 = [] 
            if len(arr[mask])==0 and len(arr[mask2])!=0:
               
                  
                for x in range(len(data2)):
                    if (data2[x][1] == P2 and (((data2[x][3])  == (P2  + (data2[x][4]) + 'L' + 'Walkover')) or ((data2[x][3])  == (P2  + (data2[x][4]) + 'L' + 'Coin Toss')) or ((data2[x][3])  == (P2  + (data2[x][4]) + 'W' + 'Coin Toss')) or ((data2[x][3])  == (P2  + (data2[x][4]) + 'L' + 'RL')) or ((data2[x][3])  == (P2 + (data2[x][4])  + 'W' + 'RL')) or ((data2[x][3])  == (P2 + (data2[x][4])  + 'L' + 'DQ')))): 
                        unplayed3.append(data2[x][3])
                    else:
                        if data2[x][1] == P2: 
                            played3.append(data2[x][3])
                    if (data2[x][1] == P2 and (((data2[x][3])  == (P2  + (data2[x][4]) + 'L' + 'Coin Toss')) or ((data2[x][3])  == (P2  + (data2[x][4]) + 'W' + 'Coin Toss')))): 
                        cointoss3.append(data2[x][3])
                if len(played3)!=0 and len(unplayed3) != 0 :
                    return (1, len(played3)/(len(played3)+ len(unplayed3)), 0, len(cointoss3)/len(unplayed3)) 
                else:
                    if len(played3)==0 and len(unplayed3) != 0:
                        return (1,0,0, len(cointoss3)/len(unplayed3))   
                    else:
                        if len(played3)!=0 and len(unplayed3) == 0 :
                            return (1,1,0,0)
            else:
                played1 = []
                unplayed1 = []
                cointoss1 = []
                cointoss2 = []
                played2 = []
                unplayed2 = []
                for x in range(len(data2)):
                    if (data2[x][1] == P1 and (((data2[x][3])  == (P1  + (data2[x][4]) + 'L' + 'Walkover')) or ((data2[x][3])  == (P1  + (data2[x][4]) + 'L' + 'Coin Toss')) or ((data2[x][3])  == (P1  + (data2[x][4]) + 'W' + 'Coin Toss')) or ((data2[x][3])  == (P1  + (data2[x][4]) + 'L' + 'RL')) or ((data2[x][3])  == (P1 + (data2[x][4])  + 'W' + 'RL')) or ((data2[x][3])  == (P1 + (data2[x][4])  + 'L' + 'DQ')))): 
                        unplayed1.append(data2[x][3])
                    else:
                        if data2[x][1] == P1: 
                            played1.append(data2[x][3])
                    if (data2[x][1] == P1 and (((data2[x][3])  == (P1  + (data2[x][4]) + 'L' + 'Coin Toss')) or ((data2[x][3])  == (P1  + (data2[x][4]) + 'W' + 'Coin Toss')))): 
                        cointoss1.append(data2[x][3])
       
                for x in range(len(data2)):
                    if (data2[x][1] == P2 and (((data2[x][3])  == (P2  + (data2[x][4]) + 'L' + 'Walkover')) or ((data2[x][3])  == (P2  + (data2[x][4]) + 'L' + 'Coin Toss')) or ((data2[x][3])  == (P2  + (data2[x][4]) + 'W' + 'Coin Toss')) or ((data2[x][3])  == (P2  + (data2[x][4]) + 'L' + 'RL')) or ((data2[x][3])  == (P2 + (data2[x][4])  + 'W' + 'RL')) or ((data2[x][3])  == (P2 + (data2[x][4])  + 'L' + 'DQ')))): 
                        unplayed2.append(data2[x][3])
                    else:
                        if data2[x][1] == P2: 
                            played2.append(data2[x][3])
                    if (data2[x][1] == P2 and (((data2[x][3])  == (P2  + (data2[x][4]) + 'L' + 'Coin Toss')) or ((data2[x][3])  == (P2  + (data2[x][4]) + 'W' + 'Coin Toss')))): 
                        cointoss2.append(data2[x][3])
       
                if len(played1)==0 and ((len(unplayed1)-len(played1))<5) and len(played2)!=0:
                    if (len(unplayed1) !=0 and len(unplayed2) !=0):
                        return (1, len(played2)/(len(played2)+ len(unplayed2)), len(cointoss1)/len(unplayed1), len(cointoss2)/len(unplayed2))
                    else:
                        if (len(unplayed1) == 0 and len(unplayed2)!=0):
                            return (1, len(played2)/(len(played2)+ len(unplayed2)),0, len(cointoss2)/len(unplayed2)) 
                        else:
                            if (len(unplayed1) != 0 and len(unplayed2)==0):
                                return (1, len(played2)/(len(played2)+ len(unplayed2)), len(cointoss1)/len(unplayed1), 0) 
                            else:
                                if (len(unplayed1) == 0 and len(unplayed2)==0):
                                    return(1,1,0,0)
                else:
                    if len(played1)==0 and ((len(unplayed1)-len(played1))>5) and len(played2)!=0:
                        if (len(unplayed1) !=0 and len(unplayed2) !=0):
                            return (0, len(played2)/(len(played2)+ len(unplayed2)), len(cointoss1)/len(unplayed1), len(cointoss2)/len(unplayed2))
                        else:
                            if (len(unplayed1) != 0 and len(unplayed2)==0):
                                return (0, len(played2)/(len(played2)+ len(unplayed2)), len(cointoss1)/len(unplayed1), 0) 
                    else:
                        if len(played1)!=0 and len(played2)==0 and ((len(unplayed2)-len(played2))<5):
                            if (len(unplayed1) !=0 and len(unplayed2) !=0):
                                return (len(played1)/(len(played1)+ len(unplayed1)), 1, len(cointoss1)/len(unplayed1), len(cointoss2)/len(unplayed2))
                            else:
                                if (len(unplayed1) == 0 and len(unplayed2)!=0):
                                    return (len(played1)/(len(played1)+ len(unplayed1)), 1,0, len(cointoss2)/len(unplayed2)) 
                                else:
                                    if (len(unplayed1) == 0 and len(unplayed2)==0):
                                         return (1, 1,0, 0) 
                                    else:
                                        if (len(unplayed1) != 0 and len(unplayed2)==0):
                                            return (len(played1)/(len(played1)+ len(unplayed1)), 1, len(cointoss1)/len(unplayed1), 0)   
                        else:
                            if len(played1)!=0 and len(played2)==0 and ((len(unplayed2)-len(played2))>5):
                                if (len(unplayed1) !=0 and len(unplayed2) !=0):
                                    return (len(played1)/(len(played1)+ len(unplayed1)), 0, len(cointoss1)/len(unplayed1), len(cointoss2)/len(unplayed2))
                                else:
                                    if (len(unplayed1) == 0 and len(unplayed2)!=0):
                                        return (1, 0,0, len(cointoss2)/len(unplayed2)) 
                            else:
                                if len(played1)==0 and ((len(unplayed1)-len(played1))<5) and len(played2)==0 and ((len(unplayed2)-len(played2))<5):
                                    if len(unplayed1) !=0 and len(unplayed2) !=0:
                                        return (1,1, len(cointoss1)/len(unplayed1), len(cointoss2)/len(unplayed2))
                                    else:
                                        if (len(unplayed1) == 0 and len(unplayed2)!=0):
                                            return (1,1,0, len(cointoss2)/len(unplayed2)) 
                                        else:
                                            if (len(unplayed1) != 0 and len(unplayed2)==0):
                                                return (1,1, len(cointoss1)/len(unplayed1),0)
                                            else:
                                                if (len(unplayed1) == 0 and len(unplayed2)==0):
                                                    return(1,1,0,0)
                                else:
                                    if len(played1)==0 and ((len(unplayed1)-len(played1))>5) and len(played2)==0 and ((len(unplayed2)-len(played2))>5):
                                        if len(unplayed1) !=0 and len(unplayed2) !=0:
                                            return (0,0, len(cointoss1)/len(unplayed1), len(cointoss2)/len(unplayed2))
                                    else:
                                  #      if len(played1)!=0 and  len(played2)!=0:
                                        if len(unplayed1) !=0 and len(unplayed2) !=0:
                                            return (len(played1)/(len(played1)+ len(unplayed1)),len(played2)/(len(played2)+ len(unplayed2)), len(cointoss1)/len(unplayed1), len(cointoss2)/len(unplayed2))
                                        else:
                                            if len(unplayed1) == 0 and len(unplayed2)!=0:
                                                return (len(played1)/(len(played1)+ len(unplayed1)),len(played2)/(len(played2)+ len(unplayed2)),0, len(cointoss2)/len(unplayed2)) 
                                            else:
                                                if len(unplayed1) != 0 and len(unplayed2)==0:
                                                    return (len(played1)/(len(played1)+ len(unplayed1)),len(played2)/(len(played2)+ len(unplayed2)), len(cointoss1)/len(unplayed1),0)
                                                else:
                                                    return (0, 0, 0, 0)
                                        

#@client.command(pass_context = True)
#async def calcyWp(ctx, x, y, P1, P2, setties):
#    print("{} {} {} {} {}".format(x, y, P1, P2, setties))
 #   wins = headtohead(P1, P2)[0]*(unplayed(P1, P2)[0]+ unplayed(P1, P2)[2] * 0.5)
 #   losses = headtohead(P1, P2)[1]*(unplayed(P1, P2)[1] + unplayed(P1, P2)[3] * 0.5)
  #  x = float(x)
  #  y = float(y)
  #  qa = 10**(x/800)
  #  qb = 10**(y/800)
  #  win1 = qa/(qa + qb)
    #win2 = qb/(qa + qb)
  #  threeset1 = (3 * (win1**2))-(2 * (win1**3))
    #threeset2 = (3 * (win2**2))-(2 * (win2**3))
  #  fiveset1 = (win1**3)*(1 + 3*(1-win1) + 6*((1-win1)**2))
    #fiveset2 = (win2**3)*(1 + 3*(1-win2) + 6*((1-win2)**2))
  #  if set == '1':
  #      if wins + losses > 0:
  #          factor1 = wins/(wins + losses)
            #factor2 = losses/(wins + losses)
            #prob1 = (0.3 * factor1 * win1) + (0.7 * win1)
            #prob2 = (0.3 * factor2 * win2) + (0.7 * win2)
            #prob = ((1-(prob2 + prob1)))*win1 + prob1 
  #          prob = 0.6*factor1*win1 + (0.3*(win1**2))-(0.6*factor1*(win1**2)) + 0.7*win1#)*unplayed(P1, P2)[0] + ((1-unplayed(P1, P2)[0])*0.5)
  #          await ctx.send(round(prob,2))
            
            
   #     else:
    #        await ctx.send(round(win1,2))
            
             
  #  if set == '3':
   #     if wins + losses > 0:
   #         factor1 = wins/(wins + losses)
   #        # factor2 = losses/(wins + losses)
           # prob1 = (0.3 * factor1 * threeset1) + (0.7 * threeset1)
           # prob2 = (0.3 * factor2 * threeset2) + (0.7 * threeset2)
           # prob = ((1-(prob2 + prob1)))*threeset1 + prob1 
   #         prob = 0.6*factor1*threeset1 + (0.3*(threeset1**2))-(0.6*factor1*(threeset1**2)) + 0.7*threeset1#)*unplayed(P1, P2)[0] + ((1-unplayed(P1, P2)[0])*0.5)
   #         await ctx.send(round(prob,2)) 
            
             
    #    else:
    #        await ctx.send(round(threeset1,2))
            
             
   # if set == '5':
    #    if wins + losses > 0:
    #        factor1 = wins/(wins + losses)
           # factor2 = losses/(wins + losses)
           # prob1 = (0.3 * factor1 * fiveset1) + (0.7 * fiveset1)
           # prob2 = (0.3 * factor2 * fiveset2) + (0.7 * fiveset2)
           # prob = ((1-(prob2 + prob1)))*fiveset1 + prob1 
    #        prob = 0.6*factor1*fiveset1 + (0.3*(fiveset1**2))-(0.6*factor1*(fiveset1**2)) + 0.7*fiveset1#)*unplayed(P1, P2)[0] + ((1-unplayed(P1, P2)[0])*0.5)
    #        await ctx.send(round(prob,2)) 
            
            
            
    #    else:
    #        await ctx.send(round(fiveset1,2)) 
def calcWp(x, y, P1, P2, sets):
    wins = headtohead(P1, P2)[0]*(unplayed(P1, P2)[0]+ unplayed(P1, P2)[2] * 0.5)
    losses = headtohead(P1, P2)[1]*(unplayed(P1, P2)[1] + unplayed(P1, P2)[3] * 0.5)
    x = float(x)
    y = float(y)
    qa = 10**(x/1500)
    qb = 10**(y/1500)
    win1 = qa/(qa + qb)
    #win2 = qb/(qa + qb)
    threeset1 = (3 * (win1**2))-(2 * (win1**3))
    #threeset2 = (3 * (win2**2))-(2 * (win2**3))
    fiveset1 = (win1**3)*(1 + 3*(1-win1) + 6*((1-win1)**2))
    #fiveset2 = (win2**3)*(1 + 3*(1-win2) + 6*((1-win2)**2))
    if sets == 1:
        if wins + losses > 0:
            factor1 = wins/(wins + losses)
            #factor2 = losses/(wins + losses)
            #prob1 = (0.3 * factor1 * win1) + (0.7 * win1)
            #prob2 = (0.3 * factor2 * win2) + (0.7 * win2)
            #prob = ((1-(prob2 + prob1)))*win1 + prob1 
            prob = 0.6*factor1*win1 + (0.3*(win1**2))-(0.6*factor1*(win1**2)) + 0.7*win1#)*unplayed(P1, P2)[0] + ((1-unplayed(P1, P2)[0])*0.5)
            return prob
        else:
            return win1
    if sets == 3:
        if wins + losses > 0:
            factor1 = wins/(wins + losses)
           # factor2 = losses/(wins + losses)
           # prob1 = (0.3 * factor1 * threeset1) + (0.7 * threeset1)
           # prob2 = (0.3 * factor2 * threeset2) + (0.7 * threeset2)
           # prob = ((1-(prob2 + prob1)))*threeset1 + prob1 
            prob = 0.6*factor1*threeset1 + (0.3*(threeset1**2))-(0.6*factor1*(threeset1**2)) + 0.7*threeset1#)*unplayed(P1, P2)[0] + ((1-unplayed(P1, P2)[0])*0.5)
            return prob
        else:
            return threeset1
    if sets == 5:
        if wins + losses > 0:
            factor1 = wins/(wins + losses)
           # factor2 = losses/(wins + losses)
           # prob1 = (0.3 * factor1 * fiveset1) + (0.7 * fiveset1)
           # prob2 = (0.3 * factor2 * fiveset2) + (0.7 * fiveset2)
           # prob = ((1-(prob2 + prob1)))*fiveset1 + prob1 
            prob = 0.6*factor1*fiveset1 + (0.3*(fiveset1**2))-(0.6*factor1*(fiveset1**2)) + 0.7*fiveset1#)*unplayed(P1, P2)[0] + ((1-unplayed(P1, P2)[0])*0.5)
            return prob
        else:
            return fiveset1          
             
def findRoundWinners(roundPlayers, sets, display):
    ## get each pair of players, return list of 'winners'
    nextRound = []
    roundMatches = int(len(roundPlayers)/2)
    draw = createTuple('drawsim.csv')
    pointDict = {}
    firstRound = []
    resultDict = {}
    for pl in draw:
        pointDict[pl[0]] = int(float(pl[2]))
        firstRound.append(pl[0])
        resultDict[pl[0]] = copy.deepcopy(blankResults)
    for i in range(roundMatches):
        j = i*2
        playerOne = roundPlayers[j]
        playerTwo = roundPlayers[j+1]
        if playerOne == 'Bye':
            oneWp = 0
        else:
            if playerTwo == 'Bye':
                oneWp = 1
            else:
                oneWp = calcWp(pointDict[playerOne], pointDict[playerTwo], playerOne, playerTwo, sets)
        winnum = random.random() 
        if winnum < oneWp: 
            winner = playerOne
            if pointDict[playerOne] > 2400:
                f = 16
            else:
                if pointDict[playerOne] > 2100 and (pointDict[playerOne] < 2400):
                    f = 24
                else:
                    if pointDict[playerOne] < 2100:
                        f = 32
            if pointDict[playerTwo] > 2400:
                g = 16
            else:
                if pointDict[playerTwo] > 2100 and (pointDict[playerTwo] < 2400):
                    g = 24
                else:
                    if pointDict[playerTwo] < 2100:
                        g = 32
            pointDict[playerOne] = pointDict[playerOne] + (f*(oneWp-winnum))
            pointDict[playerTwo] = pointDict[playerTwo] + (g*(winnum - oneWp))
        else:   
            winner = playerTwo
            if pointDict[playerOne] > 2400:
                f = 16
            else:
                if pointDict[playerOne] > 2100 and (pointDict[playerOne] < 2400):
                    f = 24
                else:
                    if pointDict[playerOne] < 2100:
                        f = 32
            if pointDict[playerTwo] > 2400:
                g = 16
            else:
                if pointDict[playerTwo] > 2100 and (pointDict[playerTwo] < 2400):
                    g = 24
                else:
                    if pointDict[playerTwo] < 2100:
                        g = 32
            pointDict[playerOne] = pointDict[playerOne] + (f*(oneWp-winnum))
            pointDict[playerTwo] = pointDict[playerTwo] + (g*(winnum-oneWp))  
        #if display == 1:
          #  print(pointDict)
        nextRound.append(winner)
    if display == 1:
        print(pointDict)
        print(nextRound)
    else:
        pass
    
    return nextRound
  



#print(unplayed ('Willito', 'Sebko')) #appearance %
#print(headtohead('Willito', 'Sebko')) #head to head
#print(calcWp(2800, 2364, 'Willito', 'Sebko', 1)) #one set
#print(calcWp(2800, 2364, 'Willito', 'Sebko', 3)) #3 sets
#print(calcWp( 2800, 2364, 'Willito', 'Sebko', 5)) #5 sets

sims = 2000
draw = createTuple('drawsim.csv')
#pd.DataFrame(draw).to_excel('drawtest.xls')
#@client.command(pass_context = True)
#async def printdraw(ctx, x):
 #   print("{}".format(x))
 #   await ctx.send(['Name', 'Seed', 'Elo'])
  #  for i in range(len(draw)):
  #    await ctx.send(draw[i])
#blankResults = {1: 0,
  #              2: 0,
   #             4: 0,
  #              8: 0
   #             }

#for z in [17, 33, 65]:
#    if len(draw) > z:
#        dsize = (z-1)
#        blankResults[dsize] = 0

#pointDict = {}
#firstRound = []
#resultDict = {}
#for pl in draw:
 #   pointDict[pl[0]] = int(float(pl[2]))
  #  firstRound.append(pl[0])
  #  resultDict[pl[0]] = copy.deepcopy(blankResults)

## run the simulation
#@client.command(pass_context = True)
#async def sim(ctx, x, simmy):
#  print("{}{}".format(x, simmy))
#  simmy = int(float(simmy))
#  for x in range(simmy):
#      if x % (simmy/100) == 0:    
#          await ctx.send (x)
#          await ctx.send((dt.datetime.now()))
 #     nextRound = firstRound
  #    while True:
   #       nextRound = findRoundWinners(nextRound,5,1)
    #      n = len(nextRound)
     #     for p in nextRound:
     #         resultDict[p][n] += 1
     #     if n == 1:  break
    
 # rds = []
 # for z in [65, 33, 17]:
  #    if len(draw) > z:
  #        rdname = 'R' + str(z-1)
   #       rds.append(rdname)

 # header = ['Player', 'Seed', 'Elo'] + rds + ['QF', 'SF', 'F', 'W']

 # resultTable = [header]

 # for pl in draw:
 #     if pl[0] !='Bye':
  #        p = pl[0]
   #       row = pl[:3]
    #      for result in [32, 16, 8, 4, 2, 1]:
     #         perc = resultDict[p][result]/float(sims)
     #         row.append(perc)
     #     resultTable.append(row)

  #writeMatrixCSV(resultTable, 'drawsimresults.csv')
 # await ctx.send(pd.read_csv('drawsimresults.csv').sort_values(by = 'W', ascending = False).head(25))
#client.run(os.getenv('TOKEN3'))