"""Shared player-specific coaching language for stats surfaces."""
from __future__ import annotations

METRIC_GROUPS = {
    "serve": {
        "1st Serve %",
        "1st Serve Won %",
        "2nd Serve Won %",
        "Aces",
        "Double Faults",
    },
    "return": {
        "1st Serve Return Points Won %",
        "2nd Serve Return Points Won %",
        "Return Points Won %",
        "Break Points Won %",
        "Breaks / Games %",
    },
    "rally": {
        "Short Rallies Won (<5) %",
        "Medium Rallies Won (5-8) %",
        "Long Rallies Won (>8) %",
        "Winners",
        "Unforced Errors",
    },
}


_STRENGTH_CONTEXT = {
    "1st Serve %": "{subject_verb} starting points on the front foot by landing first serves consistently.",
    "1st Serve Won %": "{possessive_cap} first serve is creating short balls and protecting service games.",
    "2nd Serve Won %": "{possessive_cap} second serve is holding up well when opponents attack it.",
    "Aces": "{subject_verb} earning free points and applying immediate scoreboard pressure.",
    "Double Faults": "A low double-fault rate keeps {possessive} service games under control and avoids free points.",
    "1st Serve Return Points Won %": "{possessive_cap} first-serve return is neutralising pace well and getting into return games.",
    "2nd Serve Return Points Won %": "{possessive_cap} second-serve return is creating early pressure.",
    "Return Points Won %": "{possessive_cap} overall return work consistently puts opponents under pressure.",
    "Break Points Won %": "{subject_verb} converting important return opportunities efficiently.",
    "Breaks / Games %": "{subject_verb} turning return pressure into breaks of serve.",
    "Short Rallies Won (<5) %": "{possessive_cap} serve-plus-one and return-plus-one patterns are effective.",
    "Medium Rallies Won (5-8) %": "{subject_verb} building points effectively through the middle phase of rallies.",
    "Long Rallies Won (>8) %": "{possessive_cap} patience and physical consistency are strong in extended exchanges.",
    "Winners": "{subject_verb} finishing enough points proactively rather than waiting for errors.",
    "Unforced Errors": "A low unforced-error rate gives {possessive} opponents fewer free points.",
    "Return Winners": "{subject_verb} turning return positions into proactive finishing chances.",
    "Forced Errors": "{possessive_cap} pressure makes opponents play beyond their comfort zone.",
    "Net Points Won %": "{subject_verb} converting forward movement into points when the opening appears.",
}

_DEVELOPMENT_CONTEXT = {
    "1st Serve %": "Raise first-serve reliability without taking away too much pace or placement.",
    "1st Serve Won %": "Improve first-serve location and the quality of the next attacking ball.",
    "2nd Serve Won %": "Build a heavier, safer second serve and a clearer second-serve-plus-one pattern.",
    "Aces": "Use disguise and wider placement to create more unreturned serves.",
    "Double Faults": "Reduce free points by giving the second serve more net clearance, shape, and target margin.",
    "1st Serve Return Points Won %": "Prioritise a compact block return and a neutral first ball against pace.",
    "2nd Serve Return Points Won %": "Step in earlier and direct more second-serve returns to an aggressive target.",
    "Return Points Won %": "Improve return depth so more points begin from a neutral or attacking position.",
    "Break Points Won %": "Use a committed return pattern on break points instead of changing strategy under pressure.",
    "Breaks / Games %": "Turn more return pressure into breaks by protecting leads within return games.",
    "Short Rallies Won (<5) %": "Sharpen serve-plus-one and return-plus-one patterns for the first four shots.",
    "Medium Rallies Won (5-8) %": "Improve direction changes and court position once the point becomes neutral.",
    "Long Rallies Won (>8) %": "Develop rally tolerance, height over the net, and disciplined target selection.",
    "Winners": "Create finishing chances with better court position before accelerating.",
    "Unforced Errors": "Lower the unforced-error rate by using larger targets and better shot selection under stress.",
    "Return Winners": "Create more damaging return positions before going for the finish.",
    "Forced Errors": "Build pressure through depth and court position so opponents have to manufacture pace.",
    "Net Points Won %": "Make approach attempts more selective and finish the first volley with a clear target.",
}

_TRAINING_FOCUS = {
    "serve": "Build the next practice block around serve quality: rehearse first-serve locations, then play second-serve-plus-one points with a double-fault penalty and generous second-serve targets.",
    "return": "Build the next practice block around return pressure: alternate compact first-serve blocks with aggressive second-serve returns, then play out points from the first neutral ball.",
    "rally": "Build the next practice block around rally tolerance and point construction: use cross-court consistency targets, controlled direction changes, and finish only after earning court position.",
}

_TACTICAL_STRENGTH = {
    "1st Serve %": "Use the first serve to open the court, then attack the first ball into the space it creates.",
    "1st Serve Won %": "Build points around serve-plus-one: serve to the weaker location, then take the first short reply.",
    "2nd Serve Won %": "Use a heavier second serve with a clear target, then play the next ball with controlled aggression.",
    "Aces": "Look for wide or body serve patterns that create free points or predictable returns.",
    "Double Faults": "Keep the low-risk second serve in play and make the opponent earn every return point.",
    "1st Serve Return Points Won %": "Block first serves deep through the middle, then make the next neutral ball uncomfortable.",
    "2nd Serve Return Points Won %": "Step inside the baseline against second serves and take the return early.",
    "Return Points Won %": "Start return games with depth and margin, then build pressure before changing direction.",
    "Break Points Won %": "On break chances, repeat the highest-percentage return pattern instead of chasing a low-margin winner.",
    "Breaks / Games %": "Turn early return pressure into scoreboard leads, then protect them with high-percentage patterns.",
    "Short Rallies Won (<5) %": "Prioritise the first four shots: serve-plus-one or return-plus-one, with the first attack going to space.",
    "Medium Rallies Won (5-8) %": "Use patient cross-court construction and change direction only after earning a stable court position.",
    "Long Rallies Won (>8) %": "Extend exchanges when needed, use height and depth, and wait for the opponent to give up the short ball.",
    "Winners": "Construct the point until the court opens, then accelerate into the space rather than forcing the first attack.",
    "Unforced Errors": "Use larger targets early and make the opponent hit one more ball before taking the risk.",
    "Return Winners": "Create the return position first, then finish only when the opponent leaves a genuine opening.",
    "Forced Errors": "Use depth and changing ball height to make the opponent generate their own pace under pressure.",
    "Net Points Won %": "Approach behind a ball that earns the forward move, then commit to the first volley target.",
}

_TACTICAL_DEVELOPMENT = {
    "1st Serve %": "Choose two high-margin first-serve targets and accept a neutral first ball rather than forcing placement.",
    "1st Serve Won %": "Use safer locations and a clearer serve-plus-one target so the first attacking ball is played from balance.",
    "2nd Serve Won %": "Add height and margin to the second serve, then protect the next ball instead of chasing immediate offence.",
    "Aces": "Use placement and disguise to create predictable returns; do not turn the lack of aces into low-percentage serving.",
    "Double Faults": "Prioritise a repeatable second-serve target with more net clearance and make the opponent win the rally.",
    "1st Serve Return Points Won %": "Start with a compact block return through a large target, then build the point from neutral.",
    "2nd Serve Return Points Won %": "Step in with a committed but high-margin return target and attack the next ball, not every return.",
    "Return Points Won %": "Protect return depth and avoid donating short replies before trying to create pressure.",
    "Break Points Won %": "Use the same trusted return pattern on break points and let pressure create the next opportunity.",
    "Breaks / Games %": "Convert pressure with patience: build the return game instead of rushing once a break chance appears.",
    "Short Rallies Won (<5) %": "Make the first four shots safer and deeper, especially the serve-plus-one or return-plus-one ball.",
    "Medium Rallies Won (5-8) %": "Stay patient through the neutral phase and earn court position before changing direction.",
    "Long Rallies Won (>8) %": "Avoid being drawn into extended exchanges: use depth, change height, and look for the first shorter ball.",
    "Winners": "Create the opening with court position first, then finish with a controlled target rather than forcing the winner.",
    "Unforced Errors": "Use bigger targets and a clearer rally shape until the opponent gives you a higher-percentage attack.",
    "Return Winners": "Build the return point with depth and margin before looking to finish.",
    "Forced Errors": "Make the opponent move through depth and width instead of relying on rushed attacking shots.",
    "Net Points Won %": "Choose approaches more selectively and make the first volley simple and deep.",
}


def metric_group(metric: str) -> str | None:
    for group, metrics in METRIC_GROUPS.items():
        if metric in metrics:
            return group
    return None


def metric_insight(
    metric: str,
    *,
    strength: bool,
    subject: str = "You",
) -> str:
    """Return the same coaching language used by dashboard and match views."""
    templates = _STRENGTH_CONTEXT if strength else _DEVELOPMENT_CONTEXT
    if subject == "You":
        possessive, possessive_cap, subject_verb = "your", "Your", "You are"
    elif subject == "We":
        possessive, possessive_cap, subject_verb = "our", "Our", "We are"
    else:
        possessive = f"{subject}'s"
        possessive_cap = possessive
        subject_verb = f"{subject} is"
    return templates.get(
        metric,
        f"{subject} should keep building this part of the current performance profile."
        if strength
        else f"Prioritise this part of {possessive.lower()} current performance profile in training.",
    ).format(
        subject=subject,
        possessive=possessive,
        possessive_cap=possessive_cap,
        subject_verb=subject_verb,
    )


def training_focus(group: str) -> str | None:
    return _TRAINING_FOCUS.get(group)


def field_standing(
    summary: dict,
    group: str | None,
) -> str | None:
    """Describe a player's measured standing in the available tour field."""
    if not group:
        return None
    profile = (summary.get("relative_profile") or {}).get(group)
    if not isinstance(profile, dict):
        return None
    percentile = profile.get("percentile")
    players = profile.get("players")
    if not isinstance(percentile, (int, float)):
        return None
    percentile = round(float(percentile))
    if percentile >= 85:
        level = "among the strongest"
    elif percentile <= 15:
        level = "among the weakest"
    elif percentile >= 60:
        level = "above average"
    elif percentile <= 40:
        level = "below average"
    else:
        level = "around the field average"
    sample = (
        f" across {int(players)} comparable players"
        if isinstance(players, (int, float)) and players > 0
        else ""
    )
    return f"{level} ({percentile}th percentile{sample})"


def tactical_match_advice(
    metric: str,
    *,
    strength: bool,
    field_context: str | None = None,
) -> str:
    """Turn a measured edge or development area into an in-match plan."""
    advice = (
        _TACTICAL_STRENGTH if strength else _TACTICAL_DEVELOPMENT
    ).get(
        metric,
        "Play to the larger target, protect the neutral ball, and attack only after earning the opening.",
    )
    if field_context:
        advice = (
            f"Your field standing is {field_context}; "
            + (
                "make this a primary route to points."
                if strength
                else "avoid making this the opponent's easiest route to points."
            )
            + f" {advice}"
        )
    return advice