"""Shared cached access to WTSL's complete historical results feed."""
from __future__ import annotations

import asyncio
from collections import defaultdict
from datetime import date, datetime
import gzip
import json
import os
import re
import time
import unicodedata
from pathlib import Path
from typing import Any

import aiohttp
from bs4 import BeautifulSoup

ALL_RESULTS_URL = "https://playwtsl.com/TE4/pages/all_results_fetch.php"
TOURNAMENTS_URL = "https://www.playwtsl.com/TE4/pages/tournaments.php"
CACHE_TTL_SECONDS = 15 * 60
FULL_CACHE_PATH = Path("wtsl_all_results_cache.json.gz")
RECENT_CACHE_PATH = Path("wtsl_recent_results.json")
TOURNAMENTS_CACHE_PATH = Path("wtsl_tournaments_cache.json")
RECENT_RESULT_LIMIT = 100

_memory_results: list[dict[str, Any]] | None = None
_memory_loaded_at = 0.0
_last_live_refresh_at = 0.0
_background_refresh_task: asyncio.Task | None = None
_refresh_lock = asyncio.Lock()
_schedule_memory: dict[str, list[dict[str, Any]]] = {}
_schedule_loaded_at: dict[str, float] = {}
_schedule_lock = asyncio.Lock()

_EVENT_CATEGORY_PATTERNS = (
    ("futures", re.compile(r"\bfutures?\b", re.I)),
    ("challenger", re.compile(r"\bchallenger\b", re.I)),
    ("1000", re.compile(r"\b(?:atp|wta)?\s*1000\b", re.I)),
    ("500", re.compile(r"\b(?:atp|wta)?\s*500\b", re.I)),
    ("250", re.compile(r"\b(?:atp|wta)?\s*250\b", re.I)),
)


def _text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def split_player_character(value: Any) -> tuple[str, str | None]:
    cleaned = _text(value)
    match = re.match(r"^(.*?)\s+\(([^()]*)\)\s*$", cleaned)
    if not match:
        return cleaned, None
    player, character = _text(match.group(1)), _text(match.group(2))
    return player, character or None


def normalize_result_name(value: Any) -> str:
    """Normalize a player label for exact official-result matching."""
    decomposed = unicodedata.normalize("NFKD", _text(value))
    plain = "".join(
        character
        for character in decomposed
        if unicodedata.category(character) not in {"Mn", "So", "Sk"}
        and character not in {"\u200d", "\ufe0f"}
    )
    return re.sub(r"\s+", " ", plain).strip().casefold()


def result_score_signature(value: Any) -> tuple[tuple[int, int], ...]:
    """Extract the played set scores, ignoring optional tie-break points."""
    return tuple(
        (int(first), int(second))
        for first, second in re.findall(
            r"(\d+)\s*-\s*(\d+)", str(value or "")
        )
    )


def result_score_equivalence_key(
    value: Any,
) -> tuple[tuple[int, int], ...]:
    """Return an orientation-independent key for a complete score."""
    score = result_score_signature(value)
    reversed_score = tuple((second, first) for first, second in score)
    return min(score, reversed_score) if score else ()


def official_result_is_played(result: Any) -> bool:
    """Whether an official row represents a completed statistical match."""
    text = _text(result).casefold()
    if not result_score_signature(result) or re.search(
        r"\b(?:walkover|ret(?:ired)?|retirement|coin\s+toss|bct)\b",
        text,
    ):
        return False
    # A complete match needs at least two played sets. This also rejects
    # malformed status rows that happen to contain one score fragment.
    return len(result_score_signature(result)) >= 2


def _result_date_key(value: Any) -> tuple[int, int, int] | None:
    if isinstance(value, datetime):
        value = value.date()
    if isinstance(value, date):
        return value.year, value.month, value.day
    text = _text(value)
    if "T" in text or " " in text:
        text = re.split(r"[T ]", text, maxsplit=1)[0]
    for format_string in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            parsed = datetime.strptime(text, format_string).date()
        except ValueError:
            continue
        return parsed.year, parsed.month, parsed.day
    return None


def find_confident_official_match(
    results: list[dict[str, Any]],
    player: Any,
    opponent: Any,
    match_date: Any,
    result: Any,
    *,
    name_aliases: dict[str, str] | None = None,
) -> dict[str, Any] | None:
    """Return one exact official result, or ``None`` when not confident.

    The match must agree on both players, the calendar date, and the complete
    played score. A pair/date/score that appears more than once is deliberately
    treated as ambiguous, since it cannot safely establish a tour.
    """
    aliases = {
        normalize_result_name(key): normalize_result_name(value)
        for key, value in (name_aliases or {}).items()
    }

    def canonical_name(value: Any) -> str:
        normalized = normalize_result_name(value)
        return aliases.get(normalized, normalized)

    wanted_pair = {
        canonical_name(player),
        canonical_name(opponent),
    }
    wanted_date = _result_date_key(match_date)
    wanted_score = result_score_equivalence_key(result)
    if len(wanted_pair) != 2 or wanted_date is None or not wanted_score:
        return None

    candidates: list[dict[str, Any]] = []
    for official in results:
        if not official_result_is_played(official.get("result")):
            continue
        official_pair = {
            canonical_name(
                official.get("player1") or official.get("p1")
            ),
            canonical_name(
                official.get("player2") or official.get("p2")
            ),
        }
        if official_pair != wanted_pair:
            continue
        if _result_date_key(official.get("date")) != wanted_date:
            continue
        if result_score_equivalence_key(official.get("result")) != wanted_score:
            continue
        tour = str(official.get("tour") or "").casefold()
        if tour not in {"atp", "wta"}:
            tour = _tour_from_tournament(_text(official.get("tournament")))
        if tour in {"atp", "wta"}:
            candidates.append(official)

    return candidates[0] if len(candidates) == 1 else None


def _tour_from_tournament(value: str) -> str:
    normalized = value.casefold()
    return "wta" if "wta" in normalized or "female" in normalized else "atp"

def tournament_category(value: Any) -> str:
    """Return the competition level encoded by an official event label.

    WTSL uses the event label as its only durable category field.  Keep the
    values deliberately small and stable because they are used to decide
    whether two events may share a court.  Unknown labels remain distinct from
    the numbered main-tour categories instead of being guessed as 250.
    """
    text = _text(value)
    for category, pattern in _EVENT_CATEGORY_PATTERNS:
        if pattern.search(text):
            return category
    return "main-tour"


def is_exhibition_tournament(value: Any, category: Any = None) -> bool:
    """Identify exhibition competitions that must not enter player totals."""
    category_text = _text(category).casefold()
    if "exhibition" in category_text:
        return True
    text = _text(value)
    return bool(re.search(
        r"\b(?:exhibition|year\s*end\s+holidays?\s+cup|"
        r"holidays?\s+cup|christmas\s+cup|xmas\s+cup|"
        r"six\s+kings\s+slam|mystery\s+cup)\b",
        text,
        re.I,
    ))


def is_nonroutine_matchlog_tournament(
    value: Any,
    category: Any = None,
) -> bool:
    """Identify events outside individual MatchLog verification."""
    if is_exhibition_tournament(value, category):
        return True
    return bool(re.search(
        r"\b(?:davis\s+cup|laver\s+cup)\b",
        _text(value),
        re.I,
    ))


def parse_all_results_html(html: str) -> list[dict[str, Any]]:
    soup = BeautifulSoup(html, "html.parser")
    table = None
    headers: list[str] = []
    for candidate in soup.find_all("table"):
        candidate_headers = [
            _text(cell.get_text(" ", strip=True))
            for cell in candidate.find_all("th")
        ]
        normalized = [header.casefold() for header in candidate_headers]
        if (
            any(header.startswith("player 1") for header in normalized)
            and any(header.startswith("player 2") for header in normalized)
            and "reported" in normalized
            and "result" in normalized
        ):
            table, headers = candidate, candidate_headers
            break
    if table is None:
        return []
    normalized_headers = [header.casefold() for header in headers]
    positions = {
        "tournament": normalized_headers.index("tournament"),
        "round": normalized_headers.index("round"),
        "player1": next(
            index for index, header in enumerate(normalized_headers)
            if header.startswith("player 1")
        ),
        "player2": next(
            index for index, header in enumerate(normalized_headers)
            if header.startswith("player 2")
        ),
        "date": normalized_headers.index("date"),
        "reported": normalized_headers.index("reported"),
        "result": normalized_headers.index("result"),
    }
    results = []
    for row in table.find_all("tr"):
        cells = [_text(cell.get_text(" ", strip=True)) for cell in row.find_all("td")]
        if len(cells) < len(headers):
            continue
        offset = len(cells) - len(headers)
        p1, p1_character = split_player_character(cells[positions["player1"] + offset])
        p2, p2_character = split_player_character(cells[positions["player2"] + offset])
        if not p1 or not p2:
            continue
        tournament = cells[positions["tournament"] + offset]
        round_name = cells[positions["round"] + offset]
        results.append({
            "tournament": tournament,
            "round": round_name,
            "p1": p1,
            "p2": p2,
            "player1": p1,
            "player2": p2,
            "p1_character": p1_character,
            "p2_character": p2_character,
            "player1_character": p1_character,
            "player2_character": p2_character,
            "date": cells[positions["date"] + offset],
            "reported": cells[positions["reported"] + offset],
            "result": cells[positions["result"] + offset],
            "tour": _tour_from_tournament(tournament),
            "source_url": ALL_RESULTS_URL,
        })
    return enrich_event_metadata(results)


def parse_tournaments_html(
    html: str,
    *,
    tour: str | None = None,
) -> list[dict[str, Any]]:
    """Extract the year-filterable tournament schedule from the WTSL page."""
    soup = BeautifulSoup(html, "html.parser")
    tournaments: list[dict[str, Any]] = []
    for table in soup.find_all("table"):
        headers = [
            _text(cell.get_text(" ", strip=True)).casefold()
            for cell in table.find_all("th")
        ]
        required = {"tournament", "category", "start date"}
        if not required.issubset(headers):
            continue
        positions = {header: headers.index(header) for header in required}
        for row in table.find_all("tr"):
            cells = row.find_all("td")
            if len(cells) < len(headers):
                continue
            tournament_cell = cells[positions["tournament"]]
            name = _text(tournament_cell.get_text(" ", strip=True))
            category = _text(cells[positions["category"]].get_text(" ", strip=True))
            start_date = _text(
                cells[positions["start date"]].get_text(" ", strip=True)
            )
            if not name or not category or not start_date:
                continue
            link = tournament_cell.find("a")
            href = link.get("href") if link and link.get("href") else ""
            tournaments.append({
                "tournament": name,
                "category": category,
                "start_date": start_date,
                "tour": (
                    tour.casefold()
                    if tour
                    else ("wta" if re.search(r"_F(?:_|$)", href) else "atp")
                ),
                "surface": _text(
                    cells[headers.index("surface")].get_text(" ", strip=True)
                )
                if "surface" in headers
                else None,
                "source_url": (
                    href or TOURNAMENTS_URL
                ),
            })
    return tournaments


def _schedule_cache_path(year: int | None, tour: str) -> Path:
    suffix = str(year) if year is not None else "current"
    return TOURNAMENTS_CACHE_PATH.with_name(
        f"{TOURNAMENTS_CACHE_PATH.stem}_{tour}_{suffix}.json"
    )


def _schedule_url(year: int | None, tour: str) -> str:
    tour_tag = "TE4_(F)" if tour.casefold() == "wta" else "TE4"
    query = (
        f"year={year}&tour={tour_tag}"
        if year is not None
        else f"tour={tour_tag}"
    )
    return f"{TOURNAMENTS_URL}?{query}"


def _load_schedule_cache(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    return data if isinstance(data, list) else []


def _save_schedule_cache(
    path: Path,
    tournaments: list[dict[str, Any]],
) -> None:
    temporary = path.with_suffix(".tmp")
    temporary.write_text(
        json.dumps(tournaments, ensure_ascii=False, separators=(",", ":")),
        encoding="utf-8",
    )
    os.replace(temporary, path)


async def get_tournament_schedule(
    *,
    year: int | None = None,
    tour: str = "atp",
    force_refresh: bool = False,
    allow_stale: bool = False,
) -> list[dict[str, Any]]:
    """Load the tournament schedule, optionally filtered to one calendar year."""
    global _schedule_memory, _schedule_loaded_at
    tour_key = "wta" if tour.casefold() == "wta" else "atp"
    cache_key = f"{tour_key}:{year if year is not None else 'current'}"
    cache_path = _schedule_cache_path(year, tour_key)
    now = time.time()
    if (
        not force_refresh
        and cache_key in _schedule_memory
        and now - _schedule_loaded_at.get(cache_key, 0) < CACHE_TTL_SECONDS
    ):
        return list(_schedule_memory[cache_key])
    async with _schedule_lock:
        now = time.time()
        if (
            not force_refresh
            and cache_key in _schedule_memory
            and now - _schedule_loaded_at.get(cache_key, 0) < CACHE_TTL_SECONDS
        ):
            loaded = _schedule_memory[cache_key]
        else:
            loaded: list[dict[str, Any]] = []
            if cache_path.exists():
                try:
                    loaded = await asyncio.to_thread(
                        _load_schedule_cache,
                        cache_path,
                    )
                except Exception:
                    loaded = []
            cache_age = (
                now - cache_path.stat().st_mtime
                if cache_path.exists()
                else None
            )
            if not force_refresh and loaded and (
                allow_stale or (cache_age is not None and cache_age < CACHE_TTL_SECONDS)
            ):
                pass
            else:
                try:
                    timeout = aiohttp.ClientTimeout(total=60, connect=20, sock_read=45)
                    async with aiohttp.ClientSession(timeout=timeout) as session:
                        async with session.get(
                            _schedule_url(year, tour_key)
                        ) as response:
                            response.raise_for_status()
                            page = await response.text()
                    parsed = await asyncio.to_thread(
                        parse_tournaments_html,
                        page,
                        tour=tour_key,
                    )
                    if parsed:
                        loaded = parsed
                        await asyncio.to_thread(
                            _save_schedule_cache,
                            cache_path,
                            loaded,
                        )
                except Exception as exc:
                    if not loaded:
                        print(
                            f"[WTSL Schedule] unavailable: "
                            f"{type(exc).__name__}: {exc}",
                            flush=True,
                        )
            _schedule_memory[cache_key] = loaded
            _schedule_loaded_at[cache_key] = now
        return list(loaded)


def _load_disk_cache() -> list[dict[str, Any]]:
    with gzip.open(FULL_CACHE_PATH, "rt", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, list) or not data:
        raise ValueError("WTSL full-results cache is empty or invalid")
    return data


def _save_caches(results: list[dict[str, Any]]) -> None:
    full_temp = FULL_CACHE_PATH.with_suffix(FULL_CACHE_PATH.suffix + ".tmp")
    with gzip.open(full_temp, "wt", encoding="utf-8") as handle:
        json.dump(results, handle, ensure_ascii=False, separators=(",", ":"))
    os.replace(full_temp, FULL_CACHE_PATH)
    recent_temp = RECENT_CACHE_PATH.with_suffix(".tmp")
    recent_temp.write_text(
        json.dumps(results[:RECENT_RESULT_LIMIT], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    os.replace(recent_temp, RECENT_CACHE_PATH)


def _fingerprint(result: dict[str, Any]) -> tuple[str, ...]:
    return tuple(
        _text(result.get(field)).casefold()
        for field in ("tournament", "round", "p1", "p2", "date", "result")
    )


def _correction_identity(result: dict[str, Any]) -> tuple[str, ...] | None:
    """Identify a match independently of mutable event/score labels.

    WTSL occasionally corrects an event name or score after a partial refresh.
    Date, unordered players, and round are the most stable identity available
    in the feed.  Only unique identities are used by the merge below so two
    same-day meetings are never collapsed accidentally.
    """
    date = _text(result.get("date")).casefold()
    round_name = _text(result.get("round")).casefold()
    players = sorted(
        (
            _text(result.get("p1") or result.get("player1")).casefold(),
            _text(result.get("p2") or result.get("player2")).casefold(),
        )
    )
    if not date or not round_name or not all(players):
        return None
    return date, *players, round_name


def _merge_without_history_loss(
    fresh: list[dict[str, Any]],
    stored: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], bool]:
    """Preserve known history when upstream unexpectedly becomes partial."""
    if not stored:
        return fresh, False
    fresh_keys = {_fingerprint(result) for result in fresh}
    stored_keys = {_fingerprint(result) for result in stored}
    retained_ratio = len(fresh_keys & stored_keys) / max(len(stored_keys), 1)
    appears_partial = (
        len(fresh_keys) < len(stored_keys) * 0.9
        or retained_ratio < 0.9
    )
    if not appears_partial:
        return fresh, False
    fresh_by_correction: dict[tuple[str, ...], list[dict[str, Any]]] = (
        defaultdict(list)
    )
    for result in fresh:
        identity = _correction_identity(result)
        if identity is not None:
            fresh_by_correction[identity].append(result)

    merged = []
    for result in fresh:
        stored_match = next(
            (
                candidate for candidate in stored
                if _fingerprint(candidate) == _fingerprint(result)
            ),
            None,
        )
        if stored_match is not None:
            merged.append({**stored_match, **result})
        else:
            merged.append(result)

    for result in stored:
        if _fingerprint(result) in fresh_keys:
            continue
        identity = _correction_identity(result)
        if identity is not None and len(fresh_by_correction.get(identity, [])) == 1:
            # A fresh row with the same stable match identity is a correction
            # of this stored row, even if tournament or score text changed.
            continue
        merged.append(result)
    return merged, True


def _player_page_result_rows(
    player_name: str,
    tour: str,
    recent_matches: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Turn the fast player-page history into normalised shared-feed rows."""
    tour_label = "WTA" if tour.casefold() == "wta" else "ATP"
    rows = []
    for match in recent_matches:
        if not isinstance(match, dict):
            continue
        opponent = _text(match.get("opponent"))
        date = _text(match.get("date"))
        if not opponent or not date or not _text(match.get("result")):
            continue
        year_match = re.search(r"(20\d{2})$", date)
        year = year_match.group(1) if year_match else ""
        tournament_name = _text(match.get("tournament"))
        tournament = (
            f"Tennis Elbow 4 ({tour_label} Characters) - "
            f"{tournament_name} {year}".strip()
        )
        rows.append({
            "tournament": tournament,
            "round": _text(match.get("round")),
            "p1": _text(player_name),
            "p2": opponent,
            "player1": _text(player_name),
            "player2": opponent,
            "date": date,
            "result": _text(match.get("result")),
            "tour": tour.casefold(),
            "source_url": "https://playwtsl.com/TE4/pages/player_page.php",
        })
    return enrich_event_metadata(rows)


async def merge_player_recent_results(
    player_name: str,
    tour: str,
    recent_matches: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Merge current player-page rows into the durable shared history.

    This is deliberately network-free.  It lets a fast player refresh add new
    matches and replace corrected rows without waiting for the slow full feed.
    """
    global _memory_results, _memory_loaded_at
    fresh = _player_page_result_rows(player_name, tour, recent_matches)
    if not fresh:
        return _memory_results or []
    async with _refresh_lock:
        stored = _memory_results
        if stored is None:
            if FULL_CACHE_PATH.exists():
                try:
                    stored = await asyncio.to_thread(_load_disk_cache)
                except Exception:
                    stored = []
            if not stored:
                stored = await asyncio.to_thread(_load_durable_cache)
        merged, _ = _merge_without_history_loss(fresh, stored or [])
        merged = enrich_event_metadata(merged)
        await asyncio.to_thread(_save_caches, merged)
        await asyncio.to_thread(_save_durable_cache, merged)
        _memory_results = merged
        if not _memory_loaded_at:
            _memory_loaded_at = time.time()
        return merged


def _load_durable_cache() -> list[dict[str, Any]]:
    try:
        from matchlog_store import load_wtsl_results_cache
        return load_wtsl_results_cache()
    except Exception:
        return []


def _save_durable_cache(results: list[dict[str, Any]]) -> None:
    try:
        from matchlog_store import save_wtsl_results_cache
        save_wtsl_results_cache(results)
    except Exception as exc:
        print(
            f"[WTSL Results] PostgreSQL cache unavailable: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )


async def _background_full_refresh() -> None:
    try:
        await get_all_results(force_refresh=True)
    except Exception as exc:
        print(
            f"[WTSL Results] background full refresh unavailable: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )


def _schedule_background_full_refresh() -> None:
    global _background_refresh_task
    if time.time() - _last_live_refresh_at < CACHE_TTL_SECONDS:
        return
    if _background_refresh_task is not None and not _background_refresh_task.done():
        return
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return
    _background_refresh_task = loop.create_task(_background_full_refresh())


async def get_all_results(
    *,
    force_refresh: bool = False,
    allow_stale: bool = False,
) -> list[dict[str, Any]]:
    global _memory_results, _memory_loaded_at, _last_live_refresh_at
    now = time.time()
    if (
        force_refresh
        and _memory_results
        and now - _last_live_refresh_at < 30
    ):
        return _memory_results
    if (
        not force_refresh
        and _memory_results
        and now - _memory_loaded_at < CACHE_TTL_SECONDS
    ):
        return _memory_results
    if allow_stale:
        # Dashboard requests must not queue behind a slow live refresh when a
        # complete restart-safe cache already exists.
        stored: list[dict[str, Any]] = []
        if FULL_CACHE_PATH.exists():
            try:
                stored = await asyncio.to_thread(_load_disk_cache)
            except Exception:
                stored = []
        if not stored:
            stored = await asyncio.to_thread(_load_durable_cache)
            if stored:
                await asyncio.to_thread(_save_caches, stored)
        if stored:
            stored = enrich_event_metadata(stored)
            _memory_results = stored
            _memory_loaded_at = now
            _schedule_background_full_refresh()
            return stored
    async with _refresh_lock:
        now = time.time()
        if (
            force_refresh
            and _memory_results
            and now - _last_live_refresh_at < 30
        ):
            return _memory_results
        if (
            not force_refresh
            and _memory_results
            and now - _memory_loaded_at < CACHE_TTL_SECONDS
        ):
            return _memory_results
        stored: list[dict[str, Any]] = []
        if FULL_CACHE_PATH.exists():
            try:
                stored = await asyncio.to_thread(_load_disk_cache)
            except Exception:
                stored = []
        if not stored:
            stored = await asyncio.to_thread(_load_durable_cache)
            if stored:
                await asyncio.to_thread(_save_caches, stored)
        if allow_stale:
            if stored:
                stored = enrich_event_metadata(stored)
                _memory_results = stored
                _memory_loaded_at = now
                _schedule_background_full_refresh()
            return stored
        if not force_refresh and stored and FULL_CACHE_PATH.exists():
            age = now - FULL_CACHE_PATH.stat().st_mtime
            if age < CACHE_TTL_SECONDS:
                stored = enrich_event_metadata(stored)
                _memory_results = stored
                _memory_loaded_at = now
                return _memory_results
        try:
            timeout = aiohttp.ClientTimeout(total=240, connect=30, sock_read=180)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(ALL_RESULTS_URL) as response:
                    response.raise_for_status()
                    html = await response.text()
            parsed = await asyncio.to_thread(parse_all_results_html, html)
            if not parsed:
                raise RuntimeError("WTSL full-results feed returned no matches")
            accepted, partial = _merge_without_history_loss(parsed, stored)
            accepted = enrich_event_metadata(accepted)
            if partial:
                print(
                    "[WTSL Results] Upstream feed appears truncated; merged new "
                    f"results into {len(stored)} stored historical records",
                    flush=True,
                )
            await asyncio.to_thread(_save_caches, accepted)
            await asyncio.to_thread(_save_durable_cache, accepted)
            _memory_results = accepted
            _memory_loaded_at = now
            _last_live_refresh_at = now
            return accepted
        except Exception:
            if _memory_results:
                return _memory_results
            if FULL_CACHE_PATH.exists():
                _memory_results = await asyncio.to_thread(_load_disk_cache)
                _memory_loaded_at = now
                return _memory_results
            durable = await asyncio.to_thread(_load_durable_cache)
            if durable:
                _memory_results = durable
                _memory_loaded_at = now
                await asyncio.to_thread(_save_caches, durable)
                return durable
            raise


def favorite_character(
    results: list[dict[str, Any]],
    player_name: str,
    *,
    tour: str | None = None,
) -> dict[str, Any] | None:
    wanted = _text(player_name).casefold()
    counts: dict[str, int] = {}
    labels: dict[str, str] = {}
    for result in results:
        if tour and result.get("tour") != tour:
            continue
        if _text(result.get("p1")).casefold() == wanted:
            character = _text(result.get("p1_character"))
        elif _text(result.get("p2")).casefold() == wanted:
            character = _text(result.get("p2_character"))
        else:
            continue
        if character:
            key = character.casefold()
            counts[key] = counts.get(key, 0) + 1
            labels.setdefault(key, character)
    if not counts:
        return None
    key = min(counts, key=lambda item: (-counts[item], labels[item].casefold()))
    total = sum(counts.values())
    return {
        "character": labels[key],
        "count": counts[key],
        "percentage": counts[key] / total,
    }

def _date_key(value: Any) -> tuple[int, int, int]:
    text = _text(value)
    if "T" in text or " " in text:
        text = re.split(r"[T ]", text, maxsplit=1)[0]
    for format_string in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            parsed = time.strptime(text, format_string)
            return parsed.tm_year, parsed.tm_mon, parsed.tm_mday
        except ValueError:
            continue
    return 0, 0, 0

def enrich_event_metadata(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Attach stable event start dates and categories to official result rows.

    The all-results feed is complete and winner-oriented, but only exposes a
    match date.  The earliest played date for one tournament label is the
    authoritative start-date evidence available in that feed.  Grouping by
    the full label (and tour) is important: two same-category events can start
    on the same day and must not be collapsed into one court.
    """
    starts: dict[tuple[str, str], tuple[int, int, int]] = {}
    for result in results:
        tournament = _text(result.get("tournament"))
        if not tournament:
            continue
        key = (
            str(result.get("tour") or _tour_from_tournament(tournament)).casefold(),
            tournament.casefold(),
        )
        date_key = _date_key(result.get("date"))
        if date_key == (0, 0, 0):
            continue
        previous = starts.get(key)
        if previous is None or date_key < previous:
            starts[key] = date_key

    enriched: list[dict[str, Any]] = []
    for result in results:
        item = dict(result)
        tournament = _text(item.get("tournament"))
        tour = str(item.get("tour") or _tour_from_tournament(tournament)).casefold()
        key = (tour, tournament.casefold())
        start = starts.get(key)
        if start is not None and not _text(item.get("event_start_date")):
            item["event_start_date"] = "%04d-%02d-%02d" % start
        if tournament and not _text(item.get("event_category")):
            item["event_category"] = tournament_category(tournament)
        enriched.append(item)
    return enriched
