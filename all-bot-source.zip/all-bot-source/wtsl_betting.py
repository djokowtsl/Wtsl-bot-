"""Durable virtual-currency betting storage for verified WTSL members."""
from __future__ import annotations

import os
import re
import unicodedata
from decimal import Decimal
from typing import Any

import psycopg

INITIAL_BALANCE = Decimal("1000.00")
POOL_TAKEOUT = Decimal("0.05")
MIN_POOL_ODDS = Decimal("1.000")
HOUSE_RESERVE_INITIAL = Decimal("100000.00")
REFERRAL_REWARD = Decimal("25.00")
REFERRAL_MIN_STAKE = Decimal("25.00")
REFERRAL_REMINDER_HOURS = 3


def pool_decimal_odds(total_pool: Decimal, selected_pool: Decimal) -> Decimal:
    """Return pool odds without allowing a winning bet to lose its stake."""
    total_pool = Decimal(total_pool)
    selected_pool = Decimal(selected_pool)
    if total_pool <= 0 or selected_pool <= 0:
        raise ValueError("Pool odds require positive pool amounts")
    return max(
        MIN_POOL_ODDS,
        total_pool * (Decimal("1") - POOL_TAKEOUT) / selected_pool,
    ).quantize(Decimal("0.01"))


def house_adjusted_odds(official_odds: Decimal) -> Decimal:
    """Return the deterministic placement quote after the 5% house takeout."""
    official_odds = Decimal(str(official_odds))
    if official_odds <= 0:
        raise ValueError("Official odds must be positive")
    return max(
        MIN_POOL_ODDS,
        official_odds / (Decimal("1") + POOL_TAKEOUT),
    ).quantize(Decimal("0.01"))


def pool_distributable(total_pool: Decimal, winning_pool: Decimal) -> Decimal:
    """Return the winner pool payout while protecting the winning stake."""
    total_pool = Decimal(total_pool)
    winning_pool = Decimal(winning_pool)
    if total_pool <= 0 or winning_pool <= 0:
        return Decimal("0.00")
    return max(
        (total_pool * (Decimal("1") - POOL_TAKEOUT)).quantize(
            Decimal("0.01")
        ),
        winning_pool,
    )


def hybrid_reserve_liability(stake: Decimal, guaranteed_return: Decimal) -> Decimal:
    """Return the maximum house top-up needed for a guaranteed bet return."""
    stake = Decimal(str(stake)).quantize(Decimal("0.01"))
    guaranteed_return = Decimal(str(guaranteed_return)).quantize(Decimal("0.01"))
    return max(guaranteed_return - stake, Decimal("0.00"))


def hybrid_guaranteed_odds(
    official_odds: Decimal,
    pool_odds: Decimal | None,
) -> Decimal:
    """Use the official WTSL quote as the floor, with pool upside."""
    official_floor = house_adjusted_odds(official_odds)
    if pool_odds is None:
        return official_floor
    return max(official_floor, Decimal(str(pool_odds))).quantize(
        Decimal("0.01")
    )


def hybrid_settlement_return(
    stake: Decimal,
    guaranteed_return: Decimal,
    pool_return: Decimal,
) -> Decimal:
    """Pay the guaranteed minimum or the higher closing-pool return."""
    stake = Decimal(str(stake)).quantize(Decimal("0.01"))
    guaranteed_return = Decimal(str(guaranteed_return)).quantize(Decimal("0.01"))
    pool_return = Decimal(str(pool_return)).quantize(Decimal("0.01"))
    return max(stake, guaranteed_return, pool_return).quantize(Decimal("0.01"))


def normalized_player_key(value: Any) -> str:
    """Normalize a canonical WTSL player label for identity comparisons."""
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return "".join(char for char in text if char.isalnum())


def fixture_tour(value: Any) -> str:
    normalized = normalized_player_key(value)
    if (
        "wta" in normalized
        or normalized.endswith("f")
        or "female" in normalized
    ):
        return "wta"
    return "atp"


def self_match_reason(
    verified_player_links: dict[str, str] | None,
    fixture_tour_name: Any,
    player_one: Any,
    player_two: Any,
) -> str | None:
    """Return a user-facing reason when a verified player is in the fixture."""
    if not verified_player_links:
        return None
    tour = fixture_tour(fixture_tour_name)
    linked = verified_player_links.get(tour)
    if not linked:
        return None
    linked_key = normalized_player_key(linked)
    if linked_key in {
        normalized_player_key(player_one),
        normalized_player_key(player_two),
    }:
        return (
            "You cannot bet on your own WTSL match. "
            f"Your verified {tour.upper()} identity is **{linked}**."
        )
    return None


def bet_return_breakdown(
    stake: Decimal,
    official_odds: Decimal,
    pool_odds: Decimal,
    guaranteed_odds: Decimal,
) -> dict[str, Decimal]:
    """Return gross payout, house cut, and guaranteed net payout."""
    stake = Decimal(str(stake)).quantize(Decimal("0.01"))
    official_odds = Decimal(str(official_odds))
    pool_odds = Decimal(str(pool_odds))
    guaranteed_odds = Decimal(str(guaranteed_odds))
    official_floor = house_adjusted_odds(official_odds)
    if pool_odds > official_floor:
        gross_odds = pool_odds / (Decimal("1") - POOL_TAKEOUT)
    else:
        gross_odds = official_odds
    gross_return = (stake * gross_odds).quantize(Decimal("0.01"))
    guaranteed_return = (stake * guaranteed_odds).quantize(Decimal("0.01"))
    return {
        "gross_return": gross_return,
        "house_cut": max(
            gross_return - guaranteed_return,
            Decimal("0.00"),
        ).quantize(Decimal("0.01")),
        "guaranteed_return": guaranteed_return,
    }


def _connect():
    database_url = os.environ.get("DATABASE_URL")
    if not database_url:
        raise RuntimeError("DATABASE_URL is not available")
    return psycopg.connect(database_url)


def ensure_tables(cursor) -> None:
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_betting_accounts (
            discord_user_id BIGINT PRIMARY KEY,
            balance NUMERIC(20, 2) NOT NULL DEFAULT 1000.00,
            total_staked NUMERIC(20, 2) NOT NULL DEFAULT 0.00,
            total_returned NUMERIC(20, 2) NOT NULL DEFAULT 0.00,
            total_profit NUMERIC(20, 2) NOT NULL DEFAULT 0.00,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_betting_fixtures (
            fixture_key TEXT PRIMARY KEY,
            season TEXT NOT NULL,
            tour TEXT NOT NULL,
            tournament TEXT NOT NULL,
            player_one_id TEXT NOT NULL,
            player_one TEXT NOT NULL,
            player_one_avatar TEXT,
            player_two_id TEXT NOT NULL,
            player_two TEXT NOT NULL,
            player_two_avatar TEXT,
            odds_one NUMERIC(10, 3) NOT NULL,
            odds_two NUMERIC(10, 3) NOT NULL,
            scheduled_at TEXT,
            round_deadline TIMESTAMPTZ,
            status TEXT NOT NULL DEFAULT 'open',
            winner_id TEXT,
            result_note TEXT,
            settled_at TIMESTAMPTZ,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """
    )
    # These columns were added after the first betting rollout. Keep the
    # migration idempotent so existing installations retain their fixtures.
    cursor.execute(
        """
        ALTER TABLE wtsl_betting_fixtures
        ADD COLUMN IF NOT EXISTS player_one_avatar TEXT
        """
    )
    cursor.execute(
        """
        ALTER TABLE wtsl_betting_fixtures
        ADD COLUMN IF NOT EXISTS player_two_avatar TEXT
        """
    )
    cursor.execute(
        """
        ALTER TABLE wtsl_betting_fixtures
        ADD COLUMN IF NOT EXISTS round_deadline TIMESTAMPTZ
        """
    )
    cursor.execute(
        """
        ALTER TABLE wtsl_betting_fixtures
        ADD COLUMN IF NOT EXISTS tournament_id TEXT
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_betting_bets (
            bet_id BIGSERIAL PRIMARY KEY,
            fixture_key TEXT NOT NULL REFERENCES wtsl_betting_fixtures(fixture_key),
            discord_user_id BIGINT NOT NULL,
            selection_id TEXT NOT NULL,
            selection_name TEXT NOT NULL,
            odds NUMERIC(10, 3) NOT NULL,
            stake NUMERIC(20, 2) NOT NULL CHECK (stake > 0),
            potential_return NUMERIC(20, 2) NOT NULL,
            status TEXT NOT NULL DEFAULT 'open',
            return_amount NUMERIC(20, 2) NOT NULL DEFAULT 0.00,
            placed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            settled_at TIMESTAMPTZ,
            UNIQUE (fixture_key, discord_user_id)
        )
        """
    )
    cursor.execute(
        """
        ALTER TABLE wtsl_betting_bets
        ADD COLUMN IF NOT EXISTS reserve_liability NUMERIC(20, 2)
            NOT NULL DEFAULT 0.00
        """
    )
    # Pool betting permits one open ticket on each side of a fixture. Replace
    # the original one-ticket-per-fixture constraint while preserving a
    # duplicate-selection guard.
    cursor.execute(
        """
        ALTER TABLE wtsl_betting_bets
        DROP CONSTRAINT IF EXISTS wtsl_betting_bets_fixture_key_discord_user_id_key
        """
    )
    cursor.execute(
        """
        CREATE UNIQUE INDEX IF NOT EXISTS
            wtsl_betting_bets_fixture_user_selection_idx
        ON wtsl_betting_bets (fixture_key, discord_user_id, selection_id)
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_betting_parlays (
            parlay_id BIGSERIAL PRIMARY KEY,
            discord_user_id BIGINT NOT NULL,
            stake NUMERIC(20, 2) NOT NULL CHECK (stake > 0),
            combined_odds NUMERIC(20, 6) NOT NULL,
            potential_return NUMERIC(20, 2) NOT NULL,
            status TEXT NOT NULL DEFAULT 'open',
            return_amount NUMERIC(20, 2) NOT NULL DEFAULT 0.00,
            placed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            settled_at TIMESTAMPTZ
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_betting_parlay_legs (
            parlay_id BIGINT NOT NULL
                REFERENCES wtsl_betting_parlays(parlay_id),
            fixture_key TEXT NOT NULL REFERENCES wtsl_betting_fixtures(fixture_key),
            selection_id TEXT NOT NULL,
            selection_name TEXT NOT NULL,
            odds NUMERIC(10, 3) NOT NULL,
            PRIMARY KEY (parlay_id, fixture_key)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_betting_house_reserve (
            reserve_id SMALLINT PRIMARY KEY CHECK (reserve_id = 1),
            balance NUMERIC(20, 2) NOT NULL DEFAULT 100000.00,
            reserved_liability NUMERIC(20, 2) NOT NULL DEFAULT 0.00,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """
    )
    cursor.execute(
        """
        INSERT INTO wtsl_betting_house_reserve (reserve_id, balance)
        VALUES (1, %s)
        ON CONFLICT (reserve_id) DO NOTHING
        """,
        (HOUSE_RESERVE_INITIAL,),
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_betting_notification_receipts (
            receipt_key TEXT PRIMARY KEY,
            recipient_user_id BIGINT NOT NULL,
            notification_type TEXT NOT NULL,
            claimed_at TIMESTAMPTZ,
            sent_at TIMESTAMPTZ,
            attempts INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_betting_referrals (
            referral_id BIGSERIAL PRIMARY KEY,
            referrer_user_id BIGINT NOT NULL,
            tour TEXT NOT NULL CHECK (tour IN ('atp', 'wta')),
            player_key TEXT NOT NULL,
            player_name TEXT NOT NULL,
            referred_user_id BIGINT,
            status TEXT NOT NULL DEFAULT 'pending_identity',
            reward_amount NUMERIC(20, 2) NOT NULL DEFAULT 25.00,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            verified_at TIMESTAMPTZ,
            last_reminded_at TIMESTAMPTZ,
            rewarded_at TIMESTAMPTZ,
            source_kind TEXT,
            source_id BIGINT
        )
        """
    )
    cursor.execute(
        """
        CREATE UNIQUE INDEX IF NOT EXISTS
            wtsl_betting_referrals_tour_player_idx
        ON wtsl_betting_referrals (tour, player_key)
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_betting_referral_rewards (
            reward_id BIGSERIAL PRIMARY KEY,
            referral_id BIGINT NOT NULL UNIQUE
                REFERENCES wtsl_betting_referrals(referral_id),
            referrer_user_id BIGINT NOT NULL,
            referred_user_id BIGINT NOT NULL,
            amount NUMERIC(20, 2) NOT NULL,
            source_kind TEXT NOT NULL,
            source_id BIGINT NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """
    )


def seed_account(discord_user_id: int) -> bool:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                INSERT INTO wtsl_betting_accounts (discord_user_id)
                VALUES (%s)
                ON CONFLICT (discord_user_id) DO NOTHING
                RETURNING discord_user_id
                """,
                (int(discord_user_id),),
            )
            return cursor.fetchone() is not None


def reset_all_betting_data() -> None:
    """Clear all betting history and restore every existing account."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute("DELETE FROM wtsl_betting_parlay_legs")
            cursor.execute("DELETE FROM wtsl_betting_bets")
            cursor.execute("DELETE FROM wtsl_betting_parlays")
            cursor.execute("DELETE FROM wtsl_betting_fixtures")
            cursor.execute(
                """
                UPDATE wtsl_betting_accounts
                SET balance = %s,
                    total_staked = 0.00,
                    total_returned = 0.00,
                    total_profit = 0.00,
                    updated_at = now()
                """,
                (INITIAL_BALANCE,),
            )
            cursor.execute(
                """
                UPDATE wtsl_betting_house_reserve
                SET balance = %s,
                    reserved_liability = 0.00,
                    updated_at = now()
                WHERE reserve_id = 1
                """,
                (HOUSE_RESERVE_INITIAL,),
            )


def sync_fixture(fixture: dict[str, Any]) -> None:
    odds = fixture["odds"]
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                INSERT INTO wtsl_betting_fixtures (
                    fixture_key, season, tour, tournament,
                    tournament_id,
                    player_one_id, player_one, player_two_id, player_two,
                    player_one_avatar, player_two_avatar,
                    odds_one, odds_two, scheduled_at, round_deadline, updated_at
                )
                VALUES (
                    %(fixture_key)s, %(season)s, %(tour)s, %(tournament)s,
                    %(tournament_id)s,
                    %(player_one_id)s, %(player_one)s, %(player_two_id)s,
                    %(player_two)s, %(player_one_avatar)s, %(player_two_avatar)s,
                    %(odds_one)s, %(odds_two)s,
                    %(scheduled_at)s, %(round_deadline)s, now()
                )
                ON CONFLICT (fixture_key) DO UPDATE SET
                    season = EXCLUDED.season,
                    tour = EXCLUDED.tour,
                    tournament = EXCLUDED.tournament,
                    tournament_id = COALESCE(
                        EXCLUDED.tournament_id, wtsl_betting_fixtures.tournament_id
                    ),
                    player_one_id = EXCLUDED.player_one_id,
                    player_one = EXCLUDED.player_one,
                    player_one_avatar = COALESCE(
                        EXCLUDED.player_one_avatar, wtsl_betting_fixtures.player_one_avatar
                    ),
                    player_two_id = EXCLUDED.player_two_id,
                    player_two = EXCLUDED.player_two,
                    player_two_avatar = COALESCE(
                        EXCLUDED.player_two_avatar, wtsl_betting_fixtures.player_two_avatar
                    ),
                    odds_one = EXCLUDED.odds_one,
                    odds_two = EXCLUDED.odds_two,
                    scheduled_at = EXCLUDED.scheduled_at,
                    round_deadline = EXCLUDED.round_deadline,
                    updated_at = now()
                """,
                {
                    "fixture_key": fixture["key"],
                    "season": str(fixture.get("season") or ""),
                    "tour": str(fixture.get("tour") or ""),
                    "tournament": str(fixture.get("tournament") or ""),
                    "tournament_id": str(fixture.get("tournament_id") or "") or None,
                    "player_one_id": str(fixture["first_id"]),
                    "player_one": str(fixture["first_name"]),
                    "player_one_avatar": fixture.get("first_avatar"),
                    "player_two_id": str(fixture["second_id"]),
                    "player_two": str(fixture["second_name"]),
                    "player_two_avatar": fixture.get("second_avatar"),
                    "odds_one": Decimal(str(odds[0])),
                    "odds_two": Decimal(str(odds[1])),
                    "scheduled_at": fixture.get("scheduled_at"),
                    "round_deadline": fixture.get("round_deadline"),
                },
            )


def list_open_fixtures() -> list[dict[str, Any]]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                SELECT fixture_key, season, tour, tournament,
                       tournament_id,
                       player_one_id, player_one, player_one_avatar,
                       player_two_id, player_two, player_two_avatar,
                       odds_one, odds_two, scheduled_at, round_deadline, status,
                       COALESCE((
                           SELECT SUM(b.stake)
                           FROM wtsl_betting_bets b
                           WHERE b.fixture_key = f.fixture_key
                             AND b.status = 'open'
                       ), 0.00) AS pool_total,
                       COALESCE((
                           SELECT SUM(b.stake)
                           FROM wtsl_betting_bets b
                           WHERE b.fixture_key = f.fixture_key
                             AND b.selection_id = f.player_one_id
                             AND b.status = 'open'
                       ), 0.00) AS pool_one,
                       COALESCE((
                           SELECT SUM(b.stake)
                           FROM wtsl_betting_bets b
                           WHERE b.fixture_key = f.fixture_key
                             AND b.selection_id = f.player_two_id
                             AND b.status = 'open'
                       ), 0.00) AS pool_two
                FROM wtsl_betting_fixtures f
                WHERE f.status = 'open'
                ORDER BY f.scheduled_at NULLS LAST, f.tournament, f.fixture_key
                """
            )
            columns = [
                "key", "season", "tour", "tournament",
                "tournament_id",
                "first_id", "first_name", "first_avatar",
                "second_id", "second_name", "second_avatar",
                "odds_one", "odds_two", "scheduled_at", "round_deadline", "status",
                "pool_total", "pool_one", "pool_two",
            ]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]


def list_recent_settled_fixtures(limit: int = 10) -> list[dict[str, Any]]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                SELECT f.fixture_key, f.season, f.tour, f.tournament,
                       f.player_one_id, f.player_one, f.player_one_avatar,
                       f.player_two_id, f.player_two, f.player_two_avatar,
                       f.odds_one, f.odds_two, f.scheduled_at,
                       f.round_deadline, f.status,
                       f.winner_id, f.result_note, f.settled_at,
                       COALESCE(b.single_bets, 0)
                           + COALESCE(p.parlay_legs, 0) AS total_bets,
                       COALESCE(b.single_first_bets, 0)
                           + COALESCE(p.parlay_first_legs, 0) AS first_bets,
                       COALESCE(b.single_second_bets, 0)
                           + COALESCE(p.parlay_second_legs, 0) AS second_bets,
                       COALESCE(b.pool_total, 0.00) AS pool_total,
                       COALESCE(b.pool_one, 0.00) AS pool_one,
                       COALESCE(b.pool_two, 0.00) AS pool_two
                FROM wtsl_betting_fixtures f
                LEFT JOIN (
                    SELECT fixture_key,
                           COUNT(*)::int AS single_bets,
                           COUNT(*) FILTER (
                               WHERE selection_id = (
                                   SELECT player_one_id
                                   FROM wtsl_betting_fixtures
                                   WHERE fixture_key = b.fixture_key
                               )
                           )::int AS single_first_bets,
                           COUNT(*) FILTER (
                               WHERE selection_id = (
                                   SELECT player_two_id
                                   FROM wtsl_betting_fixtures
                                   WHERE fixture_key = b.fixture_key
                               )
                           )::int AS single_second_bets,
                           COALESCE(SUM(stake), 0.00) AS pool_total,
                           COALESCE(SUM(stake) FILTER (
                               WHERE selection_id = (
                                   SELECT player_one_id
                                   FROM wtsl_betting_fixtures
                                   WHERE fixture_key = b.fixture_key
                               )
                           ), 0.00) AS pool_one,
                           COALESCE(SUM(stake) FILTER (
                               WHERE selection_id = (
                                   SELECT player_two_id
                                   FROM wtsl_betting_fixtures
                                   WHERE fixture_key = b.fixture_key
                               )
                           ), 0.00) AS pool_two
                    FROM wtsl_betting_bets b
                    GROUP BY fixture_key
                ) b ON b.fixture_key = f.fixture_key
                LEFT JOIN (
                    SELECT l.fixture_key,
                           COUNT(*)::int AS parlay_legs,
                           COUNT(*) FILTER (
                               WHERE l.selection_id = f2.player_one_id
                           )::int AS parlay_first_legs,
                           COUNT(*) FILTER (
                               WHERE l.selection_id = f2.player_two_id
                           )::int AS parlay_second_legs
                    FROM wtsl_betting_parlay_legs l
                    JOIN wtsl_betting_fixtures f2
                      ON f2.fixture_key = l.fixture_key
                    GROUP BY l.fixture_key
                ) p ON p.fixture_key = f.fixture_key
                WHERE f.status = 'settled'
                GROUP BY f.fixture_key, f.season, f.tour, f.tournament,
                         f.player_one_id, f.player_one, f.player_one_avatar,
                         f.player_two_id, f.player_two, f.player_two_avatar,
                         f.odds_one, f.odds_two, f.scheduled_at,
                         f.round_deadline, f.status,
                         f.winner_id, f.result_note, f.settled_at, f.updated_at,
                         b.single_bets, b.single_first_bets,
                         b.single_second_bets, b.pool_total,
                         b.pool_one, b.pool_two, p.parlay_legs,
                         p.parlay_first_legs, p.parlay_second_legs
                ORDER BY f.settled_at DESC NULLS LAST, f.updated_at DESC
                LIMIT %s
                """,
                (max(1, int(limit)),),
            )
            columns = [
                "key", "season", "tour", "tournament",
                "first_id", "first_name", "first_avatar",
                "second_id", "second_name", "second_avatar",
                "odds_one", "odds_two", "scheduled_at", "round_deadline", "status",
                "winner_id", "result_note", "settled_at",
                "total_bets", "first_bets", "second_bets",
                "pool_total", "pool_one", "pool_two",
            ]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]


def get_fixture(fixture_key: str) -> dict[str, Any] | None:
    """Return one fixture with authoritative names and odds."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                SELECT fixture_key, season, tour, tournament,
                       player_one_id, player_one, player_one_avatar,
                       player_two_id, player_two, player_two_avatar,
                       odds_one, odds_two, scheduled_at, round_deadline, status,
                       COALESCE((
                           SELECT SUM(b.stake)
                           FROM wtsl_betting_bets b
                           WHERE b.fixture_key = f.fixture_key
                             AND b.status = 'open'
                       ), 0.00) AS pool_total,
                       COALESCE((
                           SELECT SUM(b.stake)
                           FROM wtsl_betting_bets b
                           WHERE b.fixture_key = f.fixture_key
                             AND b.selection_id = f.player_one_id
                             AND b.status = 'open'
                       ), 0.00) AS pool_one,
                       COALESCE((
                           SELECT SUM(b.stake)
                           FROM wtsl_betting_bets b
                           WHERE b.fixture_key = f.fixture_key
                             AND b.selection_id = f.player_two_id
                             AND b.status = 'open'
                       ), 0.00) AS pool_two
                FROM wtsl_betting_fixtures f
                WHERE f.fixture_key = %s
                """,
                (fixture_key,),
            )
            row = cursor.fetchone()
            if row is None:
                return None
            columns = [
                "key", "season", "tour", "tournament",
                "first_id", "first_name", "first_avatar",
                "second_id", "second_name", "second_avatar",
                "odds_one", "odds_two", "scheduled_at", "round_deadline", "status",
                "pool_total", "pool_one", "pool_two",
            ]
            return dict(zip(columns, row))


def load_account(discord_user_id: int) -> dict[str, Any]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                INSERT INTO wtsl_betting_accounts (discord_user_id)
                VALUES (%s)
                ON CONFLICT (discord_user_id) DO NOTHING
                """,
                (int(discord_user_id),),
            )
            cursor.execute(
                """
                SELECT discord_user_id, balance, total_staked,
                       total_returned, total_profit
                FROM wtsl_betting_accounts
                WHERE discord_user_id = %s
                """,
                (int(discord_user_id),),
            )
            row = cursor.fetchone()
            if row is None:
                raise RuntimeError("Betting account could not be initialized")
            return dict(
                zip(
                    (
                        "discord_user_id",
                        "balance",
                        "total_staked",
                        "total_returned",
                        "total_profit",
                    ),
                    row,
                )
            )


def claim_notification_receipt(
    receipt_key: str,
    *,
    recipient_user_id: int,
    notification_type: str,
    stale_minutes: int = 30,
) -> bool:
    """Claim one notification for delivery without duplicating successful sends."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                INSERT INTO wtsl_betting_notification_receipts (
                    receipt_key, recipient_user_id, notification_type, claimed_at,
                    attempts
                )
                VALUES (%s, %s, %s, now(), 1)
                ON CONFLICT (receipt_key) DO NOTHING
                RETURNING receipt_key
                """,
                (
                    str(receipt_key),
                    int(recipient_user_id),
                    str(notification_type),
                ),
            )
            if cursor.fetchone() is not None:
                return True
            cursor.execute(
                """
                UPDATE wtsl_betting_notification_receipts
                SET claimed_at = now(),
                    attempts = attempts + 1,
                    last_error = NULL
                WHERE receipt_key = %s
                  AND sent_at IS NULL
                  AND (
                      claimed_at IS NULL
                      OR claimed_at < now() - (%s * INTERVAL '1 minute')
                  )
                RETURNING receipt_key
                """,
                (str(receipt_key), int(stale_minutes)),
            )
            return cursor.fetchone() is not None


def mark_notification_sent(receipt_key: str) -> None:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                UPDATE wtsl_betting_notification_receipts
                SET sent_at = now(), last_error = NULL
                WHERE receipt_key = %s
                """,
                (str(receipt_key),),
            )


def release_notification_receipt(receipt_key: str, error: str = "") -> None:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                UPDATE wtsl_betting_notification_receipts
                SET claimed_at = NULL, last_error = %s
                WHERE receipt_key = %s AND sent_at IS NULL
                """,
                (str(error)[:1000], str(receipt_key)),
            )


def list_unnotified_winning_bets(limit: int = 100) -> list[dict[str, Any]]:
    """Return settled winning tickets; durable receipts gate actual delivery."""
    requested_limit = max(1, min(int(limit), 500))
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                WITH winning_tickets AS (
                    SELECT
                        'single'::text AS kind,
                        b.bet_id AS ticket_id,
                        b.discord_user_id,
                        b.fixture_key,
                        f.tournament,
                        f.player_one,
                        f.player_two,
                        f.winner_id,
                        f.result_note,
                        b.selection_name,
                        b.stake,
                        b.return_amount,
                        b.placed_at,
                        b.settled_at,
                        ROW_NUMBER() OVER (
                            PARTITION BY b.discord_user_id
                            ORDER BY b.settled_at, b.bet_id
                        ) AS win_number
                    FROM wtsl_betting_bets b
                    JOIN wtsl_betting_fixtures f
                      ON f.fixture_key = b.fixture_key
                    WHERE b.status = 'won'
                    UNION ALL
                    SELECT
                        'parlay'::text AS kind,
                        p.parlay_id AS ticket_id,
                        p.discord_user_id,
                        NULL::text AS fixture_key,
                        'Parlay'::text AS tournament,
                        NULL::text AS player_one,
                        NULL::text AS player_two,
                        NULL::text AS winner_id,
                        NULL::text AS result_note,
                        COALESCE(
                            STRING_AGG(
                                l.selection_name || ' @ ' || f.tournament,
                                ' • ' ORDER BY l.fixture_key
                            ),
                            'Parlay'
                        ) AS selection_name,
                        p.stake,
                        p.return_amount,
                        p.placed_at,
                        p.settled_at,
                        ROW_NUMBER() OVER (
                            PARTITION BY p.discord_user_id
                            ORDER BY p.settled_at, p.parlay_id
                        ) AS win_number
                    FROM wtsl_betting_parlays p
                    LEFT JOIN wtsl_betting_parlay_legs l
                      ON l.parlay_id = p.parlay_id
                    LEFT JOIN wtsl_betting_fixtures f
                      ON f.fixture_key = l.fixture_key
                    WHERE p.status = 'won'
                    GROUP BY p.parlay_id, p.discord_user_id, p.stake,
                             p.return_amount, p.placed_at, p.settled_at
                )
                SELECT w.kind, w.ticket_id, w.discord_user_id,
                       w.fixture_key, w.tournament, w.player_one,
                       w.player_two, w.selection_name, w.stake,
                       w.return_amount, w.placed_at, w.settled_at,
                       w.win_number, a.balance
                FROM winning_tickets w
                JOIN wtsl_betting_accounts a
                  ON a.discord_user_id = w.discord_user_id
                ORDER BY w.settled_at, w.kind, w.ticket_id
                LIMIT %s
                """,
                (requested_limit,),
            )
            columns = [
                "kind", "ticket_id", "discord_user_id", "fixture_key",
                "tournament", "player_one", "player_two", "selection_name",
                "stake", "return_amount", "placed_at", "settled_at",
                "win_number", "balance",
            ]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]


def list_unnotified_refunded_bets(limit: int = 100) -> list[dict[str, Any]]:
    """Return refunded tickets that have not received a refund DM yet."""
    requested_limit = max(1, min(int(limit), 500))
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                WITH refunded_tickets AS (
                    SELECT
                        'single'::text AS kind,
                        b.bet_id AS ticket_id,
                        b.discord_user_id,
                        b.fixture_key,
                        f.tournament,
                        f.player_one,
                        f.player_two,
                        b.selection_name,
                        b.stake,
                        b.return_amount,
                        b.placed_at,
                        b.settled_at
                    FROM wtsl_betting_bets b
                    JOIN wtsl_betting_fixtures f
                      ON f.fixture_key = b.fixture_key
                    WHERE b.status = 'refunded'
                    UNION ALL
                    SELECT
                        'parlay'::text AS kind,
                        p.parlay_id AS ticket_id,
                        p.discord_user_id,
                        NULL::text AS fixture_key,
                        'Parlay'::text AS tournament,
                        NULL::text AS player_one,
                        NULL::text AS player_two,
                        COALESCE(
                            STRING_AGG(
                                l.selection_name || ' @ ' || f.tournament,
                                ' • ' ORDER BY l.fixture_key
                            ),
                            'Parlay'
                        ) AS selection_name,
                        p.stake,
                        p.return_amount,
                        p.placed_at,
                        p.settled_at
                    FROM wtsl_betting_parlays p
                    LEFT JOIN wtsl_betting_parlay_legs l
                      ON l.parlay_id = p.parlay_id
                    LEFT JOIN wtsl_betting_fixtures f
                      ON f.fixture_key = l.fixture_key
                    WHERE p.status = 'refunded'
                    GROUP BY p.parlay_id, p.discord_user_id, p.stake,
                             p.return_amount, p.placed_at, p.settled_at
                )
                SELECT r.kind, r.ticket_id, r.discord_user_id,
                       r.fixture_key, r.tournament, r.player_one,
                       r.player_two, r.winner_id, r.result_note,
                       r.selection_name, r.stake, r.return_amount,
                       r.placed_at, r.settled_at, a.balance
                FROM refunded_tickets r
                JOIN wtsl_betting_accounts a
                  ON a.discord_user_id = r.discord_user_id
                LEFT JOIN wtsl_betting_notification_receipts n
                  ON n.receipt_key =
                     'refund:' || r.kind || ':' || r.ticket_id
                 AND n.sent_at IS NOT NULL
                WHERE n.receipt_key IS NULL
                ORDER BY r.settled_at, r.kind, r.ticket_id
                LIMIT %s
                """,
                (requested_limit,),
            )
            columns = [
                "kind", "ticket_id", "discord_user_id", "fixture_key",
                "tournament", "player_one", "player_two", "winner_id",
                "result_note", "selection_name", "stake", "return_amount",
                "placed_at", "settled_at", "balance",
            ]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]


def weekly_betting_earner(
    period_start: Any,
    period_end: Any,
) -> dict[str, Any] | None:
    """Return the highest net betting earner for one reporting window."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                WITH settled_tickets AS (
                    SELECT discord_user_id,
                           CASE
                               WHEN status = 'won'
                                   THEN return_amount - stake
                               WHEN status = 'lost'
                                   THEN -stake
                               ELSE 0.00
                           END AS profit,
                           status
                    FROM wtsl_betting_bets
                    WHERE settled_at >= %s AND settled_at < %s
                    UNION ALL
                    SELECT discord_user_id,
                           CASE
                               WHEN status = 'won'
                                   THEN return_amount - stake
                               WHEN status = 'lost'
                                   THEN -stake
                               ELSE 0.00
                           END AS profit,
                           status
                    FROM wtsl_betting_parlays
                    WHERE settled_at >= %s AND settled_at < %s
                )
                SELECT discord_user_id,
                       SUM(profit) AS total_profit,
                       COUNT(*)::int AS total_bets,
                       COUNT(*) FILTER (WHERE status = 'won')::int
                           AS successful_bets,
                       COUNT(*) FILTER (WHERE status = 'lost')::int
                           AS failed_bets,
                       COUNT(*) FILTER (WHERE status = 'refunded')::int
                           AS refunded_bets
                FROM settled_tickets
                GROUP BY discord_user_id
                HAVING SUM(profit) > 0
                ORDER BY total_profit DESC, successful_bets DESC,
                         total_bets DESC, discord_user_id
                LIMIT 1
                """,
                (period_start, period_end, period_start, period_end),
            )
            row = cursor.fetchone()
            if row is None:
                return None
            return dict(
                zip(
                    (
                        "discord_user_id",
                        "total_profit",
                        "total_bets",
                        "successful_bets",
                        "failed_bets",
                        "refunded_bets",
                    ),
                    row,
                )
            )


def create_referral(
    *,
    referrer_user_id: int,
    tour: str,
    player_name: str,
    referred_user_id: int | None = None,
) -> dict[str, Any]:
    tour = str(tour or "").casefold()
    player_name = str(player_name or "").strip()
    player_key = normalized_player_key(player_name)
    if tour not in {"atp", "wta"} or not player_key:
        raise ValueError("Choose a valid ATP or WTA ranked player.")
    if referred_user_id is not None and int(referred_user_id) == int(
        referrer_user_id
    ):
        raise ValueError("You cannot refer yourself.")
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                SELECT referral_id, status, referred_user_id
                FROM wtsl_betting_referrals
                WHERE tour = %s AND player_key = %s
                """,
                (tour, player_key),
            )
            existing = cursor.fetchone()
            if existing is not None:
                raise ValueError(
                    "That ranked player already has a referral recorded."
                )
            status = "active" if referred_user_id is not None else "pending_identity"
            cursor.execute(
                """
                INSERT INTO wtsl_betting_referrals (
                    referrer_user_id, tour, player_key, player_name,
                    referred_user_id, status, reward_amount
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                RETURNING referral_id, referrer_user_id, tour, player_name,
                          referred_user_id, status, reward_amount, created_at
                """,
                (
                    int(referrer_user_id),
                    tour,
                    player_key,
                    player_name,
                    int(referred_user_id) if referred_user_id is not None else None,
                    status,
                    REFERRAL_REWARD,
                ),
            )
            row = cursor.fetchone()
            return dict(
                zip(
                    (
                        "referral_id",
                        "referrer_user_id",
                        "tour",
                        "player_name",
                        "referred_user_id",
                        "status",
                        "reward_amount",
                        "created_at",
                    ),
                    row,
                )
            )


def attach_pending_referrals(
    *,
    tour: str,
    player_name: str,
    referred_user_id: int,
) -> list[dict[str, Any]]:
    tour = str(tour or "").casefold()
    player_key = normalized_player_key(player_name)
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                UPDATE wtsl_betting_referrals
                SET referred_user_id = %s,
                    status = 'active',
                    verified_at = now(),
                    last_reminded_at = NULL
                WHERE tour = %s
                  AND player_key = %s
                  AND status = 'pending_identity'
                RETURNING referral_id, referrer_user_id, player_name,
                          referred_user_id, reward_amount
                """,
                (int(referred_user_id), tour, player_key),
            )
            columns = [
                "referral_id", "referrer_user_id", "player_name",
                "referred_user_id", "reward_amount",
            ]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]


def claim_pending_referral_reminders(
    limit: int = 25,
) -> list[dict[str, Any]]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                UPDATE wtsl_betting_referrals
                SET last_reminded_at = now()
                WHERE referral_id IN (
                    SELECT referral_id
                    FROM wtsl_betting_referrals
                    WHERE status = 'pending_identity'
                      AND (
                          last_reminded_at IS NULL
                          OR last_reminded_at < now()
                              - (%s * INTERVAL '1 hour')
                      )
                    ORDER BY created_at
                    FOR UPDATE SKIP LOCKED
                    LIMIT %s
                )
                RETURNING referral_id, referrer_user_id, tour, player_name,
                          created_at
                """,
                (REFERRAL_REMINDER_HOURS, max(1, int(limit))),
            )
            columns = [
                "referral_id", "referrer_user_id", "tour", "player_name",
                "created_at",
            ]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]


def _first_referral_qualifying_ticket(
    cursor,
    referred_user_id: int,
    created_at: Any,
) -> tuple[str, int, Decimal, Decimal] | None:
    cursor.execute(
        """
        SELECT 'single', bet_id, stake, return_amount
        FROM wtsl_betting_bets
        WHERE discord_user_id = %s
          AND placed_at >= %s
        ORDER BY placed_at, bet_id
        LIMIT 1
        """,
        (int(referred_user_id), created_at),
    )
    single = cursor.fetchone()
    cursor.execute(
        """
        SELECT 'parlay', parlay_id, stake, return_amount
        FROM wtsl_betting_parlays
        WHERE discord_user_id = %s
          AND placed_at >= %s
        ORDER BY placed_at, parlay_id
        LIMIT 1
        """,
        (int(referred_user_id), created_at),
    )
    parlay = cursor.fetchone()
    choices = [row for row in (single, parlay) if row is not None]
    if not choices:
        return None
    # The first ticket is identified by the earliest placement query result.
    # The two tables have independent sequences, so choose by a timestamp in
    # the caller's follow-up query instead of assuming IDs are comparable.
    cursor.execute(
        """
        SELECT 'single', bet_id, stake, return_amount, placed_at, status
        FROM wtsl_betting_bets
        WHERE discord_user_id = %s AND placed_at >= %s
        UNION ALL
        SELECT 'parlay', parlay_id, stake, return_amount, placed_at, status
        FROM wtsl_betting_parlays
        WHERE discord_user_id = %s AND placed_at >= %s
        ORDER BY placed_at, 2
        LIMIT 1
        """,
        (
            int(referred_user_id),
            created_at,
            int(referred_user_id),
            created_at,
        ),
    )
    row = cursor.fetchone()
    if row is None or row[5] != "won" or Decimal(row[2]) < REFERRAL_MIN_STAKE:
        return None
    return str(row[0]), int(row[1]), Decimal(row[2]), Decimal(row[3])


def settle_referral_rewards() -> list[dict[str, Any]]:
    """Credit each eligible referral once, without changing betting profit."""
    rewarded: list[dict[str, Any]] = []
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                SELECT referral_id, referrer_user_id, referred_user_id,
                       player_name, reward_amount, created_at
                FROM wtsl_betting_referrals
                WHERE status = 'active'
                  AND referred_user_id IS NOT NULL
                ORDER BY referral_id
                FOR UPDATE
                """
            )
            referrals = cursor.fetchall()
            for (
                referral_id,
                referrer_user_id,
                referred_user_id,
                player_name,
                reward_amount,
                created_at,
            ) in referrals:
                ticket = _first_referral_qualifying_ticket(
                    cursor,
                    int(referred_user_id),
                    created_at,
                )
                if ticket is None:
                    continue
                source_kind, source_id, _stake, _return_amount = ticket
                cursor.execute(
                    """
                    INSERT INTO wtsl_betting_referral_rewards (
                        referral_id, referrer_user_id, referred_user_id,
                        amount, source_kind, source_id
                    )
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON CONFLICT (referral_id) DO NOTHING
                    RETURNING reward_id
                    """,
                    (
                        int(referral_id),
                        int(referrer_user_id),
                        int(referred_user_id),
                        Decimal(reward_amount),
                        source_kind,
                        int(source_id),
                    ),
                )
                inserted = cursor.fetchone()
                if inserted is None:
                    continue
                reward_id = int(inserted[0])
                cursor.execute(
                    """
                    INSERT INTO wtsl_betting_accounts (discord_user_id)
                    VALUES (%s)
                    ON CONFLICT (discord_user_id) DO NOTHING
                    """,
                    (int(referrer_user_id),),
                )
                cursor.execute(
                    """
                    UPDATE wtsl_betting_accounts
                    SET balance = balance + %s, updated_at = now()
                    WHERE discord_user_id = %s
                    """,
                    (Decimal(reward_amount), int(referrer_user_id)),
                )
                cursor.execute(
                    """
                    UPDATE wtsl_betting_referrals
                    SET status = 'rewarded',
                        rewarded_at = now(),
                        source_kind = %s,
                        source_id = %s
                    WHERE referral_id = %s
                    """,
                    (source_kind, int(source_id), int(referral_id)),
                )
                rewarded.append(
                    {
                        "reward_id": reward_id,
                        "referral_id": int(referral_id),
                        "referrer_user_id": int(referrer_user_id),
                        "referred_user_id": int(referred_user_id),
                        "player_name": str(player_name),
                        "amount": Decimal(reward_amount),
                        "source_kind": source_kind,
                        "source_id": int(source_id),
                    }
                )
    return rewarded


def list_unnotified_referral_rewards(limit: int = 50) -> list[dict[str, Any]]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                SELECT r.reward_id, r.referral_id, r.referrer_user_id,
                       r.referred_user_id, r.amount, r.source_kind,
                       r.source_id, f.player_name
                FROM wtsl_betting_referral_rewards r
                JOIN wtsl_betting_referrals f
                  ON f.referral_id = r.referral_id
                LEFT JOIN wtsl_betting_notification_receipts n
                  ON n.receipt_key = 'referral-reward:' || r.reward_id::text
                WHERE n.sent_at IS NULL
                ORDER BY r.created_at
                LIMIT %s
                """,
                (max(1, min(int(limit), 200)),),
            )
            columns = [
                "reward_id", "referral_id", "referrer_user_id",
                "referred_user_id", "amount", "source_kind", "source_id",
                "player_name",
            ]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]


def list_user_bets(
    discord_user_id: int,
    limit: int = 200,
) -> list[dict[str, Any]]:
    """Return a user's singles and parlays as one newest-first ledger."""
    requested_limit = max(1, min(int(limit), 500))
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                SELECT b.bet_id, b.fixture_key, f.player_one, f.player_two,
                       f.tournament, b.selection_name, b.stake, b.odds,
                       b.potential_return, b.status, b.return_amount,
                       b.placed_at, b.settled_at
                FROM wtsl_betting_bets b
                JOIN wtsl_betting_fixtures f
                  ON f.fixture_key = b.fixture_key
                WHERE b.discord_user_id = %s
                ORDER BY b.placed_at DESC, b.bet_id DESC
                LIMIT %s
                """,
                (int(discord_user_id), requested_limit),
            )
            single_rows = cursor.fetchall()
            cursor.execute(
                """
                SELECT p.parlay_id, p.stake, p.combined_odds,
                       p.potential_return, p.status, p.return_amount,
                       p.placed_at, p.settled_at,
                       COALESCE(
                           STRING_AGG(
                               l.selection_name || ' @ ' || f.tournament,
                               ' • ' ORDER BY l.fixture_key
                           ),
                           'No legs recorded'
                       ) AS legs
                FROM wtsl_betting_parlays p
                LEFT JOIN wtsl_betting_parlay_legs l
                  ON l.parlay_id = p.parlay_id
                LEFT JOIN wtsl_betting_fixtures f
                  ON f.fixture_key = l.fixture_key
                WHERE p.discord_user_id = %s
                GROUP BY p.parlay_id, p.stake, p.combined_odds,
                         p.potential_return, p.status, p.return_amount,
                         p.placed_at, p.settled_at
                ORDER BY p.placed_at DESC, p.parlay_id DESC
                LIMIT %s
                """,
                (int(discord_user_id), requested_limit),
            )
            parlay_rows = cursor.fetchall()

    ledger: list[dict[str, Any]] = []
    for row in single_rows:
        stake = Decimal(row[6])
        odds = max(Decimal(row[7]), MIN_POOL_ODDS)
        ledger.append(
            {
                "kind": "single",
                "id": int(row[0]),
                "fixture": f"{row[2]} vs {row[3]}",
                "tournament": str(row[4]),
                "selection": str(row[5]),
                "stake": stake,
                "odds": odds,
                "potential_return": max(Decimal(row[8]), stake),
                "status": str(row[9]),
                "return_amount": row[10],
                "placed_at": row[11],
                "settled_at": row[12],
            }
        )
    for row in parlay_rows:
        ledger.append(
            {
                "kind": "parlay",
                "id": int(row[0]),
                "fixture": "Parlay",
                "tournament": "",
                "selection": str(row[8]),
                "stake": row[1],
                "odds": row[2],
                "potential_return": row[3],
                "status": str(row[4]),
                "return_amount": row[5],
                "placed_at": row[6],
                "settled_at": row[7],
            }
        )
    ledger.sort(
        key=lambda item: (
            item.get("placed_at") is not None,
            item.get("placed_at"),
        ),
        reverse=True,
    )
    return ledger[:requested_limit]


def place_bet(
    *,
    discord_user_id: int,
    fixture_key: str,
    selection_id: str,
    selection_name: str,
    odds: Decimal,
    stake: Decimal,
    verified_player_links: dict[str, str] | None = None,
) -> dict[str, Any]:
    stake = Decimal(stake).quantize(Decimal("0.01"))
    odds = Decimal(str(odds))
    if stake <= 0:
        raise ValueError("Stake must be greater than zero")
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                SELECT fixture_key, status,
                        player_one_id, player_one, player_two_id, player_two,
                       odds_one, odds_two
                FROM wtsl_betting_fixtures
                WHERE fixture_key = %s
                FOR UPDATE
                """,
                (fixture_key,),
            )
            fixture_row = cursor.fetchone()
            if fixture_row is None:
                raise ValueError("That fixture is no longer available")
            if fixture_row[1] != "open":
                raise ValueError("Betting on that fixture is closed")
            selection_options = {
                fixture_row[2]: (fixture_row[3], fixture_row[6]),
                fixture_row[4]: (fixture_row[5], fixture_row[7]),
            }
            selected = selection_options.get(selection_id)
            if selected is None:
                raise ValueError("That player is not part of the selected fixture")
            authoritative_name, authoritative_odds = selected
            cursor.execute(
                """
                SELECT tour
                FROM wtsl_betting_fixtures
                WHERE fixture_key = %s
                """,
                (fixture_key,),
            )
            fixture_tour_name = cursor.fetchone()[0]
            self_match = self_match_reason(
                verified_player_links,
                fixture_tour_name,
                fixture_row[3],
                fixture_row[5],
            )
            if self_match:
                raise ValueError(self_match)
            if str(selection_name) != str(authoritative_name):
                raise ValueError("The fixture player changed; please open the fixtures panel again")
            cursor.execute(
                """
                SELECT 1
                FROM wtsl_betting_bets
                WHERE fixture_key = %s
                  AND discord_user_id = %s
                  AND selection_id = %s
                  AND status = 'open'
                UNION ALL
                SELECT 1
                FROM wtsl_betting_parlay_legs l
                JOIN wtsl_betting_parlays p ON p.parlay_id = l.parlay_id
                WHERE l.fixture_key = %s
                  AND p.discord_user_id = %s
                  AND p.status = 'open'
                LIMIT 1
                """,
                (
                    fixture_key,
                    int(discord_user_id),
                    selection_id,
                    fixture_key,
                    int(discord_user_id),
                ),
            )
            if cursor.fetchone() is not None:
                raise ValueError("You already have a bet on that outcome")
            cursor.execute(
                """
                SELECT
                    COALESCE(SUM(stake), 0.00),
                    COALESCE(SUM(stake) FILTER (WHERE selection_id = %s), 0.00),
                    COALESCE(SUM(stake) FILTER (WHERE selection_id = %s), 0.00)
                FROM wtsl_betting_bets
                WHERE fixture_key = %s AND status = 'open'
                """,
                (
                    fixture_row[2],
                    fixture_row[4],
                    fixture_key,
                ),
            )
            pool_total, pool_one, pool_two = cursor.fetchone()
            pool_total = Decimal(pool_total) + stake
            selected_pool = (
                Decimal(pool_one) if selection_id == fixture_row[2]
                else Decimal(pool_two)
            ) + stake
            pool_odds = pool_decimal_odds(pool_total, selected_pool)
            guaranteed_odds = hybrid_guaranteed_odds(
                Decimal(str(authoritative_odds)),
                pool_odds,
            )
            potential_return = (stake * guaranteed_odds).quantize(Decimal("0.01"))
            return_breakdown = bet_return_breakdown(
                stake,
                Decimal(str(authoritative_odds)),
                pool_odds,
                guaranteed_odds,
            )
            reserve_liability = hybrid_reserve_liability(
                stake,
                potential_return,
            )
            cursor.execute(
                """
                INSERT INTO wtsl_betting_accounts (discord_user_id)
                VALUES (%s)
                ON CONFLICT (discord_user_id) DO NOTHING
                """,
                (int(discord_user_id),),
            )
            cursor.execute(
                """
                SELECT balance
                FROM wtsl_betting_accounts
                WHERE discord_user_id = %s
                FOR UPDATE
                """,
                (int(discord_user_id),),
            )
            balance = cursor.fetchone()[0]
            if balance < stake:
                raise ValueError(
                    f"Your balance is {balance:.2f} WTSL Dollars, "
                    f"but the stake is {stake:.2f}."
                )
            cursor.execute(
                """
                SELECT balance
                FROM wtsl_betting_house_reserve
                WHERE reserve_id = 1
                FOR UPDATE
                """
            )
            house_reserve = cursor.fetchone()
            if house_reserve is None:
                raise RuntimeError("House reserve is not initialized")
            if house_reserve[0] < reserve_liability:
                raise ValueError(
                    "That guaranteed return is temporarily unavailable because "
                    "the house reserve is at its liability limit. Try a smaller "
                    "stake or a different outcome."
                )
            cursor.execute(
                """
                UPDATE wtsl_betting_accounts
                SET balance = balance - %s,
                    total_staked = total_staked + %s,
                    updated_at = now()
                WHERE discord_user_id = %s
                """,
                (stake, stake, int(discord_user_id)),
            )
            cursor.execute(
                """
                INSERT INTO wtsl_betting_bets (
                    fixture_key, discord_user_id, selection_id,
                    selection_name, odds, stake, potential_return,
                    reserve_liability
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING bet_id
                """,
                (
                    fixture_key,
                    int(discord_user_id),
                    selection_id,
                    selection_name,
                    guaranteed_odds,
                    stake,
                    potential_return,
                    reserve_liability,
                ),
            )
            bet_id = cursor.fetchone()[0]
            cursor.execute(
                """
                UPDATE wtsl_betting_house_reserve
                SET balance = balance - %s,
                    reserved_liability = reserved_liability + %s,
                    updated_at = now()
                WHERE reserve_id = 1
                """,
                (reserve_liability, reserve_liability),
            )
            return {
                "bet_id": int(bet_id),
                "stake": stake,
                "odds": guaranteed_odds,
                "pool_odds": pool_odds,
                "guaranteed_odds": guaranteed_odds,
                "potential_return": potential_return,
                **return_breakdown,
                "reserve_liability": reserve_liability,
                "balance": balance - stake,
            }


def place_parlay(
    *,
    discord_user_id: int,
    legs: list[dict[str, Any]],
    stake: Decimal,
    verified_player_links: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Place one stake across several fixtures with one outcome per fixture."""
    stake = Decimal(stake).quantize(Decimal("0.01"))
    if stake <= 0:
        raise ValueError("Stake must be greater than zero")
    if not legs:
        raise ValueError("Choose at least two outcomes for a parlay")
    if len(legs) < 2:
        raise ValueError("A parlay needs at least two fixtures")
    fixture_keys = [str(leg.get("fixture_key") or "") for leg in legs]
    if any(not key for key in fixture_keys) or len(set(fixture_keys)) != len(fixture_keys):
        raise ValueError("Choose only one outcome per fixture")
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                SELECT fixture_key, status,
                       player_one_id, player_one, odds_one,
                       player_two_id, player_two, odds_two
                FROM wtsl_betting_fixtures
                WHERE fixture_key = ANY(%s)
                ORDER BY fixture_key
                FOR UPDATE
                """,
                (fixture_keys,),
            )
            fixture_rows = {
                str(row[0]): row for row in cursor.fetchall()
            }
            if len(fixture_rows) != len(fixture_keys):
                raise ValueError("One of those fixtures is no longer available")
            cursor.execute(
                """
                SELECT fixture_key, tour
                FROM wtsl_betting_fixtures
                WHERE fixture_key = ANY(%s)
                """,
                (fixture_keys,),
            )
            fixture_tours = {
                str(row[0]): row[1] for row in cursor.fetchall()
            }
            combined_odds = Decimal("1")
            normalized_legs = []
            for leg in legs:
                fixture = fixture_rows[str(leg["fixture_key"])]
                if fixture[1] != "open":
                    raise ValueError("One of those fixtures is no longer open")
                options = {
                    str(fixture[2]): (str(fixture[3]), Decimal(fixture[4])),
                    str(fixture[5]): (str(fixture[6]), Decimal(fixture[7])),
                }
                selection_id = str(leg.get("selection_id") or "")
                selected = options.get(selection_id)
                if selected is None:
                    raise ValueError("A selected player is not part of its fixture")
                selection_name, authoritative_odds = selected
                self_match = self_match_reason(
                    verified_player_links,
                    fixture_tours.get(str(leg["fixture_key"])),
                    fixture[3],
                    fixture[6],
                )
                if self_match:
                    raise ValueError(self_match)
                house_odds = (
                    Decimal(authoritative_odds)
                    / (Decimal("1") + POOL_TAKEOUT)
                ).quantize(Decimal("0.001"))
                if (
                    str(leg.get("selection_name") or "") != selection_name
                    or Decimal(str(leg.get("odds"))) != house_odds
                ):
                    raise ValueError(
                        "One fixture's odds changed; please build the parlay again"
                    )
                cursor.execute(
                    """
                    SELECT 1
                    FROM wtsl_betting_bets
                    WHERE fixture_key = %s AND discord_user_id = %s
                    UNION ALL
                    SELECT 1
                    FROM wtsl_betting_parlay_legs l
                    JOIN wtsl_betting_parlays p ON p.parlay_id = l.parlay_id
                    WHERE l.fixture_key = %s
                      AND p.discord_user_id = %s
                      AND p.status = 'open'
                    LIMIT 1
                    """,
                    (
                        str(leg["fixture_key"]),
                        int(discord_user_id),
                        str(leg["fixture_key"]),
                        int(discord_user_id),
                    ),
                )
                if cursor.fetchone() is not None:
                    raise ValueError(
                        "You already have a bet on one of those fixtures"
                    )
                combined_odds *= house_odds
                normalized_legs.append(
                    (
                        str(leg["fixture_key"]),
                        selection_id,
                        selection_name,
                        house_odds,
                    )
                )
            combined_odds = combined_odds.quantize(Decimal("0.001"))
            potential_return = (stake * combined_odds).quantize(Decimal("0.01"))
            cursor.execute(
                """
                INSERT INTO wtsl_betting_accounts (discord_user_id)
                VALUES (%s)
                ON CONFLICT (discord_user_id) DO NOTHING
                """,
                (int(discord_user_id),),
            )
            cursor.execute(
                """
                SELECT balance
                FROM wtsl_betting_accounts
                WHERE discord_user_id = %s
                FOR UPDATE
                """,
                (int(discord_user_id),),
            )
            balance = cursor.fetchone()[0]
            if balance < stake:
                raise ValueError(
                    f"Your balance is {balance:.2f} WTSL Dollars, "
                    f"but the stake is {stake:.2f}."
                )
            cursor.execute(
                """
                UPDATE wtsl_betting_accounts
                SET balance = balance - %s,
                    total_staked = total_staked + %s,
                    updated_at = now()
                WHERE discord_user_id = %s
                """,
                (stake, stake, int(discord_user_id)),
            )
            cursor.execute(
                """
                INSERT INTO wtsl_betting_parlays (
                    discord_user_id, stake, combined_odds, potential_return
                )
                VALUES (%s, %s, %s, %s)
                RETURNING parlay_id
                """,
                (int(discord_user_id), stake, combined_odds, potential_return),
            )
            parlay_id = int(cursor.fetchone()[0])
            cursor.executemany(
                """
                INSERT INTO wtsl_betting_parlay_legs (
                    parlay_id, fixture_key, selection_id, selection_name, odds
                )
                VALUES (%s, %s, %s, %s, %s)
                """,
                [
                    (parlay_id, fixture_key, selection_id, selection_name, odds)
                    for fixture_key, selection_id, selection_name, odds
                    in normalized_legs
                ],
            )
            return {
                "parlay_id": parlay_id,
                "stake": stake,
                "combined_odds": combined_odds,
                "potential_return": potential_return,
                "balance": balance - stake,
            }


def settle_fixture(
    fixture_key: str,
    *,
    winner_id: str | None,
    result_note: str,
) -> bool:
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                """
                SELECT status
                FROM wtsl_betting_fixtures
                WHERE fixture_key = %s
                FOR UPDATE
                """,
                (fixture_key,),
            )
            fixture = cursor.fetchone()
            if fixture is None or fixture[0] != "open":
                return False
            cursor.execute(
                """
                SELECT bet_id, discord_user_id, selection_id, stake,
                       odds, potential_return, reserve_liability
                FROM wtsl_betting_bets
                WHERE fixture_key = %s AND status = 'open'
                FOR UPDATE
                """,
                (fixture_key,),
            )
            bets = cursor.fetchall()
            total_pool = sum((Decimal(row[3]) for row in bets), Decimal("0.00"))
            winning_pool = sum(
                (Decimal(row[3]) for row in bets if row[2] == winner_id),
                Decimal("0.00"),
            )
            has_winner_pool = winner_id is not None and winning_pool > 0
            distributable = pool_distributable(total_pool, winning_pool)
            pool_returns: list[Decimal] = []
            for (
                _bet_id,
                _user_id,
                selection_id,
                stake,
                _odds,
                _potential_return,
                _reserve_liability,
            ) in bets:
                stake = Decimal(stake)
                is_refund = not has_winner_pool
                is_winner = has_winner_pool and selection_id == winner_id
                pool_return = (
                    stake
                    if is_refund
                    else (
                        (stake / winning_pool * distributable).quantize(
                            Decimal("0.01")
                        )
                        if is_winner
                        else Decimal("0.00")
                    )
                )
                pool_returns.append(pool_return)
            if has_winner_pool:
                residual = distributable - sum(
                    pool_returns,
                    Decimal("0.00"),
                )
                winner_indexes = [
                    index
                    for index, row in enumerate(bets)
                    if row[2] == winner_id
                ]
                if winner_indexes:
                    pool_returns[winner_indexes[-1]] += residual

            total_reserved = sum(
                (Decimal(row[6] or 0) for row in bets),
                Decimal("0.00"),
            )
            total_topup = Decimal("0.00")
            final_returns: list[Decimal] = []
            for index, (
                _bet_id,
                _user_id,
                selection_id,
                stake,
                _odds,
                potential_return,
                reserve_liability,
            ) in enumerate(bets):
                stake = Decimal(stake)
                is_refund = not has_winner_pool
                is_winner = has_winner_pool and selection_id == winner_id
                guaranteed_return = (
                    Decimal(potential_return)
                    if Decimal(reserve_liability or 0) > 0
                    else stake
                )
                return_amount = (
                    hybrid_settlement_return(
                        stake,
                        guaranteed_return,
                        pool_returns[index],
                    )
                    if is_winner
                    else pool_returns[index]
                )
                if is_winner:
                    total_topup += max(
                        return_amount - pool_returns[index],
                        Decimal("0.00"),
                    )
                final_returns.append(return_amount)

            cursor.execute(
                """
                UPDATE wtsl_betting_house_reserve
                SET balance = balance + %s - %s,
                    reserved_liability = reserved_liability - %s,
                    updated_at = now()
                WHERE reserve_id = 1
                  AND reserved_liability >= %s
                  AND balance + %s >= %s
                """,
                (
                    total_reserved,
                    total_topup,
                    total_reserved,
                    total_reserved,
                    total_reserved,
                    total_topup,
                ),
            )
            if cursor.rowcount != 1:
                raise RuntimeError(
                    "House reserve could not fund the guaranteed bet returns"
                )

            for index, (bet_id, user_id, selection_id, stake, *_rest) in enumerate(
                bets
            ):
                stake = Decimal(stake)
                is_refund = not has_winner_pool
                is_winner = has_winner_pool and selection_id == winner_id
                return_amount = final_returns[index]
                status = "refunded" if is_refund else "won" if is_winner else "lost"
                profit = (
                    Decimal("0.00")
                    if is_refund
                    else return_amount - stake
                    if is_winner
                    else -stake
                )
                cursor.execute(
                    """
                    UPDATE wtsl_betting_bets
                    SET status = %s, return_amount = %s, settled_at = now()
                    WHERE bet_id = %s
                    """,
                    (status, return_amount, bet_id),
                )
                cursor.execute(
                    """
                    UPDATE wtsl_betting_accounts
                    SET balance = balance + %s,
                        total_returned = total_returned + %s,
                        total_profit = total_profit + %s,
                        updated_at = now()
                    WHERE discord_user_id = %s
                    """,
                    (return_amount, return_amount, profit, user_id),
                )
            cursor.execute(
                """
                UPDATE wtsl_betting_fixtures
                SET status = 'settled',
                    winner_id = %s,
                    result_note = %s,
                    settled_at = now(),
                    updated_at = now()
                WHERE fixture_key = %s
                """,
                (winner_id, result_note, fixture_key),
            )
            cursor.execute(
                """
                SELECT p.parlay_id, p.discord_user_id, p.stake, p.combined_odds,
                       BOOL_AND(f.status = 'settled') AS all_settled,
                       BOOL_OR(f.winner_id IS NULL) AS has_refund,
                       BOOL_AND(f.winner_id = l.selection_id) AS all_won
                FROM wtsl_betting_parlays p
                JOIN wtsl_betting_parlay_legs l ON l.parlay_id = p.parlay_id
                JOIN wtsl_betting_fixtures f ON f.fixture_key = l.fixture_key
                WHERE p.status = 'open'
                  AND EXISTS (
                      SELECT 1
                      FROM wtsl_betting_parlay_legs current_leg
                      WHERE current_leg.parlay_id = p.parlay_id
                        AND current_leg.fixture_key = %s
                  )
                GROUP BY p.parlay_id, p.discord_user_id, p.stake, p.combined_odds
                """,
                (fixture_key,),
            )
            parlays = cursor.fetchall()
            for (
                parlay_id,
                user_id,
                stake,
                combined_odds,
                all_settled,
                has_refund,
                all_won,
            ) in parlays:
                if not all_settled:
                    continue
                is_refund = bool(has_refund)
                is_winner = not is_refund and bool(all_won)
                return_amount = (
                    stake
                    if is_refund
                    else (stake * combined_odds).quantize(Decimal("0.01"))
                    if is_winner
                    else Decimal("0.00")
                )
                profit = (
                    Decimal("0.00")
                    if is_refund
                    else return_amount - stake
                    if is_winner
                    else -stake
                )
                status = "refunded" if is_refund else "won" if is_winner else "lost"
                cursor.execute(
                    """
                    UPDATE wtsl_betting_parlays
                    SET status = %s, return_amount = %s, settled_at = now()
                    WHERE parlay_id = %s
                    """,
                    (status, return_amount, parlay_id),
                )
                cursor.execute(
                    """
                    UPDATE wtsl_betting_accounts
                    SET balance = balance + %s,
                        total_returned = total_returned + %s,
                        total_profit = total_profit + %s,
                        updated_at = now()
                    WHERE discord_user_id = %s
                    """,
                    (return_amount, return_amount, profit, user_id),
                )
            return True


def leaderboard(
    limit: int = 10,
    *,
    losers_only: bool = False,
) -> list[dict[str, Any]]:
    order_clause = (
        "a.total_profit ASC, total_bets DESC, a.discord_user_id"
        if losers_only
        else "a.total_profit DESC, total_bets DESC, a.discord_user_id"
    )
    loser_filter = "AND a.total_profit < 0" if losers_only else ""
    with _connect() as connection:
        with connection.cursor() as cursor:
            ensure_tables(cursor)
            cursor.execute(
                f"""
                SELECT a.discord_user_id, a.total_profit,
                       COALESCE(single.total_bets, 0)
                           + COALESCE(parlay.total_bets, 0) AS total_bets,
                       COALESCE(single.successful_bets, 0)
                           + COALESCE(parlay.successful_bets, 0)
                           AS successful_bets,
                       COALESCE(single.failed_bets, 0)
                           + COALESCE(parlay.failed_bets, 0) AS failed_bets,
                       COALESCE(single.refunded_bets, 0)
                           + COALESCE(parlay.refunded_bets, 0)
                           AS refunded_bets
                FROM wtsl_betting_accounts a
                LEFT JOIN (
                    SELECT discord_user_id,
                           COUNT(*)::int AS total_bets,
                           COUNT(*) FILTER (WHERE status = 'won')::int
                               AS successful_bets,
                           COUNT(*) FILTER (WHERE status = 'lost')::int
                                AS failed_bets,
                            COUNT(*) FILTER (WHERE status = 'refunded')::int
                                AS refunded_bets
                    FROM wtsl_betting_bets
                    WHERE status IN ('won', 'lost', 'refunded')
                    GROUP BY discord_user_id
                ) single ON single.discord_user_id = a.discord_user_id
                LEFT JOIN (
                    SELECT discord_user_id,
                           COUNT(*)::int AS total_bets,
                           COUNT(*) FILTER (WHERE status = 'won')::int
                               AS successful_bets,
                           COUNT(*) FILTER (WHERE status = 'lost')::int
                                AS failed_bets,
                            COUNT(*) FILTER (WHERE status = 'refunded')::int
                                AS refunded_bets
                    FROM wtsl_betting_parlays
                    WHERE status IN ('won', 'lost', 'refunded')
                    GROUP BY discord_user_id
                ) parlay ON parlay.discord_user_id = a.discord_user_id
                WHERE (
                    single.discord_user_id IS NOT NULL
                    OR parlay.discord_user_id IS NOT NULL
                )
                  {loser_filter}
                ORDER BY {order_clause}
                LIMIT %s
                """,
                (int(limit),),
            )
            columns = [
                "discord_user_id", "total_profit", "total_bets",
                "successful_bets", "failed_bets", "refunded_bets",
            ]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]