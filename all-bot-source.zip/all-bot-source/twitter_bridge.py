"""Small, testable helpers for posting Discord content to X/Twitter."""
from __future__ import annotations

import io
import os
from collections.abc import Iterable
from typing import Any

import tweepy


class TwitterConfigurationError(RuntimeError):
    """Raised when the posting credentials are not configured."""


def twitter_credentials_configured(environ: dict[str, str] | None = None) -> bool:
    values = environ if environ is not None else os.environ
    return all(
        values.get(name)
        for name in (
            "TWITTER_CONSUMER_KEY",
            "TWITTER_CONSUMER_SECRET",
            "TWITTER_ACCESS_TOKEN",
            "TWITTER_ACCESS_TOKEN_SECRET",
        )
    )


def is_image_attachment(filename: str = "", content_type: str | None = None) -> bool:
    if content_type and content_type.lower().startswith("image/"):
        return True
    extension = str(filename).lower().rsplit(".", 1)[-1]
    return extension in {"jpg", "jpeg", "png", "gif", "webp"}


def _shorten_with_suffix(body: str, suffix: str, limit: int = 280) -> str:
    body = body.strip()
    suffix = suffix.strip()
    if not suffix:
        return body if len(body) <= limit else body[: limit - 1].rstrip() + "…"
    if len(body) + 2 + len(suffix) <= limit:
        return f"{body}\n\n{suffix}" if body else suffix[:limit]
    available = limit - len(suffix) - 3
    if available <= 0:
        return suffix[:limit]
    clipped = body[:available].rstrip() + "…"
    return f"{clipped}\n\n{suffix}"


def build_tweet_text(
    content: str,
    *,
    source_url: str | None = None,
    attachment_urls: Iterable[str] = (),
    limit: int = 280,
) -> str:
    """Preserve announcement line breaks while keeping a useful source link."""
    body = str(content or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    links = [str(url).strip() for url in attachment_urls if str(url).strip()]
    if source_url and source_url.strip():
        links.append(source_url.strip())
    suffix = "\n".join(dict.fromkeys(links))
    return _shorten_with_suffix(body, suffix, limit=limit)


class TwitterPoster:
    """Construct clients lazily so missing secrets do not break bot startup."""

    def __init__(self, environ: dict[str, str] | None = None):
        values = environ if environ is not None else os.environ
        self.consumer_key = values.get("TWITTER_CONSUMER_KEY", "")
        self.consumer_secret = values.get("TWITTER_CONSUMER_SECRET", "")
        self.access_token = values.get("TWITTER_ACCESS_TOKEN", "")
        self.access_token_secret = values.get("TWITTER_ACCESS_TOKEN_SECRET", "")
        self.bearer_token = values.get("TWITTER_BEARER_TOKEN", "")

    @property
    def configured(self) -> bool:
        return bool(
            self.consumer_key
            and self.consumer_secret
            and self.access_token
            and self.access_token_secret
        )

    def _clients(self):
        if not self.configured:
            raise TwitterConfigurationError(
                "Twitter posting is not configured. Add the four TWITTER_* "
                "posting secrets before using this command."
            )
        client = tweepy.Client(
            bearer_token=self.bearer_token or None,
            consumer_key=self.consumer_key,
            consumer_secret=self.consumer_secret,
            access_token=self.access_token,
            access_token_secret=self.access_token_secret,
        )
        auth = tweepy.OAuthHandler(self.consumer_key, self.consumer_secret)
        auth.set_access_token(self.access_token, self.access_token_secret)
        return client, tweepy.API(auth)

    def post_sync(
        self,
        text: str,
        media_files: Iterable[tuple[str, bytes]] = (),
    ) -> dict[str, str]:
        """Post one tweet synchronously; callers should run this off-loop."""
        client, api_v1 = self._clients()
        media_ids: list[str] = []
        for filename, data in media_files:
            stream = io.BytesIO(data)
            stream.name = filename
            media = api_v1.media_upload(filename=filename, file=stream)
            media_ids.append(str(media.media_id))
        response = client.create_tweet(
            text=text,
            media_ids=media_ids or None,
        )
        tweet_id = str((response.data or {}).get("id", "")).strip()
        if not tweet_id:
            raise RuntimeError("Twitter returned no tweet ID.")
        return {
            "id": tweet_id,
            "url": f"https://twitter.com/wtsl_tennis/status/{tweet_id}",
            "has_media": "true" if media_ids else "false",
        }