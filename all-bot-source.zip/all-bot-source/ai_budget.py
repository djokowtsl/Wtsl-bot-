"""Concurrency-safe monthly budget guard for OpenAI-compatible chat calls."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import fcntl
import json
import math
import os
from pathlib import Path
import re
import tempfile
import threading
from types import SimpleNamespace
from typing import Any

from openai import AsyncOpenAI as _RawAsyncOpenAI
from openai import OpenAI as _RawOpenAI


DEFAULT_MONTHLY_BUDGET_USD = 20.0
STATE_FILE = Path(os.environ.get("AI_BUDGET_STATE_FILE", "ai_usage_state.json"))

# Provider prices are USD per million tokens. Reservations use a conservative
# multiplier so a request cannot spend the whole remaining budget while its
# final token usage is still unknown.
MODEL_PRICING_USD_PER_MILLION = {
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-5-mini": {"input": 0.25, "output": 2.00},
}
RESERVATION_SAFETY_MULTIPLIER = 4.0
IMAGE_PROMPT_TOKEN_RESERVE = 4000


class AIBudgetExceeded(RuntimeError):
    """Raised before a provider request when the monthly budget is exhausted."""


class AIBudgetStateError(RuntimeError):
    """Raised when the durable ledger cannot be trusted."""


class UnsupportedAIModel(ValueError):
    """Raised before a request when no maintained model price is available."""


@dataclass(frozen=True)
class Reservation:
    model: str
    estimated_usd: float
    max_completion_tokens: int


def _month_key() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m")


def _configured_budget() -> float:
    try:
        configured = float(
            os.environ.get("AI_MONTHLY_BUDGET_USD", str(DEFAULT_MONTHLY_BUDGET_USD))
        )
    except (TypeError, ValueError):
        configured = DEFAULT_MONTHLY_BUDGET_USD
    if not math.isfinite(configured):
        return 0.0
    return min(max(configured, 0.0), DEFAULT_MONTHLY_BUDGET_USD)


def _pricing(model: str) -> dict[str, float]:
    model_name = str(model or "").casefold()
    if model_name not in MODEL_PRICING_USD_PER_MILLION:
        raise UnsupportedAIModel(
            f"AI model {model!r} is not in the budget pricing allowlist"
        )
    return MODEL_PRICING_USD_PER_MILLION[model_name]


def _token_count(value: Any) -> int | None:
    if value is None:
        return None
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return max(number, 0)


def _usage_values(usage: Any) -> tuple[int | None, int | None, int | None]:
    if usage is None:
        return None, None, None
    prompt = _token_count(getattr(usage, "prompt_tokens", None))
    completion = _token_count(getattr(usage, "completion_tokens", None))
    total = _token_count(getattr(usage, "total_tokens", None))
    if isinstance(usage, dict):
        prompt = _token_count(usage.get("prompt_tokens", prompt))
        completion = _token_count(usage.get("completion_tokens", completion))
        total = _token_count(usage.get("total_tokens", total))
    if total is None and prompt is not None and completion is not None:
        total = prompt + completion
    return prompt, completion, total


def _messages_token_estimate(messages: Any) -> tuple[int, int]:
    """Estimate prompt tokens without expanding base64 image payloads."""
    if not isinstance(messages, list):
        return 0, 0
    text_bytes = 0
    structural_tokens = 0
    image_count = 0
    for message in messages:
        structural_tokens += 16
        content = message.get("content") if isinstance(message, dict) else None
        if isinstance(content, str):
            text_bytes += len(content.encode("utf-8"))
        elif isinstance(content, list):
            for part in content:
                if not isinstance(part, dict):
                    continue
                structural_tokens += 8
                if part.get("type") == "text":
                    text_bytes += len(str(part.get("text") or "").encode("utf-8"))
                elif part.get("type") == "image_url":
                    image_count += 1
        elif content is not None:
            text_bytes += len(str(content).encode("utf-8"))
    # A tokenizer cannot produce more ordinary text tokens than the UTF-8 byte
    # stream plus chat-structure overhead. The later safety multiplier adds a
    # further margin for provider-specific accounting.
    return (
        text_bytes
        + structural_tokens
        + image_count * IMAGE_PROMPT_TOKEN_RESERVE,
        image_count,
    )


def _guarded_completion_limit(kwargs: dict[str, Any]) -> int:
    if kwargs.get("tools") or kwargs.get("functions"):
        raise ValueError(
            "Tool schemas are not supported by the AI budget estimator"
        )
    value = kwargs.get("max_completion_tokens", kwargs.get("max_tokens"))
    try:
        limit = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            "A positive max_completion_tokens limit is required by the AI budget guard"
        ) from exc
    if limit <= 0:
        raise ValueError(
            "A positive max_completion_tokens limit is required by the AI budget guard"
        )
    return limit


def estimate_request_cost(
    model: str,
    messages: Any,
    max_completion_tokens: Any,
    *,
    safety_multiplier: float = 1.0,
) -> float:
    """Return a conservative USD estimate for one request."""
    pricing = _pricing(model)
    prompt_tokens, image_count = _messages_token_estimate(messages)
    try:
        completion_tokens = max(int(max_completion_tokens or 0), 0)
    except (TypeError, ValueError):
        completion_tokens = 0
    prompt_cost = prompt_tokens / 1_000_000 * pricing["input"]
    completion_cost = completion_tokens / 1_000_000 * pricing["output"]
    fixed_image_cost = image_count * 0.001
    return (prompt_cost + completion_cost + fixed_image_cost) * safety_multiplier


class AIBudget:
    """Persist monthly reservations and settled request costs atomically."""

    def __init__(
        self,
        state_path: Path = STATE_FILE,
        budget_usd: float | None = None,
    ):
        self.state_path = Path(state_path)
        if budget_usd is None:
            self.budget_usd = _configured_budget()
        else:
            parsed_budget = float(budget_usd)
            if not math.isfinite(parsed_budget):
                raise ValueError("AI monthly budget must be finite")
            self.budget_usd = min(max(parsed_budget, 0.0), 20.0)
        self._lock = threading.RLock()

    def _empty_state(self, month: str | None = None) -> dict[str, Any]:
        return {
            "month": month or _month_key(),
            "budget_usd": self.budget_usd,
            "spent_usd": 0.0,
            "budget_debited_usd": 0.0,
            "reserved_usd": 0.0,
            "requests": 0,
            "blocked_requests": 0,
            "by_model": {},
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }

    @property
    def _lock_path(self) -> Path:
        return self.state_path.with_suffix(self.state_path.suffix + ".lock")

    @property
    def _initialized_path(self) -> Path:
        return self.state_path.with_suffix(self.state_path.suffix + ".initialized")

    @contextmanager
    def _state_lock(self):
        with self._lock:
            try:
                self.state_path.parent.mkdir(parents=True, exist_ok=True)
                with self._lock_path.open("a+", encoding="utf-8") as lock_handle:
                    fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
                    try:
                        yield
                    finally:
                        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)
            except AIBudgetStateError:
                raise
            except OSError as exc:
                raise AIBudgetStateError(
                    f"AI budget ledger lock failed: {exc}"
                ) from exc

    def _load(self) -> dict[str, Any]:
        try:
            state = json.loads(
                self.state_path.read_text(encoding="utf-8"),
                parse_constant=lambda value: (_ for _ in ()).throw(
                    ValueError(f"invalid numeric constant {value}")
                ),
            )
        except FileNotFoundError as exc:
            if self._initialized_path.exists():
                raise AIBudgetStateError(
                    "AI budget ledger is missing after it was initialized"
                ) from exc
            state = self._empty_state()
            self._save(state)
            return state
        except (OSError, ValueError, TypeError) as exc:
            raise AIBudgetStateError(
                f"AI budget ledger cannot be read safely: {exc}"
            ) from exc
        if not isinstance(state, dict):
            raise AIBudgetStateError("AI budget ledger must contain a JSON object")
        month = state.get("month")
        if not isinstance(month, str) or not re.fullmatch(r"\d{4}-\d{2}", month):
            raise AIBudgetStateError("AI budget ledger has an invalid month")
        if month != _month_key():
            state = self._empty_state()
            self._save(state)
            return state
        state["budget_usd"] = self.budget_usd
        state.setdefault("spent_usd", 0.0)
        state.setdefault("budget_debited_usd", state["spent_usd"])
        state.setdefault("reserved_usd", 0.0)
        state.setdefault("requests", 0)
        state.setdefault("blocked_requests", 0)
        state.setdefault("by_model", {})
        self._validate_state(state)
        return state

    @staticmethod
    def _validate_state(state: dict[str, Any]) -> None:
        for field in (
            "budget_usd",
            "spent_usd",
            "budget_debited_usd",
            "reserved_usd",
        ):
            value = state.get(field)
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
                or value < 0
            ):
                raise AIBudgetStateError(
                    f"AI budget ledger has an invalid {field}"
                )
        for field in ("requests", "blocked_requests"):
            value = state.get(field)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise AIBudgetStateError(
                    f"AI budget ledger has an invalid {field}"
                )
        by_model = state.get("by_model")
        if not isinstance(by_model, dict):
            raise AIBudgetStateError("AI budget ledger has invalid model totals")
        for model, model_stats in by_model.items():
            if not isinstance(model, str) or not isinstance(model_stats, dict):
                raise AIBudgetStateError(
                    "AI budget ledger has invalid model totals"
                )
            model_stats.setdefault("budget_debited_usd", 0.0)
            for field in ("estimated_usd", "budget_debited_usd"):
                value = model_stats.get(field)
                if (
                    isinstance(value, bool)
                    or not isinstance(value, (int, float))
                    or not math.isfinite(float(value))
                    or value < 0
                ):
                    raise AIBudgetStateError(
                        f"AI budget ledger has invalid {model} {field}"
                    )
            for field in (
                "requests",
                "prompt_tokens",
                "completion_tokens",
                "total_tokens",
                "usage_available_requests",
            ):
                value = model_stats.get(field)
                if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                    raise AIBudgetStateError(
                        f"AI budget ledger has invalid {model} {field}"
                    )

    def _save(self, state: dict[str, Any]) -> None:
        state["updated_at"] = datetime.now(timezone.utc).isoformat()
        temporary_name = ""
        try:
            descriptor, temporary_name = tempfile.mkstemp(
                prefix=self.state_path.name + ".",
                suffix=".tmp",
                dir=self.state_path.parent,
            )
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(
                    state,
                    handle,
                    indent=2,
                    sort_keys=True,
                    allow_nan=False,
                )
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, self.state_path)
            self._initialized_path.touch(exist_ok=True)
        except OSError as exc:
            raise AIBudgetStateError(
                f"AI budget ledger cannot be saved safely: {exc}"
            ) from exc
        finally:
            if temporary_name:
                try:
                    Path(temporary_name).unlink(missing_ok=True)
                except OSError:
                    pass

    def reserve(
        self,
        model: str,
        messages: Any,
        max_completion_tokens: Any,
    ) -> Reservation:
        model_name = str(model or "unknown")
        estimate = estimate_request_cost(
            model_name,
            messages,
            max_completion_tokens,
            safety_multiplier=RESERVATION_SAFETY_MULTIPLIER,
        )
        try:
            completion_limit = max(int(max_completion_tokens or 0), 0)
        except (TypeError, ValueError):
            completion_limit = 0
        with self._state_lock():
            state = self._load()
            available = (
                self.budget_usd
                - float(state["budget_debited_usd"])
                - float(state["reserved_usd"])
            )
            if estimate > available + 1e-12:
                state["blocked_requests"] = int(state["blocked_requests"]) + 1
                self._save(state)
                raise AIBudgetExceeded(
                    "AI monthly budget exhausted: "
                    f"${float(state['budget_debited_usd']):.4f} conservatively "
                    f"debited plus ${float(state['reserved_usd']):.4f} reserved "
                    f"of ${self.budget_usd:.2f}; request needs about ${estimate:.4f}"
                )
            state["reserved_usd"] = float(state["reserved_usd"]) + estimate
            self._save(state)
        print(
            f"[AI Budget] Reserved ${estimate:.4f} for {model_name}; "
            f"remaining ceiling after reservation ${available - estimate:.4f}"
        )
        return Reservation(model_name, estimate, completion_limit)

    def release(self, reservation: Reservation) -> None:
        with self._state_lock():
            state = self._load()
            state["reserved_usd"] = max(
                0.0,
                float(state["reserved_usd"]) - reservation.estimated_usd,
            )
            self._save(state)

    def settle(self, reservation: Reservation, usage: Any) -> float:
        prompt_tokens, completion_tokens, total_tokens = _usage_values(usage)
        if prompt_tokens is None or completion_tokens is None:
            actual_cost = reservation.estimated_usd
            cost_basis = "conservative reservation"
        else:
            pricing = _pricing(reservation.model)
            actual_cost = (
                prompt_tokens / 1_000_000 * pricing["input"]
                + completion_tokens / 1_000_000 * pricing["output"]
            )
            cost_basis = "provider usage"
        budget_debit = max(actual_cost, reservation.estimated_usd)

        with self._state_lock():
            state = self._load()
            state["reserved_usd"] = max(
                0.0,
                float(state["reserved_usd"]) - reservation.estimated_usd,
            )
            state["spent_usd"] = float(state["spent_usd"]) + actual_cost
            state["budget_debited_usd"] = (
                float(state["budget_debited_usd"]) + budget_debit
            )
            state["requests"] = int(state["requests"]) + 1
            by_model = state.setdefault("by_model", {})
            model_stats = by_model.setdefault(
                reservation.model,
                {
                    "requests": 0,
                    "prompt_tokens": 0,
                    "completion_tokens": 0,
                    "total_tokens": 0,
                    "usage_available_requests": 0,
                    "estimated_usd": 0.0,
                    "budget_debited_usd": 0.0,
                },
            )
            model_stats.setdefault("budget_debited_usd", 0.0)
            model_stats["requests"] += 1
            model_stats["estimated_usd"] += actual_cost
            model_stats["budget_debited_usd"] += budget_debit
            if prompt_tokens is not None:
                model_stats["prompt_tokens"] += prompt_tokens
            if completion_tokens is not None:
                model_stats["completion_tokens"] += completion_tokens
            if total_tokens is not None:
                model_stats["total_tokens"] += total_tokens
            if prompt_tokens is not None and completion_tokens is not None:
                model_stats["usage_available_requests"] += 1
            self._save(state)
        print(
            f"[AI Budget] Settled ${actual_cost:.4f} for {reservation.model} "
            f"({cost_basis}); conservative monthly debit "
            f"${float(state['budget_debited_usd']):.4f}/${self.budget_usd:.2f}"
        )
        return actual_cost

    def snapshot(self) -> dict[str, Any]:
        with self._state_lock():
            state = self._load()
            state["remaining_usd"] = max(
                0.0,
                self.budget_usd
                - float(state["budget_debited_usd"])
                - float(state["reserved_usd"]),
            )
            return state


GLOBAL_AI_BUDGET = AIBudget()


class _BudgetedCompletions:
    def __init__(self, completions: Any, budget: AIBudget):
        self._completions = completions
        self._budget = budget

    def create(self, *args: Any, **kwargs: Any) -> Any:
        model = kwargs.get("model", "unknown")
        completion_limit = _guarded_completion_limit(kwargs)
        reservation = self._budget.reserve(
            model,
            kwargs.get("messages", []),
            completion_limit,
        )
        try:
            response = self._completions.create(*args, **kwargs)
        except Exception:
            # The provider may have processed a request even when its response
            # was lost. Debit the reservation rather than failing open.
            self._budget.settle(reservation, None)
            raise
        self._budget.settle(reservation, getattr(response, "usage", None))
        return response


class _BudgetedAsyncCompletions:
    def __init__(self, completions: Any, budget: AIBudget):
        self._completions = completions
        self._budget = budget

    async def create(self, *args: Any, **kwargs: Any) -> Any:
        model = kwargs.get("model", "unknown")
        completion_limit = _guarded_completion_limit(kwargs)
        reservation = self._budget.reserve(
            model,
            kwargs.get("messages", []),
            completion_limit,
        )
        try:
            response = await self._completions.create(*args, **kwargs)
        except Exception:
            self._budget.settle(reservation, None)
            raise
        self._budget.settle(reservation, getattr(response, "usage", None))
        return response


class BudgetedOpenAI:
    """Drop-in OpenAI client whose chat completions use the monthly guard."""

    def __init__(self, *args: Any, **kwargs: Any):
        kwargs["max_retries"] = 0
        raw = _RawOpenAI(*args, **kwargs)
        self.chat = SimpleNamespace(
            completions=_BudgetedCompletions(raw.chat.completions, GLOBAL_AI_BUDGET)
        )


class BudgetedAsyncOpenAI:
    """Drop-in AsyncOpenAI client whose chat completions use the monthly guard."""

    def __init__(self, *args: Any, **kwargs: Any):
        kwargs["max_retries"] = 0
        raw = _RawAsyncOpenAI(*args, **kwargs)
        self.chat = SimpleNamespace(
            completions=_BudgetedAsyncCompletions(
                raw.chat.completions, GLOBAL_AI_BUDGET
            )
        )