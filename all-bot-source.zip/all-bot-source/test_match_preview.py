import asyncio
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, MagicMock, patch

from openpyxl import Workbook
import discord

from ai_budget import AIBudgetStateError
import main
import match_preview
from main import _matchpreview_winner_poll
from match_preview import (
    MATCH_INSIGHT_CATEGORIES,
    PlayerResolutionError,
    _match_key_points,
    _parse_ranking_table,
    _summary_rows_sync,
    build_match_data,
    calculate_prediction,
    collect_match_data,
    format_match_preview,
    personalized_match_keys,
    HOMEPAGE_URL,
    normalize_name,
    parse_fixture_odds,
    parse_h2h_html,
    parse_player_avatar,
    parse_results_html,
    resolve_players,
    season_summary_text,
    split_discord_message,
    winner_for_result,
    fetch_player_results,
)


RANKINGS_HTML = """
<table id="rankTable">
  <tr><th>Rank</th><th></th><th>Player</th><th>Points</th>
      <th>Race Points</th><th>WTSL Elo</th><th>In-game Elo</th></tr>
  <tr><td>1</td><td></td><td><a href="player_page.php?player=10">Alpha Ace</a></td>
      <td>10,000</td><td>8,000</td><td>2200</td><td>3100</td></tr>
  <tr><td>2</td><td></td><td><a href="player_page.php?player=20">Beta Baseline</a></td>
      <td>9,000</td><td>7,000</td><td>2100</td><td>3000</td></tr>
</table>
"""

RESULTS_HTML = """
<table>
  <tr><th>Tournament</th><th>Round</th><th>Player 1</th>
      <th>Player 2</th><th>Date</th><th>Result</th></tr>
  <tr><td></td><td>London Open</td><td>Final</td><td>Alpha Ace</td>
      <td>Beta Baseline</td><td>20.08.2026</td><td>6-4,3-6,7-5</td></tr>
  <tr><td></td><td>Rome Open</td><td>R16</td><td>Other Player</td>
      <td>Alpha Ace</td><td>01.08.2026</td><td>4-6,4-6</td></tr>
  <tr><td></td><td>Paris Open</td><td>QF</td><td>Alpha Ace</td>
      <td>Beta Baseline</td><td>30.07.2026</td><td>Walkover</td></tr>
  <tr><td></td><td>Madrid Open</td><td>R32</td><td>Beta Baseline</td>
      <td>Alpha Ace</td><td>29.07.2026</td><td>Coin Toss</td></tr>
  <tr><td></td><td>Miami Open</td><td>R16</td><td>Alpha Ace</td>
      <td>Beta Baseline</td><td>28.07.2026</td><td>BCT</td></tr>
  <tr><td></td><td>Dubai Open</td><td>R16</td><td>Alpha Ace</td>
      <td>Beta Baseline</td><td>27.07.2026</td><td>Scheduled</td></tr>
</table>
"""

FIXTURES_HTML = """
<table class="table">
  <tr><th>Tournament</th><th>Tour</th><th>Match</th><th>Odds</th></tr>
  <tr><td>Kingston (QF)</td><td>ATP</td><td>
    <a href="../player_page.php?player=10">Alpha Ace</a> -
    <a href="../player_page.php?player=20">Beta Baseline</a></td>
    <td><a href="../h2h.php?pl_one=10&amp;pl_two=20">1.40 / 3.49</a></td></tr>
</table>
"""

REVERSED_WTA_FIXTURES_HTML = """
<table>
  <tr><th>Tournament</th><th>Tour</th><th>Match</th><th>Odds</th></tr>
  <tr><td>Toronto (SF)</td><td>WTA</td><td>
    <a href="player_page.php?player=939">Squeakova</a> -
    <a href="player_page.php?player=944">Halapeno</a></td>
    <td>2.40 / 1.67</td></tr>
</table>
"""

H2H_HTML = """
<table class="table table-hover results-table">
  <tr><th>Date</th><th>Tournament</th><th>Competition</th><th>Round</th>
      <th>Winner</th><th>Score</th></tr>
  <tr><td>20.08.2026</td><td></td><td>London Open</td><td>Singles</td>
      <td>Final</td><td><a href="player_page.php?player=10">Alpha Ace</a></td>
      <td>6-4,3-6,7-5</td></tr>
  <tr><td>10.07.2026</td><td></td><td>Paris Open</td><td>Singles</td>
      <td>QF</td><td><a href="player_page.php?player=20">Beta Baseline</a></td>
      <td>6-2,6-3</td></tr>
  <tr><td>01.06.2026</td><td></td><td>Rome Open</td><td>Singles</td>
      <td>R16</td><td>Alpha Ace</td><td>Walkover</td></tr>
</table>
"""


def player(name, player_id, rank):
    return {
        "name": name,
        "id": player_id,
        "rank": rank,
        "points": "1000",
        "race_points": "900",
        "wtsl_elo": "2000",
        "in_game_elo": "3000",
        "tour": "atp",
    }


class MatchPreviewTests(IsolatedAsyncioTestCase):
    def test_wtsl_preview_stage_limits(self):
        def allowed(category, round_name):
            return main._match_preview_allowed(
                {
                    "event_category": category,
                    "round": round_name,
                    "odds": {},
                }
            )

        self.assertFalse(allowed("WTSL 250", "R16"))
        self.assertFalse(allowed("WTSL 250", "QF"))
        self.assertTrue(allowed("WTSL 250", "SF"))
        self.assertTrue(allowed("WTSL 250", "Final"))
        self.assertFalse(allowed("WTSL 500", "R16"))
        self.assertTrue(allowed("WTSL 500", "QF"))
        self.assertTrue(allowed("WTSL Masters 1000", "Final"))

    def test_wta_elo_rankings_parser_reads_tour_elo(self):
        html = """
        <table><tr><td>1</td><td></td>
        <td><a href="player_page.php?player=1">janemasta</a></td>
        <td>100</td><td>90</td><td>1876</td></tr>
        <tr><td>2</td><td></td>
        <td><a href="player_page.php?player=2">Halapeno</a></td>
        <td>80</td><td>70</td><td>1822</td></tr></table>
        """
        self.assertEqual(
            main._parse_wtsl_elo_rankings(html),
            {"janemasta": 1876, "halapeno": 1822},
        )

    def test_wtsl_weekly_message_content_uses_completed_period_label(self):
        content = main._wtsl_weekly_message_content(
            {
                "discord_user_id": 131,
                "total_profit": "32.00",
                "successful_bets": 1,
                "failed_bets": 0,
            },
            "last week's",
        )

        self.assertIn("<@131>", content)
        self.assertIn("last week's betting leaderboard", content)
        self.assertIn("W$32.00 profit", content)
        self.assertIn("1W / 0L", content)

    async def test_startup_leaderboard_refresh_does_not_publish_betting_message(self):
        with (
            patch.object(
                main.client,
                "wait_until_ready",
                new=AsyncMock(),
            ),
            patch(
                "main.asyncio.sleep",
                new=AsyncMock(),
            ),
            patch.object(
                main,
                "_post_weekly_leaderboards_now",
                new=AsyncMock(),
            ) as refresh,
            patch.object(
                main,
                "_post_wtsl_weekly_message_now",
                new=AsyncMock(),
            ) as betting_message,
        ):
            await main._post_weekly_leaderboards_after_startup()

        refresh.assert_awaited_once_with()
        betting_message.assert_not_awaited()

    async def test_fetch_player_results_uses_shared_results_and_filters_player(self):
        alpha_result = {
            "tournament": "London Open",
            "round": "Final",
            "p1": "Alpha Ace",
            "p2": "Beta Baseline",
            "date": "20.08.2026",
            "result": "6-4, 6-4",
            "p1_character": "Character Alpha",
            "p2_character": "Character Beta",
            "tour": "atp",
            "source_url": "https://example.test/london",
        }
        beta_result = {
            "tournament": "Rome Open",
            "round": "R16",
            "p1": "Other Player",
            "p2": "Beta Baseline",
            "date": "19.08.2026",
            "result": "6-1, 6-1",
            "p1_character": "Character Other",
            "p2_character": "Character Beta",
            "tour": "atp",
            "source_url": "https://example.test/rome",
        }
        with patch(
            "match_preview.get_all_results",
            new=AsyncMock(return_value=[alpha_result, dict(alpha_result), beta_result]),
        ) as get_all_results:
            results = await fetch_player_results(MagicMock(), "  alpha ace ")

        get_all_results.assert_awaited_once_with()
        self.assertEqual(results, [alpha_result])

    async def test_fetch_player_results_can_force_shared_source_refresh(self):
        result = {
            "tournament": "London Open",
            "p1": "ruze",
            "p2": "Beta Baseline",
            "date": "20.08.2026",
            "result": "6-4, 6-4",
        }
        with patch(
            "match_preview.get_all_results",
            new=AsyncMock(return_value=[result]),
        ) as get_all_results:
            results = await fetch_player_results(
                MagicMock(),
                "itsruze",
                allow_stale=True,
                force_refresh=True,
            )

        get_all_results.assert_awaited_once_with(
            allow_stale=True,
            force_refresh=True,
        )
        self.assertEqual(results, [result])

    def test_season_summary_names_only_titles_and_finals(self):
        results = [
            {
                "tournament": "London Masters",
                "round": "Final",
                "p1": "Alpha Ace",
                "p2": "Beta Baseline",
                "date": "08.09.2026",
                "result": "6-4,6-4",
            },
            {
                "tournament": "Paris Masters",
                "round": "Final",
                "p1": "Gamma",
                "p2": "Alpha Ace",
                "date": "01.08.2026",
                "result": "6-3,6-3",
            },
        ]
        summary = season_summary_text(
            results,
            "Alpha Ace",
            {
                "beta baseline": {"rank": 2},
                "gamma": {"rank": 1},
            },
            year=2026,
        )
        self.assertIn("**1-1 (50%)**", summary)
        self.assertIn("won **London Masters**", summary)
        self.assertIn("reached the final at **Paris Masters**", summary)
        self.assertNotIn("best-ranked win", summary)
        self.assertNotIn("furthest round", summary)

    def test_season_summary_orders_achievements_by_tournament_magnitude(self):
        results = [
            {
                "tournament": "Tennis Elbow 4 (ATP Characters) - Washington 2026",
                "round": "Final",
                "p1": "Dani21",
                "p2": "Beta",
                "date": "07.08.2026",
                "result": "6-4,6-4",
            },
            {
                "tournament": "Tennis Elbow 4 (ATP Characters) - Wimbledon 2026",
                "round": "Final",
                "p1": "Dani21",
                "p2": "Gamma",
                "date": "18.07.2026",
                "result": "6-4,6-4,6-4",
            },
            {
                "tournament": "Tennis Elbow 4 (ATP Characters) - Montreal 2026",
                "round": "Final",
                "p1": "Dani21",
                "p2": "Delta",
                "date": "16.08.2026",
                "result": "6-4,6-4",
            },
            {
                "tournament": "Tennis Elbow 4 (ATP Characters) - Halle 2026",
                "round": "Final",
                "p1": "Dani21",
                "p2": "Epsilon",
                "date": "26.06.2026",
                "result": "6-4,6-4",
            },
            {
                "tournament": "Tennis Elbow 4 (ATP Characters) - Queens 2026",
                "round": "Final",
                "p1": "Dani21",
                "p2": "Zeta",
                "date": "29.06.2026",
                "result": "6-4,6-4",
            },
        ]

        summary = season_summary_text(results, "Dani21", {}, year=2026)

        self.assertIn(
            "won **Wimbledon**, **Montreal** *(WTSL Masters 1000)*, "
            "**Washington** *(WTSL 500)*, **Queens** *(WTSL 500)*, "
            "**Halle** *(WTSL 500)*",
            summary,
        )

    def test_preview_removes_te4_prefix_from_displayed_tournament_names(self):
        first, second = player("Alpha Ace", "10", 1), player("Beta Baseline", "20", 2)
        data = build_match_data(
            "atp",
            first,
            second,
            [{
                "tournament": "Tennis Elbow 4 (ATP Characters) - Wimbledon 2026",
                "round": "Final",
                "p1": "Alpha Ace",
                "p2": "Beta Baseline",
                "date": "18.07.2026",
                "result": "6-4,6-4",
            }],
            [],
            {},
            "",
            odds={
                "first": 1.5,
                "second": 2.5,
                "tournament": "Tennis Elbow 4 (ATP Characters) - Montreal 2026",
            },
        )

        preview = format_match_preview(data)

        self.assertIn("match preview for Montreal", preview)
        self.assertIn("· Wimbledon (Final)", preview)
        self.assertNotIn("Tennis Elbow 4 (ATP Characters)", preview)

    def test_matchup_profiles_use_separate_readable_lines(self):
        first, second = player("Alpha Ace", "10", 1), player("Beta Baseline", "20", 2)
        data = build_match_data(
            "atp",
            first,
            second,
            [],
            [],
            {
                "alpha ace": {"1st Serve Won %": 0.70, "Return Points Won %": 0.45},
                "beta baseline": {"1st Serve Won %": 0.65, "Return Points Won %": 0.48},
            },
            "",
        )

        story = "\n".join(match_preview._article_story_lines(data))

        self.assertIn("**Alpha Ace** — Ranked **#1**", story)
        self.assertIn("• **Serve:** **1st Serve Won % 70.0%**", story)
        self.assertIn("• **Return:** **Return Points Won % 45.0%**", story)
        self.assertIn("\n\n**Beta Baseline** — Ranked **#2**", story)
        self.assertNotIn("serve profile:", story)

    def test_season_summary_omits_ranked_and_non_played_win_details(self):
        results = [
            {
                "tournament": "Coin Event", "round": "R16",
                "p1": "Nick1234567", "p2": "Ptacek",
                "date": "08.09.2026", "result": "Coin Toss 6-3",
            },
            {
                "tournament": "Walkover Event", "round": "QF",
                "p1": "Nick1234567", "p2": "Walkover Opponent",
                "date": "07.09.2026", "result": "6-0 W/O",
            },
            {
                "tournament": "BCT Event", "round": "SF",
                "p1": "Nick1234567", "p2": "BCT Opponent",
                "date": "06.09.2026", "result": "BCT 6-4",
            },
            {
                "tournament": "Played Event", "round": "R32",
                "p1": "Nick1234567", "p2": "Played Opponent",
                "date": "05.09.2026", "result": "6-4,6-4",
            },
        ]
        summary = season_summary_text(
            results,
            "Nick1234567",
            {
                "ptacek": {"rank": 1},
                "walkover opponent": {"rank": 2},
                "bct opponent": {"rank": 3},
                "played opponent": {"rank": 20},
            },
            year=2026,
        )
        self.assertNotIn("best-ranked win", summary)
        self.assertNotIn("furthest round", summary)

    async def test_stats_metadata_preserves_screenshot_tournament_and_has_text_fallback(self):
        message = SimpleNamespace(
            content="Tournament: Wimbledon | <@101> def <@202> in the Final",
            mentions=[SimpleNamespace(id=101), SimpleNamespace(id=202)],
            created_at=datetime(2026, 9, 1, tzinfo=timezone.utc),
        )

        screenshot_value = {"tournament": "Screenshot Championship"}
        main._apply_discord_match_metadata(screenshot_value, message)
        self.assertEqual(
            screenshot_value["tournament"],
            "Screenshot Championship",
        )

        text_only_value = {"tournament": None}
        main._apply_discord_match_metadata(text_only_value, message)
        self.assertEqual(text_only_value["tournament"], "Wimbledon")

        fallback_message = SimpleNamespace(
            content="Wimbledon Final: <@101> def <@202>",
            mentions=[
                SimpleNamespace(id=101, display_name="Alpha Ace"),
                SimpleNamespace(id=202, display_name="Beta Baseline"),
            ],
            created_at=datetime(2026, 9, 1, tzinfo=timezone.utc),
        )
        missing_names = {
            "player": {"name": None},
            "opponent": {"name": ""},
            "tournament": None,
        }
        main._apply_discord_match_metadata(missing_names, fallback_message)
        self.assertEqual(missing_names["player"]["name"], "Alpha Ace")
        self.assertEqual(missing_names["opponent"]["name"], "Beta Baseline")
        self.assertIn(
            "Discord mention fallback",
            missing_names["player"]["note"],
        )

    async def test_final_interviews_use_acceptance_invites(self):
        winner = SimpleNamespace(id=101, display_name="Alpha Ace", mention="<@101>")
        loser = SimpleNamespace(id=202, display_name="Beta Baseline", mention="<@202>")
        winner_invite = SimpleNamespace(
            id=5001,
            add_user=AsyncMock(),
            send=AsyncMock(),
        )
        loser_invite = SimpleNamespace(
            id=5002,
            add_user=AsyncMock(),
            send=AsyncMock(),
        )
        channel = SimpleNamespace(
            id=9001,
            create_thread=AsyncMock(side_effect=[winner_invite, loser_invite]),
        )
        message = SimpleNamespace(
            id=9002,
            content="<@101> def <@202> in the Final",
            mentions=[winner, loser],
            attachments=[
                SimpleNamespace(
                    content_type="image/png",
                    url="https://example.test/stats.png",
                )
            ],
            guild=None,
            channel=channel,
            create_thread=AsyncMock(),
        )
        response = SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content="What changed in the match?")
                )
            ]
        )
        ai_client = SimpleNamespace(
            chat=SimpleNamespace(
                completions=SimpleNamespace(
                    create=MagicMock(return_value=response)
                )
            )
        )

        with patch(
            "main.fetch_player_profile_context",
            new=AsyncMock(return_value=""),
        ):
            try:
                await main._try_trigger_interview(message, ai_client)
                self.assertEqual(channel.create_thread.await_count, 2)
                message.create_thread.assert_not_awaited()
                self.assertIn(
                    "Interview Invite",
                    channel.create_thread.await_args_list[0].kwargs["name"],
                )
                self.assertIsNone(
                    main._pending_interviews[winner_invite.id]["first_question"]
                )
                self.assertIsNone(
                    main._pending_interviews[loser_invite.id]["first_question"]
                )
                ai_client.chat.completions.create.assert_not_called()
            finally:
                main._pending_interviews.pop(winner_invite.id, None)
                main._pending_interviews.pop(loser_invite.id, None)

    async def test_accept_generates_opening_question_after_player_accepts(self):
        invite_thread_id = 5101
        public_thread = SimpleNamespace(id=5102, send=AsyncMock())
        result_message = SimpleNamespace(
            create_thread=AsyncMock(return_value=public_thread)
        )
        result_channel = SimpleNamespace(
            fetch_message=AsyncMock(return_value=result_message)
        )
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=101, mention="<@101>"),
            response=SimpleNamespace(defer=AsyncMock()),
            edit_original_response=AsyncMock(),
            channel=SimpleNamespace(edit=AsyncMock()),
        )
        response = SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content="1. What changed in the match?")
                )
            ]
        )
        create = MagicMock(return_value=response)
        ai_client = SimpleNamespace(
            chat=SimpleNamespace(
                completions=SimpleNamespace(create=create)
            )
        )
        main._pending_interviews[invite_thread_id] = {
            "player_ids": [101],
            "player_id": 101,
            "player_name": "Alpha Ace",
            "first_question": None,
            "first_question_system": "Interview the winner.",
            "first_question_content": "Generate the opening question.",
            "opener": "well played today",
            "journalist_name": "Jake",
            "round_hint": "Final",
            "conversation_history": [
                {"role": "system", "content": "Interview the winner."}
            ],
            "result_channel_id": 9001,
            "result_message_id": 9002,
            "created_at": 1.0,
            "reaction_style": "React briefly.",
        }
        view = main.InterviewAcceptView(
            private_thread_id=invite_thread_id,
            player_ids=[101],
        )

        with (
            patch("main.OpenAI", return_value=ai_client),
            patch.object(
                main.client,
                "get_channel",
                return_value=result_channel,
            ),
        ):
            try:
                await view.accept.callback(interaction)
                create.assert_called_once()
                self.assertEqual(
                    create.call_args.kwargs["max_completion_tokens"],
                    256,
                )
                result_message.create_thread.assert_awaited_once()
                self.assertEqual(public_thread.send.await_count, 2)
                self.assertEqual(
                    public_thread.send.await_args_list[1].args[0],
                    "🎙️ What changed in the match?",
                )
                self.assertIn(public_thread.id, main._active_interviews)
            finally:
                main._pending_interviews.pop(invite_thread_id, None)
                main._active_interviews.pop(public_thread.id, None)

    async def test_accept_uses_fallback_when_opening_question_is_empty(self):
        invite_thread_id = 5201
        public_thread = SimpleNamespace(id=5202, send=AsyncMock())
        result_message = SimpleNamespace(
            create_thread=AsyncMock(return_value=public_thread)
        )
        result_channel = SimpleNamespace(
            fetch_message=AsyncMock(return_value=result_message)
        )
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=101, mention="<@101>"),
            response=SimpleNamespace(defer=AsyncMock()),
            edit_original_response=AsyncMock(),
            channel=SimpleNamespace(edit=AsyncMock()),
        )
        main._pending_interviews[invite_thread_id] = {
            "player_ids": [101],
            "player_id": 101,
            "player_name": "Alpha Ace",
            "first_question": None,
            "first_question_system": "Interview the winner.",
            "first_question_content": "Generate the opening question.",
            "opener": "well played today",
            "journalist_name": "Jake",
            "round_hint": "Final",
            "conversation_history": [
                {"role": "system", "content": "Interview the winner."}
            ],
            "result_channel_id": 9001,
            "result_message_id": 9002,
            "created_at": 1.0,
            "reaction_style": "React briefly.",
        }
        view = main.InterviewAcceptView(
            private_thread_id=invite_thread_id,
            player_ids=[101],
        )

        with (
            patch(
                "main._generate_interview_opening_for_pending",
                side_effect=ValueError("AI returned an empty opening interview question"),
            ),
            patch.object(
                main.client,
                "get_channel",
                return_value=result_channel,
            ),
        ):
            try:
                await view.accept.callback(interaction)
                result_message.create_thread.assert_awaited_once()
                self.assertEqual(
                    public_thread.send.await_args_list[1].args[0],
                    f"🎙️ {main.INTERVIEW_FALLBACK_OPENING_QUESTION}",
                )
                self.assertIn(public_thread.id, main._active_interviews)
            finally:
                main._pending_interviews.pop(invite_thread_id, None)
                main._active_interviews.pop(public_thread.id, None)

    async def test_active_interview_closes_cleanly_when_budget_ledger_fails(self):
        thread = SimpleNamespace(
            id=4242,
            send=AsyncMock(),
            edit=AsyncMock(),
        )
        message = SimpleNamespace(
            channel=thread,
            author=SimpleNamespace(mention="<@123>"),
            content="My serve felt good.",
        )
        create = MagicMock(
            side_effect=AIBudgetStateError("ledger unavailable")
        )
        interview = {
            "conversation_history": [],
            "q_count": 1,
            "reaction_style": "React briefly.",
        }
        main._active_interviews[thread.id] = interview

        mock_client = SimpleNamespace(
            chat=SimpleNamespace(
                completions=SimpleNamespace(create=create)
            )
        )
        try:
            with patch("main.OpenAI", return_value=mock_client):
                await main._handle_interview_reply(
                    message,
                    interview,
                )
        finally:
            main._active_interviews.pop(thread.id, None)

        self.assertNotIn(thread.id, main._active_interviews)
        self.assertIn(
            "monthly AI budget",
            thread.send.await_args.args[0],
        )
        thread.edit.assert_awaited_once_with(archived=True)

    async def test_active_interview_closes_cleanly_when_reply_times_out(self):
        thread = SimpleNamespace(
            id=4343,
            send=AsyncMock(),
            edit=AsyncMock(),
        )
        message = SimpleNamespace(
            channel=thread,
            author=SimpleNamespace(mention="<@456>"),
            content="My serve felt good.",
        )
        interview = {
            "conversation_history": [],
            "q_count": 1,
            "reaction_style": "React briefly.",
        }
        main._active_interviews[thread.id] = interview

        try:
            with (
                patch("main.OpenAI"),
                patch(
                    "main._interview_completion",
                    new=AsyncMock(side_effect=asyncio.TimeoutError),
                ),
            ):
                await main._handle_interview_reply(message, interview)

            self.assertIn(thread.id, main._active_interviews)
            self.assertIn(
                "still open",
                thread.send.await_args.args[0],
            )
            thread.edit.assert_not_awaited()
        finally:
            main._active_interviews.pop(thread.id, None)

    async def test_active_interview_fallback_uses_answer_context_and_varies(self):
        thread = SimpleNamespace(
            id=4444,
            send=AsyncMock(),
            edit=AsyncMock(),
        )
        message = SimpleNamespace(
            channel=thread,
            author=SimpleNamespace(id=789, mention="<@789>", bot=False),
            content="I moved my return position back and found more time.",
        )
        interview = {
            "conversation_history": [],
            "q_count": 1,
            "reaction_style": "React briefly.",
        }
        main._active_interviews[thread.id] = interview
        empty_response = SimpleNamespace(choices=[])

        try:
            with patch(
                "main._interview_completion",
                new=AsyncMock(
                    side_effect=[
                        empty_response,
                        empty_response,
                        empty_response,
                        empty_response,
                    ]
                ),
            ), patch(
                "main.asyncio.sleep",
                new=AsyncMock(),
            ):
                await main._handle_interview_reply(message, interview)
                first_fallback = thread.send.await_args_list[-1].args[0]
                interview["q_count"] = 2
                await main._handle_interview_reply(message, interview)
                second_fallback = thread.send.await_args_list[-1].args[0]
        finally:
            main._active_interviews.pop(thread.id, None)

        self.assertEqual(interview["q_count"], 3)
        self.assertIn("return position", first_fallback)
        self.assertNotEqual(first_fallback, second_fallback)
        self.assertNotIn(main.INTERVIEW_FALLBACK_FOLLOWUP, first_fallback)
        thread.edit.assert_not_awaited()

    async def test_active_interview_accepts_plain_text_reply(self):
        thread = SimpleNamespace(
            id=4455,
            send=AsyncMock(),
            edit=AsyncMock(),
        )
        message = SimpleNamespace(
            channel=thread,
            author=SimpleNamespace(
                id=789,
                mention="<@789>",
                display_name="Alpha Ace",
                bot=False,
            ),
            content="I stayed patient on the backhand.",
        )
        interview = {
            "conversation_history": [],
            "q_count": 1,
            "reaction_style": "React briefly.",
        }
        main._active_interviews[thread.id] = interview
        plain_response = SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(
                        content="That patience on the backhand paid off — what changed in the longer rallies?"
                    )
                )
            ]
        )

        try:
            with (
                patch(
                    "main._interview_completion",
                    new=AsyncMock(
                        side_effect=[
                            SimpleNamespace(choices=[]),
                            plain_response,
                        ]
                    ),
                ),
                patch("main.asyncio.sleep", new=AsyncMock()),
            ):
                await main._handle_interview_reply(message, interview)
        finally:
            main._active_interviews.pop(thread.id, None)

        self.assertIn("backhand paid off", thread.send.await_args_list[-1].args[0])
        self.assertEqual(interview["q_count"], 2)

    async def test_other_human_can_interrupt_active_public_interview(self):
        thread = SimpleNamespace(
            id=4545,
            send=AsyncMock(),
            edit=AsyncMock(),
        )
        message = SimpleNamespace(
            channel=thread,
            author=SimpleNamespace(
                id=999,
                display_name="Supporter",
                mention="<@999>",
                bot=False,
            ),
            content="That second-set comeback was wild.",
        )
        interview = {
            "conversation_history": [],
            "q_count": 1,
            "reaction_style": "React briefly.",
        }
        main._active_interviews[thread.id] = interview
        response = SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(
                        content='{"close": false, "text": "It really was — what changed tactically?"}'
                    )
                )
            ]
        )

        try:
            with patch(
                "main._interview_completion",
                new=AsyncMock(
                    side_effect=[
                        SimpleNamespace(choices=[]),
                        response,
                    ]
                ),
            ):
                await main._handle_interview_reply(message, interview)
        finally:
            main._active_interviews.pop(thread.id, None)

        self.assertIn("<@999>", thread.send.await_args_list[-1].args[0])
        self.assertIn("It really was", thread.send.await_args_list[-1].args[0])

    def test_recent_interview_state_rebuilds_from_player_last_message(self):
        created_at = datetime(2026, 9, 22, 10, 0, 0)
        thread = SimpleNamespace(
            id=5555,
            name="🎤 Post-Match Interview: Alpha Ace",
            created_at=created_at,
        )
        bot = SimpleNamespace(bot=True, id=1)
        player = SimpleNamespace(bot=False, id=789, mention="<@789>")
        messages = [
            SimpleNamespace(author=bot, content="🎤 Post-Match Press Conference"),
            SimpleNamespace(author=bot, content="What changed in the match?"),
            SimpleNamespace(author=player, content="I changed direction down the stretch."),
        ]

        with patch(
            "main.time.time",
            return_value=created_at.timestamp() + 3600,
        ):
            rebuilt = main._rebuild_interview_from_messages(thread, messages)

        self.assertIsNotNone(rebuilt)
        interview, last_message = rebuilt
        self.assertEqual(last_message.content, messages[-1].content)
        self.assertEqual(interview["player_ids"], [789])
        self.assertEqual(interview["q_count"], 1)
        self.assertEqual(interview["conversation_history"][-1]["role"], "user")

    async def test_delayed_reply_recovers_interview_state_on_demand(self):
        created_at = datetime(2026, 9, 22, 10, 0, 0)
        bot = SimpleNamespace(bot=True, id=1)
        player = SimpleNamespace(bot=False, id=789, mention="<@789>")
        messages = [
            SimpleNamespace(
                id=1,
                author=bot,
                content="🎤 **Post-Match Press Conference**",
            ),
            SimpleNamespace(
                id=2,
                author=bot,
                content="What changed in the match?",
            ),
            SimpleNamespace(
                id=3,
                author=player,
                content="I changed direction down the stretch.",
            ),
        ]

        async def history(**_kwargs):
            for current in messages:
                yield current

        thread = SimpleNamespace(
            id=5556,
            name="🎤 Post-Match Interview: Alpha Ace",
            created_at=created_at,
            archived=False,
            history=history,
        )
        delayed_message = messages[-1]

        main._active_interviews.pop(thread.id, None)
        try:
            with patch(
                "main.time.time",
                return_value=created_at.timestamp() + 3600,
            ):
                interview = await main._recover_interview_for_message(
                    SimpleNamespace(channel=thread, id=delayed_message.id)
                )

            self.assertIsNotNone(interview)
            self.assertIs(main._active_interviews[thread.id], interview)
            self.assertEqual(interview["q_count"], 1)
            self.assertEqual(
                interview["conversation_history"][-1]["content"],
                delayed_message.content,
            )
        finally:
            main._active_interviews.pop(thread.id, None)

    async def test_atp_csv_recipient_gets_renamed_csv_without_workbook(self):
        recipient = SimpleNamespace(send=AsyncMock())
        mock_client = SimpleNamespace(
            fetch_user=AsyncMock(return_value=recipient)
        )
        with patch.object(main, "client", mock_client), patch(
            "main.discord.File", return_value="csv-file"
        ) as discord_file:
            await main._dm_atp_csv_recipient(7052, test_run=True)

        mock_client.fetch_user.assert_awaited_once_with(main.ATP_CSV_RECIPIENT_ID)
        discord_file.assert_called_once_with(
            str(main.ATP_CSV_RECIPIENT_FILE),
            filename="Master TE Hub Stats.csv",
        )
        send_kwargs = recipient.send.await_args.kwargs
        self.assertEqual(send_kwargs["file"], "csv-file")
        self.assertIn("ONE-TIME TEST", recipient.send.await_args.args[0])
        self.assertNotIn("xlsx", str(send_kwargs).lower())

    async def test_periodic_atp_csv_delivery_is_paused(self):
        with (
            patch.object(main, "_dm_atp_csv_recipient", new=AsyncMock()) as send,
            patch.object(main, "export_atp_columns_csv") as export,
        ):
            delivered = await main._send_daily_atp_csv()
        self.assertFalse(delivered)
        send.assert_not_awaited()
        export.assert_not_called()

    def test_ranking_parse_and_case_insensitive_resolution(self):
        atp = _parse_ranking_table(RANKINGS_HTML, "atp")
        rankings = {"atp": atp, "wta": {}}
        tour, first, second = resolve_players(
            "  ALPHA   ACE ", "beta baseline", rankings
        )
        self.assertEqual(tour, "atp")
        self.assertEqual(first["id"], "10")
        self.assertEqual(second["rank"], 2)
        self.assertEqual(first["points"], "10,000")

    def test_resolution_rejects_unknown_cross_tour_and_same_player(self):
        atp = _parse_ranking_table(RANKINGS_HTML, "atp")
        wta = {
            "gamma": {
                **player("Gamma", "30", 1),
                "tour": "wta",
            }
        }
        rankings = {"atp": atp, "wta": wta}
        with self.assertRaises(PlayerResolutionError):
            resolve_players("Alpha Ace", "Gamma", rankings)
        with self.assertRaises(PlayerResolutionError):
            resolve_players("Alpha Ace", "Alpha Ace", rankings)
        with self.assertRaisesRegex(PlayerResolutionError, "Suggestions"):
            resolve_players("Alfa Ace", "Beta Baseline", rankings)

    def test_results_parse_winner_and_aggregation(self):
        results = parse_results_html(RESULTS_HTML)
        self.assertEqual(len(results), 6)
        self.assertEqual(results[0]["tournament"], "London Open")
        self.assertEqual(
            winner_for_result(results[0]), normalize_name("Alpha Ace")
        )
        first, second = player("Alpha Ace", "10", 1), player("Beta Baseline", "20", 2)
        summaries = {
            "alpha ace": {
                "Player": "Alpha Ace",
                "Complete rows": 4,
                "Omitted rows": 1,
                "Aces": 6.0,
                "Double Faults": 1.0,
                "relative_profile": {
                    "serve": {"percentile": 92, "players": 24},
                },
            },
            "beta baseline": {
                "Player": "Beta Baseline",
                "Complete rows": 3,
                "Omitted rows": 0,
                "Aces": 4.0,
                "Double Faults": 2.0,
                "relative_profile": {
                    "serve": {"percentile": 48, "players": 24},
                },
            },
        }
        data = build_match_data(
            "atp", first, second, results, [results[0]], summaries, "Fixture summary"
        )
        self.assertEqual(data["h2h_record"], (1, 0))
        self.assertEqual(len(data["h2h"]), 1)
        self.assertEqual(len(data["first_form"]), 2)
        self.assertTrue(all("Walkover" not in item["result"] for item in data["h2h"]))
        preview = format_match_preview(data)
        self.assertIn("📰 **ATP MATCH PREVIEW**", preview)
        self.assertNotIn(
            "Two contrasting profiles, one result, and very little room for a quiet opening set.",
            preview,
        )
        self.assertIn("**The stage is set**", preview)
        self.assertIn("**The players' view**", preview)
        self.assertIn("— **Alpha Ace**", preview)
        self.assertIn("— **Beta Baseline**", preview)
        self.assertNotIn("(fictional preview quote)", preview)
        quote_lines = [
            line for line in preview.splitlines() if "— **" in line and line.startswith("> “")
        ]
        self.assertEqual(len(quote_lines), 3)
        self.assertNotEqual(quote_lines[1], quote_lines[2])
        self.assertIn("start with intensity", quote_lines[1])
        self.assertIn("stay patient through the long games", quote_lines[2])
        self.assertNotIn("first-strike patterns", quote_lines[1])
        self.assertNotIn("second-serve points", quote_lines[2])
        self.assertIn("**The form line**", preview)
        self.assertIn("**The matchup**", preview)
        self.assertIn("**The swing factor**", preview)
        self.assertIn("— **WTSL Match Preview Desk**", preview)
        self.assertGreater(
            preview.index("— **WTSL Match Preview Desk**"),
            preview.index("**The swing factor**"),
        )
        self.assertGreater(
            preview.index("**The players' view**"),
            preview.index("— **WTSL Match Preview Desk**"),
        )
        self.assertTrue(preview.rstrip().endswith("— **Beta Baseline**"))
        self.assertIn("ATP MATCH PREVIEW", preview)
        self.assertIn("Alpha Ace 1–0 Beta Baseline", preview)
        self.assertNotIn("Keys to the Match", preview)
        self.assertNotIn("Protect the serve profile", preview)
        self.assertNotIn("Create return pressure", preview)
        self.assertIn(
            "**WTSL Elo/H2H odds:** no matching upcoming fixture found.", preview
        )
        self.assertIn("**Advanced stats lean Alpha Ace:**", preview)
        self.assertIn(
            "**Profile edges:**\n• **Alpha Ace:** serve edge — **Aces 6.0** "
            "vs Beta Baseline 4.0.",
            preview,
        )
        self.assertIn("Field standing: among the strongest", preview)
        self.assertNotIn("**Tactical plan:**", preview)
        self.assertIn("```text", preview)
        self.assertIn("Metric", preview)
        self.assertIn("Aces", preview)
        self.assertNotIn("Metric comparison:", preview)
        self.assertNotIn("Summary coverage", preview)
        self.assertNotIn("source-backed", preview)
        self.assertNotIn("data model", preview)
        self.assertNotIn("data-based matchup forecast", preview)
        self.assertNotIn("**Watch-out", preview)
        self.assertNotIn("Workbook values are player-level averages", preview)
        self.assertNotIn("🔗 **Sources:**", preview)

    def test_personalized_match_keys_return_only_verified_players_guidance(self):
        player = {
            "metrics": [
                ("1st Serve %", 0.70, 4),
                ("Aces", 6, 4),
                ("Double Faults", 1, 4),
            ],
            "ratings": [("Serve Rating", 180), ("Return Rating", 120)],
            "relative_profile": {
                "serve": {"percentile": 92, "players": 24},
            },
        }
        opponent = {
            "metrics": [
                ("1st Serve %", 0.55, 3),
                ("Aces", 3, 3),
                ("Double Faults", 3, 3),
            ],
            "ratings": [],
        }
        keys = personalized_match_keys(
            "Alpha Ace", player, "Beta Baseline", opponent
        )
        self.assertGreaterEqual(len(keys), 1)
        self.assertLessEqual(len(keys), 4)
        self.assertTrue(any("Aces" in key and "6" in key for key in keys))
        self.assertTrue(any("free points" in key for key in keys))
        self.assertTrue(any("Tactical plan:" in key for key in keys))
        self.assertTrue(any("serve patterns" in key for key in keys))

    def test_match_key_points_ignore_categories_with_only_equal_values(self):
        first, second = player("Alpha Ace", "10", 1), player("Beta Baseline", "20", 2)
        data = build_match_data(
            "atp",
            first,
            second,
            [],
            [],
            {
                "alpha ace": {"Aces": 4.0, "Double Faults": 2.0},
                "beta baseline": {"Aces": 4.0, "Double Faults": 2.0},
            },
            "Fixture summary",
        )
        keys = _match_key_points(data)
        self.assertEqual(keys["Alpha Ace"], [])
        self.assertEqual(keys["Beta Baseline"], [])

    def test_match_insight_categories_use_plain_rally_labels(self):
        labels = [label for label, _columns, _lower in MATCH_INSIGHT_CATEGORIES]
        self.assertEqual(
            labels,
            ["Serve", "Return", "Rally Attack", "Rally Defense", "Net play"],
        )
        self.assertNotIn("Return pressure", labels)
        self.assertNotIn("Attack and error control", labels)

    def test_generated_preview_copy_is_used_verbatim_with_attribution(self):
        first, second = player("Alpha Ace", "10", 1), player("Beta Baseline", "20", 2)
        data = build_match_data("atp", first, second, [], [], {}, "")
        data["preview_desk_quote"] = (
            "The opening exchanges should reveal whose preferred rhythm survives."
        )
        data["player_quotes"] = [
            "I have been looking forward to this one. I want to play with freedom.",
            "The preparation has been good, and I am ready for a long afternoon.",
        ]
        data["player_quote_sources"] = [
            "Editorial copy (no response received)",
            "Submitted by player",
        ]

        preview = format_match_preview(data)

        self.assertIn(
            "The opening exchanges should reveal whose preferred rhythm survives.” "
            "— **WTSL Match Preview Desk**",
            preview,
        )
        self.assertIn(
            "I have been looking forward to this one. I want to play with freedom.” — **Alpha Ace**",
            preview,
        )
        self.assertIn(
            "The preparation has been good, and I am ready for a long afternoon.” — **Beta Baseline**",
            preview,
        )
        self.assertIn("— **Alpha Ace** *(fictional)*", preview)
        self.assertNotIn("no player response", preview)

    def test_preview_copy_generator_allows_enough_tokens_for_gpt5_json(self):
        first, second = player("Alpha Ace", "10", 1), player("Beta Baseline", "20", 2)
        data = build_match_data("atp", first, second, [], [], {}, "")
        generated = {
            "desk": "A fresh desk observation.",
            "first": "A fresh first-player response.",
            "second": "A fresh second-player response.",
        }
        create = MagicMock(
            return_value=SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(content=json.dumps(generated))
                    )
                ]
            )
        )
        mock_client = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace(create=create))
        )

        with patch("main.OpenAI", return_value=mock_client):
            result = main._generate_match_preview_copy_sync(data)

        self.assertEqual(result, generated)
        self.assertGreaterEqual(
            create.call_args.kwargs["max_completion_tokens"], 800
        )
        self.assertEqual(
            create.call_args.kwargs["response_format"]["type"], "json_schema"
        )
        self.assertEqual(
            create.call_args.kwargs["response_format"]["json_schema"]["schema"][
                "required"
            ],
            ["desk", "first", "second"],
        )

    def test_article_opening_discloses_missing_context_without_inventing_it(self):
        first, second = player("Alpha Ace", "10", 1), player("Beta Baseline", "20", 2)
        data = build_match_data("atp", first, second, [], [], {}, "")
        data["prediction"] = calculate_prediction(data)

        preview = format_match_preview(data)

        self.assertIn("bring contrasting routes to victory", preview)
        self.assertIn("There is no previous WTSL meeting", preview)
        self.assertIn("There is no recent completed-results line", preview)
        self.assertIn("Without a previous WTSL meeting to draw on", preview)
        self.assertNotIn("Wimbledon", preview)

    def test_pair_h2h_parser_uses_winner_perspective_and_ignores_admin_result(self):
        first, second = player("Alpha Ace", "10", 1), player("Beta Baseline", "20", 2)
        results = parse_h2h_html(H2H_HTML, first, second)

        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]["p1"], "Alpha Ace")
        self.assertEqual(results[1]["p1"], "Beta Baseline")
        self.assertEqual(winner_for_result(results[1]), normalize_name("Beta Baseline"))
        data = build_match_data(
            "atp", first, second, [], [], {}, "", pair_h2h=results
        )
        self.assertEqual(data["h2h_record"], (1, 1))
        self.assertEqual(data["h2h_basis"], "pair-specific WTSL H2H")

    def test_fixture_odds_align_to_requested_players_in_both_orders_and_tours(self):
        atp = parse_fixture_odds(FIXTURES_HTML, "10", "20", "H2H")
        self.assertEqual(atp["first"], 1.40)
        self.assertEqual(atp["second"], 3.49)
        self.assertEqual(atp["tournament"], "Kingston (QF)")

        wta = parse_fixture_odds(
            REVERSED_WTA_FIXTURES_HTML, "944", "939", "homepage"
        )
        self.assertEqual(wta["first"], 1.67)
        self.assertEqual(wta["second"], 2.40)
        self.assertEqual(wta["tour"], "WTA")

    def test_fixture_and_avatar_parsers_tolerate_missing_or_changed_markup(self):
        self.assertIsNone(
            parse_fixture_odds(
                "<table><tr><th>Players</th><th>Price</th></tr></table>",
                "10",
                "20",
                "homepage",
            )
        )
        self.assertEqual(
            parse_player_avatar(
                '<img alt="Alpha Ace" src="../../files/img/avatars/av_Alpha Ace.png">',
                "Alpha Ace",
            ),
            "https://playwtsl.com/files/img/avatars/av_Alpha%20Ace.png",
        )
        self.assertIsNone(
            parse_player_avatar(
                '<img src="../../files/img/avatars/st_avatar.png">', "Alpha Ace"
            )
        )
        self.assertIsNone(parse_player_avatar("<div>No portrait</div>", "Alpha Ace"))

    def test_market_odds_are_primary_and_no_odds_uses_performance_signals(self):
        first, second = player("Alpha Ace", "10", 1), player("Beta Baseline", "20", 2)
        first["wtsl_elo"], second["wtsl_elo"] = "2200", "2000"
        data = build_match_data(
            "atp",
            first,
            second,
            [],
            [],
            {
                "alpha ace": {"Aces": 8.0, "Double Faults": 1.0},
                "beta baseline": {"Aces": 4.0, "Double Faults": 3.0},
            },
            "",
            odds={"first": 2.50, "second": 1.60, "tournament": "Final"},
        )
        market_prediction = calculate_prediction(data)
        self.assertEqual(market_prediction["favored_name"], "Beta Baseline")
        self.assertEqual(market_prediction["basis"], "market-led")
        self.assertAlmostEqual(sum(market_prediction["implied"]), 1.0)
        split_preview = format_match_preview(
            {**data, "prediction": market_prediction}
        )
        self.assertIn("**WTSL Elo/H2H odds:** **Beta Baseline is favoured**", split_preview)
        self.assertIn(
            "**Split view:** the Elo/H2H odds favour Beta Baseline; "
            "advanced stats lean Alpha Ace.",
            split_preview,
        )

        data["odds"] = None
        fallback_prediction = calculate_prediction(data)
        self.assertEqual(fallback_prediction["favored_name"], "Alpha Ace")
        self.assertIn("no matching fixture odds", fallback_prediction["basis"])

    def test_preview_shows_live_odds_checked_at_in_configured_timezone(self):
        first, second = player("Alpha Ace", "10", 1), player("Beta Baseline", "20", 2)
        checked_at = datetime(2026, 8, 28, 16, 30, tzinfo=timezone.utc).isoformat()
        data = build_match_data(
            "atp",
            first,
            second,
            [],
            [],
            {},
            "",
            odds={
                "first": 1.40,
                "second": 3.49,
                "tournament": "Kingston (QF)",
                "checked_at": checked_at,
            },
        )
        data["prediction"] = calculate_prediction(data)

        preview = format_match_preview(data)

        self.assertIn(
            "**Checked at:** 28 Aug 2026, 17:30 BST",
            preview,
        )
        self.assertIn(
            "Beta Baseline 3.49 · **Checked at:** 28 Aug 2026, 17:30 BST",
            preview,
        )

        chunks = split_discord_message(preview, limit=500)
        self.assertIn(
            "**Checked at:** 28 Aug 2026, 17:30 BST",
            "\n".join(chunks),
        )

    async def test_repeated_collection_refreshes_odds_and_checked_at(self):
        rankings = {
            "atp": {
                "alpha ace": player("Alpha Ace", "10", 1),
                "beta baseline": player("Beta Baseline", "20", 2),
            },
            "wta": {},
        }
        second_fixture_html = FIXTURES_HTML.replace(
            "Kingston (QF)", "Paris (SF)"
        ).replace("1.40 / 3.49", "1.55 / 2.70")
        live_fixture_pages = iter((FIXTURES_HTML, second_fixture_html))

        async def mocked_optional_text(session, url, params=None):
            if url == HOMEPAGE_URL:
                return next(live_fixture_pages)
            return ""

        checked_at_values = [
            datetime(2026, 8, 28, 16, 30, tzinfo=timezone.utc),
            datetime(2026, 8, 28, 16, 45, tzinfo=timezone.utc),
        ]
        with (
            patch(
                "match_preview.fetch_rankings",
                new=AsyncMock(return_value=rankings),
            ) as fetch_rankings,
            patch(
                "match_preview.fetch_player_results",
                new=AsyncMock(return_value=[]),
            ),
            patch(
                "match_preview.load_summary_rows",
                new=AsyncMock(return_value=({}, "")),
            ),
            patch(
                "match_preview._fetch_optional_text",
                new=AsyncMock(side_effect=mocked_optional_text),
            ),
            patch("match_preview.datetime") as mocked_datetime,
        ):
            mocked_datetime.now.side_effect = checked_at_values

            first_data = await collect_match_data("Alpha Ace", "Beta Baseline")
            second_data = await collect_match_data("Alpha Ace", "Beta Baseline")

        first_preview = format_match_preview(first_data)
        second_preview = format_match_preview(second_data)

        self.assertEqual(fetch_rankings.await_count, 2)
        self.assertEqual(first_data["odds"]["first"], 1.40)
        self.assertEqual(first_data["odds"]["second"], 3.49)
        self.assertEqual(second_data["odds"]["first"], 1.55)
        self.assertEqual(second_data["odds"]["second"], 2.70)
        self.assertEqual(
            first_data["odds"]["checked_at"],
            checked_at_values[0].isoformat(),
        )
        self.assertEqual(
            second_data["odds"]["checked_at"],
            checked_at_values[1].isoformat(),
        )
        self.assertIn("Kingston (QF)", first_preview)
        self.assertIn("28 Aug 2026, 17:30 BST", first_preview)
        self.assertIn("Paris (SF)", second_preview)
        self.assertIn("28 Aug 2026, 17:45 BST", second_preview)
        self.assertNotIn("Kingston (QF)", second_preview)
        self.assertNotIn("17:30 BST", second_preview)

    async def test_winner_poll_is_native_single_choice_and_discord_safe(self):
        poll = _matchpreview_winner_poll("A" * 2500, "Beta Baseline")

        self.assertEqual(poll.question, "Who will win?")
        self.assertFalse(poll.multiple)
        self.assertEqual(poll.duration, timedelta(days=7))
        self.assertEqual(len(poll.answers), 2)
        self.assertLessEqual(len(poll.answers[0].text), 55)
        self.assertEqual(poll.answers[1].text, "Beta Baseline")

    def test_matchpreview_thread_name_is_readable_and_discord_safe(self):
        self.assertEqual(
            main._matchpreview_thread_name("Alpha Ace", "Beta Baseline"),
            "Match Preview - Alpha Ace vs Beta Baseline",
        )
        long_name = main._matchpreview_thread_name("A" * 100, "B" * 100)
        self.assertLessEqual(len(long_name), 100)
        self.assertTrue(long_name.startswith("Match Preview - "))
        self.assertIn(" vs ", long_name)

    async def test_matchpreview_command_posts_fresh_preview_for_each_interaction(self):
        def preview_data(tournament, first_odds, second_odds, checked_at, avatar):
            first = player("Alpha Ace", "10", 1)
            second = player("Beta Baseline", "20", 2)
            data = build_match_data(
                "atp",
                first,
                second,
                [],
                [],
                {},
                "",
                odds={
                    "first": first_odds,
                    "second": second_odds,
                    "tournament": tournament,
                    "checked_at": checked_at,
                },
                avatars={
                    "10": f"https://example.com/{avatar}-alpha.png",
                    "20": f"https://example.com/{avatar}-beta.png",
                },
            )
            data["prediction"] = calculate_prediction(data)
            return data

        first_data = preview_data(
            "Kingston (QF)",
            1.40,
            3.49,
            "2026-08-28T16:30:00+00:00",
            "first",
        )
        second_data = preview_data(
            "Paris (SF)",
            1.55,
            2.70,
            "2026-08-28T16:45:00+00:00",
            "second",
        )

        def interaction(thread_mention):
            thread = SimpleNamespace(
                mention=thread_mention,
                send=AsyncMock(),
            )
            channel = SimpleNamespace(
                send=AsyncMock(),
                create_thread=AsyncMock(return_value=thread),
            )
            return (
                SimpleNamespace(
                    response=SimpleNamespace(defer=AsyncMock()),
                    followup=SimpleNamespace(send=AsyncMock()),
                    channel=channel,
                    user="test-user",
                ),
                channel,
                thread,
            )

        first_interaction, first_channel, first_thread = interaction("<#1001>")
        second_interaction, second_channel, second_thread = interaction("<#1002>")
        with patch(
            "main.collect_match_data",
            new=AsyncMock(side_effect=[first_data, second_data]),
        ) as collect_match_data, patch(
            "main.generate_match_preview_copy",
            new=AsyncMock(
                side_effect=[
                    {
                        "desk": "The first preview has a brand-new desk observation.",
                        "first": "I want to make this a physical contest from the first game.",
                        "second": "I am coming into this one ready to embrace the pressure.",
                    },
                    {
                        "desk": "The second preview takes a completely different desk angle.",
                        "first": "This matchup asks different questions, and I like that challenge.",
                        "second": "I will trust my preparation and let the match develop naturally.",
                    },
                ]
            ),
        ) as generate_copy:
            await main.matchpreview_slash.callback(
                first_interaction, "Alpha Ace", "Beta Baseline"
            )
            await main.matchpreview_slash.callback(
                second_interaction, "Alpha Ace", "Beta Baseline"
            )

        self.assertEqual(collect_match_data.await_count, 2)
        self.assertTrue(
            all(
                call.args[2] == main.MATCH_STATS_WORKBOOK
                for call in collect_match_data.await_args_list
            )
        )
        self.assertEqual(generate_copy.await_count, 2)
        first_messages = first_thread.send.await_args_list
        second_messages = second_thread.send.await_args_list
        first_content = "\n".join(
            call.args[0] for call in first_messages if call.args
        )
        second_content = "\n".join(
            call.args[0] for call in second_messages if call.args
        )

        self.assertIn("Kingston (QF)", first_content)
        self.assertIn("1.40", first_content)
        self.assertIn("3.49", first_content)
        self.assertIn("28 Aug 2026, 17:30 BST", first_content)
        self.assertIn("Paris (SF)", second_content)
        self.assertIn("1.55", second_content)
        self.assertIn("2.70", second_content)
        self.assertIn("28 Aug 2026, 17:45 BST", second_content)
        self.assertNotIn("Kingston (QF)", second_content)
        self.assertNotIn("17:30 BST", second_content)
        self.assertNotEqual(first_content, second_content)
        self.assertIn(
            "The first preview has a brand-new desk observation.",
            first_content,
        )
        self.assertIn(
            "The second preview takes a completely different desk angle.",
            second_content,
        )
        self.assertIn(
            "I want to make this a physical contest from the first game.",
            first_content,
        )
        self.assertIn(
            "This matchup asks different questions, and I like that challenge.",
            second_content,
        )
        self.assertNotIn(
            "I want to make this a physical contest from the first game.",
            second_content,
        )

        first_poll_call = first_messages[-1]
        second_poll_call = second_messages[-1]
        self.assertIsInstance(first_poll_call.kwargs["poll"], discord.Poll)
        self.assertIsInstance(second_poll_call.kwargs["poll"], discord.Poll)
        self.assertIsNot(
            first_poll_call.kwargs["poll"], second_poll_call.kwargs["poll"]
        )
        self.assertEqual(
            [answer.text for answer in first_poll_call.kwargs["poll"].answers],
            ["Alpha Ace", "Beta Baseline"],
        )
        first_channel.create_thread.assert_awaited_once_with(
            name="Match Preview - Alpha Ace vs Beta Baseline",
            type=discord.ChannelType.public_thread,
        )
        second_channel.create_thread.assert_awaited_once_with(
            name="Match Preview - Alpha Ace vs Beta Baseline",
            type=discord.ChannelType.public_thread,
        )
        self.assertEqual(first_channel.send.await_count, 0)
        self.assertEqual(second_channel.send.await_count, 0)
        self.assertTrue(
            any(
                "<#1001>" in call.args[0]
                for call in first_interaction.followup.send.await_args_list
                if call.args
            )
        )
        self.assertTrue(
            any(
                "<#1002>" in call.args[0]
                for call in second_interaction.followup.send.await_args_list
                if call.args
            )
        )
        self.assertTrue(
            all("view" not in call.kwargs for call in first_messages[:-1])
        )
        self.assertIn("📰 **ATP MATCH PREVIEW**", first_messages[0].args[0])

        first_embeds = first_messages[0].kwargs["embeds"]
        second_embeds = second_messages[0].kwargs["embeds"]
        self.assertIsNot(first_embeds, second_embeds)
        self.assertIsNot(first_embeds[0], second_embeds[0])
        self.assertNotEqual(
            first_embeds[0].to_dict(), second_embeds[0].to_dict()
        )
        self.assertEqual(
            first_embeds[0].thumbnail.url,
            "https://example.com/first-alpha.png",
        )
        self.assertEqual(
            second_embeds[0].thumbnail.url,
            "https://example.com/second-alpha.png",
        )

    async def test_matchpreview_reports_discord_poll_post_failure(self):
        first, second = player("Alpha Ace", "10", 1), player("Beta Baseline", "20", 2)
        data = build_match_data("atp", first, second, [], [], {}, "")
        data["prediction"] = calculate_prediction(data)
        http_error = main.discord.HTTPException(
            SimpleNamespace(status=500, reason="Server Error", headers={}),
            "poll send failed",
        )

        async def send_message(content=None, **kwargs):
            if isinstance(kwargs.get("poll"), discord.Poll):
                raise http_error
            return SimpleNamespace()

        preview_thread = SimpleNamespace(send=AsyncMock(side_effect=send_message))
        interaction = SimpleNamespace(
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
            channel=SimpleNamespace(
                create_thread=AsyncMock(return_value=preview_thread),
            ),
            user="test-user",
        )
        with patch(
            "main.collect_match_data", new=AsyncMock(return_value=data)
        ), patch(
            "main.generate_match_preview_copy",
            new=AsyncMock(return_value=None),
        ):
            await main.matchpreview_slash.callback(
                interaction, "Alpha Ace", "Beta Baseline"
            )

        status_messages = [
            call.args[0] for call in interaction.followup.send.await_args_list
        ]
        self.assertTrue(
            any("could not finish publishing" in message for message in status_messages)
        )
        self.assertTrue(
            any("may already be visible" in message for message in status_messages)
        )
        self.assertFalse(
            any("has been posted" in message for message in status_messages)
        )

    def test_summary_loader_maps_headers_without_modifying_workbook(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "summary.xlsx"
            workbook = Workbook()
            sheet = workbook.active
            sheet.title = "ATP Summary"
            sheet["A3"] = "Players represented: 1 | Complete rows used: 2"
            sheet.append([])
            sheet.append(["Player", "Complete rows", "Omitted rows", "1st Serve %"])
            sheet.append(["Alpha Ace", 2, 0, 0.65])
            workbook.create_sheet("WTA Summary")
            workbook.save(path)
            original = path.read_bytes()

            rows, metadata = _summary_rows_sync(path, "atp", ["alpha ace"])

            self.assertEqual(rows["alpha ace"]["Complete rows"], 2)
            self.assertEqual(rows["alpha ace"]["1st Serve %"], 0.65)
            self.assertIn("Complete rows used: 2", metadata)
            self.assertEqual(path.read_bytes(), original)

    def test_discord_chunks_stay_below_limit_and_preserve_text(self):
        text = "\n".join(f"line {index}: " + ("x" * 100) for index in range(60))
        chunks = split_discord_message(text, limit=500)
        self.assertGreater(len(chunks), 1)
        self.assertTrue(all(len(chunk) <= 500 for chunk in chunks))
        self.assertEqual("\n".join(chunks), text)


if __name__ == "__main__":
    unittest.main()
