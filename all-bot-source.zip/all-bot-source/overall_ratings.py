"""Shared WTSL-adapted ATP-style overall rating calculations."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any


OVERALL_RATING_COLUMNS = (
    "Serve (Overall)",
    "Return (Overall)",
    "Under Pressure",
)


def rating_formula_footnote(source: str) -> str:
    """Return the transparent formula used for each displayed overall rating."""
    del source
    serve = "1st Serve % + 1st Serve Won % + 2nd Serve Won % + Aces − Double Faults"
    return (
        f"Serve: {serve}\n"
        "Return: 1st Serve Return Points Won % + 2nd Serve Return Points Won % + "
        "Break Points Won %\n"
        "Under Pressure: Break Points Won % + Break Points Saved % + Tie-breaks "
        "Won % + Deciding Sets Won %"
    )

RELATIVE_PROFILE_METRICS = {
    "serve": (
        ("1st Serve %", False),
        ("1st Serve Won %", False),
        ("2nd Serve Won %", False),
        ("Aces", False),
        ("Double Faults", True),
    ),
    "return": (
        ("1st Serve Return Points Won %", False),
        ("2nd Serve Return Points Won %", False),
        ("Return Points Won %", False),
        ("Break Points Won %", False),
        ("Breaks / Games %", False),
    ),
    "rally": (
        ("Short Rallies Won (<5) %", False),
        ("Medium Rallies Won (5-8) %", False),
        ("Long Rallies Won (>8) %", False),
        ("Winners", False),
        ("Unforced Errors", True),
    ),
    "net": (
        ("Net Points Won %", False),
    ),
}


def _numeric(values: Mapping[str, Any], label: str) -> float | None:
    value = values.get(label)
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    return None


def _percentage_points(value: float | None) -> float | None:
    return value * 100 if value is not None else None


def _partial_total(
    values: Mapping[str, Any],
    *,
    percentages: tuple[str, ...],
    plus: tuple[str, ...] = (),
    minus: tuple[str, ...] = (),
) -> float | None:
    components = [
        _percentage_points(_numeric(values, label))
        for label in percentages
    ]
    components.extend(_numeric(values, label) for label in plus)
    components.extend(
        -value
        for label in minus
        if (value := _numeric(values, label)) is not None
    )
    available = [value for value in components if value is not None]
    return sum(available) if available else None


def calculate_partial_overall_ratings(
    values: Mapping[str, Any],
) -> dict[str, float | None]:
    """Calculate transparent WTSL ratings from currently collected metrics."""
    return {
        "Serve (Overall)": _partial_total(
            values,
            percentages=(
                "1st Serve %",
                "1st Serve Won %",
                "2nd Serve Won %",
            ),
            plus=("Aces",),
            minus=("Double Faults",),
        ),
        "Return (Overall)": _partial_total(
            values,
            percentages=(
                "1st Serve Return Points Won %",
                "2nd Serve Return Points Won %",
                "Break Points Won %",
            ),
        ),
        "Under Pressure": _partial_total(
            values,
            percentages=(
                "Break Points Won %",
                "Break Points Saved %",
                "Tie-breaks Won %",
                "Deciding Sets Won %",
            ),
        ),
    }


def calculate_atp_available_ratings(
    values: Mapping[str, Any],
) -> dict[str, float | None]:
    """Backward-compatible name for the one canonical cross-source formula."""
    return calculate_partial_overall_ratings(values)


def calculate_relative_profiles(
    target: Mapping[str, Any],
    population: list[Mapping[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Compare serve, return, rally, and net metrics with the tour population."""
    profiles: dict[str, dict[str, Any]] = {}
    for group, configured_metrics in RELATIVE_PROFILE_METRICS.items():
        comparisons = []
        for label, lower_is_better in configured_metrics:
            target_count = _numeric(target, f"{label} matches used")
            target_value = _numeric(target, label) if target_count and target_count > 0 else None
            values = [
                value
                for row in population
                if (count := _numeric(row, f"{label} matches used")) is not None
                and count > 0
                and (value := _numeric(row, label)) is not None
            ]
            if target_value is None or len(values) < 2:
                continue
            below = sum(value < target_value for value in values)
            equal = sum(value == target_value for value in values)
            percentile = 100 * (below + 0.5 * equal) / len(values)
            if lower_is_better:
                percentile = 100 - percentile
            comparisons.append({
                "metric": label,
                "percentile": round(percentile),
                "players": len(values),
            })
        if comparisons:
            profiles[group] = {
                "percentile": round(
                    sum(item["percentile"] for item in comparisons)
                    / len(comparisons)
                ),
                "players": max(item["players"] for item in comparisons),
                "metrics": comparisons,
            }
    return profiles