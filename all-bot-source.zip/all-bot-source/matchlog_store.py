"""Durable PostgreSQL storage for verified MatchLog sources and identities."""
from __future__ import annotations

import json
import os
from typing import Any

import psycopg

_BOT_LEASE_KEY = 879_341_267_104_552_031
MATCHLOG_VERIFICATION_VERSION = 3
_VERIFICATION_VERSION_KEY = "_verification_version"
_RAW_COVERAGE_KEY = "_raw_coverage"


def _encoded_verified_matches(
    matches: list[dict[str, Any]],
    raw_coverage: list[dict[str, str]] | None = None,
) -> str:
    return json.dumps([
        {
            _VERIFICATION_VERSION_KEY: MATCHLOG_VERIFICATION_VERSION,
            _RAW_COVERAGE_KEY: raw_coverage or [],
        },
        *matches,
    ])


def _connect():
    database_url = os.environ.get("DATABASE_URL")
    if not database_url:
        raise RuntimeError("DATABASE_URL is not available")
    return psycopg.connect(database_url)


def try_acquire_bot_lease():
    """Return a dedicated connection holding the singleton bot lease, if free."""
    connection = _connect()
    connection.autocommit = True
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT pg_try_advisory_lock(%s)",
            (_BOT_LEASE_KEY,),
        )
        acquired = bool(cursor.fetchone()[0])
    if not acquired:
        connection.close()
        return None
    return connection


def release_bot_lease(connection) -> None:
    if connection is None:
        return
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT pg_advisory_unlock(%s)",
                (_BOT_LEASE_KEY,),
            )
    finally:
        connection.close()


def _ensure_bot_ui_tables(cursor) -> None:
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS matchlog_verification_requests (
            discord_user_id BIGINT PRIMARY KEY,
            requested_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_results_cache (
            cache_key TEXT PRIMARY KEY,
            results JSONB NOT NULL,
            result_count INTEGER NOT NULL,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS matchlog_bot_messages (
            message_key TEXT PRIMARY KEY,
            channel_id BIGINT NOT NULL,
            message_id BIGINT NOT NULL,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_match_schedules (
            schedule_id TEXT PRIMARY KEY,
            guild_id BIGINT NOT NULL,
            tournament_id TEXT NOT NULL,
            tournament_name TEXT NOT NULL,
            round_name TEXT NOT NULL,
            source_match_id TEXT NOT NULL,
            player_one TEXT NOT NULL,
            player_two TEXT NOT NULL,
            player_one_user_id BIGINT,
            player_two_user_id BIGINT,
            thread_id BIGINT UNIQUE,
            log_message_id BIGINT,
            status TEXT NOT NULL DEFAULT 'active',
            is_test BOOLEAN NOT NULL DEFAULT FALSE,
            created_by BIGINT NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            completed_by BIGINT,
            completed_at TIMESTAMPTZ,
            metadata JSONB NOT NULL DEFAULT '{}'::jsonb
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS wtsl_match_scheduler_notices (
            notice_key TEXT PRIMARY KEY,
            user_id BIGINT NOT NULL,
            status TEXT NOT NULL DEFAULT 'sending',
            claimed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            sent_at TIMESTAMPTZ
        )
        """
    )


def load_wtsl_results_cache() -> list[dict[str, Any]]:
    """Load the durable full-history snapshot, if one has been recorded."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(
                "SELECT results FROM wtsl_results_cache WHERE cache_key = 'all'"
            )
            row = cursor.fetchone()
            return list(row[0]) if row and isinstance(row[0], list) else []


def save_wtsl_results_cache(results: list[dict[str, Any]]) -> None:
    """Atomically replace the durable snapshot after regression-safe merging."""
    if not results:
        raise ValueError("Refusing to persist an empty WTSL results cache")
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(
                """
                INSERT INTO wtsl_results_cache (
                    cache_key, results, result_count, updated_at
                )
                VALUES ('all', %s::jsonb, %s, now())
                ON CONFLICT (cache_key) DO UPDATE
                SET results = EXCLUDED.results,
                    result_count = EXCLUDED.result_count,
                    updated_at = now()
                """,
                (json.dumps(results, ensure_ascii=False), len(results)),
            )


def load_outreach_state() -> dict[str, Any] | None:
    """Load the durable pre-match outreach ledger."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT state FROM match_preview_outreach_state "
                "WHERE state_key = 'primary'"
            )
            row = cursor.fetchone()
            return dict(row[0]) if row and isinstance(row[0], dict) else None


def save_outreach_state(state: dict[str, Any]) -> None:
    """Atomically replace the durable pre-match outreach ledger."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO match_preview_outreach_state (
                    state_key, state, updated_at
                )
                VALUES ('primary', %s::jsonb, now())
                ON CONFLICT (state_key) DO UPDATE
                SET state = EXCLUDED.state, updated_at = now()
                """,
                (json.dumps(state, ensure_ascii=False),),
            )


def reserve_verification_request(
    discord_user_id: int,
    cooldown_seconds: int = 300,
) -> bool:
    """Atomically reserve a durable verification-request cooldown."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(
                """
                INSERT INTO matchlog_verification_requests (
                    discord_user_id, requested_at
                )
                VALUES (%s, now())
                ON CONFLICT (discord_user_id) DO UPDATE
                SET requested_at = now()
                WHERE matchlog_verification_requests.requested_at
                      <= now() - (%s * interval '1 second')
                RETURNING discord_user_id
                """,
                (discord_user_id, cooldown_seconds),
            )
            return cursor.fetchone() is not None


def release_verification_request(discord_user_id: int) -> None:
    """Release a reservation after delivery fails so the user can retry."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(
                """
                DELETE FROM matchlog_verification_requests
                WHERE discord_user_id = %s
                """,
                (discord_user_id,),
            )


def load_bot_message(message_key: str) -> tuple[int, int] | None:
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(
                """
                SELECT channel_id, message_id
                FROM matchlog_bot_messages
                WHERE message_key = %s
                """,
                (message_key,),
            )
            row = cursor.fetchone()
            return (int(row[0]), int(row[1])) if row else None


def save_bot_message(
    message_key: str,
    channel_id: int,
    message_id: int,
) -> None:
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(
                """
                INSERT INTO matchlog_bot_messages (
                    message_key, channel_id, message_id
                )
                VALUES (%s, %s, %s)
                ON CONFLICT (message_key) DO UPDATE
                SET channel_id = EXCLUDED.channel_id,
                    message_id = EXCLUDED.message_id,
                    updated_at = now()
                """,
                (message_key, channel_id, message_id),
            )


def save_match_schedule(schedule: dict[str, Any]) -> None:
    """Persist one scheduling thread before it is exposed to players."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(
                """
                INSERT INTO wtsl_match_schedules (
                    schedule_id, guild_id, tournament_id, tournament_name,
                    round_name, source_match_id, player_one, player_two,
                    player_one_user_id, player_two_user_id, thread_id,
                    log_message_id, status, is_test, created_by, metadata
                )
                VALUES (
                    %(schedule_id)s, %(guild_id)s, %(tournament_id)s,
                    %(tournament_name)s, %(round_name)s, %(source_match_id)s,
                    %(player_one)s, %(player_two)s, %(player_one_user_id)s,
                    %(player_two_user_id)s, %(thread_id)s, %(log_message_id)s,
                    %(status)s, %(is_test)s, %(created_by)s,
                    %(metadata)s::jsonb
                )
                ON CONFLICT (schedule_id) DO UPDATE SET
                    thread_id = EXCLUDED.thread_id,
                    log_message_id = EXCLUDED.log_message_id,
                    status = EXCLUDED.status,
                    player_one_user_id = EXCLUDED.player_one_user_id,
                    player_two_user_id = EXCLUDED.player_two_user_id,
                    metadata = EXCLUDED.metadata
                """,
                {
                    **schedule,
                    "metadata": json.dumps(schedule.get("metadata") or {}),
                },
            )


def load_match_schedules(status: str | None = None) -> list[dict[str, Any]]:
    """Load scheduling records for restart recovery and message routing."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            query = """
                SELECT schedule_id, guild_id, tournament_id, tournament_name,
                       round_name, source_match_id, player_one, player_two,
                       player_one_user_id, player_two_user_id, thread_id,
                       log_message_id, status, is_test, created_by,
                       created_at, completed_by, completed_at, metadata
                FROM wtsl_match_schedules
            """
            params: tuple[Any, ...] = ()
            if status:
                query += " WHERE status = %s"
                params = (status,)
            query += " ORDER BY created_at"
            cursor.execute(query, params)
            columns = [
                "schedule_id", "guild_id", "tournament_id", "tournament_name",
                "round_name", "source_match_id", "player_one", "player_two",
                "player_one_user_id", "player_two_user_id", "thread_id",
                "log_message_id", "status", "is_test", "created_by",
                "created_at", "completed_by", "completed_at", "metadata",
            ]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]


def update_match_schedule(schedule_id: str, **values: Any) -> None:
    """Update only approved scheduling lifecycle fields."""
    allowed = {
        "thread_id", "log_message_id", "status", "completed_by",
        "completed_at", "metadata",
    }
    unknown = set(values) - allowed
    if unknown:
        raise ValueError(f"unsupported match schedule fields: {sorted(unknown)}")
    if not values:
        return
    assignments = []
    params: dict[str, Any] = {"schedule_id": schedule_id}
    for key, value in values.items():
        assignments.append(f"{key} = %({key})s")
        params[key] = json.dumps(value) if key == "metadata" else value
    query = (
        "UPDATE wtsl_match_schedules SET "
        + ", ".join(assignments)
        + " WHERE schedule_id = %(schedule_id)s"
    )
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(query, params)


def claim_match_scheduler_notice(
    notice_key: str,
    user_id: int,
    *,
    stale_after_seconds: int = 3600,
) -> bool:
    """Reserve one first-detection DM, allowing crashed sends to retry."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(
                """
                INSERT INTO wtsl_match_scheduler_notices (
                    notice_key, user_id, status, claimed_at
                )
                VALUES (%s, %s, 'sending', now())
                ON CONFLICT (notice_key) DO UPDATE
                SET status = 'sending', claimed_at = now()
                WHERE wtsl_match_scheduler_notices.status <> 'sent'
                  AND wtsl_match_scheduler_notices.claimed_at
                      <= now() - (%s * interval '1 second')
                RETURNING notice_key
                """,
                (notice_key, user_id, stale_after_seconds),
            )
            return cursor.fetchone() is not None


def mark_match_scheduler_notice_sent(notice_key: str) -> None:
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(
                """
                UPDATE wtsl_match_scheduler_notices
                SET status = 'sent', sent_at = now()
                WHERE notice_key = %s
                """,
                (notice_key,),
            )


def match_scheduler_notice_was_sent(notice_key: str) -> bool:
    """Return whether a first-detection notice was successfully sent."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(
                """
                SELECT status = 'sent'
                FROM wtsl_match_scheduler_notices
                WHERE notice_key = %s
                """,
                (notice_key,),
            )
            row = cursor.fetchone()
            return bool(row and row[0])


def release_match_scheduler_notice(notice_key: str) -> None:
    with _connect() as connection:
        with connection.cursor() as cursor:
            _ensure_bot_ui_tables(cursor)
            cursor.execute(
                """
                DELETE FROM wtsl_match_scheduler_notices
                WHERE notice_key = %s AND status <> 'sent'
                """,
                (notice_key,),
            )


def save_source(
    *,
    source_hash: str,
    submitter_id: int,
    source_message_id: int,
    attachment_id: int,
    filename: str,
    raw_html: bytes,
    verified_matches: list[dict[str, Any]],
    raw_coverage: list[dict[str, str]] | None = None,
) -> bool:
    """Persist one source and its current verified match set."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO matchlog_sources (
                    source_hash, submitter_id, source_message_id,
                    attachment_id, filename, raw_html, verified_matches
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s::jsonb)
                ON CONFLICT (source_hash) DO UPDATE
                SET verified_matches = EXCLUDED.verified_matches
                """,
                (
                    source_hash,
                    submitter_id,
                    source_message_id,
                    attachment_id,
                    filename,
                    raw_html,
                    _encoded_verified_matches(verified_matches, raw_coverage),
                ),
            )
            return cursor.rowcount == 1


def load_sources() -> list[dict[str, Any]]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT source_hash, submitter_id, source_message_id,
                       attachment_id, filename,
                       CASE WHEN COALESCE(
                           NULLIF(
                               verified_matches->0->>'_verification_version',
                               ''
                           )::integer,
                           0
                       ) < %s
                            THEN raw_html ELSE NULL END,
                       verified_matches,
                       COALESCE(
                           NULLIF(
                               verified_matches->0->>'_verification_version',
                               ''
                           )::integer,
                           0
                       )
                FROM matchlog_sources
                ORDER BY accepted_at, source_hash
                """,
                (MATCHLOG_VERIFICATION_VERSION,),
            )
            sources = []
            for row in cursor.fetchall():
                stored_matches = list(row[6] or [])
                marker = {}
                if (
                    stored_matches
                    and isinstance(stored_matches[0], dict)
                    and _VERIFICATION_VERSION_KEY in stored_matches[0]
                ):
                    marker = stored_matches[0]
                    stored_matches = stored_matches[1:]
                source = {
                    "source_hash": row[0],
                    "submitter_id": row[1],
                    "source_message_id": row[2],
                    "attachment_id": row[3],
                    "filename": row[4],
                    "verified_matches": stored_matches,
                    "verification_version": int(row[7] or 0),
                    "raw_coverage": list(marker.get(_RAW_COVERAGE_KEY) or []),
                }
                if row[5] is not None:
                    source["raw_html"] = bytes(row[5])
                sources.append(source)
            return sources


def save_reverified_sources(sources: list[dict[str, Any]]) -> None:
    """Persist refreshed match lists after replaying retained source HTML."""
    if not sources:
        return
    with _connect() as connection:
        with connection.cursor() as cursor:
            cursor.executemany(
                """
                UPDATE matchlog_sources
                SET verified_matches = %s::jsonb
                WHERE source_hash = %s
                """,
                [
                    (
                        _encoded_verified_matches(
                            source.get("verified_matches") or [],
                            source.get("raw_coverage") or [],
                        ),
                        source["source_hash"],
                    )
                    for source in sources
                ],
            )


def load_source_message_ids(source_hashes: set[str]) -> set[int]:
    """Return original Discord message IDs for the requested durable sources."""
    if not source_hashes:
        return set()
    with _connect() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT DISTINCT source_message_id
                FROM matchlog_sources
                WHERE source_hash = ANY(%s)
                """,
                (list(source_hashes),),
            )
            return {int(row[0]) for row in cursor.fetchall()}


def _identity_tour(player: str, tour: str | None = None) -> tuple[str, str]:
    """Return a canonical tour and unqualified player name."""
    prefix, separator, name = player.partition(":")
    resolved_tour = (tour or (prefix if separator else "")).strip().casefold()
    if resolved_tour not in {"atp", "wta"}:
        raise ValueError("MatchLog identity tour must be ATP or WTA")
    return resolved_tour, (name if separator else player).strip()


def save_identity(
    discord_user_id: int, player: str, receipt: str, tour: str | None = None
) -> None:
    tour, player = _identity_tour(player, tour)
    with _connect() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO matchlog_player_identities (
                    discord_user_id, tour, player, receipt
                )
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (discord_user_id, tour) DO UPDATE
                SET player = EXCLUDED.player,
                    receipt = EXCLUDED.receipt,
                    approved_at = now()
                """,
                (discord_user_id, tour, player, receipt),
            )


def load_identities() -> dict[int, dict[str, str]]:
    with _connect() as connection:
        with connection.cursor() as cursor:
            identities: dict[int, dict[str, str]] = {}
            cursor.execute(
                """
                SELECT discord_user_id, player
                FROM matchlog_identities
                """
            )
            for user_id, player in cursor.fetchall():
                tour, player = _identity_tour_legacy(player)
                identities.setdefault(int(user_id), {})[tour] = player
            cursor.execute(
                """
                SELECT discord_user_id, tour, player
                FROM matchlog_player_identities
                """
            )
            for user_id, tour, player in cursor.fetchall():
                identities.setdefault(int(user_id), {})[tour] = player
            return identities


def load_identity(discord_user_id: int) -> dict[str, str]:
    """Return all approved tour-scoped identities for a Discord user."""
    with _connect() as connection:
        with connection.cursor() as cursor:
            identities: dict[str, str] = {}
            cursor.execute(
                """
                SELECT player
                FROM matchlog_identities
                WHERE discord_user_id = %s
                """,
                (discord_user_id,),
            )
            for row in cursor.fetchall():
                tour, player = _identity_tour_legacy(row[0])
                identities[tour] = player
            cursor.execute(
                """
                SELECT tour, player
                FROM matchlog_player_identities
                WHERE discord_user_id = %s
                """,
                (discord_user_id,),
            )
            identities.update({row[0]: row[1] for row in cursor.fetchall()})
            return identities


def _identity_tour_legacy(player: str) -> tuple[str, str]:
    prefix, separator, name = str(player).partition(":")
    tour = prefix.strip().casefold() if separator else "atp"
    if tour not in {"atp", "wta"}:
        tour = "atp"
    return tour, (name if separator else str(player)).strip()