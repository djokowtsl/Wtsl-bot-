"""Conservative parsers and durable delivery state for WTSL draw reminders."""
from __future__ import annotations

import json
import os
import re
import warnings
import hashlib
import copy
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urljoin, urlparse, urlunparse
from zoneinfo import ZoneInfo

from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning

LONDON = ZoneInfo("Europe/London")
STATE_PATH = Path("deadline_reminder_state.json")
DRAW_BASE_URL = "https://playwtsl.com/TE4/draw.php?tournament={tournament_id}"
TOURNAMENT_PAGE_URL = (
    "https://playwtsl.com/TE4/pages/tournament_page.php?tournament={tournament_id}"
)
ONGOING_TOURNAMENTS_URL = (
    "https://www.playwtsl.com/TE4/pages/tournaments.php?tour=TE4"
)
ONGOING_TOURNAMENTS_WTA_URL = (
    "https://www.playwtsl.com/TE4/pages/tournaments.php?tour=TE4_(F)"
)
DISCORD_NAME_ALIASES: dict[str, str] = {}


def clean_player_name(value: str) -> str:
    """Remove TE4's leading seed and trailing in-game-character annotation."""
    value = " ".join(str(value or "").split())
    value = re.sub(r"^\(\d+\)\s*", "", value)
    return re.sub(r"\s*\([^()]*\)\s*$", "", value).strip()


def discord_lookup_name(player_name: str) -> str:
    """Apply only explicitly confirmed WTSL-to-Discord display-name aliases."""
    return DISCORD_NAME_ALIASES.get(player_name.casefold(), player_name)


def parse_deadline(value: str) -> datetime | None:
    """Parse a draw deadline as an aware UTC datetime (BST/GMT is London time)."""
    match = re.search(r"Until\s+(\d{2}/\d{2}/\d{2})\s+at\s+(\d{2}:\d{2})\s+(?:BST|GMT)", value)
    if not match:
        return None
    try:
        local = datetime.strptime(" ".join(match.groups()), "%d/%m/%y %H:%M").replace(tzinfo=LONDON)
    except ValueError:
        return None
    return local.astimezone(timezone.utc)


def parse_ongoing_tournaments(
    html: str,
    base_url: str = "https://playwtsl.com/TE4/",
    tour: str = "TE4",
) -> list[dict[str, str]]:
    """Return uniquely identified tournaments from the homepage's ongoing table."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", XMLParsedAsHTMLWarning)
        soup = BeautifulSoup(html, "html.parser")
    ongoing = soup.select_one("tbody#ongoing")
    found: dict[str, dict[str, str]] = {}

    def add_tournament(link, category: str | None = None) -> None:
        href = urljoin(base_url, link["href"])
        tournament_id = (parse_qs(urlparse(href).query).get("tournament") or [""])[0].strip()
        if tournament_id:
            if not category:
                small = link.select_one("small")
                category = small.get_text(" ", strip=True) if small else ""
            if not category:
                row = link.find_parent("tr")
                cells = row.find_all("td") if row else []
                category = cells[2].get_text(" ", strip=True) if len(cells) > 2 else ""
            tournament_tour = (
                "TE4_(F)"
                if re.search(r"_F(?:_|$)", tournament_id, flags=re.IGNORECASE)
                else tour
            )
            found.setdefault(tournament_id, {
                "id": tournament_id,
                "name": link.get_text(" ", strip=True) or f"Tournament {tournament_id}",
                "category": category or "",
                "draw_url": DRAW_BASE_URL.format(tournament_id=tournament_id),
                "page_url": TOURNAMENT_PAGE_URL.format(tournament_id=tournament_id),
                "tour": tournament_tour,
            })

    if ongoing is not None:
        for link in ongoing.select("a[href]"):
            add_tournament(link)
        return list(found.values())

    # The live tournaments page no longer marks its ongoing tbody with an id.
    # Fall back to rows whose status link explicitly says "Ongoing"; this
    # prevents sign-up and finished tournaments from entering draw scans.
    for row in soup.select("table tr"):
        event_link = row.select_one("td.event-name a[href]")
        if event_link is None:
            continue
        status_links = row.select("a[href]")
        if not any(
            link.get_text(" ", strip=True).casefold() == "ongoing"
            for link in status_links
        ):
            continue
        cells = row.find_all("td")
        category = cells[2].get_text(" ", strip=True) if len(cells) > 2 else ""
        add_tournament(event_link, category)
    return list(found.values())


def parse_tournament_directory(
    html: str,
    base_url: str = "https://playwtsl.com/TE4/",
    tour: str = "TE4",
) -> list[dict[str, str]]:
    """Return tournament links from both ongoing and finished directory rows."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", XMLParsedAsHTMLWarning)
        soup = BeautifulSoup(html, "html.parser")
    found: dict[str, dict[str, str]] = {}
    for row in soup.select("table tr"):
        event_link = row.select_one("td.event-name a[href]")
        if event_link is None:
            continue
        href = urljoin(base_url, event_link["href"])
        tournament_id = (
            parse_qs(urlparse(href).query).get("tournament") or [""]
        )[0].strip()
        if not tournament_id:
            continue
        cells = row.find_all("td")
        category = cells[2].get_text(" ", strip=True) if len(cells) > 2 else ""
        tournament_tour = (
            "TE4_(F)"
            if re.search(r"_F(?:_|$)", tournament_id, flags=re.IGNORECASE)
            else tour
        )
        found.setdefault(
            tournament_id,
            {
                "id": tournament_id,
                "name": event_link.get_text(" ", strip=True)
                or f"Tournament {tournament_id}",
                "category": category,
                "draw_url": DRAW_BASE_URL.format(tournament_id=tournament_id),
                "page_url": TOURNAMENT_PAGE_URL.format(
                    tournament_id=tournament_id
                ),
                "tour": tournament_tour,
            },
        )
    return list(found.values())


def parse_challonge_svg_url(html: str, page_url: str) -> str | None:
    """Extract the exact Challonge SVG draw URL embedded by WTSL."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", XMLParsedAsHTMLWarning)
        soup = BeautifulSoup(html, "html.parser")
    iframe = soup.select_one("iframe[src*='challonge.com']")
    if iframe is None:
        return None
    iframe_url = urljoin(page_url, iframe.get("src", "").strip())
    parsed = urlparse(iframe_url)
    if parsed.scheme not in {"http", "https"} or "challonge.com" not in parsed.netloc:
        return None
    path = parsed.path.rstrip("/")
    if not path.endswith("/module"):
        return None
    svg_path = path[: -len("/module")] + ".svg"
    return urlunparse(parsed._replace(path=svg_path, query="", fragment=""))


def _parse_challonge_json_matches(
    html: str,
    tournament: dict[str, str],
    *,
    require_deadline: bool,
) -> list[dict[str, Any]]:
    """Parse matches from Challonge's current embedded tournament state."""
    state_match = re.search(
        r"window\._initialStoreState\['TournamentStore'\]\s*=\s*"
        r"(\{.*?\});\s*window\._initialStoreState\['ThemeStore'\]",
        html,
        flags=re.S,
    )
    if state_match is None:
        return []
    try:
        state = json.loads(state_match.group(1))
    except json.JSONDecodeError:
        return []
    if not isinstance(state, dict):
        return []

    round_by_number = {
        str(item.get("number")): item
        for item in state.get("rounds") or []
        if isinstance(item, dict)
    }
    matches: list[dict[str, Any]] = []
    match_state = "open" if require_deadline else "complete"
    matches_by_round = state.get("matches_by_round") or {}
    if not isinstance(matches_by_round, dict):
        return []
    for round_key, round_matches in matches_by_round.items():
        if not isinstance(round_matches, list):
            continue
        for match in round_matches:
            if not isinstance(match, dict) or match.get("state") != match_state:
                continue
            player_names = [
                clean_player_name(
                    str((match.get(player_key) or {}).get("display_name") or "")
                )
                for player_key in ("player1", "player2")
            ]
            if any(not name for name in player_names):
                continue
            match_id = str(match.get("id") or "").strip()
            if not match_id:
                continue
            round_info = round_by_number.get(
                str(match.get("round", round_key))
            ) or {}
            round_title = str(round_info.get("title") or "")
            deadline = parse_deadline(round_title)
            if require_deadline and deadline is None:
                continue
            round_name = re.sub(
                r"\s*-?\s*Until\b.*$",
                "",
                round_title,
                flags=re.I,
            ).strip()
            round_name = re.sub(
                r"\s*\([^)]*pts[^)]*\)\s*$",
                "",
                round_name,
                flags=re.I,
            ).strip() or "Completed match"
            item = {
                "tournament_id": tournament["id"],
                "tournament": tournament["name"],
                "category": tournament.get("category", ""),
                "draw_url": tournament["draw_url"],
                "match_id": match_id,
                "round": round_name,
                "_legacy_round": round_name,
                "players": player_names,
            }
            if deadline is not None:
                item["deadline"] = deadline
            item["match_key"] = stable_match_key(item)
            matches.append(item)
    return matches


def _parse_draw_match_nodes(
    html: str,
    tournament: dict[str, str],
    selector: str,
    *,
    require_deadline: bool,
) -> list[dict[str, Any]]:
    """Parse fully populated open or completed draw nodes."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", XMLParsedAsHTMLWarning)
        soup = BeautifulSoup(html, "html.parser")
    rounds: dict[tuple[str, str], tuple[str, datetime]] = {}
    legacy_rounds: dict[str, tuple[str, datetime]] = {}
    bracket_offsets: dict[str, float] = {}

    def bracket_key(node) -> str:
        """Distinguish winner and loser brackets sharing the same x positions."""
        bracket = node.find_parent("g", class_="rounds")
        return str(bracket.get("transform", "") if bracket else "")

    def translate_position(value: str) -> tuple[float, float] | None:
        match = re.search(
            r"translate\(\s*([-\d.]+)(?:\s*,\s*|\s+)([-\d.]+)",
            value,
        )
        if not match:
            return None
        return float(match.group(1)), float(match.group(2))

    for round_node in soup.select(".round"):
        label = round_node.select_one(".round-label")
        round_text = label.get_text(" ", strip=True) if label else ""
        deadline = parse_deadline(round_text)
        transform = re.search(
            r"translate\(\s*([\d.]+)", str(round_node.get("transform", ""))
        )
        x_position = str(round_node.get("x", "")).strip()
        if not x_position and transform:
            x_position = transform.group(1)
        if (require_deadline and deadline is None) or not x_position:
            continue
        bracket_transform = str(
            round_node.find_parent("g", class_="rounds").get("transform", "")
            if round_node.find_parent("g", class_="rounds")
            else ""
        )
        bracket_position = translate_position(bracket_transform)
        if bracket_position is not None:
            bracket_offsets[bracket_key(round_node)] = bracket_position[1]
        round_name = re.sub(r"\s*-?\s*Until\b.*$", "", round_text, flags=re.I).strip()
        round_name = re.sub(r"\s*\([^)]*pts[^)]*\)\s*$", "", round_name, flags=re.I)
        rounds[(bracket_key(round_node), x_position)] = (round_name, deadline)
        # Keep the result produced by the old x-position-only lookup so the
        # scheduler can issue one durable correction for notices affected by
        # the winner/loser bracket collision.
        legacy_rounds[x_position] = (round_name, deadline)

    matches: list[dict[str, Any]] = []
    for match in soup.select(selector):
        transform = re.search(r"translate\(\s*([\d.]+)", str(match.get("transform", "")))
        if not transform:
            continue
        match_position = translate_position(str(match.get("transform", "")))
        match_bracket_key = bracket_key(match)
        if not match_bracket_key and match_position and bracket_offsets:
            eligible = [
                (offset, key)
                for key, offset in bracket_offsets.items()
                if offset <= match_position[1]
            ]
            if eligible:
                match_bracket_key = max(eligible)[1]
            else:
                match_bracket_key = min(
                    bracket_offsets.items(),
                    key=lambda item: abs(item[1] - match_position[1]),
                )[0]
        round_name, deadline = rounds.get(
            (
                match_bracket_key,
                transform.group(1),
            ),
            ("Completed match", None),
        )
        if require_deadline and deadline is None:
            continue
        legacy_round_name, _ = legacy_rounds.get(
            transform.group(1),
            ("Completed match", None),
        )
        players = []
        for player in match.select("svg.match--player[data-participant-id]"):
            title = player.find("title")
            raw_name = (
                title.get_text(" ", strip=True)
                if title else player.get_text(" ", strip=True)
            )
            cleaned = clean_player_name(raw_name)
            if cleaned:
                players.append(cleaned)
        if len(players) != 2:
            continue
        match_id = str(match["data-match-id"]).strip()
        if not match_id:
            continue
        item = {
            "tournament_id": tournament["id"],
            "tournament": tournament["name"],
            "category": tournament.get("category", ""),
            "draw_url": tournament["draw_url"],
            "match_id": match_id,
            "round": round_name,
            "_legacy_round": legacy_round_name,
            "players": players,
        }
        if deadline is not None:
            item["deadline"] = deadline
        item["match_key"] = stable_match_key(item)
        matches.append(item)
    if matches:
        return matches
    return _parse_challonge_json_matches(
        html,
        tournament,
        require_deadline=require_deadline,
    )


def parse_draw_matches(html: str, tournament: dict[str, str]) -> list[dict[str, Any]]:
    """Parse open, fully populated draw matches with a valid round deadline."""
    return _parse_draw_match_nodes(
        html,
        tournament,
        "g.match.-open[data-match-id]",
        require_deadline=True,
    )


def parse_completed_draw_matches(
    html: str,
    tournament: dict[str, str],
) -> list[dict[str, Any]]:
    """Parse completed draw matches for automatic scheduling cleanup."""
    return _parse_draw_match_nodes(
        html,
        tournament,
        "g.match.-complete[data-match-id]",
        require_deadline=False,
    )


def stable_match_key(match: dict[str, Any]) -> str:
    """A deadline revision becomes a new reminder while match IDs stay stable."""
    deadline = match.get("deadline", "complete")
    if isinstance(deadline, datetime):
        deadline = deadline.astimezone(timezone.utc).isoformat()
    return f"{match['tournament_id']}:{match['match_id']}:{deadline}"


def reminder_window(deadline: datetime, now: datetime) -> str | None:
    """Return the one permitted reminder window, using UTC-aware datetimes."""
    remaining = (deadline - now).total_seconds()
    if 12 * 3600 < remaining <= 24 * 3600:
        return "24h"
    if 0 < remaining <= 12 * 3600:
        return "12h"
    if remaining <= 0:
        overdue_period = int(abs(remaining) // (24 * 3600))
        return f"overdue:{overdue_period}"
    return None


def admin_reminder_window(deadline: datetime, now: datetime) -> str | None:
    """Return the one-time admin windows for adjudication readiness."""
    remaining = (deadline - now).total_seconds()
    if 0 < remaining <= 6 * 3600:
        return "admin:6h"
    # If the 6-hour warning was missed, catch the match up on the first
    # overdue scan instead of waiting another twelve hours.
    if remaining <= 0:
        return "admin:overdue12h"
    return None


def reminder_key(match: dict[str, Any], window: str) -> str:
    return f"{match['match_key']}:{window}"


def reminder_window_started_at(match: dict[str, Any], window: str) -> datetime:
    """Earliest possible send time for this deterministic reminder window."""
    deadline = match["deadline"].astimezone(timezone.utc)
    if window == "24h":
        return deadline - timedelta(hours=24)
    if window == "12h":
        return deadline - timedelta(hours=12)
    if window.startswith("overdue:"):
        try:
            period = max(0, int(window.split(":", 1)[1]))
        except (TypeError, ValueError):
            period = 0
        return deadline + timedelta(hours=24 * period)
    return deadline


class DeadlineReminderState:
    """Atomic JSON ledger; each channel/DM delivery is recorded independently."""

    def __init__(self, path: Path = STATE_PATH):
        self.path = Path(path)
        self.data: dict[str, Any] = {"reminders": {}}

    def load(self) -> None:
        try:
            self.data = json.loads(self.path.read_text(encoding="utf8"))
        except FileNotFoundError:
            self.data = {"reminders": {}}
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"cannot load deadline reminder state: {exc}") from exc
        if not isinstance(self.data, dict) or not isinstance(self.data.get("reminders", {}), dict):
            raise RuntimeError("cannot load deadline reminder state: invalid ledger structure")
        self.data.setdefault("reminders", {})

    def sent(self, key: str, destination: str) -> bool:
        delivery = self.delivery(key, destination)
        if isinstance(delivery, bool):
            return delivery
        return delivery.get("status") == "sent"

    def delivery(self, key: str, destination: str) -> dict[str, Any] | bool:
        item = self.data["reminders"].get(key, {})
        if destination == "channel":
            return item.get("channel", {})
        if destination.startswith("channel:"):
            return item.get("channels", {}).get(destination[8:], {})
        if destination.startswith("dm:"):
            return item.get("dms", {}).get(destination[3:], {})
        return {}

    def begin_delivery(self, key: str, destination: str) -> str:
        current = self.delivery(key, destination)
        if isinstance(current, dict) and current.get("operation_ref"):
            return str(current["operation_ref"])
        operation_ref = hashlib.sha256(
            f"{key}|{destination}".encode("utf8")
        ).hexdigest()[:16]
        value = {"status": "sending", "operation_ref": operation_ref}
        value["sending_started_at"] = datetime.now(timezone.utc).isoformat()
        candidate = copy.deepcopy(self.data)
        item = candidate["reminders"].setdefault(key, {})
        if destination == "channel":
            item["channel"] = value
        elif destination.startswith("channel:"):
            item.setdefault("channels", {})[destination[8:]] = value
        elif destination.startswith("dm:"):
            item.setdefault("dms", {})[destination[3:]] = value
        else:
            raise ValueError(f"unknown reminder destination: {destination}")
        self._save(candidate)
        self.data = candidate
        return operation_ref

    def mark_sent(self, key: str, destination: str) -> None:
        current = self.delivery(key, destination)
        operation_ref = (
            current.get("operation_ref")
            if isinstance(current, dict) else None
        )
        value = {"status": "sent"}
        if operation_ref:
            value["operation_ref"] = operation_ref
        candidate = copy.deepcopy(self.data)
        item = candidate["reminders"].setdefault(key, {})
        if destination == "channel":
            item["channel"] = value
        elif destination.startswith("channel:"):
            item.setdefault("channels", {})[destination[8:]] = value
        elif destination.startswith("dm:"):
            item.setdefault("dms", {})[destination[3:]] = value
        else:
            raise ValueError(f"unknown reminder destination: {destination}")
        self._save(candidate)
        self.data = candidate

    def _save(self, data: dict[str, Any]) -> None:
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf8")
        os.replace(temp, self.path)