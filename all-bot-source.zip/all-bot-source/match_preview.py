"""Data collection and formatting for the Discord match-preview command.

This module deliberately keeps the preview deterministic. The workbook and
WTSL pages are the sources of truth; no model is asked to fill in missing
statistics or invent a prediction.
"""

from __future__ import annotations

import asyncio
import datetime as _datetime
from datetime import date, datetime, timezone
from difflib import get_close_matches
from pathlib import Path
import re
from typing import Any
from urllib.parse import parse_qs, quote, urljoin, urlparse
from zoneinfo import ZoneInfo

import aiohttp
from bs4 import BeautifulSoup
from openpyxl import load_workbook
from overall_ratings import (
    calculate_partial_overall_ratings,
    calculate_relative_profiles,
    rating_formula_footnote,
)
from player_insights import field_standing, metric_insight, tactical_match_advice
from tennis_stats_scraper import NAME_ALIASES as PLAYER_NAME_ALIASES
from wtsl_results import get_all_results


WTSL_ROOT = "https://playwtsl.com"
RANKINGS_FETCH_URL = f"{WTSL_ROOT}/TE4/pages/rankings_fetch_list.php"
RANKINGS_PAGE_URL = f"{WTSL_ROOT}/TE4/pages/rankings.php"
ALL_RESULTS_URL = f"{WTSL_ROOT}/TE4/pages/all_results_fetch.php"
PLAYER_PAGE_URL = f"{WTSL_ROOT}/TE4/pages/player_page.php"
H2H_URL = f"{WTSL_ROOT}/TE4/pages/h2h.php"
HOMEPAGE_URL = f"{WTSL_ROOT}/TE4"
DEFAULT_WORKBOOK = Path(
    "attached_assets/te4_hub_2808_FINAL_cleaned_summaries_1787911235428.xlsx"
)
MATCH_PREVIEW_TIMEZONE = ZoneInfo("Europe/London")

TOURS = {
    "atp": {
        "label": "ATP",
        "slug": "TE4",
        "summary_sheet": "ATP Summary",
    },
    "wta": {
        "label": "WTA",
        "slug": "TE4_(F)",
        "summary_sheet": "WTA Summary",
    },
}

SUMMARY_METRICS = [
    ("1st Serve %", "1st serve"),
    ("Aces", "aces"),
    ("Double Faults", "double faults"),
    ("Fastest Serve", "fastest serve"),
    ("Avg 1st Serve Speed", "avg 1st serve speed"),
    ("Avg 2nd Serve Speed", "avg 2nd serve speed"),
    ("Winners", "winners"),
    ("Forced Errors", "forced errors"),
    ("Unforced Errors", "unforced errors"),
    ("Net Points Won %", "net points won"),
    ("Break Points Won %", "break points won"),
    ("Total Points Won", "total points won"),
    ("Short Rallies Won (<5) %", "short rallies"),
    ("Medium Rallies Won (5-8) %", "medium rallies"),
    ("Long Rallies Won (>8) %", "long rallies"),
    ("Average Rally Length", "avg rally length"),
    ("1st Serve Won %", "1st serve won"),
    ("2nd Serve Won %", "2nd serve won"),
    ("Return Points Won %", "return points won"),
    ("Return Winners", "return winners"),
    ("Breaks / Games %", "breaks / games"),
]

PERCENT_COLUMNS = {
    "1st Serve %",
    "Net Points Won %",
    "Break Points Won %",
    "Short Rallies Won (<5) %",
    "Medium Rallies Won (5-8) %",
    "Long Rallies Won (>8) %",
    "1st Serve Won %",
    "2nd Serve Won %",
    "Return Points Won %",
    "Breaks / Games %",
}


class PlayerResolutionError(ValueError):
    """Raised when the two requested names cannot identify one tour."""


def normalize_name(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip().casefold()


def canonical_player_name(value: Any) -> str:
    normalized = normalize_name(value)
    return PLAYER_NAME_ALIASES.get(normalized, normalized)


def _number(value: Any) -> int | None:
    match = re.search(r"\d+", str(value or "").replace(",", ""))
    return int(match.group()) if match else None


def _text(value: Any) -> str:
    return re.sub(r"\s+", " ", "" if value is None else str(value)).strip()


def _parse_ranking_table(html: str, tour: str) -> dict[str, dict[str, Any]]:
    """Parse the live rankTable, including IDs used by filtered results pages."""
    soup = BeautifulSoup(html, "html.parser")
    table = soup.find("table", id="rankTable")
    if table is None:
        for candidate in soup.find_all("table"):
            header = " ".join(
                _text(cell.get_text(" ", strip=True)).casefold()
                for cell in candidate.find_all("th")
            )
            if "rank" in header and "player" in header:
                table = candidate
                break
    if table is None:
        raise RuntimeError(f"WTSL {tour.upper()} rankings table not found")

    result: dict[str, dict[str, Any]] = {}
    for row in table.find_all("tr"):
        cells = row.find_all("td")
        link = row.find("a", href=re.compile(r"player="))
        if not link or len(cells) < 3:
            continue
        name = _text(link.get_text(" ", strip=True))
        key = normalize_name(name)
        href = link.get("href", "")
        query = parse_qs(urlparse(href).query)
        player_id = (query.get("player") or [""])[0]
        if not key or not player_id:
            continue

        link_index = next(
            (index for index, cell in enumerate(cells) if cell.find("a") is link),
            2,
        )
        values = [_text(cell.get_text(" ", strip=True)) for cell in cells]
        rank = _number(values[0])
        info = {
            "name": name,
            "id": player_id,
            "rank": rank,
            "points": values[link_index + 1] if len(values) > link_index + 1 else "",
            "race_points": values[link_index + 2] if len(values) > link_index + 2 else "",
            "wtsl_elo": values[link_index + 3] if len(values) > link_index + 3 else "",
            "in_game_elo": values[link_index + 4] if len(values) > link_index + 4 else "",
            "tour": tour,
        }
        previous = result.get(key)
        if previous is None or (rank or 999999) < (previous.get("rank") or 999999):
            result[key] = info
    if not result:
        raise RuntimeError(f"No WTSL {tour.upper()} ranking players found")
    return result


async def fetch_rankings(
    session: aiohttp.ClientSession,
) -> dict[str, dict[str, dict[str, Any]]]:
    responses = await asyncio.gather(
        *(
            session.get(RANKINGS_FETCH_URL, params={"tour": config["slug"]})
            for config in TOURS.values()
        )
    )
    try:
        html_by_tour: dict[str, str] = {}
        for tour, response in zip(TOURS, responses):
            response.raise_for_status()
            html_by_tour[tour] = await response.text()
        return {
            tour: _parse_ranking_table(html, tour)
            for tour, html in html_by_tour.items()
        }
    finally:
        for response in responses:
            response.release()


def _suggestions(value: str, rankings: dict[str, dict[str, dict[str, Any]]]) -> list[str]:
    all_names = {
        entry["name"]
        for tour_entries in rankings.values()
        for entry in tour_entries.values()
    }
    return get_close_matches(value, sorted(all_names), n=3, cutoff=0.55)


def resolve_players(
    requested_one: str,
    requested_two: str,
    rankings: dict[str, dict[str, dict[str, Any]]],
    allow_same_player: bool = False,
) -> tuple[str, dict[str, Any], dict[str, Any]]:
    one = normalize_name(requested_one)
    two = normalize_name(requested_two)
    if not one or not two:
        raise PlayerResolutionError("Please provide two non-empty player names.")
    if one == two and not allow_same_player:
        raise PlayerResolutionError("Please choose two different players.")
    tours = [
        tour
        for tour in TOURS
        if one in rankings.get(tour, {}) and two in rankings.get(tour, {})
    ]
    if len(tours) != 1:
        details = []
        for requested in (requested_one, requested_two):
            found = [
                TOURS[tour]["label"]
                for tour in TOURS
                if normalize_name(requested) in rankings.get(tour, {})
            ]
            if not found:
                suggestions = _suggestions(requested, rankings)
                suffix = f" Suggestions: {', '.join(suggestions)}." if suggestions else ""
                details.append(f"Could not find **{requested}**.{suffix}")
            else:
                details.append(f"**{requested}** is listed in {', '.join(found)}.")
        if len(tours) > 1:
            raise PlayerResolutionError(
                "Both names exist in more than one tour, so the tour is ambiguous. "
                "Use names that uniquely identify the ATP or WTA ranking entry."
            )
        raise PlayerResolutionError(" ".join(details))
    tour = tours[0]
    return tour, rankings[tour][one], rankings[tour][two]


def _summary_rows_sync(
    workbook_path: Path,
    tour: str,
    player_names: list[str],
) -> tuple[dict[str, dict[str, Any]], str]:
    if not workbook_path.exists():
        raise FileNotFoundError(f"Stats workbook not found: {workbook_path}")
    sheet_name = TOURS[tour]["summary_sheet"]
    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    try:
        if sheet_name not in workbook.sheetnames:
            raise RuntimeError(f"Workbook sheet {sheet_name!r} not found")
        sheet = workbook[sheet_name]
        headers = [_text(cell.value) for cell in sheet[5]]
        if not headers or headers[0] != "Player":
            raise RuntimeError(f"Unexpected headers in workbook sheet {sheet_name!r}")
        wanted = {normalize_name(name): name for name in player_names}
        found: dict[str, dict[str, Any]] = {}
        population: list[dict[str, Any]] = []
        for row in sheet.iter_rows(min_row=6, values_only=True):
            name = _text(row[0] if row else "")
            key = normalize_name(name)
            if not name:
                continue
            mapped = {
                header: row[index] if index < len(row) else None
                for index, header in enumerate(headers)
                if header
            }
            population.append(mapped)
            if key in wanted:
                found[key] = mapped
        for summary in found.values():
            summary["relative_profile"] = calculate_relative_profiles(
                summary,
                population,
            )
        return found, _text(sheet["A3"].value)
    finally:
        workbook.close()


async def load_summary_rows(
    workbook_path: Path,
    tour: str,
    player_names: list[str],
) -> tuple[dict[str, dict[str, Any]], str]:
    return await asyncio.to_thread(_summary_rows_sync, workbook_path, tour, player_names)


def _player_id_from_link(href: str) -> str:
    return (parse_qs(urlparse(href or "").query).get("player") or [""])[0]


def parse_fixture_odds(
    html: str,
    first_id: str,
    second_id: str,
    source: str,
) -> dict[str, Any] | None:
    """Find one upcoming fixture and align its decimal odds to requested IDs."""
    soup = BeautifulSoup(html, "html.parser")
    wanted = {str(first_id), str(second_id)}
    for table in soup.find_all("table"):
        headers = [
            normalize_name(cell.get_text(" ", strip=True))
            for cell in table.find_all("th")
        ]
        if "match" not in headers or "odds" not in headers:
            continue
        for row in table.find_all("tr"):
            links = [
                link
                for link in row.find_all("a", href=True)
                if _player_id_from_link(link.get("href", ""))
            ]
            if len(links) < 2:
                continue
            ordered_ids = [_player_id_from_link(link["href"]) for link in links[:2]]
            if set(ordered_ids) != wanted:
                continue
            values = [_text(cell.get_text(" ", strip=True)) for cell in row.find_all("td")]
            odds_match = re.search(
                r"(\d+(?:[.,]\d+)?)\s*/\s*(\d+(?:[.,]\d+)?)",
                " ".join(values),
            )
            if not odds_match:
                return None
            ordered_odds = [
                float(value.replace(",", "."))
                for value in odds_match.groups()
            ]
            if any(value <= 1 for value in ordered_odds):
                return None
            by_id = dict(zip(ordered_ids, ordered_odds))
            return {
                "first": by_id[str(first_id)],
                "second": by_id[str(second_id)],
                "tournament": values[0] if values else "",
                "tour": values[1] if len(values) > 1 else "",
                "source": source,
            }
    return None


def parse_h2h_html(
    html: str,
    first: dict[str, Any],
    second: dict[str, Any],
) -> list[dict[str, Any]]:
    """Parse pair-specific H2H rows, whose scores use the winner's perspective."""
    soup = BeautifulSoup(html, "html.parser")
    table = soup.find("table", class_=lambda value: value and "results-table" in value)
    if table is None:
        return []
    players = {
        normalize_name(first["name"]): first["name"],
        normalize_name(second["name"]): second["name"],
    }
    results: list[dict[str, Any]] = []
    for row in table.find_all("tr")[1:]:
        cells = row.find_all("td")
        values = [_text(cell.get_text(" ", strip=True)) for cell in cells]
        if len(values) >= 7:
            match_date, tournament, competition, round_name, winner, score = (
                values[0],
                values[2],
                values[3],
                values[4],
                values[5],
                values[6],
            )
        elif len(values) >= 6:
            match_date, tournament, competition, round_name, winner, score = values[:6]
        else:
            continue
        winner_key = normalize_name(winner)
        if winner_key not in players:
            continue
        loser_key = next(key for key in players if key != winner_key)
        result = {
            "date": match_date,
            "tournament": tournament,
            "competition": competition,
            "round": round_name,
            "p1": players[winner_key],
            "p2": players[loser_key],
            "result": score,
            "source_url": (
                f"{H2H_URL}?pl_one={first['id']}&pl_two={second['id']}"
            ),
        }
        if _completed(result):
            results.append(result)
    return sorted(
        results,
        key=lambda result: _date_key(result.get("date", "")),
        reverse=True,
    )


def _h2h_page_matches_players(html: str, first_id: str, second_id: str) -> bool:
    """Confirm that WTSL rendered the requested pair, including a zero-match pair."""
    soup = BeautifulSoup(html, "html.parser")
    selected = {
        option.get("value", "")
        for option in soup.select("select option[selected]")
    }
    return {str(first_id), str(second_id)}.issubset(selected)


def parse_player_avatar(html: str, player_name: str) -> str | None:
    """Return a real player avatar URL, excluding the site's generic placeholder."""
    soup = BeautifulSoup(html, "html.parser")
    candidates = [
        image
        for image in soup.find_all("img", src=True)
        if "avatars/" in image.get("src", "").casefold()
    ]
    if not candidates:
        return None
    preferred = next(
        (
            image
            for image in candidates
            if normalize_name(image.get("alt")) == normalize_name(player_name)
        ),
        candidates[0],
    )
    source = preferred.get("src", "")
    if not source or source.casefold().endswith("/st_avatar.png"):
        return None
    return quote(urljoin(PLAYER_PAGE_URL, source), safe=":/?&=%")


async def _fetch_optional_text(
    session: aiohttp.ClientSession,
    url: str,
    params: dict[str, str] | None = None,
) -> str:
    try:
        async with session.get(url, params=params) as response:
            response.raise_for_status()
            return await response.text()
    except (aiohttp.ClientError, asyncio.TimeoutError):
        return ""


def _result_table(soup: BeautifulSoup):
    for table in soup.find_all("table"):
        header = " ".join(
            _text(cell.get_text(" ", strip=True)).casefold()
            for cell in table.find_all("th")
        )
        if "player 1" in header and "player 2" in header and "result" in header:
            return table
    return None


def _player_name_and_character(value: str) -> tuple[str, str | None]:
    """Split the all-results character label from the displayed player name."""
    match = re.fullmatch(r"\s*(.*?)\s*\(\s*([^()]+?)\s*\)\s*", value)
    if not match:
        return value, None
    player_name, character = (_text(part) for part in match.groups())
    if not character or not player_name:
        return value, None
    return player_name, character


def parse_results_html(html: str, source_url: str = ALL_RESULTS_URL) -> list[dict[str, Any]]:
    soup = BeautifulSoup(html, "html.parser")
    table = _result_table(soup)
    if table is None:
        return []
    header_row = table.find("tr")
    headers = [
        normalize_name(cell.get_text(" ", strip=True))
        for cell in header_row.find_all("th")
    ] if header_row else []

    def column_index(label: str) -> int | None:
        return next(
            (index for index, header in enumerate(headers) if header == label),
            None,
        )

    tournament_index = column_index("tournament")
    round_index = column_index("round")
    player_one_index = next(
        (index for index, header in enumerate(headers) if header.startswith("player 1")),
        None,
    )
    player_two_index = next(
        (index for index, header in enumerate(headers) if header.startswith("player 2")),
        None,
    )
    date_index = column_index("date")
    result_index = column_index("result")
    required_indexes = (
        tournament_index,
        round_index,
        player_one_index,
        player_two_index,
        date_index,
        result_index,
    )
    if any(index is None for index in required_indexes):
        return []

    results = []
    for row in table.find_all("tr")[1:]:
        cells = row.find_all("td")
        values = [_text(cell.get_text(" ", strip=True)) for cell in cells]
        # Some versions include a leading logo cell which has no header.
        if len(values) == len(headers) + 1 and not values[0]:
            values = values[1:]
        if len(values) < len(headers):
            continue
        tournament = values[tournament_index]
        round_name = values[round_index]
        player_one, p1_character = _player_name_and_character(values[player_one_index])
        player_two, p2_character = _player_name_and_character(values[player_two_index])
        match_date = values[date_index]
        result = values[result_index]
        if not player_one or not player_two:
            continue
        parsed_result = {
            "tournament": tournament,
            "round": round_name,
            "p1": player_one,
            "p2": player_two,
            "date": match_date,
            "result": result,
            "source_url": source_url,
        }
        if p1_character:
            parsed_result["p1_character"] = p1_character
        if p2_character:
            parsed_result["p2_character"] = p2_character
        results.append(parsed_result)
    return results


async def fetch_player_results(
    session: aiohttp.ClientSession,
    player: str,
    *,
    allow_stale: bool = False,
    force_refresh: bool = False,
) -> list[dict[str, Any]]:
    """Return the shared result rows involving ``player``.

    ``session`` remains part of the public function signature for callers that
    share one HTTP session while collecting preview data.  Results themselves
    are fetched once by the shared WTSL results module, which owns pagination
    and normalization.
    """
    del session
    requested_player = canonical_player_name(player)
    all_results = (
        await get_all_results(
            allow_stale=allow_stale,
            force_refresh=force_refresh,
        )
        if allow_stale or force_refresh
        else await get_all_results()
    )

    unique = {}
    for result in all_results:
        participants = {
            canonical_player_name(result.get("p1")),
            canonical_player_name(result.get("p2")),
            # Permit callers that still provide an ID to work when the shared
            # source includes its optional participant ID fields.
            normalize_name(result.get("p1_id")),
            normalize_name(result.get("p2_id")),
        }
        if requested_player not in participants:
            continue
        key = (
            normalize_name(result.get("tournament")),
            canonical_player_name(result.get("p1")),
            canonical_player_name(result.get("p2")),
            result.get("date"),
            result.get("result"),
        )
        unique[key] = result
    return list(unique.values())


def _date_key(value: str) -> tuple[int, int, int]:
    for fmt in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            parsed = datetime.strptime(value, fmt)
            return parsed.year, parsed.month, parsed.day
        except ValueError:
            continue
    return 0, 0, 0


def _completed(result: dict[str, Any]) -> bool:
    """Only count results whose score resolves one clear winner."""
    value = normalize_name(result.get("result"))
    if not value or value in {"scheduled", "tbd", "pending", "to be played"}:
        return False
    return winner_for_result(result) is not None


def _set_score(result: str) -> tuple[int, int]:
    one = two = 0
    score = re.sub(r"\([^)]*\)", "", result or "")
    for left, right in re.findall(r"(\d+)\s*[-–]\s*(\d+)", score):
        left, right = int(left), int(right)
        if left > right:
            one += 1
        elif right > left:
            two += 1
    return one, two


def winner_for_result(result: dict[str, Any]) -> str | None:
    one, two = _set_score(result.get("result", ""))
    if one > two:
        return canonical_player_name(result["p1"])
    if two > one:
        return canonical_player_name(result["p2"])
    return None


def _is_non_played_decision(result: dict[str, Any]) -> bool:
    """Return whether an administrative result should not count as a ranked win."""
    value = _text(result.get("result"))
    return bool(
        re.search(
            r"\b(?:walkover|coin\s*toss|cointoss|bct)\b|\bw\s*/\s*o\b",
            value,
            re.IGNORECASE,
        )
    )


def _player_outcome(result: dict[str, Any], player_name: str) -> str:
    winner = winner_for_result(result)
    player = canonical_player_name(player_name)
    if winner is None or player not in {
        canonical_player_name(result.get("p1")),
        canonical_player_name(result.get("p2")),
    }:
        return "—"
    return "W" if winner == player else "L"


def _latest(results: list[dict[str, Any]], limit: int = 5) -> list[dict[str, Any]]:
    return sorted(
        (result for result in results if _completed(result)),
        key=lambda result: _date_key(result.get("date", "")),
        reverse=True,
    )[:limit]


_GRAND_SLAM_NAMES = {
    "australian open",
    "french open",
    "roland garros",
    "us open",
    "wimbledon",
}

_MASTERS_1000_NAMES = {
    "cincinnati",
    "indian wells",
    "madrid",
    "miami",
    "monte carlo",
    "montreal",
    "paris",
    "rome",
    "shanghai",
    "toronto",
}

_WTSL_500_NAMES = {
    "acapulco",
    "barcelona",
    "basel",
    "beijing",
    "dubai",
    "halle",
    "hamburg",
    "queens",
    "queen's",
    "rio",
    "rotterdam",
    "tokyo",
    "vienna",
    "washington",
}


def _achievement_tournament_name(value: Any) -> str:
    """Return a readable event name from the shared WTSL tournament label."""
    tournament = _text(value) or "unnamed tournament"
    tournament = re.sub(
        r"^Tennis Elbow 4\s*\([^)]*\)\s*-\s*",
        "",
        tournament,
        flags=re.IGNORECASE,
    )
    tournament = re.sub(r"\s+\d{4}$", "", tournament).strip()
    return tournament or "unnamed tournament"


def _achievement_tier(value: Any) -> tuple[int, str | None]:
    """Return a sort rank and display label for a tournament achievement."""
    tournament = _achievement_tournament_name(value)
    normalized = normalize_name(tournament)
    if normalized in _GRAND_SLAM_NAMES or "grand slam" in normalized:
        return 600, "Grand Slam"
    if (
        normalized in _MASTERS_1000_NAMES
        or "masters 1000" in normalized
        or "atp 1000" in normalized
    ):
        return 500, "WTSL Masters 1000"
    if "finals" in normalized:
        return 450, "WTSL Finals"
    challenger = re.search(r"\bchallenger\s*(\d+)?\b", normalized)
    if challenger:
        points = int(challenger.group(1) or 0)
        return 250 + min(points, 200) // 10, f"Challenger {points}" if points else "Challenger"
    if "futures" in normalized or "future" in normalized:
        return 100, "Futures"
    if re.search(r"\b500\b", normalized) or normalized in _WTSL_500_NAMES:
        return 400, "WTSL 500"
    if re.search(r"\b250\b", normalized):
        return 300, "WTSL 250"
    return 200, None


def _achievement_sort_key(result: dict[str, Any]) -> tuple[Any, ...]:
    tier, _label = _achievement_tier(result.get("tournament"))
    return (-tier, tuple(-part for part in _date_key(result.get("date", ""))))


def _formatted_achievement(result: dict[str, Any]) -> str:
    tournament = _achievement_tournament_name(result.get("tournament"))
    _tier, label = _achievement_tier(result.get("tournament"))
    suffix = f" *({label})*" if label and label != "Grand Slam" else ""
    return f"**{tournament}**{suffix}"


def result_period_summary_text(
    results: list[dict[str, Any]],
    player_name: str,
    rankings: dict[str, dict[str, Any]] | None = None,
    *,
    period: str = "year",
    as_of: date | datetime | str | None = None,
) -> str:
    """Summarize completed results in one supported window with highlights."""
    if isinstance(as_of, _datetime.datetime):
        reference = as_of.date()
    elif isinstance(as_of, _datetime.date):
        reference = as_of
    elif isinstance(as_of, str):
        reference = date.fromisoformat(as_of[:10])
    else:
        reference = date.today()
    labels = {
        "career": "Career",
        "30d": "Last 30 days",
        "90d": "Last 90 days",
        "year": "Year to date",
        "52w": "Last 52 weeks",
    }
    if period not in labels:
        raise ValueError("period must be career, 30d, 90d, year, or 52w")
    start = {
        "30d": reference - _datetime.timedelta(days=29),
        "90d": reference - _datetime.timedelta(days=89),
        "year": _datetime.date(reference.year, 1, 1),
        "52w": reference - _datetime.timedelta(days=363),
    }.get(period)
    completed = [
        result
        for result in results
        if _completed(result)
        and (
            period == "career"
            or (
                _date_key(result.get("date", "")) != (0, 0, 0)
                and start
                <= _datetime.date(*_date_key(result.get("date", "")))
                <= reference
            )
        )
        and canonical_player_name(player_name) in {
            canonical_player_name(result.get("p1")),
            canonical_player_name(result.get("p2")),
        }
    ]
    wins = [
        result for result in completed
        if winner_for_result(result) == canonical_player_name(player_name)
    ]
    losses = len(completed) - len(wins)
    total = len(completed)
    if not total:
        return f"No completed results found for {labels[period].lower()}."

    titles: dict[str, dict[str, Any]] = {}
    finals: dict[str, dict[str, Any]] = {}
    for result in completed:
        round_name = normalize_name(result.get("round"))
        tournament = _achievement_tournament_name(result.get("tournament"))
        is_final = round_name in {"f", "final", "finals"}
        if not is_final:
            continue
        if winner_for_result(result) == canonical_player_name(player_name):
            titles.setdefault(tournament, result)
        else:
            finals.setdefault(tournament, result)

    highlights = []
    if titles:
        highlights.append(
            "won "
            + ", ".join(
                _formatted_achievement(result)
                for result in sorted(titles.values(), key=_achievement_sort_key)
            )
        )
    if finals:
        highlights.append(
            "reached the final at "
            + ", ".join(
                _formatted_achievement(result)
                for result in sorted(finals.values(), key=_achievement_sort_key)
            )
        )
    percentage = wins.__len__() / total
    base = (
        f"**{len(wins)}-{losses} ({percentage:.0%})** "
        f"across {labels[period].lower()}."
    )
    if not highlights:
        return base
    return base + " Highlights:\n" + "\n".join(f"• {highlight}" for highlight in highlights) + "."


def season_summary_text(
    results: list[dict[str, Any]],
    player_name: str,
    rankings: dict[str, dict[str, Any]] | None = None,
    *,
    year: int | None = None,
) -> str:
    reference = (
        _datetime.date(year, 12, 31)
        if year is not None else _datetime.date.today()
    )
    return result_period_summary_text(
        results,
        player_name,
        rankings,
        period="year",
        as_of=reference,
    )


def _same_match(result: dict[str, Any], first: str, second: str) -> bool:
    names = {normalize_name(result.get("p1")), normalize_name(result.get("p2"))}
    return names == {normalize_name(first), normalize_name(second)}


def build_match_data(
    tour: str,
    first: dict[str, Any],
    second: dict[str, Any],
    first_results: list[dict[str, Any]],
    second_results: list[dict[str, Any]],
    summaries: dict[str, dict[str, Any]],
    summary_metadata: str,
    pair_h2h: list[dict[str, Any]] | None = None,
    odds: dict[str, Any] | None = None,
    avatars: dict[str, str | None] | None = None,
    rankings: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    first_name, second_name = first["name"], second["name"]
    first = dict(first)
    second = dict(second)
    avatars = avatars or {}
    for player in (first, second):
        player["profile_url"] = f"{PLAYER_PAGE_URL}?player={player['id']}"
        player["avatar_url"] = avatars.get(str(player["id"]))
    if pair_h2h is not None:
        h2h = pair_h2h
        h2h_basis = "pair-specific WTSL H2H"
    else:
        combined_h2h = {}
        for result in first_results + second_results:
            if _same_match(result, first_name, second_name) and _completed(result):
                key = (
                    normalize_name(result["tournament"]),
                    result["date"],
                    result["result"],
                )
                combined_h2h[key] = result
        h2h = sorted(
            combined_h2h.values(),
            key=lambda result: _date_key(result.get("date", "")),
            reverse=True,
        )
        h2h_basis = "player result histories"
    first_wins = sum(
        winner_for_result(result) == normalize_name(first_name) for result in h2h
    )
    second_wins = sum(
        winner_for_result(result) == normalize_name(second_name) for result in h2h
    )
    return {
        "tour": tour,
        "tour_label": TOURS[tour]["label"],
        "first": first,
        "second": second,
        "summaries": summaries,
        "summary_metadata": summary_metadata,
        "first_form": _latest(first_results),
        "second_form": _latest(second_results),
        "h2h": h2h,
        "h2h_record": (first_wins, second_wins),
        "h2h_basis": h2h_basis,
        "odds": odds,
        "season_summaries": {
            normalize_name(first_name): season_summary_text(
                first_results, first_name, rankings
            ),
            normalize_name(second_name): season_summary_text(
                second_results, second_name, rankings
            ),
        },
        "sources": {
            "rankings": f"{RANKINGS_PAGE_URL}?tour={TOURS[tour]['slug']}",
            "first_results": f"{ALL_RESULTS_URL}?player={first['id']}",
            "second_results": f"{ALL_RESULTS_URL}?player={second['id']}",
            "summary_sheet": TOURS[tour]["summary_sheet"],
            "summary_source": "screenshots",
        },
    }


async def collect_match_data(
    requested_one: str,
    requested_two: str,
    workbook_path: Path = DEFAULT_WORKBOOK,
    *,
    allow_same_player: bool = False,
) -> dict[str, Any]:
    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        rankings = await fetch_rankings(session)
        tour, first, second = resolve_players(
            requested_one, requested_two, rankings, allow_same_player=allow_same_player
        )
        allowed_same_player = (
            allow_same_player
            and normalize_name(requested_one) == normalize_name(requested_two)
        )
        # The isolated outreach test is deliberately not a real self-match.
        # Do not share mutable player records or request self-H2H/odds data.
        if allowed_same_player:
            first, second = dict(first), dict(second)
        h2h_params = {
            "tour": TOURS[tour]["slug"],
            "pl_one": str(first["id"]),
            "pl_two": str(second["id"]),
        }
        (
            summary_result,
            first_results,
            second_results,
            h2h_html,
            homepage_html,
            first_page_html,
            second_page_html,
        ) = await asyncio.gather(
            load_summary_rows(workbook_path, tour, [first["name"], second["name"]]),
            fetch_player_results(session, first["name"]),
            fetch_player_results(session, second["name"]),
            (
                asyncio.sleep(0, result="")
                if allowed_same_player
                else _fetch_optional_text(session, H2H_URL, h2h_params)
            ),
            _fetch_optional_text(session, HOMEPAGE_URL),
            _fetch_optional_text(
                session, PLAYER_PAGE_URL, {"player": str(first["id"])}
            ),
            _fetch_optional_text(
                session, PLAYER_PAGE_URL, {"player": str(second["id"])}
            ),
        )
    summaries, metadata = summary_result
    pair_h2h = [] if allowed_same_player else (
        parse_h2h_html(h2h_html, first, second)
        if h2h_html
        and _h2h_page_matches_players(h2h_html, first["id"], second["id"])
        else None
    )
    odds = None if allowed_same_player else parse_fixture_odds(
        h2h_html, first["id"], second["id"], "pair-specific H2H page"
    )
    if odds is None and not allowed_same_player:
        odds = parse_fixture_odds(
            homepage_html, first["id"], second["id"], "homepage fixtures"
        )
    if odds is not None:
        # Keep this retrieval time with the in-memory preview only; odds are
        # never cached or persisted between command invocations.
        odds = {
            **odds,
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }
    data = build_match_data(
        tour,
        first,
        second,
        first_results,
        second_results,
        summaries,
        metadata,
        pair_h2h=pair_h2h,
        odds=odds,
        avatars={
            str(first["id"]): parse_player_avatar(first_page_html, first["name"]),
            str(second["id"]): parse_player_avatar(second_page_html, second["name"]),
        },
        rankings=rankings[tour],
    )
    data["prediction"] = calculate_prediction(data)
    return data


def _format_value(column: str, value: Any) -> str:
    if value is None or value == "":
        return "—"
    if column in PERCENT_COLUMNS:
        try:
            return f"{float(value):.1%}"
        except (TypeError, ValueError):
            return _text(value)
    if isinstance(value, float):
        return f"{value:.1f}"
    return _text(value)


def _ranking_line(entry: dict[str, Any]) -> str:
    rank = f"#{entry['rank']}" if entry.get("rank") else "unranked"
    points = entry.get("points") or "—"
    wtsl_elo = entry.get("wtsl_elo") or "—"
    game_elo = entry.get("in_game_elo") or "—"
    return (
        f"**[{entry['name']}]({PLAYER_PAGE_URL}?player={entry['id']})** — "
        f"{rank} · {points} pts · "
        f"WTSL Elo {wtsl_elo} · in-game Elo {game_elo}"
    )


def _form_line(result: dict[str, Any], player: str) -> str:
    outcome = _player_outcome(result, player)
    return (
        f"{outcome} {result.get('date') or 'date unknown'} · "
        f"{_achievement_tournament_name(result.get('tournament'))} "
        f"({result.get('round') or 'round unknown'}) vs "
        f"{result.get('p2') if normalize_name(result.get('p1')) == normalize_name(player) else result.get('p1')} "
        f"— {result.get('result') or 'score unavailable'}"
    )


def _edge_counts(data: dict[str, Any]) -> tuple[int, int, int]:
    first_score = second_score = comparable = 0
    first_summary = data["summaries"].get(normalize_name(data["first"]["name"]), {})
    second_summary = data["summaries"].get(normalize_name(data["second"]["name"]), {})
    lower_is_better = {"Double Faults", "Unforced Errors"}
    for column, _ in SUMMARY_METRICS:
        first_value, second_value = first_summary.get(column), second_summary.get(column)
        if not isinstance(first_value, (int, float)) or not isinstance(second_value, (int, float)):
            continue
        comparable += 1
        if first_value == second_value:
            continue
        if column in lower_is_better:
            if first_value < second_value:
                first_score += 1
            else:
                second_score += 1
        elif first_value > second_value:
            first_score += 1
        else:
            second_score += 1
    return first_score, second_score, comparable


def _float_value(value: Any) -> float | None:
    match = re.search(r"-?\d+(?:[.,]\d+)?", str(value or "").replace(" ", ""))
    if not match:
        return None
    try:
        return float(match.group().replace(",", "."))
    except ValueError:
        return None

def _format_odds_checked_at(value: Any) -> str:
    if isinstance(value, datetime):
        checked_at = value
    else:
        checked_at = datetime.fromisoformat(_text(value).replace("Z", "+00:00"))
    if checked_at.tzinfo is None:
        checked_at = checked_at.replace(tzinfo=timezone.utc)
    return checked_at.astimezone(MATCH_PREVIEW_TIMEZONE).strftime(
        "%d %b %Y, %H:%M %Z"
    )
def calculate_prediction(data: dict[str, Any]) -> dict[str, Any]:
    """Produce a deterministic favourite from market and performance signals."""
    first, second = data["first"], data["second"]
    names = [first["name"], second["name"]]
    scores = [0.0, 0.0]
    evidence: list[str] = []
    non_market_winners: list[int] = []

    def signal(
        label: str,
        left: float | int | None,
        right: float | int | None,
        weight: float,
        *,
        lower_is_better: bool = False,
        detail: str,
    ) -> None:
        if left is None or right is None or left == right:
            return
        winner = 0 if (left < right if lower_is_better else left > right) else 1
        scores[winner] += weight
        non_market_winners.append(winner)
        evidence.append(f"{label}: **{names[winner]}** — {detail}")

    odds = data.get("odds")
    market_favorite: int | None = None
    implied: list[float] | None = None
    if odds and odds.get("first", 0) > 1 and odds.get("second", 0) > 1:
        listed = [float(odds["first"]), float(odds["second"])]
        raw = [1 / value for value in listed]
        total = sum(raw)
        implied = [value / total for value in raw]
        if listed[0] != listed[1]:
            market_favorite = 0 if listed[0] < listed[1] else 1
            scores[market_favorite] += 8.0

    signal(
        "Ranking",
        first.get("rank"),
        second.get("rank"),
        2.0,
        lower_is_better=True,
        detail=f"#{first.get('rank') or '—'} vs #{second.get('rank') or '—'}",
    )
    first_wtsl, second_wtsl = (
        _float_value(first.get("wtsl_elo")),
        _float_value(second.get("wtsl_elo")),
    )
    signal(
        "WTSL Elo",
        first_wtsl,
        second_wtsl,
        2.0,
        detail=f"{first.get('wtsl_elo') or '—'} vs {second.get('wtsl_elo') or '—'}",
    )
    first_game, second_game = (
        _float_value(first.get("in_game_elo")),
        _float_value(second.get("in_game_elo")),
    )
    signal(
        "In-game Elo",
        first_game,
        second_game,
        1.25,
        detail=f"{first.get('in_game_elo') or '—'} vs {second.get('in_game_elo') or '—'}",
    )

    form_rates = []
    for player, results in ((first, data["first_form"]), (second, data["second_form"])):
        wins = sum(_player_outcome(result, player["name"]) == "W" for result in results)
        form_rates.append(wins / len(results) if results else None)
    signal(
        "Recent form",
        form_rates[0],
        form_rates[1],
        1.5,
        detail=(
            f"{sum(_player_outcome(r, first['name']) == 'W' for r in data['first_form'])}"
            f"/{len(data['first_form'])} wins vs "
            f"{sum(_player_outcome(r, second['name']) == 'W' for r in data['second_form'])}"
            f"/{len(data['second_form'])}"
        ),
    )
    h2h_first, h2h_second = data["h2h_record"]
    signal(
        "Head-to-head",
        h2h_first,
        h2h_second,
        1.5,
        detail=f"{h2h_first}–{h2h_second}",
    )
    first_edges, second_edges, comparable = _edge_counts(data)
    signal(
        "Advanced-stat edges",
        first_edges,
        second_edges,
        1.5,
        detail=f"{first_edges}–{second_edges} across {comparable} comparable metrics",
    )

    if market_favorite is not None:
        favored = market_favorite
        probability = implied[favored] if implied else 0.5
        confidence = (
            "strong" if probability >= 0.68
            else "clear" if probability >= 0.59
            else "slight"
        )
        supporting = sum(winner == favored for winner in non_market_winners)
        conflicting = sum(winner != favored for winner in non_market_winners)
        if conflicting > supporting and confidence == "strong":
            confidence = "clear"
        basis = "market-led"
    else:
        if scores[0] == scores[1]:
            first_rank = first.get("rank") or 999999
            second_rank = second.get("rank") or 999999
            favored = 0 if first_rank <= second_rank else 1
        else:
            favored = 0 if scores[0] > scores[1] else 1
        margin = abs(scores[0] - scores[1])
        confidence = "clear" if margin >= 4 else "slight"
        basis = "performance-led; no matching fixture odds found"

    return {
        "favored_index": favored,
        "favored_name": names[favored],
        "confidence": confidence,
        "basis": basis,
        "scores": scores,
        "evidence": evidence,
        "implied": implied,
    }


def _category_leader(
    first_summary: dict[str, Any],
    second_summary: dict[str, Any],
    columns: list[str],
    lower_is_better: set[str] | None = None,
) -> tuple[int | None, int]:
    """Return the player with more measurable edges and the comparison count."""
    lower_is_better = lower_is_better or set()
    first_edges = second_edges = comparable = 0
    for column in columns:
        first_value = first_summary.get(column)
        second_value = second_summary.get(column)
        if not isinstance(first_value, (int, float)) or not isinstance(
            second_value, (int, float)
        ):
            continue
        comparable += 1
        if first_value == second_value:
            continue
        first_is_better = (
            first_value < second_value
            if column in lower_is_better
            else first_value > second_value
        )
        if first_is_better:
            first_edges += 1
        else:
            second_edges += 1
    if first_edges == second_edges:
        return None, comparable
    return (1 if first_edges > second_edges else 2), comparable


MATCH_INSIGHT_CATEGORIES = [
    (
        "Serve",
        [
            "1st Serve %",
            "1st Serve Won %",
            "2nd Serve Won %",
            "Aces",
            "Double Faults",
        ],
        {"Double Faults"},
    ),
    (
        "Return",
        ["Return Points Won %", "Return Winners", "Break Points Won %", "Breaks / Games %"],
        set(),
    ),
    (
        "Rally Attack",
        ["Winners", "Forced Errors", "Short Rallies Won (<5) %"],
        set(),
    ),
    (
        "Rally Defense",
        ["Unforced Errors", "Medium Rallies Won (5-8) %", "Long Rallies Won (>8) %"],
        {"Unforced Errors"},
    ),
    ("Net play", ["Net Points Won %"], set()),
]

MATCH_INSIGHT_PROFILE_GROUPS = {
    "Serve": "serve",
    "Return": "return",
    "Rally Attack": "rally",
    "Rally Defense": "rally",
    "Net play": "net",
}


def _paired_metric_edges(
    first_summary: dict[str, Any],
    second_summary: dict[str, Any],
    columns: list[str],
    lower_is_better: set[str],
) -> list[tuple[str, Any, Any, int]]:
    edges = []
    for column in columns:
        first_value = first_summary.get(column)
        second_value = second_summary.get(column)
        if not isinstance(first_value, (int, float)) or not isinstance(
            second_value, (int, float)
        ) or first_value == second_value:
            continue
        first_is_better = (
            first_value < second_value
            if column in lower_is_better
            else first_value > second_value
        )
        edges.append((
            column,
            first_value,
            second_value,
            1 if first_is_better else 2,
        ))
    return edges


def _best_rally_profile(summary: dict[str, Any]) -> str | None:
    options = [
        ("short", "Short Rallies Won (<5) %"),
        ("medium", "Medium Rallies Won (5-8) %"),
        ("long", "Long Rallies Won (>8) %"),
    ]
    usable = [
        (label, value)
        for label, column in options
        if isinstance((value := summary.get(column)), (int, float))
    ]
    return max(usable, key=lambda item: item[1])[0] if usable else None


def _match_key_points(data: dict[str, Any]) -> dict[str, list[str]]:
    first, second = data["first"], data["second"]
    first_summary = data["summaries"].get(normalize_name(first["name"]), {})
    second_summary = data["summaries"].get(normalize_name(second["name"]), {})
    keys = {first["name"]: [], second["name"]: []}

    for label, columns, lower_is_better in MATCH_INSIGHT_CATEGORIES:
        edges = _paired_metric_edges(
            first_summary, second_summary, columns, lower_is_better
        )
        leader, comparable = _category_leader(
            first_summary, second_summary, columns, lower_is_better
        )
        if comparable == 0 or leader is None:
            continue
        if not edges:
            continue
        for player_index, player, opponent in (
            (1, first, second),
            (2, second, first),
        ):
            supporting = [edge for edge in edges if edge[3] == player_index]
            if supporting:
                metric, player_value, opponent_value, _winner = max(
                    supporting, key=lambda edge: abs(edge[1] - edge[2])
                )
                strength = True
            else:
                metric, first_value, second_value, _winner = min(
                    edges, key=lambda edge: abs(edge[1] - edge[2])
                )
                player_value = first_value if player_index == 1 else second_value
                opponent_value = second_value if player_index == 1 else first_value
                strength = False
            player_summary = (
                first_summary if player_index == 1 else second_summary
            )
            standing = field_standing(
                player_summary,
                MATCH_INSIGHT_PROFILE_GROUPS.get(label),
            )
            standing_text = (
                f" Field standing: {standing}."
                if standing else ""
            )
            tactical_plan = tactical_match_advice(
                metric,
                strength=strength,
                field_context=standing,
            )
            keys[player["name"]].append(
                f"{label}: **{metric}** {_format_value(metric, player_value)} "
                f"vs {opponent['name']} {_format_value(metric, opponent_value)}. "
                f"{metric_insight(metric, strength=strength, subject=player['name'])}"
                f"{standing_text}\n"
                f"**Tactical plan:** {tactical_plan}"
            )

    first_rally = _best_rally_profile(first_summary)
    second_rally = _best_rally_profile(second_summary)
    if first_rally:
        keys[first["name"]].append(
            f"Rally shape: steer points toward {first_rally} rallies, "
            f"where {first['name']}'s available summary profile is strongest."
        )
    if second_rally:
        keys[second["name"]].append(
            f"Rally shape: steer points toward {second_rally} rallies, "
            f"where {second['name']}'s available summary profile is strongest."
        )
    return keys


def _match_key_lines(data: dict[str, Any]) -> list[str]:
    keys = _match_key_points(data)
    first, second = data["first"], data["second"]
    lines: list[str] = []
    for player in (first["name"], second["name"]):
        lines.append(f"**{player}**")
        if keys[player]:
            lines.extend(f"• {key}" for key in keys[player][:4])
        else:
            lines.append("• No clear statistical key separates the players.")
    return lines


def personalized_match_keys(
    player_name: str,
    player_summary: dict[str, Any],
    opponent_name: str,
    opponent_summary: dict[str, Any] | None,
) -> list[str]:
    """Return private, evidence-based keys for one verified player."""
    player_values = {
        label: value
        for label, value, _count in player_summary.get("metrics", [])
        if isinstance(value, (int, float))
    }
    player_context = {
        **player_values,
        "relative_profile": player_summary.get("relative_profile") or {},
    }
    if opponent_summary:
        opponent_values = {
            label: value
            for label, value, _count in opponent_summary.get("metrics", [])
            if isinstance(value, (int, float))
        }
        opponent_context = {
            **opponent_values,
            "relative_profile": opponent_summary.get("relative_profile") or {},
        }
        data = {
            "first": {"name": player_name},
            "second": {"name": opponent_name},
            "summaries": {
                normalize_name(player_name): player_context,
                normalize_name(opponent_name): opponent_context,
            },
        }
        compared = _match_key_points(data)[player_name][:4]
        if compared:
            return compared

    keys: list[str] = []
    ratings = [
        (label, value)
        for label, value in player_summary.get("ratings", [])
        if isinstance(value, (int, float))
    ]
    if ratings:
        strongest = max(ratings, key=lambda item: item[1])[0]
        weakest = min(ratings, key=lambda item: item[1])[0]
        keys.append(
            f"Build around your {strongest.lower()}, the strongest available "
            "part of this statistical profile."
        )
        if weakest != strongest:
            keys.append(
                f"Protect your {weakest.lower()} with disciplined patterns "
                "until you establish scoreboard pressure."
            )
    rally = _best_rally_profile(player_values)
    if rally:
        keys.append(
            f"Steer points toward {rally} rallies, where your available "
            "summary profile is strongest."
        )
    if not keys:
        keys.append(
            "There is not enough populated statistical evidence to identify "
            "a reliable tactical key yet."
        )
    return keys[:4]


def _prediction_lines(data: dict[str, Any]) -> list[str]:
    first, second = data["first"], data["second"]
    prediction = data.get("prediction") or calculate_prediction(data)
    lines = [
        "🎯 **Prediction**",
        f"**{prediction['favored_name']} is favoured** — "
        f"{prediction['confidence']} confidence ({prediction['basis']}).",
    ]
    odds = data.get("odds")
    implied = prediction.get("implied")
    if odds and implied:
        odds_favorite = 0 if odds["first"] < odds["second"] else 1
        tournament_name = _achievement_tournament_name(odds.get("tournament"))
        tournament = f" · {tournament_name}" if tournament_name else ""
        checked_at = odds.get("checked_at")
        checked_at_text = (
            f" · **Checked at:** {_format_odds_checked_at(checked_at)}"
            if checked_at
            else ""
        )
        lines.extend(
            [
                f"**WTSL Elo/H2H odds:** **{(first, second)[odds_favorite]['name']} "
                f"is favoured**{tournament}.",
                f"**Listed odds{tournament}:** "
                f"{first['name']} {odds['first']:.2f} · "
                f"{second['name']} {odds['second']:.2f}"
                f"{checked_at_text}",
                f"**Odds-implied chances:** {first['name']} {implied[0]:.1%} · "
                f"{second['name']} {implied[1]:.1%}",
            ]
        )
        first_edges, second_edges, comparable = _edge_counts(data)
        if comparable and first_edges != second_edges:
            stats_favorite = 0 if first_edges > second_edges else 1
            if stats_favorite != odds_favorite:
                lines.append(
                    f"**Split view:** the Elo/H2H odds favour "
                    f"{(first, second)[odds_favorite]['name']}; advanced stats lean "
                    f"{(first, second)[stats_favorite]['name']}."
                )
    else:
        lines.append("**WTSL Elo/H2H odds:** no matching upcoming fixture found.")
    if prediction["evidence"]:
        lines.append("**Why:**")
        lines.extend(f"• {item}" for item in prediction["evidence"])
    lines.append(
        "*A forecast, not a guarantee or staking recommendation.*"
    )
    return lines


def _statistical_takeaway_lines(
    data: dict[str, Any],
    first_edges: int,
    second_edges: int,
    comparable_metrics: int,
) -> list[str]:
    """Summarize the advanced-stat view without repeating category findings."""
    first, second = data["first"], data["second"]
    summaries = [
        data["summaries"].get(normalize_name(first["name"]), {}),
        data["summaries"].get(normalize_name(second["name"]), {}),
    ]
    profile_parts = []
    for label, columns, lower_is_better in MATCH_INSIGHT_CATEGORIES:
        leader, comparable = _category_leader(
            summaries[0], summaries[1], columns, lower_is_better
        )
        if leader is None or not comparable:
            continue
        edges = _paired_metric_edges(
            summaries[0], summaries[1], columns, lower_is_better
        )
        supporting = [edge for edge in edges if edge[3] == leader]
        if not supporting:
            continue
        metric, first_value, second_value, _winner = max(
            supporting, key=lambda edge: abs(edge[1] - edge[2])
        )
        player = (first, second)[leader - 1]
        opponent = second if leader == 1 else first
        player_value = first_value if leader == 1 else second_value
        opponent_value = second_value if leader == 1 else first_value
        player_summary = summaries[leader - 1]
        standing = field_standing(
            player_summary,
            MATCH_INSIGHT_PROFILE_GROUPS.get(label),
        )
        standing_text = (
            f" Field standing: {standing}."
            if standing else ""
        )
        profile_parts.append(
            f"• **{player['name']}:** {label.lower()} edge — "
            f"**{metric} {_format_value(metric, player_value)}** vs "
            f"{opponent['name']} {_format_value(metric, opponent_value)}. "
            f"{metric_insight(metric, strength=True, subject=player['name'])}"
            f"{standing_text}"
        )

    lines = ["🧭 **Statistical takeaway**"]
    if comparable_metrics:
        if first_edges == second_edges:
            lines.append(
                f"**Advanced stats are level:** {first_edges}–{second_edges} across "
                f"{comparable_metrics} comparable metrics."
            )
        else:
            favored = first if first_edges > second_edges else second
            lines.append(
                f"**Advanced stats lean {favored['name']}:** "
                f"{first['name']} {first_edges}–{second_edges} {second['name']} "
                f"across {comparable_metrics} comparable metrics."
            )
    else:
        lines.append(
            "**Advanced-stat lean:** unavailable because there are no paired metrics."
        )

    if profile_parts:
        lines.append("**Profile edges:**")
        lines.extend(profile_parts)
    elif comparable_metrics:
        lines.append(
            "**Profile edges:** no clear category advantage in the paired data."
        )
    return lines


def _article_form_sentence(player: dict[str, Any], results: list[dict[str, Any]]) -> str:
    """Turn the recent-results line into concise article copy."""
    if not results:
        return "There is no recent completed-results line to lean on."
    outcomes = [_player_outcome(result, player["name"]) for result in results]
    wins = outcomes.count("W")
    losses = outcomes.count("L")
    record = f"{wins} win{'s' if wins != 1 else ''} and {losses} loss{'es' if losses != 1 else ''}"
    return f"The latest line reads **{' '.join(outcomes)}**, a run of {record}."


PROFILE_HIGHLIGHT_GROUPS = [
    (
        "serve",
        ["1st Serve Won %", "1st Serve %", "2nd Serve Won %", "Aces", "Double Faults"],
    ),
    (
        "return",
        ["Return Points Won %", "1st Serve Return Points Won %", "2nd Serve Return Points Won %", "Break Points Won %"],
    ),
    (
        "rally",
        ["Long Rallies Won (>8) %", "Medium Rallies Won (5-8) %", "Short Rallies Won (<5) %", "Winners", "Unforced Errors"],
    ),
]


def _article_profile_lines(
    player: dict[str, Any],
    summary: dict[str, Any],
) -> list[str]:
    """Build readable player lines from ranking and measured profile traits."""
    rank = player.get("rank")
    elo = player.get("wtsl_elo")
    if rank and elo:
        opening = f"Ranked **#{rank}** with a WTSL Elo of **{elo}**."
    elif rank:
        opening = f"Ranked **#{rank}**."
    elif elo:
        opening = f"Carrying a WTSL Elo of **{elo}**."
    else:
        opening = "They arrive without a numeric ranking or Elo marker."

    lines = [f"**{player['name']}** — {opening}"]
    for group, metrics in PROFILE_HIGHLIGHT_GROUPS:
        metric = next(
            (candidate for candidate in metrics if isinstance(summary.get(candidate), (int, float))),
            None,
        )
        if metric:
            lines.append(
                f"• **{group.title()}:** **{metric} "
                f"{_format_value(metric, summary[metric])}** — "
                f"{metric_insight(metric, strength=True, subject=player['name'])}"
            )
        if len(lines) == 3:
            break
    if len(lines) == 1:
        lines.append("• No populated serve, return, or rally metric is available yet.")
    return lines


def _article_profile_sentence(
    player: dict[str, Any],
    summary: dict[str, Any],
) -> str:
    """Keep a compact string helper for callers that need one profile sentence."""
    return " ".join(_article_profile_lines(player, summary))


def _article_headline(data: dict[str, Any]) -> str:
    first, second = data["first"], data["second"]
    odds = data.get("odds")
    if odds and odds.get("tournament"):
        return (
            f"{first['name']} vs. {second['name']}: "
            f"match preview for {_achievement_tournament_name(odds['tournament'])}"
        )
    return f"{first['name']} vs. {second['name']}: paths to victory"


def _article_quote(
    data: dict[str, Any], first_edges: int, second_edges: int, comparable: int
) -> str:
    generated_quote = data.get("preview_desk_quote")
    if isinstance(generated_quote, str) and generated_quote.strip():
        return f"> “{generated_quote.strip()}” — **WTSL Match Preview Desk**"
    first, second = data["first"], data["second"]
    if comparable and first_edges != second_edges:
        leader, challenger = (
            (first, second) if first_edges > second_edges else (second, first)
        )
        quote = (
            f"{leader['name']} brings the clearer statistical edge, but the "
            f"match may turn on whether {challenger['name']} can disrupt that pattern."
        )
    elif comparable:
        quote = (
            "There is little between them on paper, so the opening exchanges "
            "could set the tone for the entire contest."
        )
    else:
        quote = "With the comparison incomplete, the first player to settle could own the story."
    return f"> “{quote}” — **WTSL Match Preview Desk**"


def _article_player_quote(
    player: dict[str, Any],
    opponent: dict[str, Any],
    results: list[dict[str, Any]],
    has_h2h: bool,
    perspective: int,
) -> str:
    if has_h2h:
        if perspective == 0:
            history = (
                "We have played before, so I know how quickly the momentum can "
                "shift. The head-to-head is part of the story, not the script."
            )
        else:
            history = (
                "The previous meetings give us both clues, but I will not be "
                "relying on an old scoreline. This one will come down to today's decisions."
            )
    else:
        if perspective == 0:
            history = (
                f"There is no previous WTSL meeting between us, so the opening "
                f"games against {opponent['name']} will be about finding the right read."
            )
        else:
            history = (
                f"Without a previous WTSL meeting to draw on, I will focus on "
                f"making the first exchanges against {opponent['name']} count."
            )

    if results:
        outcomes = [_player_outcome(result, player["name"]) for result in results]
        wins = outcomes.count("W")
        losses = outcomes.count("L")
        if wins >= losses:
            if perspective == 0:
                form = (
                    "The recent run has given me confidence, but I still have "
                    "to earn every point on the day."
                )
            else:
                form = (
                    "I am taking confidence from my recent results, while knowing "
                    "that form only matters if I bring the same level from the start."
                )
        else:
            if perspective == 0:
                form = (
                    "The recent line is a reminder that I need to be sharp from "
                    "the first ball and stay in the contest."
                )
            else:
                form = (
                    "The recent results have made me determined to write a different "
                    "story in this match."
                )
    else:
        if perspective == 0:
            form = "I am focused on finding rhythm early and trusting the work I have put in."
        else:
            form = "I want to settle quickly, enjoy the occasion, and stay composed under pressure."

    if perspective == 0:
        approach = (
            "I want to start with intensity, get my feet moving, and make the "
            "opening games feel like a contest straight away."
        )
    else:
        approach = (
            "My job is to stay patient through the long games, read the court "
            "well, and take my chances when they come."
        )
    quote = f"{history} {form} {approach}"
    return f"> “{quote}” — **{player['name']}**"


def _article_player_quote_lines(data: dict[str, Any]) -> list[str]:
    first, second = data["first"], data["second"]
    generated_quotes = data.get("player_quotes")
    if (
        isinstance(generated_quotes, (list, tuple))
        and len(generated_quotes) >= 2
        and all(isinstance(quote, str) and quote.strip() for quote in generated_quotes[:2])
    ):
        sources = data.get("player_quote_sources")
        suffixes = ["", ""]
        if isinstance(sources, (list, tuple)) and len(sources) >= 2:
            suffixes = [
                " *(fictional)*"
                if str(source).startswith("Editorial copy") else ""
                for source in sources[:2]
            ]
        return [
            f"> “{generated_quotes[0].strip()}” — **{first['name']}**{suffixes[0]}",
            f"> “{generated_quotes[1].strip()}” — **{second['name']}**{suffixes[1]}",
        ]
    return [
        _article_player_quote(
            first,
            second,
            data["first_form"],
            bool(data["h2h"]),
            0,
        ),
        _article_player_quote(
            second,
            first,
            data["second_form"],
            bool(data["h2h"]),
            1,
        ),
    ]


def _article_story_lines(data: dict[str, Any]) -> list[str]:
    """Return a concise editorial opening without inventing player quotations."""
    first, second = data["first"], data["second"]
    first_summary = data["summaries"].get(normalize_name(first["name"]), {})
    second_summary = data["summaries"].get(normalize_name(second["name"]), {})
    first_edges, second_edges, comparable = _edge_counts(data)
    prediction = data.get("prediction") or calculate_prediction(data)
    odds = data.get("odds")
    h2h_first, h2h_second = data["h2h_record"]

    if odds and odds.get("tournament"):
        setup = (
            f"The {data['tour_label']} meeting is listed at "
            f"**{_achievement_tournament_name(odds['tournament'])}**, "
            f"with {first['name']} at **{odds['first']:.2f}** and "
            f"{second['name']} at **{odds['second']:.2f}**."
        )
    else:
        setup = (
            f"{first['name']} and {second['name']} bring contrasting routes to "
            "victory into this matchup, with the early exchanges likely to reveal "
            "which pattern will hold."
        )

    if data["h2h"]:
        history = (
            f"The rivalry stands at **{first['name']} {h2h_first}–{h2h_second} "
            f"{second['name']}** after {len(data['h2h'])} completed "
            f"meeting{'s' if len(data['h2h']) != 1 else ''}."
        )
    else:
        history = "There is no previous WTSL meeting to shape the rivalry."

    if comparable:
        if first_edges == second_edges:
            statistical_read = (
                f"Neither player owns a clear edge across the {comparable} "
                "comparable statistical categories."
            )
        else:
            leader = first if first_edges > second_edges else second
            statistical_read = (
                f"**{leader['name']}** leads the statistical battle "
                f"{max(first_edges, second_edges)}–{min(first_edges, second_edges)} "
                f"across {comparable} categories."
            )
    else:
        statistical_read = "The decisive pattern will have to emerge on court."

    prediction_read = (
        f"The early call leans **{prediction['favored_name']}** with "
        f"{prediction['confidence']} confidence."
    )
    return [
        f"📰 **{data['tour_label']} MATCH PREVIEW**",
        f"**{_article_headline(data)}**",
        "",
        "**The stage is set**",
        setup,
        history,
        "",
        "**The form line**",
        f"**{first['name']}:** {_article_form_sentence(first, data['first_form'])}",
        f"**{second['name']}:** {_article_form_sentence(second, data['second_form'])}",
        "",
        "**The matchup**",
        *_article_profile_lines(first, first_summary),
        "",
        *_article_profile_lines(second, second_summary),
        statistical_read,
        "",
        "**The swing factor**",
        prediction_read,
    ]


def _table_cell(value: Any, width: int) -> str:
    text = str(value).replace("\n", " ").strip()
    return text if len(text) <= width else text[: width - 1].rstrip() + "…"


def _comparison_table_lines(
    data: dict[str, Any],
    first_summary: dict[str, Any],
    second_summary: dict[str, Any],
) -> list[str]:
    first, second = data["first"], data["second"]
    metric_width, value_width, edge_width = 22, 14, 12

    def row(metric: Any, left: Any, right: Any, edge: Any) -> str:
        return (
            f"{_table_cell(metric, metric_width):<{metric_width}} "
            f"{_table_cell(left, value_width):>{value_width}} "
            f"{_table_cell(right, value_width):>{value_width}} "
            f"{_table_cell(edge, edge_width):<{edge_width}}"
        )

    lines = [
        "```text",
        row("Metric", first["name"], second["name"], "Edge"),
        row("-" * metric_width, "-" * value_width, "-" * value_width, "-" * edge_width),
    ]
    lower_is_better = {"Double Faults", "Unforced Errors"}
    for column, label in SUMMARY_METRICS:
        left = first_summary.get(column)
        right = second_summary.get(column)
        edge = "—"
        if isinstance(left, (int, float)) and isinstance(right, (int, float)):
            if left != right:
                left_wins = left < right if column in lower_is_better else left > right
                edge = first["name"] if left_wins else second["name"]
        lines.append(
            row(
                label[:1].upper() + label[1:],
                _format_value(column, left),
                _format_value(column, right),
                edge,
            )
        )
    lines.append("```")
    return lines


def format_match_preview(data: dict[str, Any]) -> str:
    first, second = data["first"], data["second"]
    first_key, second_key = normalize_name(first["name"]), normalize_name(second["name"])
    first_summary = data["summaries"].get(first_key, {})
    second_summary = data["summaries"].get(second_key, {})
    first_edges, second_edges, comparable_metrics = _edge_counts(data)
    h2h_first, h2h_second = data["h2h_record"]
    first_ratings = calculate_partial_overall_ratings(first_summary)
    second_ratings = calculate_partial_overall_ratings(second_summary)
    rating_lines = [
        f"**{label.replace(' (Overall)', ' Rating')}:** "
        f"{_format_value(label, first_ratings.get(label))} | "
        f"{_format_value(label, second_ratings.get(label))}"
        for label in ("Serve (Overall)", "Return (Overall)", "Under Pressure")
    ]

    lines = [
        *_article_story_lines(data),
        "",
        "🏆 **Rankings**",
        _ranking_line(first),
        _ranking_line(second),
        "",
        f"📅 **{datetime.now(timezone.utc).year} Season Highlights**",
        f"**{first['name']}:** "
        f"{data.get('season_summaries', {}).get(first_key, 'Not currently available')}",
        f"**{second['name']}:** "
        f"{data.get('season_summaries', {}).get(second_key, 'Not currently available')}",
        "",
        *_prediction_lines(data),
        "",
        f"⚡ **Screenshot Ratings — {first['name']} | {second['name']}**",
        *rating_lines,
        "",
        "📊 **Advanced Stats — Screenshots**",
        *_comparison_table_lines(data, first_summary, second_summary),
    ]
    missing_summaries = [
        player["name"]
        for player, summary in ((first, first_summary), (second, second_summary))
        if not summary
    ]
    if missing_summaries:
        lines.append(
            "No advanced-stat profile was found for: "
            + ", ".join(missing_summaries)
            + "."
        )
    lines += [
        "",
        "📈 **Recent form (latest five completed results)**",
    ]
    for label, player, results in (
        (first["name"], first["name"], data["first_form"]),
        (second["name"], second["name"], data["second_form"]),
    ):
        record = [_player_outcome(result, player) for result in results]
        lines.append(f"**{label}:** {' '.join(record) or 'No completed results found'}")
        lines.extend(f"• {_form_line(result, player)}" for result in results)

    lines += [
        "",
        "🤝 **Head-to-head**",
    ]
    if data["h2h"]:
        lines.append(
            f"Recorded meetings: **{first['name']} {h2h_first}–{h2h_second} "
            f"{second['name']}** ({len(data['h2h'])} completed; "
            f"{data.get('h2h_basis', 'WTSL history')})"
        )
        lines.extend(
            f"• {_form_line(result, first['name'])}" for result in data["h2h"][:5]
        )
    else:
        lines.append("No completed head-to-head meetings were found in WTSL results.")

    lines += [
        "",
        *_statistical_takeaway_lines(
            data, first_edges, second_edges, comparable_metrics
        ),
        "",
        _article_quote(data, first_edges, second_edges, comparable_metrics),
        "",
        "🧮 **Rating Formulas**",
        rating_formula_footnote("screenshots"),
        "",
        "**The players' view**",
        *_article_player_quote_lines(data),
    ]
    return "\n".join(lines)


def split_discord_message(text: str, limit: int = 1850) -> list[str]:
    """Split a preview on line boundaries without exceeding Discord's limit."""
    units: list[str] = []
    fenced_lines: list[str] = []
    in_fence = False
    for raw_line in text.splitlines():
        if raw_line.startswith("```"):
            fenced_lines.append(raw_line)
            if in_fence:
                units.append("\n".join(fenced_lines))
                fenced_lines = []
            in_fence = not in_fence
        elif in_fence:
            fenced_lines.append(raw_line)
        else:
            units.append(raw_line)
    if fenced_lines:
        units.extend(fenced_lines)

    chunks: list[str] = []
    current: list[str] = []
    current_length = 0
    for raw_line in units:
        parts = [
            raw_line[index:index + limit]
            for index in range(0, max(len(raw_line), 1), limit)
        ]
        for part in parts:
            added = len(part) + (1 if current else 0)
            if current and current_length + added > limit:
                chunks.append("\n".join(current))
                current = [part]
                current_length = len(part)
            else:
                current.append(part)
                current_length += added
    if current:
        chunks.append("\n".join(current))
    return chunks
