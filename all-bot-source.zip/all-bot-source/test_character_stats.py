import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from openpyxl import Workbook

from character_stats import (
    attribute_names,
    attribute_ranking,
    character_profile,
    compare_characters,
    load_roster,
    recommend_characters,
    resolve_character,
    EXPECTED_ATTRIBUTE_HEADERS,
    ATTRIBUTE_MECHANICS,
    TECHNICAL_SKILL_INTERACTIONS,
    _validate_workbook,
    _canonical_name,
    calculate_combined_skill_rating,
    calculate_max_serve_speed,
    current_workbook_path,
    install_workbook,
)


class CharacterStatsTests(unittest.TestCase):
    def test_latest_workbook_matches_a_to_aq_schema(self):
        summary = _validate_workbook(current_workbook_path())
        self.assertEqual(summary["columns"], 43)
        self.assertEqual(summary["characters"], 155)

    def test_invalid_workbook_does_not_replace_installed_roster(self):
        workbook = Workbook()
        worksheet = workbook.active
        worksheet.append(["name", "Sex (0: male; 1: female)"])
        worksheet.append(["", 0])
        data = io.BytesIO()
        workbook.save(data)
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "roster.xlsx"
            target.write_bytes(b"known-good-roster")
            with patch(
                "character_stats.canonical_workbook_path",
                return_value=target,
            ):
                with self.assertRaisesRegex(ValueError, "complete character schema"):
                    install_workbook(data.getvalue())
            self.assertEqual(target.read_bytes(), b"known-good-roster")

    def test_schema_rejects_named_rows_with_invalid_values(self):
        workbook = Workbook()
        worksheet = workbook.active
        worksheet.append(EXPECTED_ATTRIBUTE_HEADERS)
        row = ["Test Player", 7, 180, 75, "GB", 1, 1, 0, 12, "Mystery"]
        worksheet.append(row + [50] * (43 - len(row)))
        with tempfile.NamedTemporaryFile(suffix=".xlsx") as temporary:
            workbook.save(temporary.name)
            with self.assertRaisesRegex(ValueError, "invalid sex value"):
                _validate_workbook(Path(temporary.name))

    def test_versions_collapse_and_mental_columns_are_excluded(self):
        roster = load_roster()
        self.assertEqual(len(roster), 155)
        self.assertEqual(
            resolve_character("Alexander Zverev v3")["_canonical"],
            "Alexander Zverev",
        )
        self.assertNotIn("Short Term Form", attribute_names())
        self.assertNotIn("Skills Average", attribute_names())
        self.assertNotIn("AnimVictoryGreat", attribute_names())
        self.assertIn("Topspin", attribute_names())
        self.assertNotIn("Points Left", attribute_names())

    def test_attribute_ranking_reports_roster_range(self):
        ranking = attribute_ranking("Forehand Power", "atp")
        self.assertEqual(ranking["count"], 102)
        self.assertLessEqual(ranking["minimum"], ranking["maximum"])
        self.assertEqual(ranking["ranked"][0]["rank"], 1)
        self.assertLessEqual(ranking["ranked"][-1]["rank"], ranking["count"])

    def test_attribute_ranking_gives_equal_values_the_same_rank(self):
        ranking = attribute_ranking("Height", "atp")
        values = {}
        for item in ranking["ranked"]:
            values.setdefault(item["value"], []).append(item["rank"])
        tied_values = [
            ranks for ranks in values.values()
            if len(ranks) > 1
        ]
        self.assertTrue(tied_values)
        self.assertTrue(all(len(set(ranks)) == 1 for ranks in tied_values))

    def test_legacy_clay_mover_name_is_normalized(self):
        self.assertEqual(
            _canonical_name("Clay Mover Old"),
            "Clay Mover",
        )
        self.assertIn("Clay Mover", attribute_names())
        self.assertNotIn("Clay Mover Old", attribute_names())

    def test_pick_counts_merge_initials_and_full_names(self):
        results = [
            {
                "tour": "atp",
                "p1": "J. Sinner",
                "p1_character": "A. Zverev",
            },
            {
                "tour": "atp",
                "p1": "Jannik Sinner",
                "p1_character": "Alexander Zverev",
            },
            {
                "tour": "atp",
                "p2": "A. Player",
                "p2_character": "Alexander Zverev",
            },
        ]
        profile = character_profile("Alexander Zverev v2", "atp", results)
        self.assertEqual(profile["pick_count"], 3)
        self.assertEqual(profile["top_pickers"][0], ("J. Sinner", 2))

    def test_profile_has_roster_selection_guidance(self):
        profile = character_profile("Roger Federer", "atp")
        guidance = profile["selection_guidance"]
        self.assertTrue(guidance["top_edges"])
        self.assertTrue(guidance["benefit"])
        self.assertTrue(guidance["tradeoff"])
        self.assertTrue(guidance["why_select"])
        self.assertTrue(guidance["why_not_select"])
        self.assertTrue(guidance["game_plan"])
        self.assertTrue(guidance["best_for"])
        self.assertTrue(guidance["acceleration_mechanics"])
        self.assertNotEqual(guidance["strongest_group"], "Overall")

    def test_profile_guidance_turns_mechanics_into_distinct_point_insights(self):
        federer = character_profile("Roger Federer", "atp")
        nadal = character_profile("Rafael Nadal", "atp")
        federer_mechanics = federer["mechanics_insights"]
        nadal_mechanics = nadal["mechanics_insights"]
        for key in (
            "serve",
            "groundstrokes",
            "surface_fit",
            "counter",
            "net",
        ):
            self.assertTrue(federer_mechanics[key])
        self.assertIn(
            "touch",
            federer["selection_guidance"]["why_select"],
        )
        self.assertIn("clay", nadal_mechanics["surface_fit"].casefold())
        self.assertNotEqual(
            federer_mechanics["surface_fit"],
            nadal_mechanics["surface_fit"],
        )
        self.assertIn("km/h", federer_mechanics["serve"])

    def test_selection_advice_is_character_specific_and_tennis_focused(self):
        federer = character_profile("Roger Federer", "atp")["selection_guidance"]
        alcaraz = character_profile("Carlos Alcaraz", "atp")["selection_guidance"]
        self.assertNotEqual(federer["why_select"], alcaraz["why_select"])
        self.assertNotEqual(
            federer["why_not_select"],
            alcaraz["why_not_select"],
        )
        for guidance in (federer, alcaraz):
            for key in ("why_select", "why_not_select", "game_plan"):
                text = guidance[key].casefold()
                self.assertNotIn("simulated", text)
                self.assertNotIn("second phase", text)
            self.assertTrue(
                any(
                    word in guidance["why_select"].casefold()
                    for word in ("serve", "court", "ball", "rally", "net")
                )
            )
            self.assertNotIn("first pattern", guidance["why_select"].casefold())
            self.assertNotIn("service consistency", guidance["why_not_select"].casefold())
            self.assertNotIn("protect the weaker", guidance["why_not_select"].casefold())

    def test_power_is_not_the_main_driver_of_technical_ratings(self):
        baseline = calculate_combined_skill_rating(50, 70, 70)
        more_power = calculate_combined_skill_rating(80, 70, 70)
        more_control = calculate_combined_skill_rating(50, 90, 70)
        self.assertLess(
            more_power["value"] - baseline["value"],
            more_control["value"] - baseline["value"],
        )

    def test_combined_rating_respects_precision_power_interaction(self):
        equal_low = calculate_combined_skill_rating(20, 20, 20)
        equal_high = calculate_combined_skill_rating(40, 40, 40)
        underpowered_precision = calculate_combined_skill_rating(80, 80, 40)
        overpowered_precision = calculate_combined_skill_rating(80, 80, 100)
        self.assertEqual(
            equal_low["precision_effect"],
            equal_high["precision_effect"],
        )
        self.assertLess(
            underpowered_precision["precision_effect"],
            100,
        )
        self.assertGreater(
            overpowered_precision["precision_effect"],
            100,
        )
        self.assertLess(
            underpowered_precision["value"],
            overpowered_precision["value"],
        )
        mismatched_serve = calculate_combined_skill_rating(
            90, 30, 90, service=True
        )
        balanced_serve = calculate_combined_skill_rating(
            60, 60, 60, service=True
        )
        self.assertLess(
            mismatched_serve["value"],
            balanced_serve["value"],
        )
        self.assertEqual(calculate_max_serve_speed(0, "ATP"), 102)
        self.assertEqual(calculate_max_serve_speed(100, "ATP"), 204)
        self.assertEqual(calculate_max_serve_speed(50, "WTA"), 133)

    def test_profile_includes_combined_serve_and_groundstroke_ratings(self):
        profile = character_profile("Roger Federer", "atp")
        ratings = {
            item["attribute"]: item for item in profile["combined_ratings"]
        }
        self.assertEqual(
            set(ratings),
            {"Serve Rating", "Forehand Rating", "Backhand Rating"},
        )
        self.assertTrue(all(item["count"] > 1 for item in ratings.values()))
        self.assertTrue(all("Precision effect" in item["components"] for item in ratings.values()))
        self.assertTrue(
            all(
                item["simulation"]["average_rally_length"] > 0
                and item["simulation"]["winners_per_100"] > 0
                for item in ratings.values()
            )
        )
        self.assertGreater(ratings["Serve Rating"]["max_serve_speed_kmh"], 102)

    def test_simulated_ratings_are_roster_wide_and_not_balance_penalties(self):
        alcaraz = character_profile("Carlos Alcaraz", "atp")
        sinner = character_profile("Jannik Sinner", "atp")
        self.assertEqual(alcaraz["country_flag"], "🇪🇸")
        self.assertEqual(sinner["country_flag"], "🇮🇹")
        for profile in (alcaraz, sinner):
            ratings = {
                item["attribute"]: item for item in profile["combined_ratings"]
            }
            self.assertEqual(
                {item["count"] for item in ratings.values()},
                {profile["roster_count"]},
            )
            self.assertTrue(
                all(
                    item["simulation"]["forehand_winners_per_100"] > 0
                    and item["simulation"]["backhand_winners_per_100"] > 0
                    for item in ratings.values()
                )
            )
        self.assertLess(
            sinner["combined_ratings"][2]["value"],
            100,
        )

    def test_contextual_technical_skill_guidance_matches_documentation(self):
        self.assertIn("50% is neutral", ATTRIBUTE_MECHANICS["Topspin"])
        self.assertIn("does not add raw power", ATTRIBUTE_MECHANICS["Net Presence"])
        self.assertIn(
            "combining with Net Presence",
            ATTRIBUTE_MECHANICS["Forehand Volley"],
        )
        self.assertIn(
            "combining with Net Presence",
            ATTRIBUTE_MECHANICS["Smash"],
        )
        self.assertIn("7.5 km/h", ATTRIBUTE_MECHANICS["Counter"])
        self.assertIn("slow incoming balls", ATTRIBUTE_MECHANICS["Counter"])
        self.assertIn("forehand or backhand skill", ATTRIBUTE_MECHANICS["Lob"])
        self.assertIn("Speed and Muscle Tone", ATTRIBUTE_MECHANICS["Focus"])
        self.assertIn("from 1 to 5", ATTRIBUTE_MECHANICS["Stamina"])
        interaction_labels = {label for label, _ in TECHNICAL_SKILL_INTERACTIONS}
        self.assertEqual(
            interaction_labels,
            {
                "Serve",
                "Forehand / Backhand",
                "Topspin",
                "Counter",
                "Volley / Smash",
                "Lob / Drop Shot",
            },
        )

    def test_character_comparison_explains_distinctive_edges(self):
        comparison = compare_characters("Roger Federer", "Rafael Nadal", "atp")
        self.assertEqual(comparison["first"], "Roger Federer")
        self.assertEqual(comparison["second"], "Rafael Nadal")
        self.assertTrue(comparison["first_edges"])
        self.assertTrue(comparison["second_edges"])
        combined_guidance = " ".join([
            comparison["first_guidance"]["why_select"],
            comparison["first_guidance"]["style_mechanics"],
            comparison["second_guidance"]["why_select"],
            comparison["second_guidance"]["style_mechanics"],
        ])
        self.assertNotIn("This unknown", combined_guidance)
        self.assertNotIn(
            "No documented style mechanic",
            combined_guidance,
        )
        self.assertIn("all-rounder", combined_guidance.casefold())
        self.assertIn("bulldog", combined_guidance.casefold())
        tactical_text = " ".join(
            comparison["first_mechanics"] + comparison["second_mechanics"]
        )
        self.assertTrue(tactical_text)
        self.assertIn("court", tactical_text)

    def test_recommendations_use_strength_development_and_training_focus(self):
        summary = {
            "relative_profile": {
                "serve": {
                    "percentile": 90,
                    "metrics": [{"metric": "Aces", "percentile": 90}],
                },
                "return": {
                    "percentile": 25,
                    "metrics": [
                        {
                            "metric": "Return Points Won %",
                            "percentile": 25,
                        }
                    ],
                },
                "rally": {
                    "percentile": 55,
                    "metrics": [
                        {
                            "metric": "Long Rallies Won (>8) %",
                            "percentile": 55,
                        }
                    ],
                },
            }
        }
        insights = {
            "strength_group": "serve",
            "development_group": "return",
            "training_group": "return",
            "focus": "Improve return pressure.",
        }
        recommendations = recommend_characters(summary, insights, "atp")
        self.assertEqual(len(recommendations), 3)
        self.assertTrue(recommendations[0]["edge_attributes"])
        self.assertEqual(recommendations[0]["strength_group"], "serve")
        self.assertEqual(recommendations[0]["development_group"], "return")
        self.assertTrue(recommendations[0]["tradeoff"])
        self.assertTrue(all(item["mechanics_score"] for item in recommendations))
        self.assertTrue(all(item["mechanics_reason"] for item in recommendations))
        self.assertTrue(all(item["development_route"] for item in recommendations))
        self.assertGreater(
            len({item["mechanics_reason"] for item in recommendations}),
            1,
        )
        self.assertTrue(
            any(
                "Counter" in item["development_route"]
                for item in recommendations
            )
        )


if __name__ == "__main__":
    unittest.main()