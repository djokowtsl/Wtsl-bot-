"""Parse, verify, and persist official TE4 MatchLog submissions."""
from __future__ import annotations

import hashlib
import html
import csv
import io
import re
import unicodedata
from collections import defaultdict
from copy import copy, deepcopy
from datetime import date, datetime, timedelta
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

from bs4 import BeautifulSoup
from openpyxl import load_workbook
from overall_ratings import (
    OVERALL_RATING_COLUMNS,
    calculate_atp_available_ratings,
    calculate_relative_profiles,
    rating_formula_footnote,
)
from wtsl_results import (
    is_exhibition_tournament,
    is_nonroutine_matchlog_tournament,
    parse_all_results_html,
    split_player_character,
    tournament_category,
)


ALL_RESULTS_URL = "https://playwtsl.com/TE4/pages/all_results_fetch.php"
RAW_SHEETS = {"atp": "MatchLog ATP", "wta": "MatchLog WTA"}
SUMMARY_SHEETS = {
    "atp": "MatchLog ATP Summary",
    "wta": "MatchLog WTA Summary",
}
IDENTITY_SHEET = "MatchLog Identities"
STATS = {
    "first_serve_pct": "1st Serve %",
    "aces": "Aces",
    "double_faults": "Double Faults",
    "fastest_serve": "Fastest Serve",
    "avg_first_serve_speed": "Avg 1st Serve Speed",
    "avg_second_serve_speed": "Avg 2nd Serve Speed",
    "winners": "Winners",
    "forced_errors": "Forced Errors",
    "unforced_errors": "Unforced Errors",
    "net_points_won_pct": "Net Points Won %",
    "break_points_won_pct": "Break Points Won %",
    "total_points_won": "Total Points Won",
    "short_rallies_won_pct": "Short Rallies Won (<5) %",
    "medium_rallies_won_pct": "Medium Rallies Won (5-8) %",
    "long_rallies_won_pct": "Long Rallies Won (>8) %",
    "average_rally_length": "Average Rally Length",
    "set_points_saved": "Set Points Saved",
    "match_points_saved": "Match Points Saved",
    "first_serve_won_pct": "1st Serve Won %",
    "second_serve_won_pct": "2nd Serve Won %",
    "return_points_won_pct": "Return Points Won %",
    "return_winners": "Return Winners",
    "breaks_games_pct": "Breaks / Games %",
}
DERIVED_STATS = {
    "first_serve_return_won_pct": "1st Serve Return Points Won %",
    "second_serve_return_won_pct": "2nd Serve Return Points Won %",
    "break_points_saved_pct": "Break Points Saved %",
    "tiebreaks_won_pct": "Tie-breaks Won %",
    "deciding_sets_won_pct": "Deciding Sets Won %",
}
SUMMARY_STATS = {**STATS, **DERIVED_STATS}
RATING_COMPONENT_LABELS = frozenset(DERIVED_STATS.values())
SPEEDS = (
    "fastest_serve",
    "avg_first_serve_speed",
    "avg_second_serve_speed",
)
SPEED_LABELS = frozenset(STATS[key] for key in SPEEDS)
META_COLUMNS = [
    "match_id", "match_datetime", "date", "time", "tournament", "duration",
    "online", "player", "player_crc", "player_elo", "player_elo_change",
    "result", "opponent", "opponent_crc", "opponent_elo",
    "opponent_elo_change",
]
SPEED_COLUMNS = [
    value
    for key in SPEEDS
    for value in (
        f"{key}_raw", f"{key}_unit", f"{key}_mph", f"{key}_kph"
    )
]
BREAK_POINT_COLUMNS = ["break_points_won", "break_point_opportunities"]
SOURCE_COLUMNS = [
    "discord_message_id", "discord_attachment_id", "submitter_id",
    "source_sha256", "source_file", "parse_warning",
]
RAW_COLUMNS = [
    *META_COLUMNS, *STATS, *BREAK_POINT_COLUMNS, *SPEED_COLUMNS, *SOURCE_COLUMNS,
    "character", "opponent_character",
]
UPLOAD_COLUMNS = [
    "pl_stats_pl_ID", "pl_name", "pl_first_serve_perc", "pl_aces",
    "pl_double_faults", "pl_first_serve_speed", "pl_second_serve_speed",
    "pl_net_points", "pl_winners", "pl_forced_errors",
    "pl_unforced_errors", "pl_breakpoint_conversion",
    "pl_short_rallies_won", "pl_medium_rallies_won",
    "pl_long_rallies_won", "pl_first_serve_points_won",
    "pl_second_serve_points_won", "pl_return_points_won",
    "pl_rally_length", "pl_tour",
]
UPLOAD_METRICS = {
    "pl_first_serve_perc": "1st Serve %",
    "pl_aces": "Aces",
    "pl_double_faults": "Double Faults",
    "pl_first_serve_speed": "Avg 1st Serve Speed",
    "pl_second_serve_speed": "Avg 2nd Serve Speed",
    "pl_net_points": "Net Points Won %",
    "pl_winners": "Winners",
    "pl_forced_errors": "Forced Errors",
    "pl_unforced_errors": "Unforced Errors",
    "pl_breakpoint_conversion": "Break Points Won %",
    "pl_short_rallies_won": "Short Rallies Won (<5) %",
    "pl_medium_rallies_won": "Medium Rallies Won (5-8) %",
    "pl_long_rallies_won": "Long Rallies Won (>8) %",
    "pl_first_serve_points_won": "1st Serve Won %",
    "pl_second_serve_points_won": "2nd Serve Won %",
    "pl_return_points_won": "Return Points Won %",
    "pl_rally_length": "Average Rally Length",
}
UPLOAD_PERCENT_COLUMNS = {
    "pl_first_serve_perc", "pl_net_points", "pl_breakpoint_conversion",
    "pl_short_rallies_won", "pl_medium_rallies_won",
    "pl_long_rallies_won", "pl_first_serve_points_won",
    "pl_second_serve_points_won", "pl_return_points_won",
}


MATCHLOG_NAME_ALIASES = {
    "ruze": "itsruze",
    "squeaky94": "squeaky",
}


def normalize_name(value: Any) -> str:
    decomposed = unicodedata.normalize("NFKD", str(value or ""))
    plain = "".join(
        char for char in decomposed
        if unicodedata.category(char) not in {"Mn", "So", "Sk"}
        and char not in {"\u200d", "\ufe0f"}
    )
    normalized = re.sub(r"\s+", " ", plain).strip().casefold()
    return MATCHLOG_NAME_ALIASES.get(normalized, normalized)


def _clean(value: Any) -> str:
    return re.sub(
        r"\s+", " ", html.unescape(str(value or "")).replace("\xa0", " ")
    ).strip()


def _number(value: Any) -> int | float | None:
    match = re.search(r"-?\d+(?:[.,]\d+)?", str(value or "").replace(",", "."))
    if not match:
        return None
    number = float(match.group())
    return int(number) if number.is_integer() else number


def _date_time(text: str) -> str | None:
    patterns = (
        r"\b(20\d{2}[-/]\d{1,2}[-/]\d{1,2}[ T]\d{1,2}:\d{2}(?::\d{2})?)\b",
        r"\b(\d{1,2}[-/]\d{1,2}[-/]20\d{2}[ T]\d{1,2}:\d{2}(?::\d{2})?)\b",
    )
    for pattern in patterns:
        match = re.search(pattern, text)
        if not match:
            continue
        raw = match.group(1).replace("/", "-")
        for fmt in (
            "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
            "%d-%m-%Y %H:%M:%S", "%d-%m-%Y %H:%M",
        ):
            try:
                return datetime.strptime(raw, fmt).strftime("%Y-%m-%d %H:%M:%S")
            except ValueError:
                pass
    return None


def _first(text: str, patterns: tuple[str, ...]) -> str | None:
    for pattern in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            return _clean(match.group(1))
    return None


def _after(rows: list[list[str]], label: str) -> str | None:
    wanted = label.casefold()
    for row in rows:
        for index, cell in enumerate(row):
            cleaned = _clean(cell)
            if cleaned.casefold() == wanted:
                return row[index + 1] if index + 1 < len(row) else None
            if cleaned.casefold().startswith(wanted):
                rest = cleaned[len(label):].lstrip(" :\t")
                return rest or (
                    row[index + 1] if index + 1 < len(row) else None
                )
    return None


def _match_id(
    match_datetime: str | None,
    first: str,
    second: str,
    tournament: str | None,
) -> str:
    names = sorted((normalize_name(first), normalize_name(second)))
    raw = "|".join([match_datetime or "NO_DATETIME", *names])
    if not match_datetime:
        raw += "|" + normalize_name(tournament)
    return hashlib.sha256(raw.encode("utf8")).hexdigest()


def _history_player(value: str) -> dict[str, Any]:
    crc = _first(value, (r"\bCrc\s*=\s*(\d+)",))
    elo = _number(_first(value, (r"\bELO\s*:\s*(-?\d+(?:\.\d+)?)",)))
    change = _number(_first(
        value, (r"\bELO\s*:\s*-?\d+(?:\.\d+)?\s+([+-]\d+|0)",)
    ))
    fake_player = bool(re.match(r"^\[Fake\]\s*", value, flags=re.I))
    name = re.sub(r"^\[Fake\]\s*", "", value, flags=re.I)
    name = re.sub(r"\s*\([^)]*\)\)*\s*$", "", name).strip()
    name = re.sub(r"^\(\d+\)\s*", "", name).strip()
    if fake_player:
        name = re.sub(r"\d+$", "", name).strip()
    return {"name": name, "crc": crc, "elo": elo, "elo_change": change}


def _history_stat_value(value: str, percentage: bool) -> int | float | None:
    if percentage:
        match = re.search(r"(-?\d+(?:[.,]\d+)?)\s*%", value)
        return float(match.group(1).replace(",", ".")) / 100 if match else None
    return _number(value)


def _history_label(value: str) -> str:
    normalized = normalize_name(value).replace("%", "")
    normalized = re.sub(r"\s*([<>])\s*", r"\1", normalized)
    return normalized.rstrip(": ")


def _parse_history_html(source: str, source_file: str) -> list[dict[str, Any]]:
    soup = BeautifulSoup(source, "html.parser")
    labels = {
        _history_label(label): key for key, label in STATS.items()
    }
    matches = []
    for table in soup.find_all("table"):
        paragraph = table.find_previous_sibling("p")
        title = _clean(paragraph.get_text(" ", strip=True) if paragraph else "")
        if " def. " not in title or " : " not in title:
            continue
        try:
            match_text, tournament, duration, date_text = title.rsplit(" - ", 3)
            winner_text, loser_and_score = match_text.split(" def. ", 1)
            loser_text, score = loser_and_score.rsplit(" : ", 1)
        except ValueError:
            continue
        if "&" in winner_text or "&" in loser_text:
            continue
        winner = _history_player(winner_text)
        loser = _history_player(loser_text)
        if not winner["name"] or not loser["name"]:
            continue
        match_datetime = _date_time(date_text)
        winner_score = re.sub(r"(?<=\d)/(?=\d)", "-", score)
        loser_score = re.sub(
            r"(\d+)\s*/\s*(\d+)",
            lambda match: f"{match.group(2)}-{match.group(1)}",
            score,
        )
        side_stats = [{}, {}]
        warning = ""
        for tr in table.find_all("tr"):
            cells = [_clean(cell.get_text(" ", strip=True)) for cell in tr.find_all("td")]
            for index, cell in enumerate(cells):
                label = _history_label(cell)
                if label.startswith("average rally length"):
                    value = _number(cell)
                    side_stats[0]["average_rally_length"] = value
                    side_stats[1]["average_rally_length"] = value
                    continue
                key = labels.get(label)
                if key is None or index == 0 or index + 1 >= len(cells):
                    continue
                percentage = key.endswith("_pct")
                for side_index, value_index in ((0, index - 1), (1, index + 1)):
                    raw_value = cells[value_index]
                    value = _history_stat_value(raw_value, percentage)
                    ratio = (
                        re.search(r"(\d+)\s*/\s*(\d+)", raw_value)
                        if key == "break_points_won_pct" else None
                    )
                    if ratio:
                        won, opportunities = map(int, ratio.groups())
                        value = (
                            won / opportunities
                            if opportunities > 0 else None
                        )
                    side_stats[side_index][key] = value
                    if key == "break_points_won_pct":
                        if ratio:
                            side_stats[side_index]["break_points_won"] = int(
                                ratio.group(1)
                            )
                            side_stats[side_index][
                                "break_point_opportunities"
                            ] = int(ratio.group(2))
                    if key in SPEEDS:
                        unit = (
                            "kph" if re.search(r"\b(?:km/h|kmh|kph)\b", raw_value, re.I)
                            else "mph" if re.search(r"\bmph\b", raw_value, re.I)
                            else None
                        )
                        side_stats[side_index][f"{key}_raw"] = value
                        side_stats[side_index][f"{key}_unit"] = unit
                        side_stats[side_index][f"{key}_mph"] = (
                            value if unit == "mph"
                            else round(float(value) / 1.609344, 1)
                            if value is not None and unit == "kph" else None
                        )
                        side_stats[side_index][f"{key}_kph"] = (
                            value if unit == "kph"
                            else round(float(value) * 1.609344, 1)
                            if value is not None and unit == "mph" else None
                        )
                        if side_stats[side_index][f"{key}_kph"] is not None:
                            side_stats[side_index][key] = side_stats[
                                side_index
                            ][f"{key}_kph"]
                        if value is not None and unit is None:
                            warning = "Speed unit not detected; raw speed preserved."
        match_id = _match_id(
            match_datetime, winner["name"], loser["name"], tournament
        )
        rows = []
        for player, opponent, result, stats in (
            (winner, loser, winner_score, side_stats[0]),
            (loser, winner, loser_score, side_stats[1]),
        ):
            rows.append({
                "match_id": match_id,
                "match_datetime": match_datetime,
                "tournament": tournament,
                "duration": duration.split(" ", 1)[0],
                "online": "Yes" if "[Online]" in title else "No",
                "player": player["name"],
                "player_crc": player["crc"],
                "player_elo": player["elo"],
                "player_elo_change": player["elo_change"],
                "result": result,
                "opponent": opponent["name"],
                "opponent_crc": opponent["crc"],
                "opponent_elo": opponent["elo"],
                "opponent_elo_change": opponent["elo_change"],
                **stats,
                "source_file": source_file,
                "parse_warning": warning,
            })
        matches.append({"match_id": match_id, "rows": rows})
    if not matches:
        raise ValueError("No two-player match history was found in the HTML file")
    return matches


def parse_matchlog_html(raw: bytes, source_file: str) -> list[dict[str, Any]]:
    """Return complete two-sided matches from a TE4 MatchLog HTML file."""
    source = raw.decode("utf8", errors="replace")
    if (
        "Tennis Elbow - Match Log" in source
        and re.search(r"\sdef\.\s", source, re.I)
    ):
        return _exclude_nonroutine_matchlog_events(
            _parse_history_html(source, source_file)
        )
    parsed_sides: list[dict[str, Any]] = []
    for table in re.findall(r"<table\b[^>]*>(.*?)</table\s*>", source, re.I | re.S):
        rows = []
        for row_html in re.findall(r"<tr\b[^>]*>(.*?)</tr\s*>", table, re.I | re.S):
            cells = re.findall(
                r"<(?:td|th)\b[^>]*>(.*?)</(?:td|th)\s*>",
                row_html,
                re.I | re.S,
            )
            if cells:
                rows.append([
                    _clean(re.sub(
                        r"<[^>]+>", " ",
                        re.sub(r"<br\s*/?>", " ", cell, flags=re.I),
                    ))
                    for cell in cells
                ])
        text = " | ".join(cell for row in rows for cell in row)
        if not any(label.casefold() in text.casefold() for label in (
            "Aces", "Winners", "Unforced Errors"
        )):
            continue
        player = _first(text, (r"(?:Player|Name)\s*:\s*([^|]+)",))
        opponent = _first(text, (r"Opponent\s*:\s*([^|]+)",))
        if not player or not opponent:
            continue
        match_datetime = _date_time(text)
        tournament = _first(
            text, (r"(?:Tournament|Event)\s*:\s*([^|]+)",)
        )
        speed_unit = (
            "kph" if re.search(r"\b(?:km/h|kph|kmh)\b", text, re.I)
            else "mph" if re.search(r"\b(?:mph|mi/h)\b", text, re.I)
            else None
        )
        stats: dict[str, Any] = {}
        warning = ""
        for key, label in STATS.items():
            raw_value = _after(rows, label)
            value = _number(raw_value)
            if key.endswith("_pct") and value is not None and value > 1:
                value /= 100
            if key == "break_points_won_pct":
                ratio = re.search(r"(\d+)\s*/\s*(\d+)", raw_value or "")
                if ratio:
                    won, opportunities = map(int, ratio.groups())
                    stats["break_points_won"] = won
                    stats["break_point_opportunities"] = opportunities
                    value = won / opportunities if opportunities > 0 else None
            stats[key] = value
        for key in SPEEDS:
            value = stats.get(key)
            stats[f"{key}_raw"] = value
            stats[f"{key}_unit"] = speed_unit
            stats[f"{key}_mph"] = (
                value if speed_unit == "mph"
                else round(float(value) / 1.609344, 1)
                if value is not None and speed_unit == "kph" else None
            )
            stats[f"{key}_kph"] = (
                value if speed_unit == "kph"
                else round(float(value) * 1.609344, 1)
                if value is not None and speed_unit == "mph" else None
            )
            if stats[f"{key}_kph"] is not None:
                # Keep the main metric canonical in km/h. The original value
                # and unit remain available in the *_raw and *_unit columns.
                stats[key] = stats[f"{key}_kph"]
            if value is not None and speed_unit is None:
                warning = "Speed unit not detected; raw speed preserved."
        parsed_sides.append({
            "match_id": _match_id(
                match_datetime, player, opponent, tournament
            ),
            "match_datetime": match_datetime,
            "tournament": tournament,
            "duration": _first(
                text,
                (r"(?:Duration|Match Duration)\s*:\s*([0-9:]+(?:\s*(?:min|minutes|h|hours))?)",),
            ),
            "online": _first(
                text, (r"\bOnline\s*:\s*(Yes|No|True|False|1|0)",)
            ),
            "player": player,
            "player_crc": _first(
                text, (r"(?:Player\s*)?CRC\s*:\s*(\d+)", r"\bCrc\s+(\d+)\b")
            ),
            "player_elo": _number(_first(
                text, (r"(?:Player|Name)[^|]*ELO\s*:\s*(-?\d+(?:\.\d+)?)",)
            )),
            "player_elo_change": _number(_first(
                text, (r"(?:Player|Name)[^|]*ELO[^|]*?([+-]\d+)",)
            )),
            "result": _first(text, (r"(?:Result|Score)\s*:\s*([^|]+)",)),
            "opponent": opponent,
            **stats,
            "source_file": source_file,
            "parse_warning": warning,
        })
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for side in parsed_sides:
        if not any(
            normalize_name(existing["player"]) == normalize_name(side["player"])
            for existing in grouped[side["match_id"]]
        ):
            grouped[side["match_id"]].append(side)
    matches = []
    for match_id, sides in grouped.items():
        if len(sides) != 2:
            continue
        for side, opponent in ((sides[0], sides[1]), (sides[1], sides[0])):
            side["opponent"] = opponent["player"]
            side["opponent_crc"] = opponent.get("player_crc")
            side["opponent_elo"] = opponent.get("player_elo")
            side["opponent_elo_change"] = opponent.get("player_elo_change")
        matches.append({"match_id": match_id, "rows": sides})
    if not matches:
        raise ValueError("No complete two-player match was found in the HTML file")
    return _exclude_nonroutine_matchlog_events(matches)


def _exclude_nonroutine_matchlog_events(
    matches: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Exclude team and exhibition rows before individual verification."""
    eligible = [
        match
        for match in matches
        if not is_nonroutine_matchlog_tournament(
            (match.get("rows") or [{}])[0].get("tournament")
        )
    ]
    if matches and not eligible:
        raise ValueError(
            "MatchLog contains only Davis Cup, Laver Cup, or exhibition events; "
            "these are excluded from individual MatchLog verification."
        )
    return eligible


def parse_official_results(page: str) -> list[dict[str, str]]:
    parsed = parse_all_results_html(page)
    if parsed:
        return parsed
    # Legacy fixture/page compatibility.
    soup = BeautifulSoup(page, "html.parser")
    result = []
    for table in soup.find_all("table"):
        headers = [cell.get_text(" ", strip=True) for cell in table.find_all("th")]
        normalized = [normalize_name(header) for header in headers]
        p1_index = next((i for i, h in enumerate(normalized) if h.startswith("player 1")), None)
        p2_index = next((i for i, h in enumerate(normalized) if h.startswith("player 2")), None)
        if p1_index is None or p2_index is None or "date" not in normalized or "result" not in normalized:
            continue
        for row in table.find_all("tr"):
            cells = [cell.get_text(" ", strip=True) for cell in row.find_all("td")]
            if len(cells) < len(headers):
                continue
            offset = len(cells) - len(headers)
            p1, p1_char = split_player_character(cells[p1_index + offset])
            p2, p2_char = split_player_character(cells[p2_index + offset])
            tournament = cells[normalized.index("tournament") + offset]
            result.append({
                "player1": p1, "player2": p2,
                "player1_character": p1_char, "player2_character": p2_char,
                "date": cells[normalized.index("date") + offset],
                "result": cells[normalized.index("result") + offset],
                "tournament": tournament,
                "tour": "wta" if "wta" in tournament.casefold() else "atp",
            })
    return result


def _score_signature(value: Any) -> tuple[tuple[int, int], ...]:
    return tuple(
        (int(first), int(second))
        for first, second in re.findall(r"(\d+)\s*-\s*(\d+)", str(value or ""))
    )


def _score_equivalence_key(
    score: tuple[tuple[int, int], ...],
) -> tuple[tuple[int, int], ...]:
    """Return one key for a score regardless of which player is listed first."""
    reversed_score = tuple((second, first) for first, second in score)
    return min(score, reversed_score)


def _score_matches(rows: list[dict[str, Any]], official: dict[str, str]) -> bool | None:
    official_score = _score_signature(official.get("result"))
    if not official_score:
        return None
    first_player = normalize_name(official.get("player1"))
    submitted = next(
        (
            _score_signature(row.get("result"))
            for row in rows
            if normalize_name(row.get("player")) == first_player
            and _score_signature(row.get("result"))
        ),
        (),
    )
    if not submitted:
        submitted = next(
            (
                _score_signature(row.get("result"))
                for row in rows if _score_signature(row.get("result"))
            ),
            (),
        )
        if submitted:
            reversed_score = tuple((second, first) for first, second in submitted)
            return submitted == official_score or reversed_score == official_score
        return None
    return submitted == official_score


def _short_set_score(value: Any) -> bool:
    score = _score_signature(value)
    return (
        len(score) >= 2
        and all(max(first, second) <= 5 for first, second in score)
        and any(max(first, second) == 4 for first, second in score)
    )


def _is_next_gen_finals(value: Any) -> bool:
    text = normalize_name(value)
    return "next gen" in text and "final" in text


def _matchlog_record_is_exhibition(
    tournament: Any,
    result: Any,
    category: Any = None,
) -> bool:
    return (
        is_exhibition_tournament(tournament, category)
        or (
            _short_set_score(result)
            and not _is_next_gen_finals(tournament)
        )
    )


def _matchlog_event_identity(value: Any) -> tuple[str, str]:
    """Normalize event labels while preserving explicit ground identifiers."""
    text = normalize_name(value)
    ground = re.search(r"\bground[\s_-]*(\d+)\b", text)
    text = re.sub(
        r"^tennis elbow 4(?:\s*\([^)]*\))?\s*[-:]\s*",
        "",
        text,
    )
    text = re.sub(r"\s*\([^)]*\)", "", text)
    text = re.sub(r"\b20\d{2}\b", "", text)
    text = re.sub(r"\bground[_\s-]*\d+\b", " ", text)
    aliases = (
        ("australian open", ("australian open", "ao rod laver", "ao margaret court")),
        ("roland garros", ("roland garros", "rg philippe chartier", "rg philippe chatrier")),
        ("wimbledon", ("wimbledon",)),
        ("us open", ("us open",)),
        ("rome", ("rome", "roma")),
        ("queens", ("queen's", "queens")),
        ("china open", ("china open", "beijing lotus", "beijing")),
        ("atlanta open", ("atlanta open", "atlanta")),
        ("stuttgart", ("stuttgart", "boss open")),
        ("next gen finals", ("next gen finals", "next gen atp finals")),
    )
    for canonical, candidates in aliases:
        if any(candidate in text for candidate in candidates):
            return ground.group(1) if ground else "", canonical
    text = re.sub(r"\b(?:atp|wta)\s+(?:250|500|1000)\b", " ", text)
    text = re.sub(
        r"\b(?:day|night|center|centre|court|no\.?\s*1|"
        r"arthur ashe|louis armstrong|manolo santana|rod laver|"
        r"margaret court)\b",
        " ",
        text,
    )
    return ground.group(1) if ground else "", re.sub(r"\s+", " ", text).strip()


def _matchlog_event_compatible(
    submitted: Any,
    official: Any,
) -> bool:
    if not normalize_name(submitted):
        return True
    submitted_ground, submitted_event = _matchlog_event_identity(submitted)
    official_ground, official_event = _matchlog_event_identity(official)
    if not submitted_event or not official_event:
        return False
    if submitted_event != official_event:
        return False
    return (
        not submitted_ground
        or not official_ground
        or submitted_ground == official_ground
    )


def _allow_unique_date_event_inference(
    submitted: Any,
    official: Any,
) -> bool:
    if _matchlog_event_compatible(submitted, official):
        return True
    return tournament_category(submitted) != tournament_category(official)


def _is_atp_cup_tournament(value: Any) -> bool:
    return "atp cup" in normalize_name(value)


def _trusted_atp_cup_official(
    match: dict[str, Any],
    canonical_rankings: dict[str, dict[str, str]],
) -> dict[str, str] | None:
    """Build a local official row for ATP Cup, absent from the WTSL feed."""
    rows = match.get("rows") or []
    if len(rows) < 2:
        return None
    names = [normalize_name(row.get("player")) for row in rows[:2]]
    if not all(names) or not _score_signature(rows[0].get("result")):
        return None
    possible_tours = [
        tour for tour in ("atp", "wta")
        if all(name in canonical_rankings[tour] for name in names)
    ]
    if len(possible_tours) != 1:
        return None
    match_datetime = rows[0].get("match_datetime")
    match_date = None
    if match_datetime:
        try:
            match_date = datetime.strptime(
                str(match_datetime), "%Y-%m-%d %H:%M:%S"
            ).strftime("%d.%m.%Y")
        except ValueError:
            return None
    return {
        "tour": possible_tours[0],
        "player1": canonical_rankings[possible_tours[0]][names[0]],
        "player2": canonical_rankings[possible_tours[0]][names[1]],
        "player1_character": rows[0].get("character"),
        "player2_character": rows[1].get("character"),
        "tournament": rows[0].get("tournament") or "ATP Cup",
        "date": match_date or "",
        "result": rows[0].get("result") or "",
    }


def _official_result_is_played(official: dict[str, str]) -> bool:
    result = normalize_name(official.get("result"))
    if re.search(r"\b(?:walkover|coin toss|bct)\b", result):
        return False
    if not _score_signature(official.get("result")):
        return False
    return not _matchlog_record_is_exhibition(
        official.get("tournament"),
        official.get("result"),
        official.get("event_category"),
    )


def _official_side_aliases(
    official: dict[str, str],
    player_field: str,
    character_field: str,
) -> set[str]:
    aliases = {normalize_name(official.get(player_field))}
    character = normalize_name(official.get(character_field))
    if character:
        aliases.add(character)
        without_initials = re.sub(
            r"^(?:[a-z]\.?\s+)+", "", character, flags=re.I
        ).strip()
        if without_initials:
            aliases.add(without_initials)
    return {alias for alias in aliases if alias}


def _similar_official_player_name(observed: Any, canonical: Any) -> bool:
    first = normalize_name(observed)
    second = normalize_name(canonical)
    if not first or not second or first == second:
        return False
    first_compact = re.sub(r"[^a-z0-9]", "", first)
    second_compact = re.sub(r"[^a-z0-9]", "", second)
    if min(len(first_compact), len(second_compact)) >= 6:
        if SequenceMatcher(None, first_compact, second_compact).ratio() >= 0.85:
            return True
    first_match = re.fullmatch(r"([a-z]{3,})(\d+)", first_compact)
    second_match = re.fullmatch(r"([a-z]{3,})(\d+)", second_compact)
    return bool(
        first_match
        and second_match
        and first_match.group(1) == second_match.group(1)
    )


def _canonicalize_match_from_official(
    match: dict[str, Any],
    official: dict[str, str],
) -> dict[str, Any] | None:
    """Map MatchLog character labels to exact official player accounts."""
    rows = match["rows"]
    sides = (
        (
            official["player1"],
            _official_side_aliases(
                official, "player1", "player1_character"
            ),
        ),
        (
            official["player2"],
            _official_side_aliases(
                official, "player2", "player2_character"
            ),
        ),
    )
    mappings = []
    for first_side, second_side in ((0, 1), (1, 0)):
        oriented = (sides[first_side], sides[second_side])
        if not all(
            (
                normalize_name(row.get("player")) in side_aliases
                or _similar_official_player_name(
                    row.get("player"), canonical
                )
            )
            for row, (canonical, side_aliases) in zip(rows, oriented)
        ):
            continue
        exact_players = sum(
            normalize_name(row.get("player")) == normalize_name(canonical)
            for row, (canonical, _aliases) in zip(rows, oriented)
        )
        if exact_players < 1:
            continue
        mappings.append(oriented)
    if len(mappings) != 1:
        return None
    updated = deepcopy(match)
    for row, (canonical, _aliases), (
        opponent_canonical, _opponent_aliases
    ) in zip(updated["rows"], mappings[0], reversed(mappings[0])):
        row["player"] = canonical
        row["opponent"] = opponent_canonical
    return updated


def _canonicalize_match_from_unique_anchor(
    match: dict[str, Any],
    official: dict[str, str],
) -> dict[str, Any] | None:
    """Infer one unlabeled side from a unique event/score/date candidate."""
    rows = match["rows"]
    sides = (
        (
            official["player1"],
            _official_side_aliases(
                official, "player1", "player1_character"
            ),
        ),
        (
            official["player2"],
            _official_side_aliases(
                official, "player2", "player2_character"
            ),
        ),
    )
    mappings = []
    for first_side, second_side in ((0, 1), (1, 0)):
        oriented = (sides[first_side], sides[second_side])
        anchored = [
            normalize_name(row.get("player")) in aliases
            for row, (_canonical, aliases) in zip(rows, oriented)
        ]
        if sum(anchored) != 1:
            continue
        mappings.append(oriented)
    if len(mappings) != 1:
        return None
    updated = deepcopy(match)
    for row, (canonical, _aliases), (
        opponent_canonical, _opponent_aliases
    ) in zip(updated["rows"], mappings[0], reversed(mappings[0])):
        row["player"] = canonical
        row["opponent"] = opponent_canonical
    return updated


def canonicalize_and_verify(
    matches: list[dict[str, Any]],
    rankings: dict[str, dict[str, str]],
    official_results: list[dict[str, str]],
    *,
    previously_verified: bool = False,
) -> list[dict[str, Any]]:
    # A trusted archive hash proves where the file came from, not that every
    # parsed entry in the file was an official match. Keep the argument for
    # replay-call compatibility, but never bypass per-match verification.
    del previously_verified
    output = []
    for match in matches:
        rows = match["rows"]
        if (
            is_nonroutine_matchlog_tournament(rows[0].get("tournament"))
            or _matchlog_record_is_exhibition(
                rows[0].get("tournament"),
                rows[0].get("result"),
            )
        ):
            continue
        observed = {normalize_name(rows[0]["player"]), normalize_name(rows[1]["player"])}
        canonical_by_tour = {
            tour: {
                normalize_name(canonical): canonical
                for canonical in rankings.get(tour, {}).values()
            }
            for tour in ("atp", "wta")
        }
        possible_tours = []
        for tour in ("atp", "wta"):
            if all(name in canonical_by_tour[tour] for name in observed):
                possible_tours.append(tour)
        if len(possible_tours) != 1:
            raise ValueError("Players do not resolve uniquely to one ATP/WTA tour")
        tour = possible_tours[0]
        canonical = canonical_by_tour[tour]
        for row in rows:
            row["player"] = canonical[normalize_name(row["player"])]
            row["opponent"] = canonical[normalize_name(row["opponent"])]
        canonical_pair = {
            normalize_name(rows[0]["player"]), normalize_name(rows[1]["player"])
        }
        match_date = (
            datetime.strptime(rows[0]["match_datetime"], "%Y-%m-%d %H:%M:%S")
            .strftime("%d.%m.%Y")
            if rows[0].get("match_datetime") else None
        )
        if not any(_score_signature(row.get("result")) for row in rows):
            raise ValueError(
                "A parseable MatchLog score is required for official "
                "result verification"
            )
        candidates = [
            official for official in official_results
            if official["tour"] == tour
            and {
                normalize_name(official["player1"]),
                normalize_name(official["player2"]),
            } == canonical_pair
            and _official_result_is_played(official)
        ]
        if rows[0].get("tournament"):
            narrowed = [
                official for official in candidates
                if _matchlog_event_compatible(
                    rows[0]["tournament"], official.get("tournament")
                )
            ]
            if narrowed:
                candidates = narrowed
        score_checks = [
            (official, _score_matches(rows, official))
            for official in candidates
        ]
        candidates = [
            official for official, check in score_checks if check
        ]
        if match_date:
            dated = [
                official for official in candidates
                if official["date"] == match_date
            ]
            if dated:
                candidates = [
                    official for official in dated
                    if _allow_unique_date_event_inference(
                        rows[0].get("tournament"),
                        official.get("tournament"),
                    )
                ]
        if len(candidates) != 1:
            reason = (
                "is not an official result"
                if not candidates else
                "matches multiple official results and is ambiguous"
            )
            raise ValueError(
                f"{rows[0]['player']} vs {rows[1]['player']} {reason} "
                "in the WTSL all-results feed"
            )
        official = candidates[0]
        official_score = _score_signature(official["result"])
        for row in rows:
            row["tournament"] = official["tournament"]
            oriented_score = (
                official_score
                if normalize_name(row.get("player"))
                == normalize_name(official.get("player1"))
                else tuple(
                    (second, first) for first, second in official_score
                )
            )
            row["result"] = " ".join(
                f"{first}-{second}" for first, second in oriented_score
            )
            first_side = (
                normalize_name(row.get("player"))
                == normalize_name(official.get("player1"))
            )
            row["character"] = official.get(
                "player1_character" if first_side else "player2_character"
            )
            row["opponent_character"] = official.get(
                "player2_character" if first_side else "player1_character"
            )
        output.append({"tour": tour, **match})
    return output


def select_official_matches(
    matches: list[dict[str, Any]],
    rankings: dict[str, dict[str, str]],
    official_results: list[dict[str, str]],
    *,
    previously_verified: bool = False,
) -> list[dict[str, Any]]:
    """Keep verified official matches from a MatchLog history export."""
    canonical_rankings = {
        tour: dict(rankings.get(tour, {}))
        for tour in ("atp", "wta")
    }
    for official in official_results:
        tour = official["tour"]
        for field in ("player1", "player2"):
            canonical = official[field]
            canonical_rankings[tour].setdefault(
                normalize_name(canonical), canonical
            )
    official_by_score: dict[
        tuple[tuple[int, int], ...],
        list[dict[str, str]],
    ] = defaultdict(list)
    for official in official_results:
        if not _official_result_is_played(official):
            continue
        if is_exhibition_tournament(
            official.get("tournament"),
            official.get("event_category"),
        ):
            continue
        score = _score_signature(official.get("result"))
        official_by_score[_score_equivalence_key(score)].append(official)
    verified = []
    for match in matches:
        rows = match.get("rows") or [{}]
        if (
            is_nonroutine_matchlog_tournament(rows[0].get("tournament"))
            or _matchlog_record_is_exhibition(
                rows[0].get("tournament"),
                rows[0].get("result"),
            )
        ):
            continue
        candidates = []
        match_score_keys = {
            _score_equivalence_key(score)
            for row in match.get("rows") or []
            if (score := _score_signature(row.get("result")))
        }
        possible_official = [
            official
            for score_key in match_score_keys
            for official in official_by_score.get(score_key, [])
        ]
        for official in possible_official:
            canonicalized = _canonicalize_match_from_official(
                match, official
            )
            if canonicalized is None:
                canonicalized = _canonicalize_match_from_unique_anchor(
                    match, official
                )
            if canonicalized is None:
                continue
            score_check = _score_matches(
                canonicalized["rows"], official
            )
            if score_check:
                candidates.append((official, canonicalized))
        submitted_tournament = match["rows"][0].get("tournament")
        if not candidates and _is_atp_cup_tournament(submitted_tournament):
            trusted = _trusted_atp_cup_official(match, canonical_rankings)
            if trusted is not None:
                canonicalized = _canonicalize_match_from_official(
                    match, trusted
                )
                if canonicalized is not None:
                    candidates = [(trusted, canonicalized)]
        if not candidates:
            continue
        if submitted_tournament:
            narrowed = [
                candidate for candidate in candidates
                if _matchlog_event_compatible(
                    submitted_tournament,
                    candidate[0].get("tournament"),
                )
            ]
            if narrowed:
                candidates = narrowed
        match_date = (
            datetime.strptime(
                match["rows"][0]["match_datetime"],
                "%Y-%m-%d %H:%M:%S",
            ).strftime("%d.%m.%Y")
            if match["rows"][0].get("match_datetime") else None
        )
        if match_date:
            dated = [
                candidate for candidate in candidates
                if candidate[0].get("date") == match_date
            ]
            if dated:
                candidates = [
                    candidate for candidate in dated
                    if _allow_unique_date_event_inference(
                        submitted_tournament,
                        candidate[0].get("tournament"),
                    )
                ]
        if len(candidates) != 1:
            continue
        official, canonicalized = candidates[0]
        tour = official["tour"]
        verification_rankings = {
            "atp": canonical_rankings["atp"] if tour == "atp" else {},
            "wta": canonical_rankings["wta"] if tour == "wta" else {},
        }
        try:
            verified.extend(canonicalize_and_verify(
                [canonicalized],
                verification_rankings,
                [official],
                previously_verified=previously_verified,
            ))
        except ValueError:
            continue
    if not verified:
        raise ValueError(
            "No official WTSL matches with matching players and scores were "
            "found in this MatchLog history"
        )
    return verified


def identifiable_raw_coverage(
    matches: list[dict[str, Any]],
    official_results: list[dict[str, str]],
) -> list[dict[str, str]]:
    """Return earliest raw dates for labels resolving to one official identity."""
    identities_by_alias: dict[str, set[tuple[str, str]]] = defaultdict(set)
    for official in official_results:
        tour = str(official.get("tour") or "").casefold()
        if tour not in {"atp", "wta"}:
            continue
        for player_field, character_field in (
            ("player1", "player1_character"),
            ("player2", "player2_character"),
        ):
            player = str(official.get(player_field) or "").strip()
            if not player:
                continue
            for alias in _official_side_aliases(
                official, player_field, character_field
            ):
                identities_by_alias[alias].add((tour, player))

    earliest: dict[tuple[str, str], str] = {}
    for match in matches:
        for row in match.get("rows") or []:
            resolved = identities_by_alias.get(
                normalize_name(row.get("player")), set()
            )
            if len(resolved) != 1:
                continue
            match_datetime = str(row.get("match_datetime") or "")
            if not re.match(r"^\d{4}-\d{2}-\d{2}", match_datetime):
                continue
            key = next(iter(resolved))
            raw_date = match_datetime[:10]
            if key not in earliest or raw_date < earliest[key]:
                earliest[key] = raw_date
    return [
        {"tour": tour, "player": player, "first_record": first_record}
        for (tour, player), first_record in sorted(earliest.items())
    ]


def _ensure_sheets(workbook) -> None:
    for tour, raw_name in RAW_SHEETS.items():
        if raw_name not in workbook.sheetnames:
            raw = workbook.create_sheet(raw_name)
            raw.append(RAW_COLUMNS)
            raw.freeze_panes = "A2"
            raw.auto_filter.ref = f"A1:{raw.cell(1, len(RAW_COLUMNS)).coordinate}"
        else:
            raw = workbook[raw_name]
            existing = {
                str(cell.value).strip()
                for cell in raw[1] if cell.value not in (None, "")
            }
            for header in RAW_COLUMNS:
                if header not in existing:
                    raw.cell(1, raw.max_column + 1).value = header
        summary_name = SUMMARY_SHEETS[tour]
        summary_headers = [
            "Player", "Unique matches",
            *[
                _metric_usage_header(label)
                for label in SUMMARY_STATS.values()
            ],
            *SUMMARY_STATS.values(),
            *OVERALL_RATING_COLUMNS,
        ]
        if summary_name not in workbook.sheetnames:
            summary = workbook.create_sheet(summary_name)
            summary.append(summary_headers)
            summary.freeze_panes = "A2"
        else:
            summary = workbook[summary_name]
            for column, header in enumerate(summary_headers, start=1):
                summary.cell(1, column).value = header
    if IDENTITY_SHEET not in workbook.sheetnames:
        identity = workbook.create_sheet(IDENTITY_SHEET)
        identity.append([
            "Discord User ID", "Tour", "Player", "Verified Source Hash"
        ])
        identity.freeze_panes = "A2"


def reset_matchlog_data(workbook_path: Path) -> None:
    """Remove only MatchLog-derived sheets, preserving screenshot statistics."""
    workbook = load_workbook(workbook_path)
    temporary = workbook_path.with_suffix(".matchlog-reset.tmp.xlsx")
    try:
        for sheet_name in (
            *RAW_SHEETS.values(),
            *SUMMARY_SHEETS.values(),
            IDENTITY_SHEET,
        ):
            if sheet_name in workbook.sheetnames:
                del workbook[sheet_name]
        _ensure_sheets(workbook)
        workbook.save(temporary)
    finally:
        workbook.close()
    temporary.replace(workbook_path)


def rebuild_from_sources(
    workbook_path: Path,
    sources: list[dict[str, Any]],
    identities: dict[int, dict[str, str] | str],
) -> int:
    """Atomically rebuild every MatchLog sheet with one workbook save."""
    workbook = load_workbook(workbook_path)
    temporary = workbook_path.with_suffix(".matchlog-rebuild.tmp.xlsx")
    added = 0
    try:
        for sheet_name in (
            *RAW_SHEETS.values(),
            *SUMMARY_SHEETS.values(),
            IDENTITY_SHEET,
        ):
            if sheet_name in workbook.sheetnames:
                del workbook[sheet_name]
        _ensure_sheets(workbook)
        # Repair screenshot-derived metrics from their authoritative raw rows
        # during every production replay, including stale historical values.
        from tennis_stats_scraper import recalculate_summary_sheets
        try:
            recalculate_summary_sheets(workbook)
        except ValueError as exc:
            print(
                "[MatchLog Stats] screenshot summary repair skipped because "
                f"the workbook is not compatible: {exc}",
                flush=True,
            )
        existing_match_ids = {tour: set() for tour in RAW_SHEETS}
        for source in sources:
            for match in source["verified_matches"]:
                tour = match["tour"]
                match_id = match["match_id"]
                if match_id in existing_match_ids[tour]:
                    continue
                existing_match_ids[tour].add(match_id)
                added += 1
                sheet = workbook[RAW_SHEETS[tour]]
                for row in match["rows"]:
                    values = {column: row.get(column) for column in RAW_COLUMNS}
                    for speed in SPEEDS:
                        normalized_kph = values.get(f"{speed}_kph")
                        if (
                            isinstance(normalized_kph, (int, float))
                            and not isinstance(normalized_kph, bool)
                        ):
                            values[speed] = normalized_kph
                    values.update({
                        "date": (
                            row["match_datetime"][:10]
                            if row.get("match_datetime") else None
                        ),
                        "time": (
                            row["match_datetime"][11:]
                            if row.get("match_datetime") else None
                        ),
                        "discord_message_id": str(
                            source["source_message_id"]
                        ),
                        "discord_attachment_id": str(source["attachment_id"]),
                        "submitter_id": str(source["submitter_id"]),
                        "source_sha256": source["source_hash"],
                    })
                    sheet.append([
                        _safe_excel_value(values.get(column))
                        for column in RAW_COLUMNS
                    ])
        for sheet_name in RAW_SHEETS.values():
            sheet = workbook[sheet_name]
            sheet.auto_filter.ref = sheet.dimensions
        identity_sheet = workbook[IDENTITY_SHEET]
        for user_id, linked in identities.items():
            links = linked.items() if isinstance(linked, dict) else [
                _parse_identity(linked)
            ]
            for tour, player in links:
                identity_sheet.append([
                    str(user_id), tour.upper(), _safe_excel_value(player),
                    "Persistent MatchLog identity",
                ])
        _rebuild_summaries(workbook)
        workbook.save(temporary)
    finally:
        workbook.close()
    temporary.replace(workbook_path)
    return added


def _derived_match_stats(
    row: dict[str, Any],
    opponent: dict[str, Any] | None,
) -> dict[str, float | list[float]]:
    """Derive ATP leaderboard components available from a paired MatchLog."""
    derived: dict[str, float] = {}
    if opponent is not None:
        first_won = opponent.get("first_serve_won_pct")
        if isinstance(first_won, (int, float)) and not isinstance(first_won, bool):
            derived["first_serve_return_won_pct"] = 1 - float(first_won)
        second_won = opponent.get("second_serve_won_pct")
        if isinstance(second_won, (int, float)) and not isinstance(second_won, bool):
            derived["second_serve_return_won_pct"] = 1 - float(second_won)
        opponent_breaks = opponent.get("break_points_won")
        opponent_chances = opponent.get("break_point_opportunities")
        if (
            isinstance(opponent_breaks, (int, float))
            and not isinstance(opponent_breaks, bool)
            and isinstance(opponent_chances, (int, float))
            and not isinstance(opponent_chances, bool)
            and opponent_chances > 0
        ):
            derived["break_points_saved_pct"] = (
                float(opponent_chances) - float(opponent_breaks)
            ) / float(opponent_chances)

    sets = _score_signature(row.get("result"))
    tiebreak_sets = [
        (first, second)
        for first, second in sets
        if {first, second} == {6, 7}
    ]
    if tiebreak_sets:
        derived["tiebreaks_won_pct"] = [
            float(first > second) for first, second in tiebreak_sets
        ]
    if len(sets) >= 3:
        prior_player_sets = sum(first > second for first, second in sets[:-1])
        prior_opponent_sets = sum(second > first for first, second in sets[:-1])
        final_first, final_second = sets[-1]
        if (
            prior_player_sets == prior_opponent_sets
            and final_first != final_second
        ):
            derived["deciding_sets_won_pct"] = float(
                final_first > final_second
            )
    return derived


def _rebuild_summaries(workbook) -> None:
    for tour in ("atp", "wta"):
        raw = workbook[RAW_SHEETS[tour]]
        summary = workbook[SUMMARY_SHEETS[tour]]
        groups: dict[str, dict[str, Any]] = {}
        seen_matches: set[tuple[str, str]] = set()
        raw_headers = [cell.value for cell in raw[1]]
        raw_rows = [
            dict(zip(raw_headers, values))
            for values in raw.iter_rows(min_row=2, values_only=True)
        ]
        rows_by_match: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in raw_rows:
            rows_by_match[str(row.get("match_id") or "")].append(row)
        for row in raw_rows:
            player = str(row.get("player") or "")
            key = normalize_name(player)
            if not key:
                continue
            group = groups.setdefault(key, {
                "player": player, "matches": 0,
                "values": {metric: [] for metric in SUMMARY_STATS},
            })
            unique = (key, str(row.get("match_id") or ""))
            if unique not in seen_matches:
                seen_matches.add(unique)
                group["matches"] += 1
            for metric in STATS:
                if (
                    metric == "break_points_won_pct"
                    and not (
                        isinstance(row.get("break_point_opportunities"), (int, float))
                        and row["break_point_opportunities"] > 0
                    )
                ):
                    continue
                value = (
                    row.get(f"{metric}_kph")
                    if metric in SPEEDS
                    else row.get(metric)
                )
                if isinstance(value, (int, float)):
                    group["values"][metric].append(value)
            opponent = next(
                (
                    candidate
                    for candidate in rows_by_match.get(
                        str(row.get("match_id") or ""), []
                    )
                    if normalize_name(candidate.get("player")) != key
                ),
                None,
            )
            for metric, value in _derived_match_stats(row, opponent).items():
                if isinstance(value, list):
                    group["values"][metric].extend(value)
                else:
                    group["values"][metric].append(value)
        if summary.max_row > 1:
            summary.delete_rows(2, summary.max_row - 1)
        for group in sorted(groups.values(), key=lambda item: normalize_name(item["player"])):
            counts = [
                len(group["values"][metric]) for metric in SUMMARY_STATS
            ]
            averages_by_key = {
                metric: (
                    sum(group["values"][metric]) / len(group["values"][metric])
                    if group["values"][metric] else None
                )
                for metric in SUMMARY_STATS
            }
            averages = [
                averages_by_key[metric] for metric in SUMMARY_STATS
            ]
            ratings = calculate_atp_available_ratings({
                SUMMARY_STATS[metric]: value
                for metric, value in averages_by_key.items()
            })
            summary.append([
                group["player"],
                group["matches"],
                *counts,
                *averages,
                *[ratings[label] for label in OVERALL_RATING_COLUMNS],
            ])
        summary.auto_filter.ref = summary.dimensions


def append_submission(
    workbook_path: Path,
    matches: list[dict[str, Any]],
    *,
    message_id: int,
    attachment_id: int,
    submitter_id: int,
    source_hash: str,
) -> dict[str, Any]:
    workbook = load_workbook(workbook_path)
    temporary = workbook_path.with_suffix(".matchlog.tmp.xlsx")
    try:
        _ensure_sheets(workbook)
        existing_hashes = set()
        existing_match_ids = {tour: set() for tour in RAW_SHEETS}
        for tour, sheet_name in RAW_SHEETS.items():
            sheet = workbook[sheet_name]
            headers = {cell.value: cell.column for cell in sheet[1]}
            for row in range(2, sheet.max_row + 1):
                existing_hashes.add(sheet.cell(row, headers["source_sha256"]).value)
                existing_match_ids[tour].add(
                    sheet.cell(row, headers["match_id"]).value
                )
        if source_hash in existing_hashes:
            return {"added": 0, "duplicate": "file"}
        new_matches = [
            match for match in matches
            if match["match_id"] not in existing_match_ids[match["tour"]]
        ]
        if not new_matches:
            return {"added": 0, "duplicate": "match"}
        players = set()
        warnings = set()
        for match in new_matches:
            sheet = workbook[RAW_SHEETS[match["tour"]]]
            for row in match["rows"]:
                values = {column: row.get(column) for column in RAW_COLUMNS}
                values.update({
                    "date": row["match_datetime"][:10] if row.get("match_datetime") else None,
                    "time": row["match_datetime"][11:] if row.get("match_datetime") else None,
                    "discord_message_id": str(message_id),
                    "discord_attachment_id": str(attachment_id),
                    "submitter_id": str(submitter_id),
                    "source_sha256": source_hash,
                })
                sheet.append([
                    _safe_excel_value(values.get(column))
                    for column in RAW_COLUMNS
                ])
                players.add(row["player"])
                if row.get("parse_warning"):
                    warnings.add(row["parse_warning"])
        for sheet_name in RAW_SHEETS.values():
            sheet = workbook[sheet_name]
            sheet.auto_filter.ref = sheet.dimensions
        _rebuild_summaries(workbook)
        workbook.save(temporary)
    finally:
        workbook.close()
    temporary.replace(workbook_path)
    return {
        "added": len(new_matches),
        "players": sorted(players, key=normalize_name),
        "warnings": sorted(warnings),
    }


def reconcile_source_matches(
    workbook_path: Path,
    source_hash: str,
    verified_matches: list[dict[str, Any]],
) -> dict[str, int]:
    """Remove conclusively unverified rows for one trusted MatchLog source."""
    workbook = load_workbook(workbook_path)
    temporary = workbook_path.with_suffix(".matchlog.tmp.xlsx")
    removed_rows = 0
    removed_matches: set[tuple[str, str]] = set()
    try:
        _ensure_sheets(workbook)
        valid_ids = {
            tour: {
                str(match["match_id"])
                for match in verified_matches
                if match["tour"] == tour
            }
            for tour in RAW_SHEETS
        }
        for tour, sheet_name in RAW_SHEETS.items():
            sheet = workbook[sheet_name]
            headers = {cell.value: cell.column for cell in sheet[1]}
            source_column = headers["source_sha256"]
            match_column = headers["match_id"]
            rows_to_delete = []
            for row_index in range(2, sheet.max_row + 1):
                if str(sheet.cell(row_index, source_column).value or "") != source_hash:
                    continue
                match_id = str(sheet.cell(row_index, match_column).value or "")
                if match_id not in valid_ids[tour]:
                    rows_to_delete.append(row_index)
                    removed_matches.add((tour, match_id))
            for row_index in reversed(rows_to_delete):
                sheet.delete_rows(row_index)
            removed_rows += len(rows_to_delete)
            sheet.auto_filter.ref = sheet.dimensions
        if removed_rows:
            _rebuild_summaries(workbook)
            workbook.save(temporary)
    finally:
        workbook.close()
    if removed_rows:
        temporary.replace(workbook_path)
    elif temporary.exists():
        temporary.unlink()
    return {
        "removed_rows": removed_rows,
        "removed_matches": len(removed_matches),
    }


def _safe_excel_value(value: Any) -> Any:
    if isinstance(value, str) and value.startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def bind_player_identity(
    workbook_path: Path,
    discord_user_id: int,
    player: str,
    receipt: str,
    tour: str | None = None,
) -> None:
    workbook = load_workbook(workbook_path)
    temporary = workbook_path.with_suffix(".matchlog.tmp.xlsx")
    try:
        _ensure_sheets(workbook)
        sheet = workbook[IDENTITY_SHEET]
        tour, player = _parse_identity(player, tour)
        # Upgrade the old three-column workbook sheet in place.
        if sheet.cell(1, 2).value != "Tour":
            sheet.insert_cols(2)
            sheet.cell(1, 2, "Tour")
        matching_rows = [
            row for row in range(2, sheet.max_row + 1)
            if (
                str(sheet.cell(row, 1).value) == str(discord_user_id)
                and str(sheet.cell(row, 2).value or "").casefold() == tour
            )
        ]
        if matching_rows:
            first = matching_rows[0]
            sheet.cell(first, 3, _safe_excel_value(player))
            sheet.cell(first, 4, receipt)
            for row in reversed(matching_rows[1:]):
                sheet.delete_rows(row)
        else:
            sheet.append([
                str(discord_user_id),
                tour.upper(),
                _safe_excel_value(player),
                receipt,
            ])
        workbook.save(temporary)
    finally:
        workbook.close()
    temporary.replace(workbook_path)


class AmbiguousPlayerNameError(ValueError):
    pass


def _parse_identity(player: str, tour: str | None = None) -> tuple[str, str]:
    prefix, separator, name = str(player).strip().partition(":")
    resolved_tour = (tour or (prefix if separator else "")).strip().casefold()
    if resolved_tour not in {"atp", "wta"}:
        # Preserve old unqualified workbook bindings: their historical default
        # was ATP unless the player query itself resolved otherwise.
        resolved_tour = "atp"
    return resolved_tour, (name if separator else str(player)).strip()


def _parse_player_query(player_name: str) -> tuple[str, str | None]:
    query = player_name.strip()
    wanted_tour = None
    prefix, separator, remainder = query.partition(":")
    if separator and normalize_name(prefix) in {"atp", "wta"}:
        wanted_tour = normalize_name(prefix)
        query = remainder
    return normalize_name(query), wanted_tour


_SUMMARY_PERIODS = {
    "career": "Career",
    "30d": "Last 30 days",
    "90d": "Last 90 days",
    "year": "Year to date",
    "52w": "Last 52 weeks",
}


def _summary_period(
    period: str | None,
    as_of: date | datetime | str | None,
) -> tuple[str, str, date]:
    """Normalize a requested summary window and its inclusive reference date."""
    key = str(period or "career").strip().casefold()
    if key not in _SUMMARY_PERIODS:
        raise ValueError(
            "period must be one of: career, 30d, 90d, year, 52w"
        )
    if as_of is None:
        reference = datetime.now().date()
    elif isinstance(as_of, datetime):
        reference = as_of.date()
    elif isinstance(as_of, date):
        reference = as_of
    elif isinstance(as_of, str):
        try:
            reference = datetime.fromisoformat(as_of.strip()).date()
        except ValueError as error:
            raise ValueError("as_of must be an ISO-8601 date or datetime") from error
    else:
        raise ValueError("as_of must be an ISO-8601 date or datetime")
    return key, _SUMMARY_PERIODS[key], reference


def _raw_row_date(row: dict[str, Any]) -> date | None:
    """Read a MatchLog date without treating malformed values as dated."""
    value = row.get("match_datetime") or row.get("date")
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        return datetime.fromisoformat(value.strip()).date()
    except ValueError:
        try:
            return date.fromisoformat(value.strip())
        except ValueError:
            return None


def _row_in_summary_period(
    row: dict[str, Any], period: str, as_of: date
) -> bool:
    if period == "career":
        return True
    match_date = _raw_row_date(row)
    if match_date is None or match_date > as_of:
        return False
    if period == "year":
        return match_date.year == as_of.year
    days = {"30d": 29, "90d": 89, "52w": 363}[period]
    return match_date >= as_of - timedelta(days=days)


def _aggregate_raw_summary_rows(
    raw_rows: list[dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Aggregate raw MatchLog rows using the persisted summary conventions."""
    groups: dict[str, dict[str, Any]] = {}
    seen_matches: set[tuple[str, str]] = set()
    rows_by_match: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in raw_rows:
        rows_by_match[str(row.get("match_id") or "")].append(row)
    for row in raw_rows:
        player = str(row.get("player") or "")
        key = normalize_name(player)
        if not key:
            continue
        group = groups.setdefault(key, {
            "player": player,
            "matches": 0,
            "values": {metric: [] for metric in SUMMARY_STATS},
        })
        unique = (key, str(row.get("match_id") or ""))
        if unique not in seen_matches:
            seen_matches.add(unique)
            group["matches"] += 1
        for metric in STATS:
            if (
                metric == "break_points_won_pct"
                and not (
                    isinstance(row.get("break_point_opportunities"), (int, float))
                    and row["break_point_opportunities"] > 0
                )
            ):
                continue
            value = row.get(f"{metric}_kph") if metric in SPEEDS else row.get(metric)
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                group["values"][metric].append(value)
        opponent = next((
            candidate for candidate in rows_by_match.get(
                str(row.get("match_id") or ""), []
            )
            if normalize_name(candidate.get("player")) != key
        ), None)
        for metric, value in _derived_match_stats(row, opponent).items():
            group["values"][metric].extend(value if isinstance(value, list) else [value])
    return groups


def _summary_group_row(group: dict[str, Any]) -> dict[str, Any]:
    averages_by_key = {
        metric: (
            sum(group["values"][metric]) / len(group["values"][metric])
            if group["values"][metric] else None
        )
        for metric in SUMMARY_STATS
    }
    values = {
        "Player": group["player"],
        "Unique matches": group["matches"],
    }
    for metric, label in SUMMARY_STATS.items():
        values[_metric_usage_header(label)] = len(group["values"][metric])
        values[label] = averages_by_key[metric]
    values.update(calculate_atp_available_ratings({
        SUMMARY_STATS[metric]: value for metric, value in averages_by_key.items()
    }))
    return values


def _summary_for_normalized_player(
    workbook,
    wanted: str,
    wanted_tour: str | None = None,
    period: str | None = None,
    as_of: date | datetime | str | None = None,
) -> dict[str, Any] | None:
        period_key, period_label, as_of_date = _summary_period(period, as_of)
        matches = []
        populations: dict[str, list[dict[str, Any]]] = defaultdict(list)
        raw_by_tour: dict[str, list[dict[str, Any]]] = {}
        for tour, raw_name in RAW_SHEETS.items():
            if wanted_tour is not None and tour != wanted_tour:
                continue
            if raw_name not in workbook.sheetnames:
                continue
            sheet = workbook[raw_name]
            headers = [cell.value for cell in sheet[1]]
            rows = [
                dict(zip(headers, values))
                for values in sheet.iter_rows(min_row=2, values_only=True)
            ]
            all_groups = _aggregate_raw_summary_rows(rows)
            coverage_dates = sorted(
                parsed_date
                for raw_row in rows
                if normalize_name(raw_row.get("player")) == wanted
                and (parsed_date := _raw_row_date(raw_row)) is not None
            )
            raw_by_tour[tour] = [
                row for row in rows
                if _row_in_summary_period(row, period_key, as_of_date)
            ]
            groups = _aggregate_raw_summary_rows(raw_by_tour[tour])
            populations[tour] = [
                _summary_group_row(group) for group in groups.values()
            ]
            group = groups.get(wanted)
            if group is None and period_key != "career" and wanted in all_groups:
                group = {
                    "player": all_groups[wanted]["player"],
                    "matches": 0,
                    "values": {metric: [] for metric in SUMMARY_STATS},
                }
            if group is None:
                continue
            row = _summary_group_row(group)
            metrics = [
                (label, row.get(label), row.get(_metric_usage_header(label)))
                for label in SUMMARY_STATS.values()
                if row.get(label) is not None
                and (row.get(_metric_usage_header(label)) or 0) > 0
            ]
            matches.append({
                "player": group["player"],
                "tour": tour,
                "matches": row["Unique matches"],
                "metrics": metrics,
                "ratings": [
                    (label.replace(" (Overall)", " Rating"), row.get(label))
                    for label in OVERALL_RATING_COLUMNS
                ],
                "coverage_start": (
                    coverage_dates[0].isoformat() if coverage_dates else None
                ),
                "coverage_end": (
                    coverage_dates[-1].isoformat() if coverage_dates else None
                ),
                "_target_row": row,
            })
        if not matches and period_key == "career":
            for tour, summary_name in SUMMARY_SHEETS.items():
                if wanted_tour is not None and tour != wanted_tour:
                    continue
                if summary_name not in workbook.sheetnames:
                    continue
                sheet = workbook[summary_name]
                headers = [cell.value for cell in sheet[1]]
                for values in sheet.iter_rows(min_row=2, values_only=True):
                    row = dict(zip(headers, values))
                    if row.get("Player"):
                        populations[tour].append(row)
                    if not values or normalize_name(values[0]) != wanted:
                        continue
                    metrics = [
                        (
                            label,
                            row.get(label),
                            row.get(_metric_usage_header(label)),
                        )
                        for label in SUMMARY_STATS.values()
                        if row.get(label) is not None
                        and (row.get(_metric_usage_header(label)) or 0) > 0
                    ]
                    matches.append({
                        "player": values[0],
                        "tour": tour,
                        "matches": row.get("Unique matches") or 0,
                        "metrics": metrics,
                        "ratings": [
                            (
                                label.replace(" (Overall)", " Rating"),
                                row.get(label),
                            )
                            for label in OVERALL_RATING_COLUMNS
                        ],
                        "_target_row": row,
                    })
        if not matches:
            return None
        if len(matches) > 1:
            raise AmbiguousPlayerNameError(
                "That player name exists in both ATP and WTA statistics. "
                "Prefix the name with `ATP:` or `WTA:`."
            )
        summary = matches[0]
        summary["relative_profile"] = calculate_relative_profiles(
            summary.pop("_target_row"), populations.get(summary["tour"], [])
        )
        summary["period"] = period_key
        summary["period_label"] = period_label
        summary["as_of"] = as_of_date.isoformat()
        recent = []
        for row in raw_by_tour.get(summary["tour"], []):
            if normalize_name(row.get("player")) != normalize_name(summary["player"]):
                continue
            recent.append({
                "match_datetime": row.get("match_datetime") or "",
                "date": row.get("date") or "",
                "opponent": row.get("opponent") or "",
                "result": row.get("result") or "",
                "tournament": row.get("tournament") or "",
                "tour": summary["tour"].upper(),
            })
        recent.sort(
            key=lambda match: (
                str(match["match_datetime"]), str(match["date"])
            ),
            reverse=True,
        )
        summary["recent_matches"] = recent[:5]
        return summary


def player_summary_by_name(
    workbook_path: Path,
    player_name: str,
    period: str | None = None,
    as_of: date | datetime | str | None = None,
) -> dict[str, Any] | None:
    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    try:
        wanted, wanted_tour = _parse_player_query(player_name)
        return _summary_for_normalized_player(
            workbook,
            wanted,
            wanted_tour,
            period,
            as_of,
        )
    finally:
        workbook.close()

def player_summary_names(workbook_path: Path) -> list[str]:
    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    try:
        players: list[tuple[str, str]] = []
        tours_by_name: dict[str, set[str]] = {}
        for tour, summary_name in SUMMARY_SHEETS.items():
            if summary_name not in workbook.sheetnames:
                continue
            sheet = workbook[summary_name]
            headers = [cell.value for cell in sheet[1]]
            for values in sheet.iter_rows(min_row=2, values_only=True):
                row = dict(zip(headers, values))
                player = str(row.get("Player") or "").strip()
                if not player:
                    continue
                players.append((tour, player))
                tours_by_name.setdefault(normalize_name(player), set()).add(tour)
        return sorted(
            (
                f"{tour.upper()}: {player}"
                if len(tours_by_name[normalize_name(player)]) > 1
                else player
                for tour, player in players
            ),
            key=normalize_name,
        )
    finally:
        workbook.close()


def query_match_stat_values(
    workbook_path: Path,
    metric_key: str,
    *,
    tour: str | None = None,
    period: str | None = None,
    set_count: int | None = None,
    player_name: str | None = None,
    opponent_name: str | None = None,
) -> list[dict[str, Any]]:
    """Return verified single-match values for a raw MatchLog metric."""
    metric_key = str(metric_key or "").strip().casefold()
    if metric_key not in SUMMARY_STATS:
        raise ValueError("That metric is not available as a MatchLog stat")
    metric_label = SUMMARY_STATS[metric_key]
    is_derived = metric_key in DERIVED_STATS
    selected_tour = str(tour or "").strip().casefold() or None
    if selected_tour not in {None, *RAW_SHEETS}:
        raise ValueError("tour must be ATP or WTA")
    if set_count is not None and (int(set_count) < 1 or int(set_count) > 5):
        raise ValueError("set_count must be between 1 and 5")
    period_key, _period_label, as_of_date = _summary_period(period, None)
    wanted_player = normalize_name(player_name) if player_name else None
    wanted_opponent = normalize_name(opponent_name) if opponent_name else None

    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    try:
        candidates: list[dict[str, Any]] = []
        seen_rows: set[tuple[str, str, str]] = set()
        for current_tour, raw_name in RAW_SHEETS.items():
            if selected_tour is not None and current_tour != selected_tour:
                continue
            if raw_name not in workbook.sheetnames:
                continue
            sheet = workbook[raw_name]
            headers = [cell.value for cell in sheet[1]]
            rows = [
                dict(zip(headers, values))
                for values in sheet.iter_rows(min_row=2, values_only=True)
            ]
            rows_by_match = defaultdict(list)
            for row in rows:
                rows_by_match[str(row.get("match_id") or "")].append(row)
            if not is_derived and metric_key not in headers:
                continue
            for row in rows:
                player = str(row.get("player") or "").strip()
                opponent = str(row.get("opponent") or "").strip()
                if not player or (
                    wanted_player is not None
                    and normalize_name(player) != wanted_player
                ):
                    continue
                if (
                    wanted_opponent is not None
                    and normalize_name(opponent) != wanted_opponent
                ):
                    continue
                if not _row_in_summary_period(row, period_key, as_of_date):
                    continue
                result = str(row.get("result") or "").strip()
                actual_sets = len(re.findall(r"\d+\s*[-–]\s*\d+", result))
                if set_count is not None and actual_sets != int(set_count):
                    continue
                if is_derived:
                    opponent_row = next(
                        (
                            candidate
                            for candidate in rows_by_match.get(
                                str(row.get("match_id") or ""), []
                            )
                            if normalize_name(candidate.get("player")) !=
                            normalize_name(player)
                        ),
                        None,
                    )
                    derived_values = _derived_match_stats(row, opponent_row).get(
                        metric_key
                    )
                    if isinstance(derived_values, list):
                        values_to_add = list(enumerate(derived_values))
                    elif isinstance(derived_values, (int, float)):
                        values_to_add = [(0, derived_values)]
                    else:
                        values_to_add = []
                else:
                    value = row.get(metric_key)
                    values_to_add = (
                        [(0, value)]
                        if isinstance(value, (int, float))
                        and not isinstance(value, bool)
                        else []
                    )
                if not values_to_add:
                    continue
                for derived_index, value in values_to_add:
                    row_key = (
                        str(row.get("match_id") or ""),
                        normalize_name(player),
                        current_tour,
                        str(derived_index),
                    )
                    if row_key in seen_rows:
                        continue
                    seen_rows.add(row_key)
                    candidates.append({
                        "value": float(value),
                        "match_id": str(row.get("match_id") or ""),
                        "player": player,
                        "opponent": opponent,
                        "character": str(row.get("character") or "").strip(),
                        "opponent_character": str(
                            row.get("opponent_character") or ""
                        ).strip(),
                        "tour": current_tour,
                        "date": str(row.get("date") or row.get("match_datetime") or ""),
                        "tournament": str(row.get("tournament") or "").strip(),
                        "result": result,
                        "sets": actual_sets,
                        "metric": metric_key,
                        "metric_label": metric_label,
                    })
        return candidates
    finally:
        workbook.close()


def query_match_stat_record(
    workbook_path: Path,
    metric_key: str,
    *,
    tour: str | None = None,
    period: str | None = None,
    set_count: int | None = None,
    player_name: str | None = None,
) -> dict[str, Any] | None:
    """Return the highest single-match value for a raw MatchLog metric."""
    values = query_match_stat_values(
        workbook_path,
        metric_key,
        tour=tour,
        period=period,
        set_count=set_count,
        player_name=player_name,
    )
    return max(
        values,
        key=lambda candidate: (candidate["value"], str(candidate["date"])),
        default=None,
    )


def leaderboard_rows(workbook_path: Path, tour: str) -> list[dict[str, Any]]:
    """Read career rating rows for one MatchLog tour."""
    selected_tour = str(tour or "").casefold()
    if selected_tour not in SUMMARY_SHEETS:
        raise ValueError("MatchLog leaderboard requires an ATP or WTA tour")
    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    try:
        sheet_name = SUMMARY_SHEETS[selected_tour]
        if sheet_name not in workbook.sheetnames:
            return []
        sheet = workbook[sheet_name]
        headers = [cell.value for cell in sheet[1]]
        rows = []
        for values in sheet.iter_rows(min_row=2, values_only=True):
            row = dict(zip(headers, values))
            player = str(row.get("Player") or "").strip()
            if not player:
                continue
            calculated = calculate_atp_available_ratings(row)
            ratings = {
                label: calculated.get(label)
                for label in OVERALL_RATING_COLUMNS
                if isinstance(calculated.get(label), (int, float))
            }
            if ratings:
                rows.append({
                    "player": player,
                    "tour": selected_tour,
                    "source": "matchlog",
                    "matches": int(row.get("Unique matches") or 0),
                    "ratings": ratings,
                    "metrics": {
                        label: row.get(label)
                        for label in SUMMARY_STATS.values()
                        if isinstance(row.get(label), (int, float))
                        and (row.get(_metric_usage_header(label)) or 0) > 0
                    },
                })
        return rows
    finally:
        workbook.close()


def player_summary(
    workbook_path: Path,
    discord_user_id: int,
    tour: str | None = None,
    period: str | None = None,
    as_of: date | datetime | str | None = None,
) -> dict[str, Any] | None:
    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    try:
        if IDENTITY_SHEET not in workbook.sheetnames:
            return None
        sheet = workbook[IDENTITY_SHEET]
        headers = [cell.value for cell in sheet[1]]
        tour_column = headers.index("Tour") if "Tour" in headers else None
        player_column = headers.index("Player") if "Player" in headers else 1
        bound_players = {
            _parse_identity(
                str(row[player_column]).strip(),
                str(row[tour_column]).strip() if tour_column is not None
                and row[tour_column] else None,
            )
            for row in sheet.iter_rows(min_row=2, values_only=True)
            if row and str(row[0]) == str(discord_user_id) and row[player_column]
        }
        if tour:
            bound_players = {
                link for link in bound_players if link[0] == tour.casefold()
            }
        if len(bound_players) != 1:
            return None
        wanted_tour, player = next(iter(bound_players))
        return _summary_for_normalized_player(
            workbook, normalize_name(player), wanted_tour, period, as_of
        )
    finally:
        workbook.close()


def _upload_metric_values(summary: dict[str, Any]) -> dict[str, Any]:
    values = {}
    for upload_column, summary_column in UPLOAD_METRICS.items():
        value = summary.get(summary_column)
        if value is None:
            values[upload_column] = ""
        elif upload_column in UPLOAD_PERCENT_COLUMNS:
            values[upload_column] = round(float(value) * 100, 1)
        else:
            values[upload_column] = round(float(value), 1)
    return values


def _build_upload_csv_from_summary_sheets(
    workbook_path: Path,
    template_path: Path,
    summary_sheets: dict[str, str],
    *,
    header_row: int = 1,
) -> bytes:
    """Build the site's 20-column upload CSV from player summary sheets."""
    roster_players: dict[tuple[str, str], list[tuple[str, str]]] = {}
    with template_path.open(encoding="utf-8-sig", newline="") as source:
        for row in csv.DictReader(source):
            name = row.get("pl_name")
            if name:
                tour_value = normalize_name(row.get("pl_tour"))
                if tour_value in {"2", "2.0", "wta"}:
                    template_tour = "wta"
                elif tour_value in {"1", "1.0", "atp"}:
                    template_tour = "atp"
                else:
                    continue
                key = (normalize_name(name), template_tour)
                roster_players.setdefault(key, []).append(
                    (name, row.get("pl_stats_pl_ID", "") or "")
                )
    identities = {
        key: candidates[0]
        for key, candidates in roster_players.items()
        if len(candidates) == 1
    }
    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=UPLOAD_COLUMNS)
    writer.writeheader()
    writer.writerow({
        "pl_stats_pl_ID": (
            "Dont change the ID or player names! Insert data below this row. "
            "You can either only add new entries or update existing players if wanted."
        )
    })
    try:
        for tour, summary_name in summary_sheets.items():
            if summary_name not in workbook.sheetnames:
                continue
            sheet = workbook[summary_name]
            headers = [cell.value for cell in sheet[header_row]]
            rows = []
            for values in sheet.iter_rows(
                min_row=header_row + 1,
                values_only=True,
            ):
                summary = dict(zip(headers, values))
                player = str(summary.get("Player") or "")
                if not player:
                    continue
                roster_identity = identities.get((normalize_name(player), tour))
                row = {
                    "pl_stats_pl_ID": (
                        roster_identity[1] if roster_identity else ""
                    ),
                    "pl_name": roster_identity[0] if roster_identity else player,
                    "pl_tour": "1.0" if tour == "atp" else "2.0",
                }
                row.update(_upload_metric_values(summary))
                rows.append(row)
            writer.writerows(sorted(rows, key=lambda row: normalize_name(row["pl_name"])))
    finally:
        workbook.close()
    return output.getvalue().encode("utf-8-sig")


def _build_ranked_atp_screenshot_upload_csv(
    workbook_path: Path,
    template_path: Path,
) -> bytes:
    """Export every named ATP roster row, filling only unique summary matches."""
    roster_rows = []
    roster_counts: dict[str, int] = {}
    with template_path.open(encoding="utf-8-sig", newline="") as source:
        for row in csv.DictReader(source):
            name = str(row.get("pl_name") or "")
            tour_value = normalize_name(row.get("pl_tour"))
            if not name.strip() or tour_value not in {"1", "1.0", "atp"}:
                continue
            key = normalize_name(name)
            roster_counts[key] = roster_counts.get(key, 0) + 1
            roster_rows.append({
                "name": name,
                "id": row.get("pl_stats_pl_ID", "") or "",
                "key": key,
            })

    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    summaries: dict[str, list[dict[str, Any]]] = {}
    try:
        summary_name = "ATP Summary"
        if summary_name in workbook.sheetnames:
            sheet = workbook[summary_name]
            headers = [cell.value for cell in sheet[5]]
            for values in sheet.iter_rows(min_row=6, values_only=True):
                summary = dict(zip(headers, values))
                player = str(summary.get("Player") or "").strip()
                if player:
                    summaries.setdefault(normalize_name(player), []).append(
                        summary
                    )
    finally:
        workbook.close()

    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=UPLOAD_COLUMNS)
    writer.writeheader()
    writer.writerow({
        "pl_stats_pl_ID": (
            "Dont change the ID or player names! Insert data below this row. "
            "You can either only add new entries or update existing players if wanted."
        )
    })
    for roster_row in roster_rows:
        row = {
            "pl_stats_pl_ID": roster_row["id"],
            "pl_name": roster_row["name"],
            "pl_tour": "1.0",
        }
        row.update({column: "" for column in UPLOAD_METRICS})
        key = roster_row["key"]
        candidates = summaries.get(key, [])
        if roster_counts[key] == 1 and len(candidates) == 1:
            row.update(_upload_metric_values(candidates[0]))
        writer.writerow(row)
    return output.getvalue().encode("utf-8-sig")


def build_upload_csv(workbook_path: Path, template_path: Path) -> bytes:
    """Build the upload CSV from MatchLog-only summary sheets."""
    return _build_upload_csv_from_summary_sheets(
        workbook_path,
        template_path,
        SUMMARY_SHEETS,
    )


def build_screenshot_stats_upload_csv(
    workbook_path: Path,
    template_path: Path,
    tour: str | None = None,
) -> bytes:
    """Build screenshot-derived upload rows, optionally for one tour only."""
    summary_sheets = {"atp": "ATP Summary", "wta": "WTA Summary"}
    if tour is not None:
        tour = tour.casefold()
        if tour not in summary_sheets:
            raise ValueError("tour must be 'atp', 'wta', or None")
        if tour == "atp":
            return _build_ranked_atp_screenshot_upload_csv(
                workbook_path,
                template_path,
            )
        summary_sheets = {tour: summary_sheets[tour]}
    return _build_upload_csv_from_summary_sheets(
        workbook_path,
        template_path,
        summary_sheets,
        header_row=5,
    )


def build_composite_log_csv(workbook_path: Path) -> bytes:
    """Export every accepted ATP/WTA MatchLog row from the cumulative workbook."""
    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    output = io.StringIO(newline="")
    fieldnames = ["tour", *RAW_COLUMNS]
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    try:
        for tour, raw_name in RAW_SHEETS.items():
            if raw_name not in workbook.sheetnames:
                continue
            sheet = workbook[raw_name]
            headers = [cell.value for cell in sheet[1]]
            for values in sheet.iter_rows(min_row=2, values_only=True):
                row = dict(zip(headers, values))
                if not row.get("match_id"):
                    continue
                writer.writerow({
                    "tour": tour.upper(),
                    **{column: row.get(column) for column in RAW_COLUMNS},
                })
    finally:
        workbook.close()
    return output.getvalue().encode("utf-8-sig")


def format_player_summary(summary: dict[str, Any]) -> str:
    lines = [
        f"📊 **MatchLog stats — {summary['player']}**",
        f"Official matches recorded: **{summary['matches']}**",
    ]
    if summary.get("ratings"):
        lines.append("\n**WTSL ratings — available MatchLog components**")
    for label, value in summary.get("ratings") or []:
        shown = (
            f"{value:.2f}".rstrip("0").rstrip(".")
            if isinstance(value, (int, float))
            else "Not available"
        )
        lines.append(f"• **{label}:** {shown}")
    rating_components = [
        metric
        for metric in summary["metrics"]
        if metric[0] in RATING_COMPONENT_LABELS
    ]
    if rating_components:
        lines.append("\n**Derived rating components**")
        for label, value, count in rating_components:
            shown = _format_summary_value(label, value)
            unit = (
                "tie-breaks"
                if label == "Tie-breaks Won %"
                else "deciding matches"
                if label == "Deciding Sets Won %"
                else "matches"
            )
            lines.append(f"• **{label}:** {shown} ({count} {unit})")
    lines.append("\n**Career Stats**")
    regular_metrics = [
        metric
        for metric in summary["metrics"]
        if metric[0] not in RATING_COMPONENT_LABELS
    ]
    for label, value, count in regular_metrics[:12]:
        shown = _format_summary_value(label, value)
        lines.append(f"• **{label}:** {shown} ({count} match{'es' if count != 1 else ''})")
    recent = (summary.get("recent_matches") or [])[:5]
    if recent:
        lines.append(f"\n**Last {len(recent)} parsed matches**")
        for match in recent:
            date = str(match["date"] or match["match_datetime"][:10] or "Unknown")
            opponent = str(match["opponent"])[:24]
            score = str(match["result"] or "No score")[:28]
            lines.append(f"• {date} — {opponent}: {score}")
    if summary.get("ratings"):
        lines.append(f"\n_{rating_formula_footnote('matchlog')}_")
    lines.append("_Source: MatchLog._")
    return "\n".join(lines)


def _format_summary_value(label: str, value: Any) -> str:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return "N/A"
    if label.endswith("%"):
        return f"{value:.1%}"
    shown = f"{value:.2f}".rstrip("0").rstrip(".")
    return f"{shown} km/h" if label in SPEED_LABELS else shown


def _metric_usage_header(label: str) -> str:
    if label == "Tie-breaks Won %":
        return f"{label} opportunities used"
    return f"{label} matches used"


def format_player_comparison(
    first: dict[str, Any],
    second: dict[str, Any],
) -> str:
    first_ratings = dict(first.get("ratings") or [])
    second_ratings = dict(second.get("ratings") or [])
    first_metrics = {
        label: value for label, value, _count in first.get("metrics") or []
    }
    second_metrics = {
        label: value for label, value, _count in second.get("metrics") or []
    }
    lines = [
        f"⚖️ **{first['player']} vs {second['player']}**",
        (
            f"Official matches: **{first['matches']}** vs "
            f"**{second['matches']}**"
        ),
        "",
        "**WTSL-adapted ratings**",
    ]
    for label in ("Serve Rating", "Return Rating", "Under Pressure"):
        lines.append(
            f"• **{label}:** "
            f"{_format_summary_value(label, first_ratings.get(label))} | "
            f"{_format_summary_value(label, second_ratings.get(label))}"
        )
    lines.append("\n**Career Stats**")
    for label in SUMMARY_STATS.values():
        first_value = first_metrics.get(label)
        second_value = second_metrics.get(label)
        if first_value is None and second_value is None:
            continue
        lines.append(
            f"• **{label}:** "
            f"{_format_summary_value(label, first_value)} | "
            f"{_format_summary_value(label, second_value)}"
        )
    lines.append(f"\n_{rating_formula_footnote('matchlog')}_")
    lines.append("_Source: MatchLog._")
    return "\n".join(lines)
