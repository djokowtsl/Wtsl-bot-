import asyncio
import hashlib
import copy
import csv
import io
import json
import re
import tempfile
import threading
import time
import unittest
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from openpyxl import Workbook, load_workbook
from overall_ratings import calculate_relative_profiles
from wtsl_results import parse_tournaments_html

import main
from matchlog_stats import (
    RAW_SHEETS,
    SUMMARY_SHEETS,
    AmbiguousPlayerNameError,
    append_submission,
    bind_player_identity,
    build_screenshot_stats_upload_csv,
    build_upload_csv,
    build_composite_log_csv,
    canonicalize_and_verify,
    _derived_match_stats,
    format_player_summary,
    format_player_comparison,
    identifiable_raw_coverage,
    parse_matchlog_html,
    parse_official_results,
    player_summary,
    player_summary_by_name,
    player_summary_names,
    query_match_stat_values,
    reconcile_source_matches,
    rebuild_from_sources,
    select_official_matches,
)
from tennis_stats_scraper import match_record_summaries


def matchlog_html():
    def side(player, opponent, aces, first_serve):
        score = "6-4,6-4" if player == "Alpha" else "4-6,4-6"
        return f"""
        <table>
          <tr><td>Player: {player}</td><td>Opponent: {opponent}</td></tr>
          <tr><td>Tournament: US Open</td><td>2026-09-07 12:30:00</td></tr>
          <tr><td>Score: {score}</td></tr>
          <tr><td>Aces</td><td>{aces}</td></tr>
          <tr><td>Winners</td><td>20</td></tr>
          <tr><td>Unforced Errors</td><td>10</td></tr>
          <tr><td>1st Serve %</td><td>{first_serve}%</td></tr>
          <tr><td>Fastest Serve</td><td>120 mph</td></tr>
        </table>"""
    return (side("Alpha", "Beta", 5, 60) + side("Beta", "Alpha", 7, 50)).encode()


OFFICIAL_HTML = """
<table>
<tr><th>Tournament</th><th>Round</th><th>Player 1</th><th>Player 2</th>
<th>Date</th><th>Reported</th><th>Result</th></tr>
<tr><td></td><td>Tennis Elbow 4 (ATP Characters) - US Open 2026</td>
<td>Round of 16</td><td>Alpha</td><td>Beta</td><td>07.09.2026</td>
<td>2026-09-07 15:00:00</td><td>6-4,6-4</td></tr>
</table>
"""


def history_match_html(winner="Alpha", loser="Beta", score="6/4 6/4"):
    return f"""
    <html><head><title>Tennis Elbow - Match Log</title></head><body>
    <p>{winner} (ELO: 1500 +5 ; Crc = 111) def.
    {loser} (ELO: 1400 -5 ; Crc = 222) : {score} -
    US Open Arthur Ashe - 0:30'00 (1:10'00) -
    2026-09-10 12:30 [Online]</p>
    <table>
      <tr><td>6 / 10 = 60%</td><td>1ST SERVE %</td><td>5 / 10 = 50%</td></tr>
      <tr><td>5</td><td>ACES</td><td>7</td></tr>
      <tr><td>1</td><td>DOUBLE FAULTS</td><td>2</td></tr>
      <tr><td>190 Km/h</td><td>AVG 1st SERVE SPEED</td><td>180 Km/h</td></tr>
      <tr><td>20</td><td>WINNERS</td><td>15</td></tr>
      <tr><td>10</td><td>UNFORCED ERRORS</td><td>12</td></tr>
      <tr><td>5 / 8 = 63%</td><td>NET POINTS WON</td><td>3 / 8 = 38%</td></tr>
    </table></body></html>
    """


def base_workbook(path):
    workbook = Workbook()
    workbook.active.title = "atp"
    workbook["atp"]["A1"] = "scraped ATP sentinel"
    workbook.create_sheet("wta")["A1"] = "scraped WTA sentinel"
    workbook.create_sheet("ATP Summary")["A1"] = "ATP summary sentinel"
    workbook.create_sheet("WTA Summary")["A1"] = "WTA summary sentinel"
    workbook.save(path)
    workbook.close()


class MatchLogStatsTests(unittest.TestCase):
    def test_wta_screenshot_alias_canonicalizes_and_identifies_tour(self):
        extracted = {
            "player": {"name": "LVL_0_Gurl"},
            "opponent": {"name": "Unknown WTA Opponent"},
            "tour_hint": None,
            "is_doubles": False,
        }

        sheet, result = main.canonicalize_match(
            extracted,
            {"atp": {}, "wta": {}},
        )

        self.assertEqual(sheet, "wta")
        self.assertEqual(result["player"]["name"], "Danishusband-chan")
        self.assertNotIn("Name not found", result["player"].get("note", ""))

    def test_explicit_atp_screenshot_does_not_apply_wta_alias(self):
        extracted = {
            "player": {"name": "LVL_0_Gurl"},
            "opponent": {"name": "ATP Opponent"},
            "tour_hint": "atp",
            "is_doubles": False,
        }

        sheet, result = main.canonicalize_match(
            extracted,
            {"atp": {"atp opponent": "ATP Opponent"}, "wta": {}},
        )

        self.assertEqual(sheet, "atp")
        self.assertEqual(result["player"]["name"], "LVL_0_Gurl")

    def test_stats_question_parser_resolves_primary_player_and_character(self):
        with patch.object(
            main,
            "_stats_autocomplete_cache",
            (1, ["Dani21", "Grigor Dimitrov"]),
        ):
            parsed = main._parse_stats_question(
                "What are Dani's average aces when using Dimitrov?"
            )

        self.assertEqual(parsed["player_name"], "Dani21")
        self.assertIsNone(parsed["opponent_name"])
        self.assertEqual(parsed["character_name"], "Grigor Dimitrov")
        self.assertEqual(parsed["period"], "career")

    def test_character_filter_joins_stat_rows_to_all_results_characters(self):
        records = [{
            "player": "Dani21",
            "opponent": "fakefederer",
            "tour": "atp",
            "date": "2026-09-08",
            "result": "6-2 6-2 6-2",
            "tournament": "US Open 2026",
            "value": 7,
        }]
        official_results = [{
            "tour": "atp",
            "date": "08.09.2026",
            "result": "6-2,6-2,6-2",
            "tournament": "Tennis Elbow 4 (ATP Characters) - US Open 2026",
            "player1": "Dani21",
            "player2": "fakefederer",
            "player1_character": "G. Dimitrov",
            "player2_character": "G. Dimitrov",
        }]

        filtered = main._filter_stats_question_character_records(
            records,
            official_results,
            "Grigor Dimitrov",
        )

        self.assertEqual(filtered, records)

    def test_stats_planner_keeps_subject_before_faced_opponent(self):
        with patch.object(
            main,
            "_stats_autocomplete_cache",
            (1, ["Dani21", "Debuffy"]),
        ):
            merged = main._merge_stats_question_entities(
                {
                    "metric_key": "aces",
                    "player_name": "Debuffy",
                    "opponent_name": "Dani21",
                    "character_name": None,
                    "is_personal": False,
                },
                "How many aces does Dani21 average when he faces Debuffy?",
            )

        self.assertEqual(merged["player_name"], "Dani21")
        self.assertEqual(merged["opponent_name"], "Debuffy")

    def test_stats_parser_supports_best_at_profile_questions(self):
        with patch.object(
            main,
            "_stats_autocomplete_cache",
            (1, ["KINGBARBOZA"]),
        ):
            parsed = main._parse_stats_question(
                "What is KINGBARBOZA best at?"
            )

        self.assertEqual(parsed["question_type"], "best_at")
        self.assertIsNone(parsed["metric_key"])
        self.assertEqual(parsed["player_name"], "KINGBARBOZA")

    def test_stats_parser_supports_metric_leaderboard_questions(self):
        parsed = main._parse_stats_question(
            "Who is the best net player in the game?"
        )

        self.assertEqual(parsed["question_type"], "leaderboard")
        self.assertEqual(parsed["metric_key"], "net_points_won_pct")
        self.assertIsNone(parsed["player_name"])

    def test_stats_parser_supports_worst_and_ranked_leaderboards(self):
        worst = main._parse_stats_question(
            "Who is the worst net player in the game?"
        )
        second = main._parse_stats_question(
            "Who is the second best net player in the game?"
        )

        self.assertEqual(worst["question_type"], "leaderboard")
        self.assertEqual(worst["rank_direction"], "lowest")
        self.assertEqual(worst["rank_position"], 1)
        self.assertEqual(second["rank_direction"], "highest")
        self.assertEqual(second["rank_position"], 2)

    def test_stats_parser_supports_weakest_player_profile_questions(self):
        with patch.object(main, "_stats_autocomplete_cache", (1, ["Debuffy"])):
            for wording in (
                "What is Debuffy weakest in?",
                "What is Debuffy worst at?",
            ):
                parsed = main._parse_stats_question(wording)

                self.assertEqual(parsed["question_type"], "best_at")
                self.assertEqual(parsed["player_name"], "Debuffy")
                self.assertEqual(parsed["rank_direction"], "lowest")

    def test_stats_parser_does_not_treat_set_length_as_tournament(self):
        parsed = main._parse_stats_question(
            "What is the record for aces in a three setter?"
        )

        self.assertEqual(parsed["metric_key"], "aces")
        self.assertEqual(parsed["set_count"], 3)
        self.assertEqual(parsed["operation"], "max")
        self.assertIsNone(parsed["tournament_query"])

    def test_metric_leaderboard_response_uses_simple_screenshot_footer(self):
        response = main._format_stats_leaderboard_response(
            [
                {
                    "player": "Alpha",
                    "tour": "atp",
                    "value": 0.612,
                    "matches": 30,
                },
            ],
            "net_points_won_pct",
        )

        self.assertIn("Alpha", response)
        self.assertIn("61.2%", response)
        self.assertTrue(response.endswith("_Source: Screenshots._"))

    def test_metric_leaderboard_response_labels_worst_rank(self):
        response = main._format_stats_leaderboard_response(
            [
                {
                    "player": "Beta",
                    "tour": "atp",
                    "value": 0.312,
                    "matches": 25,
                },
            ],
            "net_points_won_pct",
            rank_direction="lowest",
            rank_position=1,
        )

        self.assertIn("Worst Net Points Won % players", response)

    def test_best_at_response_ranks_verified_profile_percentiles(self):
        response = main._format_best_at_response(
            {
                "matches": 6,
                "period_label": "Career",
                "metrics": [
                    ("1st Serve %", 0.84, 6),
                    ("Aces", 3.7, 6),
                ],
                "relative_profile": {
                    "serve": {
                        "metrics": [
                            {"metric": "1st Serve %", "percentile": 99, "players": 70},
                            {"metric": "Aces", "percentile": 92, "players": 70},
                        ],
                    },
                },
            },
            "KINGBARBOZA",
        )

        self.assertIn("1st Serve %", response)
        self.assertIn("99th percentile", response)
        self.assertIn("KINGBARBOZA is strongest", response)
        self.assertIn("complete stat data", response)
        self.assertIn("92nd percentile", response)
        self.assertIn("Source: Screenshots", response)

    def test_stats_recovery_message_offers_a_nearby_question(self):
        message = main._stats_question_recovery_message(
            "What is KINGBARBOZA's unusual stat?",
            {"player_name": "KINGBARBOZA", "metric_key": "aces"},
            "I couldn't answer that exact question",
        )

        self.assertIn("KINGBARBOZA", message)
        self.assertIn("average **Aces**", message)
        self.assertIn("Would you like to ask another stats question?", message)

    def test_best_at_response_handles_no_standout_and_personal_dashboard(self):
        response = main._format_best_at_response(
            {
                "matches": 4,
                "period_label": "Career",
                "metrics": [("Aces", 1.0, 4)],
                "relative_profile": {
                    "serve": {
                        "metrics": [
                            {"metric": "Aces", "percentile": 42, "players": 70},
                        ],
                    },
                },
            },
            "KINGBARBOZA",
            is_personal=True,
        )

        self.assertIn("clear standout strength", response)
        self.assertIn("`/mystats`", response)

    def test_weakest_at_response_ranks_verified_profile_percentiles_lowest_first(self):
        response = main._format_best_at_response(
            {
                "matches": 141,
                "period_label": "Career",
                "metrics": [
                    ("1st Serve Return Points Won %", 0.493, 138),
                    ("Return Points Won %", 0.49, 137),
                ],
                "relative_profile": {
                    "return": {
                        "metrics": [
                            {
                                "metric": "1st Serve Return Points Won %",
                                "percentile": 6,
                                "players": 331,
                            },
                            {
                                "metric": "Return Points Won %",
                                "percentile": 8,
                                "players": 344,
                            },
                        ],
                    },
                },
            },
            "Debuffy",
            strength=False,
        )

        self.assertIn("Debuffy is weakest in", response)
        self.assertIn("1st Serve Return Points Won %", response)
        self.assertIn("6th percentile", response)

    def test_unscoped_count_stat_combines_both_sides_of_each_match(self):
        records = [
            {
                "value": 41,
                "player": "elmanzanas",
                "opponent": "HSM09",
                "tour": "atp",
                "date": "2026-09-19",
                "tournament": "Guangzhou Challenger 75",
                "result": "6-3 6-7(5) 7-6(5)",
                "metric": "aces",
                "source": "screenshots",
            },
            {
                "value": 18,
                "player": "HSM09",
                "opponent": "elmanzanas",
                "tour": "atp",
                "date": "2026-09-19",
                "tournament": "Guangzhou Challenger 75",
                "result": "3-6 7-6(5) 6-7(5)",
                "metric": "aces",
                "source": "screenshots",
            },
        ]

        totals = main._aggregate_stats_question_match_totals(records, "aces")

        self.assertEqual(len(totals), 1)
        self.assertEqual(totals[0]["value"], 59)
        self.assertTrue(totals[0]["match_total"])

    def test_three_setter_aces_use_combined_match_total(self):
        records = [
            {
                "value": 57,
                "player": "GooeyHead",
                "opponent": "Dyl",
                "tour": "atp",
                "date": "2022-07-27",
                "tournament": "Ground_027 Washington",
                "result": "7-6 6-7 6-2",
                "metric": "aces",
                "source": "screenshots",
            },
            {
                "value": 43,
                "player": "Dyl",
                "opponent": "GooeyHead",
                "tour": "atp",
                "date": "2022-07-27",
                "tournament": "Ground_027 Washington",
                "result": "7-6 6-7 6-2",
                "metric": "aces",
                "source": "screenshots",
            },
        ]

        totals = main._aggregate_stats_question_match_totals(records, "aces")

        self.assertEqual(len(totals), 1)
        self.assertEqual(totals[0]["value"], 100)
        self.assertTrue(totals[0]["match_total"])

    def test_match_total_response_is_compact_but_keeps_question_echo(self):
        answer = main._format_stats_question_with_echo(
            "what is the record for aces in a 3 setter?",
            main._format_stats_match_total_response(
                {
                    "value": 100,
                    "side_values": [
                        {"player": "Dyl", "value": 43},
                        {"player": "GooeyHead", "value": 57},
                    ],
                },
                "aces",
                "Screenshots",
            ),
        )

        self.assertIn("**Question:**", answer)
        self.assertIn("**100 aces**", answer)
        self.assertIn("Dyl: 43", answer)
        self.assertIn("GooeyHead: 57", answer)
        self.assertIn("_Source: Screenshots._", answer)
        self.assertNotIn("verified observations", answer)
        self.assertNotIn("Tennis Elbow", answer)

    def test_stats_question_parser_resolves_unique_abbreviated_player(self):
        with patch.object(
            main,
            "_stats_autocomplete_cache",
            (1, ["Dani21", "Squeaky"]),
        ):
            parsed = main._parse_stats_question(
                "How many aces did Dani average with 3 sets?"
            )

        self.assertEqual(parsed["metric_key"], "aces")
        self.assertEqual(parsed["operation"], "average")
        self.assertEqual(parsed["set_count"], 3)
        self.assertEqual(parsed["player_name"], "Dani21")

    def test_query_match_stat_values_filters_exact_set_count(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            workbook = Workbook()
            atp = workbook.active
            atp.title = "MatchLog ATP"
            wta = workbook.create_sheet("MatchLog WTA")
            headers = [
                "match_id", "match_datetime", "date", "player", "opponent",
                "result", "aces", "tournament",
            ]
            atp.append(headers)
            wta.append(headers)
            atp.append([
                "three", "2026-09-10 12:00:00", "2026-09-10", "Alpha",
                "Beta", "6-4 4-6 6-2", 18, "Three-set match",
            ])
            atp.append([
                "two", "2026-09-11 12:00:00", "2026-09-11", "Alpha",
                "Gamma", "6-0 6-0", 99, "Two-set match",
            ])
            workbook.save(path)
            workbook.close()

            values = query_match_stat_values(path, "aces", set_count=3)

            self.assertEqual(len(values), 1)
            self.assertEqual(values[0]["value"], 18)
            self.assertEqual(values[0]["sets"], 3)
            opponent_values = query_match_stat_values(
                path,
                "aces",
                opponent_name="Beta",
            )
            self.assertEqual(len(opponent_values), 1)
            self.assertEqual(opponent_values[0]["opponent"], "Beta")

    def test_query_match_stat_values_derives_tiebreak_rate_from_score(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            workbook = Workbook()
            atp = workbook.active
            atp.title = "MatchLog ATP"
            wta = workbook.create_sheet("MatchLog WTA")
            headers = [
                "match_id", "match_datetime", "date", "player", "opponent",
                "result", "tournament",
            ]
            atp.append(headers)
            wta.append(headers)
            atp.append([
                "tb", "2026-09-10 12:00:00", "2026-09-10", "Alpha",
                "Beta", "7-6 6-4", "Tiebreak",
            ])
            atp.append([
                "tb", "2026-09-10 12:00:00", "2026-09-10", "Beta",
                "Alpha", "6-7 4-6", "Tiebreak",
            ])
            workbook.save(path)
            workbook.close()

            values = query_match_stat_values(
                path,
                "tiebreaks_won_pct",
                player_name="Alpha",
            )

            self.assertEqual(len(values), 1)
            self.assertEqual(values[0]["value"], 1.0)

    def test_match_record_summaries_reads_every_player_once_per_raw_match(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            workbook = Workbook()
            atp = workbook.active
            atp.title = "atp"
            wta = workbook.create_sheet("wta")
            headers = [
                "Player", "Opponent", "Tournament", "Date", "Result",
                "Unique ID B",
            ]
            atp.append(headers)
            atp.append([
                "Alpha", "Beta", "US Open", "2026-09-07", "6-4 6-4",
                "alpha-us-open",
            ])
            atp.append([
                "Alpha", "Beta", "US Open", "2026-09-07", "6-4 6-4",
                "alpha-us-open",
            ])
            atp.append([
                "No Ratings", "Gamma", "Paris", "2026-09-08", "6-2 6-2",
                "no-ratings-paris",
            ])
            atp.append([
                "No Score", "Delta", "Rome", "2026-09-09", None,
                "no-score-rome",
            ])
            wta.append(headers)
            wta.append([
                "Ria", "Mia", "Rome", "2026-09-09", "Scheduled",
                "ria-rome",
            ])
            workbook.save(path)
            workbook.close()

            summaries = match_record_summaries(path)

        self.assertEqual(
            [(summary["tour"], summary["player"], summary["matches"])
             for summary in summaries],
            [
                ("atp", "Alpha", 1),
                ("atp", "No Ratings", 1),
                ("atp", "No Score", 1),
            ],
        )

    def test_character_leaderboard_counts_both_sides_for_selected_tour(self):
        results = [
            {
                "tour": "atp",
                "p1_character": "R. Federer",
                "p2_character": "S. Wawrinka",
            },
            {
                "tour": "atp",
                "p1_character": "R. Federer",
                "p2_character": None,
            },
            {
                "tour": "wta",
                "p1_character": "R. Federer",
                "p2_character": "S. Williams",
            },
        ]
        cards = main._character_leaderboard_cards(results, "atp")
        self.assertEqual(
            [(card["character"], card["count"]) for card in cards],
            [("R. Federer", 2), ("S. Wawrinka", 1)],
        )
        self.assertAlmostEqual(cards[0]["percentage"], 2 / 3)

    def test_character_leaderboard_is_available_for_every_source(self):
        self.assertIn(
            main.MOST_PICKED_CHARACTERS_STAT,
            main._leaderboard_stat_options("screenshots"),
        )
        self.assertIn(
            main.MOST_PICKED_CHARACTERS_STAT,
            main._leaderboard_stat_options("matchlog"),
        )

    def test_persisted_results_fallback_keeps_character_picks(self):
        sources = [{
            "verified_matches": [{
                "tour": "atp",
                "rows": [{
                    "player": "Squeaky",
                    "opponent": "gosydar",
                    "character": "R. Federer",
                    "opponent_character": "S. Wawrinka",
                    "match_datetime": "2026-09-01 16:39:01",
                    "tournament": "US Open 2026",
                    "round": "Round of 32",
                    "result": "6-2 1-6 6-2 6-7 6-0",
                }],
            }],
        }]
        with patch.object(main, "load_matchlog_sources", return_value=sources):
            results = main._persisted_matchlog_results_for_player(
                "Squeaky", "atp"
            )
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["p1_character"], "R. Federer")
        self.assertEqual(results[0]["p2_character"], "S. Wawrinka")
        self.assertEqual(results[0]["date"], "01.09.2026")

    def test_relative_profiles_compare_serve_return_and_rally_population(self):
        target = {
            "1st Serve Won %": 0.75,
            "1st Serve Won % matches used": 3,
            "Return Points Won %": 0.40,
            "Return Points Won % matches used": 3,
            "Short Rallies Won (<5) %": 0.60,
            "Short Rallies Won (<5) % matches used": 3,
            "Double Faults": 1,
            "Double Faults matches used": 3,
        }
        population = [
            target,
            {
                "1st Serve Won %": 0.55,
                "1st Serve Won % matches used": 3,
                "Return Points Won %": 0.50,
                "Return Points Won % matches used": 3,
                "Short Rallies Won (<5) %": 0.45,
                "Short Rallies Won (<5) % matches used": 3,
                "Double Faults": 4,
                "Double Faults matches used": 3,
            },
            {
                "1st Serve Won %": 0.65,
                "1st Serve Won % matches used": 3,
                "Return Points Won %": 0.55,
                "Return Points Won % matches used": 3,
                "Short Rallies Won (<5) %": 0.50,
                "Short Rallies Won (<5) % matches used": 3,
                "Double Faults": 3,
                "Double Faults matches used": 3,
            },
        ]
        profiles = calculate_relative_profiles(target, population)
        self.assertGreater(
            profiles["serve"]["percentile"],
            profiles["return"]["percentile"],
        )
        self.assertGreater(
            profiles["rally"]["percentile"],
            profiles["return"]["percentile"],
        )
        double_faults = next(
            metric for metric in profiles["serve"]["metrics"]
            if metric["metric"] == "Double Faults"
        )
        self.assertGreater(double_faults["percentile"], 80)
        self.assertEqual(
            calculate_relative_profiles(target, [target]),
            {},
        )
        tied = calculate_relative_profiles(
            target,
            [target, dict(target)],
        )
        tied_serve = next(
            metric for metric in tied["serve"]["metrics"]
            if metric["metric"] == "1st Serve Won %"
        )
        self.assertEqual(tied_serve["percentile"], 50)
        unsupported = dict(target)
        unsupported["1st Serve Won % matches used"] = 0
        without_unsupported = calculate_relative_profiles(
            target,
            [target, unsupported],
        )
        self.assertNotIn(
            "1st Serve Won %",
            {
                metric["metric"]
                for metric in without_unsupported["serve"]["metrics"]
            },
        )

    def test_insights_treat_low_double_faults_as_tennis_strength(self):
        summary = {
            "relative_profile": {
                "serve": {
                    "percentile": 88,
                    "metrics": [
                        {
                            "metric": "Double Faults",
                            "percentile": 92,
                            "players": 40,
                        },
                        {
                            "metric": "1st Serve Won %",
                            "percentile": 75,
                            "players": 40,
                        },
                    ],
                },
                "return": {
                    "percentile": 28,
                    "metrics": [
                        {
                            "metric": "Return Points Won %",
                            "percentile": 28,
                            "players": 40,
                        },
                    ],
                },
            },
        }
        insights = main._generate_mystats_insights_sync(summary, {})
        strengths = " ".join(insights["strengths"])
        weaknesses = " ".join(insights["weaknesses"])
        self.assertIn("Your", strengths)
        self.assertIn("Your", weaknesses)
        self.assertNotIn("Our", strengths)
        self.assertNotIn("Our", weaknesses)
        self.assertIn("low double-fault rate", strengths)
        self.assertNotIn("Double Faults", weaknesses)
        self.assertIn("compact first-serve blocks", insights["focus"])
        self.assertNotIn("We should", insights["focus"])
        self.assertNotIn("Our ", insights["focus"])

    def _verified(self):
        parsed = parse_matchlog_html(matchlog_html(), "match.html")
        official = parse_official_results(OFFICIAL_HTML)
        rankings = {
            "atp": {"alpha": "Alpha", "beta": "Beta"},
            "wta": {},
        }
        return canonicalize_and_verify(parsed, rankings, official)

    def test_official_results_use_bare_first_page_and_reported_last_page(self):
        self.assertEqual(
            main.MATCHLOG_ALL_RESULTS_URL,
            "https://playwtsl.com/TE4/pages/all_results_fetch.php",
        )
        page = """
        <nav><ul class="pagination">
          <li><a href="./all_results.php?">1</a></li>
          <li><a href="./all_results.php?&pagination=2">2</a></li>
          <li><a href="./all_results.php?&pagination=28">28</a></li>
        </ul></nav>
        """
        self.assertEqual(main._matchlog_page_count(page), 28)

    def test_tournament_schedule_parser_reads_category_and_start_date(self):
        page = """
        <table>
          <thead>
            <tr>
              <th>Tournament</th><th>Location</th><th>Category</th>
              <th>Main Draw Size</th><th>Surface</th><th>Start Date</th>
              <th>Status</th><th>Champion</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><a href="../pages/tournament_page.php?tournament=Jinan_2025_TE4">
                Jinan</a></td>
              <td>China</td><td>Challenger 125</td><td>20</td>
              <td>Outdoor Hard</td><td>25.09.2025</td>
              <td>Completed</td><td>Alpha</td>
            </tr>
          </tbody>
        </table>
        """
        self.assertEqual(
            parse_tournaments_html(page),
            [{
                "tournament": "Jinan",
                "category": "Challenger 125",
                "start_date": "25.09.2025",
                "tour": "atp",
                "surface": "Outdoor Hard",
                "source_url": (
                    "../pages/tournament_page.php?"
                    "tournament=Jinan_2025_TE4"
                ),
            }],
        )

    def test_targeted_player_ids_preserve_same_name_across_tours(self):
        rankings = {
            "atp": {"shared": {"id": "10"}},
            "wta": {"shared": {"id": "20"}},
        }
        self.assertEqual(
            main._matchlog_player_ids(rankings)["shared"],
            {("atp", "10"), ("wta", "20")},
        )

    def test_batch_rebuild_preserves_screenshot_sheets_and_binds_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            added = rebuild_from_sources(
                path,
                [{
                    "source_hash": "a" * 64,
                    "submitter_id": 30,
                    "source_message_id": 10,
                    "attachment_id": 20,
                    "verified_matches": self._verified(),
                }],
                {30: "Alpha"},
            )
            self.assertEqual(added, 1)
            self.assertEqual(player_summary(path, 30)["player"], "Alpha")
            workbook = load_workbook(path, read_only=True)
            self.assertEqual(workbook["atp"]["A1"].value, "scraped ATP sentinel")
            self.assertEqual(workbook["wta"]["A1"].value, "scraped WTA sentinel")
            workbook.close()

    def test_parser_verifies_official_match_and_normalizes_speeds(self):
        verified = self._verified()
        self.assertEqual(len(verified), 1)
        self.assertEqual(verified[0]["tour"], "atp")
        alpha = verified[0]["rows"][0]
        beta = verified[0]["rows"][1]
        self.assertEqual(alpha["first_serve_pct"], 0.6)
        self.assertEqual(alpha["fastest_serve"], 193.1)
        self.assertEqual(alpha["fastest_serve_raw"], 120)
        self.assertEqual(alpha["fastest_serve_unit"], "mph")
        self.assertEqual(alpha["fastest_serve_mph"], 120)
        self.assertAlmostEqual(alpha["fastest_serve_kph"], 193.1)
        self.assertEqual(alpha["result"], "6-4 6-4")
        self.assertEqual(beta["result"], "4-6 4-6")
        self.assertIn("US Open 2026", alpha["tournament"])

    def test_real_te4_history_layout_produces_two_player_rows(self):
        parsed = parse_matchlog_html(
            history_match_html().encode(), "TrainingClub.007.html"
        )
        self.assertEqual(len(parsed), 1)
        winner, loser = parsed[0]["rows"]
        self.assertEqual((winner["player"], loser["player"]), ("Alpha", "Beta"))
        self.assertEqual((winner["result"], loser["result"]), (
            "6-4 6-4", "4-6 4-6"
        ))
        self.assertEqual(winner["aces"], 5)
        self.assertEqual(loser["aces"], 7)
        self.assertEqual(winner["first_serve_pct"], 0.6)
        self.assertEqual(winner["avg_first_serve_speed_kph"], 190)

    def test_real_te4_history_converts_mph_to_canonical_kph(self):
        raw = history_match_html().replace(
            "190 Km/h", "118 mph"
        ).replace(
            "180 Km/h", "112 mph"
        )
        winner, loser = parse_matchlog_html(
            raw.encode(), "TrainingClub.007.html"
        )[0]["rows"]
        self.assertEqual(winner["avg_first_serve_speed_raw"], 118)
        self.assertEqual(winner["avg_first_serve_speed_unit"], "mph")
        self.assertEqual(winner["avg_first_serve_speed_kph"], 189.9)
        self.assertEqual(winner["avg_first_serve_speed"], 189.9)
        self.assertEqual(loser["avg_first_serve_speed"], 180.2)

    def test_rebuild_canonicalizes_legacy_cached_speed_to_kph(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            verified = copy.deepcopy(self._verified())
            row = verified[0]["rows"][0]
            row["fastest_serve"] = 120
            row["fastest_serve_raw"] = 120
            row["fastest_serve_unit"] = "mph"
            row["fastest_serve_mph"] = 120
            row["fastest_serve_kph"] = 193.1
            rebuild_from_sources(
                path,
                [{
                    "source_hash": "legacy",
                    "submitter_id": 30,
                    "source_message_id": 10,
                    "attachment_id": 20,
                    "verified_matches": verified,
                }],
                {30: "Alpha"},
            )
            workbook = load_workbook(path, read_only=True, data_only=True)
            sheet = workbook[RAW_SHEETS["atp"]]
            headers = [cell.value for cell in sheet[1]]
            values = dict(zip(headers, next(sheet.iter_rows(
                min_row=2, max_row=2, values_only=True
            ))))
            workbook.close()
            self.assertEqual(values["fastest_serve"], 193.1)
            self.assertEqual(values["fastest_serve_raw"], 120)

    def test_mixed_history_keeps_only_official_matches(self):
        mixed = history_match_html() + history_match_html(
            "Practice One", "Practice Two", "6/0"
        )
        parsed = parse_matchlog_html(mixed.encode(), "history.html")
        rankings = {
            "atp": {
                "alpha": "Alpha", "beta": "Beta",
                "practice one": "Practice One",
                "practice two": "Practice Two",
            },
            "wta": {},
        }
        verified = select_official_matches(
            parsed, rankings, parse_official_results(OFFICIAL_HTML)
        )
        self.assertEqual(len(verified), 1)
        self.assertEqual(verified[0]["rows"][0]["player"], "Alpha")

    def test_trusted_mixed_history_still_excludes_practice_matches(self):
        mixed = history_match_html() + history_match_html(
            "Practice One", "Practice Two", "6/0"
        )
        parsed = parse_matchlog_html(mixed.encode(), "trusted-history.html")
        rankings = {
            "atp": {
                "alpha": "Alpha", "beta": "Beta",
                "practice one": "Practice One",
                "practice two": "Practice Two",
            },
            "wta": {},
        }
        verified = select_official_matches(
            parsed,
            rankings,
            parse_official_results(OFFICIAL_HTML),
            previously_verified=True,
        )
        self.assertEqual(len(verified), 1)
        self.assertEqual(verified[0]["rows"][0]["player"], "Alpha")

    def test_official_history_verifies_players_absent_from_current_rankings(self):
        parsed = parse_matchlog_html(
            history_match_html().encode(), "historical.html"
        )
        verified = select_official_matches(
            parsed,
            {"atp": {}, "wta": {}},
            parse_official_results(OFFICIAL_HTML),
        )
        self.assertEqual(len(verified), 1)
        self.assertEqual(
            {row["player"] for row in verified[0]["rows"]},
            {"Alpha", "Beta"},
        )

    def test_official_character_alias_maps_to_player_account(self):
        parsed = parse_matchlog_html(
            history_match_html(
                "Riachsoup", "Tsitsipas", "6/1 6/3"
            ).encode(),
            "montreal.html",
        )
        official = [{
            "tour": "atp",
            "player1": "Riachsoup",
            "player2": "karyj8",
            "player1_character": "G. Dimitrov",
            "player2_character": "S. Tsitsipas",
            "tournament": "Montreal 2026",
            "date": "04.08.2026",
            "result": "6-1,6-3",
        }]
        verified = select_official_matches(
            parsed,
            {"atp": {"riachsoup": "Riachsoup"}, "wta": {}},
            official,
        )
        self.assertEqual(len(verified), 1)
        self.assertEqual(
            {row["player"] for row in verified[0]["rows"]},
            {"Riachsoup", "karyj8"},
        )

    def test_seeded_matchlog_name_maps_to_official_account(self):
        parsed = parse_matchlog_html(
            history_match_html(
                "(1) Squeaky", "Riachsoup", "6/1 6/1"
            ).encode(),
            "seeded.html",
        )
        official = [{
            "tour": "atp",
            "player1": "Squeaky",
            "player2": "Riachsoup",
            "player1_character": "R. Federer",
            "player2_character": "G. Dimitrov",
            "tournament": "Mallorca 2026",
            "date": "26.06.2026",
            "result": "6-1,6-1",
        }]
        verified = select_official_matches(
            parsed, {"atp": {}, "wta": {}}, official
        )
        self.assertEqual(len(verified), 1)
        self.assertEqual(
            {row["player"] for row in verified[0]["rows"]},
            {"Squeaky", "Riachsoup"},
        )

    def test_unique_similar_name_maps_to_official_account(self):
        parsed = parse_matchlog_html(
            history_match_html(
                "HSM88", "Riachsoup", "3/6 6/3 6/2"
            ).encode(),
            "similar-name.html",
        )
        official = [{
            "tour": "atp",
            "player1": "HSM09",
            "player2": "Riachsoup",
            "player1_character": "Player A",
            "player2_character": "Player B",
            "tournament": "Dublin 2026",
            "date": "16.06.2026",
            "result": "3-6,6-3,6-2",
        }]
        verified = select_official_matches(
            parsed, {"atp": {}, "wta": {}}, official
        )
        self.assertEqual(len(verified), 1)
        self.assertEqual(
            {row["player"] for row in verified[0]["rows"]},
            {"HSM09", "Riachsoup"},
        )

    def test_ambiguous_similar_names_remain_rejected(self):
        parsed = parse_matchlog_html(
            history_match_html(
                "HSM88", "Riachsoup", "3/6 6/3 6/2"
            ).encode(),
            "ambiguous-name.html",
        )
        official = [
            {
                "tour": "atp",
                "player1": player,
                "player2": "Riachsoup",
                "player1_character": None,
                "player2_character": None,
                "tournament": "Dublin 2026",
                "date": "16.06.2026",
                "result": "3-6,6-3,6-2",
            }
            for player in ("HSM09", "HSM10")
        ]
        with self.assertRaisesRegex(ValueError, "No official WTSL matches"):
            select_official_matches(
                parsed, {"atp": {}, "wta": {}}, official
            )

    def test_fake_player_numeric_suffix_maps_to_official_player(self):
        parsed = parse_matchlog_html(
            history_match_html(
                "Riachsoup", "[Fake] RyGuy4696", "6/2 6/4"
            ).encode(),
            "fake-player.html",
        )
        official = [{
            "tour": "atp",
            "player1": "Riachsoup",
            "player2": "RyGuy",
            "player1_character": "G. Dimitrov",
            "player2_character": "F. Auger-Aliassime",
            "tournament": "Birmingham 2026",
            "date": "01.07.2026",
            "result": "6-2,6-4",
        }]
        verified = select_official_matches(
            parsed, {"atp": {}, "wta": {}}, official
        )
        self.assertEqual(len(verified), 1)
        self.assertEqual(
            {row["player"] for row in verified[0]["rows"]},
            {"Riachsoup", "RyGuy"},
        )

    def test_unique_pair_score_date_infers_wrong_event_label(self):
        parsed = parse_matchlog_html(
            history_match_html().replace(
                "US Open Arthur Ashe", "Dallas ATP 250"
            ).replace(
                "2026-09-10", "2026-09-07"
            ).encode(),
            "wrong-event.html",
        )
        official = [{
            "tour": "atp",
            "player1": "Alpha",
            "player2": "Beta",
            "player1_character": "Player A",
            "player2_character": "Player B",
            "tournament": "Belgrade 2026",
            "date": "07.09.2026",
            "result": "6-4,6-4",
        }]
        verified = select_official_matches(
            parsed,
            {"atp": {"alpha": "Alpha", "beta": "Beta"}, "wta": {}},
            official,
        )
        self.assertEqual(len(verified), 1)
        self.assertEqual(
            verified[0]["rows"][0]["tournament"], "Belgrade 2026"
        )

    def test_same_day_same_category_events_do_not_cross_match(self):
        parsed = parse_matchlog_html(
            history_match_html().replace(
                "US Open Arthur Ashe", "Miami ATP 250"
            ).replace(
                "2026-09-10", "2026-09-07"
            ).encode(),
            "same-category.html",
        )
        official = [
            {
                "tour": "atp",
                "player1": "Alpha",
                "player2": "Beta",
                "player1_character": "Player A",
                "player2_character": "Player B",
                "tournament": tournament,
                "date": "07.09.2026",
                "result": "6-4,6-4",
            }
            for tournament in ("Dallas ATP 250", "Belgrade ATP 250")
        ]
        with self.assertRaisesRegex(ValueError, "No official WTSL matches"):
            select_official_matches(
                parsed,
                {"atp": {"alpha": "Alpha", "beta": "Beta"}, "wta": {}},
                official,
            )

    def test_unique_event_score_recovers_unlabeled_opponent_alias(self):
        parsed = parse_matchlog_html(
            history_match_html("Alpha", "BetaAlias").encode(),
            "opponent-alias.html",
        )
        official = [{
            "tour": "atp",
            "player1": "Alpha",
            "player2": "Beta",
            "player1_character": "Player A",
            "player2_character": "Player B",
            "tournament": "US Open 2026",
            "date": "10.09.2026",
            "result": "6-4,6-4",
        }]
        verified = select_official_matches(
            parsed,
            {"atp": {"alpha": "Alpha", "beta": "Beta"}, "wta": {}},
            official,
        )
        self.assertEqual(len(verified), 1)
        self.assertEqual(verified[0]["rows"][1]["player"], "Beta")

    def test_short_sets_are_only_allowed_for_next_gen_finals(self):
        score = "4/1 4/2 4/0"
        ordinary = parse_matchlog_html(
            history_match_html(score=score).encode(), "ordinary-short.html"
        )
        ordinary_official = [{
            "tour": "atp",
            "player1": "Alpha",
            "player2": "Beta",
            "player1_character": "Player A",
            "player2_character": "Player B",
            "tournament": "Wimbledon 2026",
            "date": "10.09.2026",
            "result": "4-1,4-2,4-0",
        }]
        with self.assertRaisesRegex(ValueError, "No official WTSL matches"):
            select_official_matches(
                ordinary,
                {"atp": {"alpha": "Alpha", "beta": "Beta"}, "wta": {}},
                ordinary_official,
            )

        next_gen = parse_matchlog_html(
            history_match_html(score=score).replace(
                "US Open Arthur Ashe", "Next Gen ATP Finals"
            ).encode(),
            "next-gen-short.html",
        )
        next_gen_official = [{
            **ordinary_official[0],
            "tournament": "Next Gen Finals 2026",
        }]
        verified = select_official_matches(
            next_gen,
            {"atp": {"alpha": "Alpha", "beta": "Beta"}, "wta": {}},
            next_gen_official,
        )
        self.assertEqual(len(verified), 1)

    def test_atp_cup_is_trusted_when_absent_from_official_feed(self):
        parsed = parse_matchlog_html(
            history_match_html().replace(
                "US Open Arthur Ashe", "ATP Cup"
            ).encode(),
            "atp-cup.html",
        )
        verified = select_official_matches(
            parsed,
            {"atp": {"alpha": "Alpha", "beta": "Beta"}, "wta": {}},
            [],
        )
        self.assertEqual(len(verified), 1)
        self.assertEqual(verified[0]["rows"][0]["tournament"], "ATP Cup")

    def test_indexed_reconciliation_preserves_player_aliases_and_tours(self):
        summary = {
            "player": "HSM88",
            "tour": "atp",
            "source": "screenshots",
            "matches": 1,
            "period": "career",
            "match_records": [{
                "match_key": "alias-match",
                "date": "2026-01-10",
                "tournament": "ATP 250 Dubai",
                "opponent": "Opponent",
                "result": "6-4 6-4",
            }],
        }
        official = [
            {
                "tour": "atp",
                "p1": "HSM09",
                "p2": "Opponent",
                "date": "2026-01-10",
                "tournament": "ATP 250 Dubai",
                "result": "6-4 6-4",
            },
            {
                "tour": "wta",
                "p1": "HSM09",
                "p2": "Opponent",
                "date": "2026-01-10",
                "tournament": "WTA 250 Dubai",
                "result": "6-4 6-4",
            },
        ]

        index = main._screenshot_official_results_by_player(official)
        self.assertEqual(
            len(index[("atp", main._dashboard_player_key("HSM88"))]),
            1,
        )
        exclusions = main._screenshot_statistics_exclusion_keys(
            [copy.deepcopy(summary)],
            official,
        )
        self.assertNotIn(
            "alias-match",
            exclusions["atp"].get("HSM88", set()),
        )

    def test_unofficial_match_is_rejected(self):
        parsed = parse_matchlog_html(matchlog_html(), "match.html")
        rankings = {
            "atp": {"alpha": "Alpha", "beta": "Beta"},
            "wta": {},
        }
        with self.assertRaisesRegex(ValueError, "not an official result"):
            canonicalize_and_verify(parsed, rankings, [])

    def test_delayed_report_date_is_allowed_but_wrong_score_is_rejected(self):
        html_with_score = matchlog_html().replace(
            b"2026-09-07", b"2026-09-10"
        )
        parsed = parse_matchlog_html(html_with_score, "delayed.html")
        rankings = {
            "atp": {"alpha": "Alpha", "beta": "Beta"},
            "wta": {},
        }
        official = parse_official_results(OFFICIAL_HTML)
        verified = canonicalize_and_verify(parsed, rankings, official)
        self.assertEqual(len(verified), 1)

        wrong = parse_matchlog_html(
            html_with_score.replace(b"6-4,6-4", b"6-0,6-0"),
            "wrong-score.html",
        )
        with self.assertRaisesRegex(ValueError, "not an official result"):
            canonicalize_and_verify(wrong, rankings, official)

    def test_missing_score_is_rejected(self):
        without_score = re.sub(
            rb"<tr><td>Score: [^<]+</td></tr>", b"", matchlog_html()
        )
        parsed = parse_matchlog_html(without_score, "no-score.html")
        rankings = {
            "atp": {"alpha": "Alpha", "beta": "Beta"},
            "wta": {},
        }
        with self.assertRaisesRegex(ValueError, "score is required"):
            canonicalize_and_verify(
                parsed, rankings, parse_official_results(OFFICIAL_HTML)
            )

    def test_separate_sheets_and_duplicate_file_and_match_are_safe(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            verified = self._verified()
            source_hash = hashlib.sha256(matchlog_html()).hexdigest()
            result = append_submission(
                path, verified, message_id=10, attachment_id=20,
                submitter_id=30, source_hash=source_hash,
            )
            self.assertEqual(result["added"], 1)

            duplicate_file = append_submission(
                path, verified, message_id=11, attachment_id=21,
                submitter_id=30, source_hash=source_hash,
            )
            self.assertEqual(duplicate_file, {"added": 0, "duplicate": "file"})

            duplicate_match = append_submission(
                path, verified, message_id=12, attachment_id=22,
                submitter_id=30, source_hash="different-hash",
            )
            self.assertEqual(
                duplicate_match, {"added": 0, "duplicate": "match"}
            )

            workbook = load_workbook(path, read_only=True, data_only=True)
            self.assertEqual(workbook["atp"]["A1"].value, "scraped ATP sentinel")
            self.assertEqual(
                workbook["ATP Summary"]["A1"].value, "ATP summary sentinel"
            )
            self.assertEqual(workbook[RAW_SHEETS["atp"]].max_row, 3)
            self.assertEqual(workbook[RAW_SHEETS["wta"]].max_row, 1)
            self.assertIn(SUMMARY_SHEETS["atp"], workbook.sheetnames)
            workbook.close()

    def test_reconcile_removes_only_unofficial_matchlog_source_rows(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            official = self._verified()[0]
            practice = copy.deepcopy(official)
            practice["match_id"] = "practice-set"
            for index, row in enumerate(practice["rows"]):
                row["match_id"] = "practice-set"
                row["player"] = ("Practice One", "Practice Two")[index]
                row["opponent"] = ("Practice Two", "Practice One")[index]
            append_submission(
                path,
                [official, practice],
                message_id=10,
                attachment_id=20,
                submitter_id=30,
                source_hash="mixed-source",
            )
            bind_player_identity(path, 30, "Alpha", "admin receipt")

            result = reconcile_source_matches(
                path, "mixed-source", [official]
            )

            self.assertEqual(
                result, {"removed_rows": 2, "removed_matches": 1}
            )
            workbook = load_workbook(path, read_only=True, data_only=True)
            self.assertEqual(workbook["atp"]["A1"].value, "scraped ATP sentinel")
            self.assertEqual(
                workbook["ATP Summary"]["A1"].value, "ATP summary sentinel"
            )
            self.assertEqual(workbook[RAW_SHEETS["atp"]].max_row, 3)
            self.assertEqual(workbook[SUMMARY_SHEETS["atp"]].max_row, 3)
            self.assertEqual(
                workbook["MatchLog Identities"].max_row, 2
            )
            workbook.close()
            self.assertEqual(player_summary(path, 30)["matches"], 1)

    def test_summary_uses_persisted_discord_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            append_submission(
                path, self._verified(), message_id=10, attachment_id=20,
                submitter_id=30, source_hash="first",
            )
            bind_player_identity(path, 30, "Alpha", "admin receipt")
            summary = player_summary(path, 30)
            self.assertEqual(summary["player"], "Alpha")
            self.assertEqual(summary["matches"], 1)
            metrics = {label: (value, count) for label, value, count in summary["metrics"]}
            self.assertEqual(metrics["Aces"], (5, 1))
            self.assertEqual(metrics["1st Serve %"], (0.6, 1))
            workbook = load_workbook(path, read_only=True, data_only=True)
            sheet = workbook[SUMMARY_SHEETS["atp"]]
            headers = [cell.value for cell in sheet[1]]
            values = {
                header: sheet.cell(2, column).value
                for column, header in enumerate(headers, start=1)
            }
            self.assertEqual(values["Serve (Overall)"], 65)
            self.assertIsNone(values["Return (Overall)"])
            self.assertIsNone(values["Under Pressure"])
            workbook.close()
            rendered = format_player_summary(summary)
            self.assertIn("Official matches recorded: **1**", rendered)
            self.assertIn("**Serve Rating:** 65", rendered)
            self.assertIn("**Return Rating:** Not available", rendered)
            self.assertIn("**Under Pressure:** Not available", rendered)
            self.assertIn("60.0%", rendered)
            speed_summary = {
                **summary,
                "metrics": [
                    ("Avg 1st Serve Speed", 190, 1),
                ],
            }
            self.assertIn(
                "**Avg 1st Serve Speed:** 190 km/h",
                format_player_summary(speed_summary),
            )
            named = player_summary_by_name(path, "  ALPHA ")
            self.assertEqual(named["player"], "Alpha")

    def test_summary_merges_confirmed_ruze_identity_alias(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            ruze_match = copy.deepcopy(self._verified()[0])
            alias_match = copy.deepcopy(ruze_match)
            for match, player_name, match_id in (
                (ruze_match, "ruze", "ruze-match"),
                (alias_match, "itsruze", "itsruze-match"),
            ):
                match["match_id"] = match_id
                for row in match["rows"]:
                    row["match_id"] = match_id
                    if str(row.get("player") or "").casefold() == "alpha":
                        row["player"] = player_name
                    if str(row.get("opponent") or "").casefold() == "alpha":
                        row["opponent"] = player_name
            append_submission(
                path,
                [ruze_match, alias_match],
                message_id=10,
                attachment_id=20,
                submitter_id=30,
                source_hash="ruze-alias-source",
            )
            bind_player_identity(path, 30, "itsruze", "admin receipt", "atp")

            linked = player_summary(path, 30, "atp")
            direct = player_summary_by_name(path, "ATP: ruze")

            self.assertEqual(linked["matches"], 2)
            self.assertEqual(direct["matches"], 2)

    def test_named_summary_filters_raw_rows_by_requested_period(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            recent = copy.deepcopy(self._verified()[0])
            old = copy.deepcopy(recent)
            undated = copy.deepcopy(recent)
            for match, match_id, match_datetime, aces in (
                (recent, "recent", "2026-09-15 12:30:00", 5),
                (old, "old", "2026-06-01 12:30:00", 11),
                (undated, "undated", None, 20),
            ):
                match["match_id"] = match_id
                for row in match["rows"]:
                    row["match_id"] = match_id
                    row["match_datetime"] = match_datetime
                match["rows"][0]["aces"] = aces
            append_submission(
                path, [recent, old, undated], message_id=10, attachment_id=20,
                submitter_id=30, source_hash="periods",
            )

            career = player_summary_by_name(path, "Alpha", as_of="2026-10-01")
            thirty_days = player_summary_by_name(
                path, "Alpha", period="30d", as_of="2026-10-01"
            )
            year = player_summary_by_name(
                path, "Alpha", period="year", as_of="2026-10-01"
            )
            fifty_two_weeks = player_summary_by_name(
                path, "Alpha", period="52w", as_of="2026-10-01"
            )

            self.assertEqual((career["period"], career["period_label"]), (
                "career", "Career",
            ))
            self.assertEqual(career["matches"], 3)
            self.assertEqual((thirty_days["period"], thirty_days["matches"]), (
                "30d", 1,
            ))
            self.assertEqual(dict(
                (label, value) for label, value, _count in thirty_days["metrics"]
            )["Aces"], 5)
            self.assertEqual(year["matches"], 2)
            self.assertEqual(fifty_two_weeks["matches"], 2)

    def test_matchlog_ratings_use_available_atp_components(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            verified = copy.deepcopy(self._verified())
            alpha, beta = verified[0]["rows"]
            alpha.update({
                "result": "6-7 6-4 6-3",
                "first_serve_won_pct": 0.70,
                "second_serve_won_pct": 0.50,
                "break_points_won_pct": 0.40,
                "break_points_won": 2,
                "break_point_opportunities": 5,
                "double_faults": 1,
            })
            beta.update({
                "result": "7-6 4-6 3-6",
                "first_serve_won_pct": 0.60,
                "second_serve_won_pct": 0.45,
                "break_points_won_pct": 0.25,
                "break_points_won": 1,
                "break_point_opportunities": 4,
            })
            append_submission(
                path,
                verified,
                message_id=10,
                attachment_id=20,
                submitter_id=30,
                source_hash="atp-components",
            )
            bind_player_identity(path, 30, "Alpha", "admin receipt")
            summary = player_summary(path, 30)
            metrics = {
                label: value
                for label, value, _count in summary["metrics"]
            }
            ratings = dict(summary["ratings"])
            self.assertAlmostEqual(
                metrics["1st Serve Return Points Won %"], 0.40
            )
            self.assertAlmostEqual(
                metrics["2nd Serve Return Points Won %"], 0.55
            )
            self.assertAlmostEqual(metrics["Break Points Saved %"], 0.75)
            self.assertEqual(metrics["Tie-breaks Won %"], 0)
            self.assertEqual(metrics["Deciding Sets Won %"], 1)
            self.assertAlmostEqual(ratings["Serve Rating"], 184)
            self.assertAlmostEqual(ratings["Return Rating"], 135)
            self.assertAlmostEqual(ratings["Under Pressure"], 215)

    def test_deciding_set_result_uses_authoritative_oriented_score_not_elo(self):
        row = {
            "result": "3-6,6-3,6-4",
            "player_elo_change": -7,
        }
        derived = _derived_match_stats(row, None)
        self.assertEqual(derived["deciding_sets_won_pct"], 1)
        reversed_row = {
            "result": "6-3,3-6,4-6",
            "player_elo_change": 7,
        }
        reversed_derived = _derived_match_stats(reversed_row, None)
        self.assertEqual(reversed_derived["deciding_sets_won_pct"], 0)

    def test_persisted_shared_score_is_reoriented_from_official_winner(self):
        stored = {
            "verified_matches": [{
                "match_id": "franky-squeaky",
                "rows": [
                    {
                        "player": "Squeaky",
                        "opponent": "Franky Franchicha",
                        "result": "3-6,6-3,6-4",
                        "match_datetime": "2026-08-01 14:20:00",
                        "tournament": "Washington 2026",
                        "player_elo_change": 7,
                    },
                    {
                        "player": "Franky Franchicha",
                        "opponent": "Squeaky",
                        "result": "3-6,6-3,6-4",
                        "match_datetime": "2026-08-01 14:20:00",
                        "tournament": "Washington 2026",
                        "player_elo_change": -7,
                    },
                ],
            }],
        }
        rankings = {
            "atp": {
                "squeaky": "Squeaky",
                "franky franchicha": "Franky Franchicha",
            },
            "wta": {},
        }
        official = [{
            "player1": "Franky Franchicha",
            "player2": "Squeaky",
            "date": "02.08.2026",
            "result": "3-6,6-3,6-4",
            "tournament": "Washington 2026",
            "tour": "atp",
        }]
        sources, preserved_without_refresh = main._reverify_persisted_matchlog_sources(
            [stored], rankings, official
        )
        self.assertEqual(preserved_without_refresh, 0)
        rows = sources[0]["verified_matches"][0]["rows"]
        by_player = {row["player"]: row for row in rows}
        self.assertEqual(
            by_player["Franky Franchicha"]["result"],
            "3-6 6-3 6-4",
        )
        self.assertEqual(by_player["Squeaky"]["result"], "6-3 3-6 4-6")
        self.assertEqual(
            _derived_match_stats(by_player["Squeaky"], None)[
                "deciding_sets_won_pct"
            ],
            0,
        )

    def test_persisted_match_is_preserved_when_official_feed_cannot_refresh_it(self):
        stored_match = {
            "match_id": "historical",
            "rows": [{
                "player": "Historical Player",
                "opponent": "Historical Opponent",
                "result": "6-4,6-4",
            }],
        }
        sources, preserved = main._reverify_persisted_matchlog_sources(
            [{"verified_matches": [stored_match]}],
            {"atp": {}, "wta": {}},
            [],
        )
        self.assertEqual(preserved, 1)
        self.assertEqual(sources[0]["verified_matches"], [stored_match])

    def test_persisted_source_reparses_raw_html_to_recover_new_matches(self):
        old_match = {"tour": "atp", "match_id": "old", "rows": []}
        recovered = {"tour": "atp", "match_id": "recovered", "rows": []}
        source = {
            "filename": "history.html",
            "raw_html": b"retained source",
            "verified_matches": [old_match],
        }
        with (
            patch.object(
                main,
                "parse_matchlog_html",
                return_value=[{"match_id": "parsed"}],
            ) as parse,
            patch.object(
                main,
                "select_official_matches",
                return_value=[old_match, recovered],
            ) as select,
        ):
            sources, preserved = main._reverify_persisted_matchlog_sources(
                [source],
                {"atp": {}, "wta": {}},
                [],
            )
        parse.assert_called_once_with(b"retained source", "history.html")
        select.assert_called_once()
        self.assertEqual(preserved, 0)
        self.assertEqual(
            [match["match_id"] for match in sources[0]["verified_matches"]],
            ["old", "recovered"],
        )
        self.assertEqual(
            sources[0]["verification_version"],
            main.MATCHLOG_VERIFICATION_VERSION,
        )

    def test_identifiable_raw_coverage_includes_unverified_older_records(self):
        parsed = [{
            "match_id": "raw-old",
            "rows": [
                {
                    "player": "Alpha",
                    "opponent": "Unknown",
                    "match_datetime": "2023-04-05 12:00:00",
                },
                {
                    "player": "Unknown",
                    "opponent": "Alpha",
                    "match_datetime": "2023-04-05 12:00:00",
                },
            ],
        }]
        official = [{
            "tour": "atp",
            "player1": "Alpha",
            "player2": "Beta",
            "player1_character": "",
            "player2_character": "",
        }]
        self.assertEqual(
            identifiable_raw_coverage(parsed, official),
            [{
                "tour": "atp",
                "player": "Alpha",
                "first_record": "2023-04-05",
            }],
        )

    def test_tiebreak_rating_uses_all_tiebreaks_not_match_averages(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            first = copy.deepcopy(self._verified()[0])
            first["match_id"] = "one-tiebreak"
            first["rows"][0].update({
                "match_id": "one-tiebreak",
                "result": "6-7 6-4 6-3",
            })
            first["rows"][1].update({
                "match_id": "one-tiebreak",
                "result": "7-6 4-6 3-6",
            })
            second = copy.deepcopy(self._verified()[0])
            second["match_id"] = "three-tiebreaks"
            second["rows"][0].update({
                "match_id": "three-tiebreaks",
                "result": "7-6 6-7 7-6",
            })
            second["rows"][1].update({
                "match_id": "three-tiebreaks",
                "result": "6-7 7-6 6-7",
            })
            append_submission(
                path,
                [first, second],
                message_id=10,
                attachment_id=20,
                submitter_id=30,
                source_hash="tiebreak-weighting",
            )
            bind_player_identity(path, 30, "Alpha", "admin receipt")
            summary = player_summary(path, 30)
            metrics = {
                label: (value, count)
                for label, value, count in summary["metrics"]
            }
            self.assertEqual(metrics["Tie-breaks Won %"], (0.5, 4))
            self.assertEqual(metrics["Deciding Sets Won %"], (1, 2))

    def test_zero_break_point_opportunities_are_not_rated(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            verified = copy.deepcopy(self._verified())
            alpha, beta = verified[0]["rows"]
            alpha.update({
                "break_points_won_pct": 0,
                "break_points_won": 0,
                "break_point_opportunities": 0,
            })
            beta.update({
                "break_points_won_pct": 0,
                "break_points_won": 0,
                "break_point_opportunities": 0,
            })
            append_submission(
                path, verified, message_id=10, attachment_id=20,
                submitter_id=30, source_hash="no-break-points",
            )
            bind_player_identity(path, 30, "Alpha", "admin receipt")
            summary = player_summary(path, 30)
            metrics = {label for label, _value, _count in summary["metrics"]}
            self.assertNotIn("Break Points Won %", metrics)
            self.assertNotIn("Break Points Saved %", metrics)

    def test_discord_identity_can_bind_one_player_per_tour(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            atp = self._verified()[0]
            wta = copy.deepcopy(atp)
            wta["tour"] = "wta"
            wta["match_id"] = "wta-identity"
            for row in wta["rows"]:
                row["match_id"] = "wta-identity"
            append_submission(
                path, [atp, wta], message_id=10, attachment_id=20,
                submitter_id=30, source_hash="both-tours",
            )
            bind_player_identity(path, 30, "Alpha", "ATP receipt", "atp")
            bind_player_identity(path, 30, "Alpha", "WTA receipt", "wta")
            self.assertEqual(player_summary(path, 30, "atp")["tour"], "atp")
            self.assertEqual(player_summary(path, 30, "wta")["tour"], "wta")
            # An unqualified request is intentionally ambiguous for two links.
            self.assertIsNone(player_summary(path, 30))

    def test_player_comparison_uses_na_for_missing_values(self):
        first = {
            "player": "Alpha",
            "matches": 4,
            "ratings": [
                ("Serve Rating", 180),
                ("Return Rating", None),
                ("Under Pressure", 44),
            ],
            "metrics": [("Aces", 5, 4), ("1st Serve %", 0.61, 4)],
        }
        second = {
            "player": "Beta",
            "matches": 3,
            "ratings": [
                ("Serve Rating", 170),
                ("Return Rating", 100),
                ("Under Pressure", None),
            ],
            "metrics": [("Aces", 3, 3)],
        }
        rendered = format_player_comparison(first, second)
        self.assertIn("**Alpha vs Beta**", rendered)
        self.assertIn("**Serve Rating:** 180 | 170", rendered)
        self.assertIn("**Return Rating:** N/A | 100", rendered)
        self.assertIn("**1st Serve %:** 61.0% | N/A", rendered)
        first["metrics"].append(("Fastest Serve", 193.1, 4))
        second["metrics"].append(("Fastest Serve", 188, 3))
        rendered = format_player_comparison(first, second)
        self.assertIn("**Fastest Serve:** 193.1 km/h | 188 km/h", rendered)

    def test_named_summary_requires_tour_for_shared_name(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "stats.xlsx"
            workbook = Workbook()
            workbook.remove(workbook.active)
            for tour, sheet_name in SUMMARY_SHEETS.items():
                sheet = workbook.create_sheet(sheet_name)
                sheet.append(["Player", "Unique matches"])
                sheet.append(["Shared Name", 1 if tour == "atp" else 2])
            for sheet_name in RAW_SHEETS.values():
                sheet = workbook.create_sheet(sheet_name)
                sheet.append(["player"])
            workbook.save(path)
            workbook.close()

            with self.assertRaises(AmbiguousPlayerNameError):
                player_summary_by_name(path, "Shared Name")
            summary = player_summary_by_name(path, "WTA: Shared Name")
            self.assertEqual(summary["tour"], "wta")
            self.assertEqual(summary["matches"], 2)

            workbook = load_workbook(path)
            identity_sheet = workbook.create_sheet("MatchLog Identities")
            identity_sheet.append(["Discord User ID", "Player", "Receipt"])
            identity_sheet.append(["30", "WTA: Shared Name", "approved"])
            workbook.save(path)
            workbook.close()
            self.assertEqual(player_summary(path, 30)["tour"], "wta")

    def test_player_summary_names_qualifies_only_shared_names(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "stats.xlsx"
            workbook = Workbook()
            workbook.remove(workbook.active)
            for tour, sheet_name in SUMMARY_SHEETS.items():
                sheet = workbook.create_sheet(sheet_name)
                sheet.append(["Player", "Unique matches"])
                sheet.append(["Shared Name", 1])
                sheet.append([
                    "Alpha" if tour == "atp" else "Beta",
                    1,
                ])
            workbook.save(path)
            workbook.close()

            self.assertEqual(
                player_summary_names(path),
                ["Alpha", "ATP: Shared Name", "Beta", "WTA: Shared Name"],
            )

    def test_summary_counts_matches_independently_per_metric(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            first = self._verified()[0]
            second = copy.deepcopy(first)
            second["match_id"] = "second-official-match"
            for row in second["rows"]:
                row["match_id"] = second["match_id"]
                row["aces"] = None
            append_submission(
                path, [first, second], message_id=10, attachment_id=20,
                submitter_id=30, source_hash="two-matches",
            )
            bind_player_identity(path, 30, "Alpha", "admin receipt")
            summary = player_summary(path, 30)
            metrics = {
                label: (value, count)
                for label, value, count in summary["metrics"]
            }
            self.assertEqual(summary["matches"], 2)
            self.assertEqual(metrics["Aces"], (5, 1))
            self.assertEqual(metrics["Winners"], (20, 2))

    def test_canonical_name_resolution_handles_accents(self):
        parsed = parse_matchlog_html(
            matchlog_html().replace(b"Alpha", "Álpha".encode()), "match.html"
        )
        rankings = {
            "atp": {"álpha": "Álpha", "beta": "Beta"},
            "wta": {},
        }
        official = parse_official_results(
            OFFICIAL_HTML.replace("Alpha", "Álpha")
        )
        verified = canonicalize_and_verify(parsed, rankings, official)
        self.assertEqual(verified[0]["rows"][0]["player"], "Álpha")

    def test_explicit_wta_event_routes_to_wta_sheets(self):
        parsed = parse_matchlog_html(matchlog_html(), "wta.html")
        official = parse_official_results(
            OFFICIAL_HTML.replace(
                "(ATP Characters)", "(WTA Characters)"
            )
        )
        rankings = {
            "atp": {},
            "wta": {"alpha": "Alpha", "beta": "Beta"},
        }
        verified = canonicalize_and_verify(parsed, rankings, official)
        self.assertEqual(verified[0]["tour"], "wta")

    def test_untrusted_filename_is_safe_for_excel(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            verified = self._verified()
            for row in verified[0]["rows"]:
                row["source_file"] = '=HYPERLINK("https://example.com")'
            append_submission(
                path, verified, message_id=10, attachment_id=20,
                submitter_id=30, source_hash="safe-file",
            )
            workbook = load_workbook(path, read_only=True, data_only=False)
            sheet = workbook[RAW_SHEETS["atp"]]
            headers = [cell.value for cell in sheet[1]]
            source_column = headers.index("source_file") + 1
            self.assertTrue(
                sheet.cell(2, source_column).value.startswith("'=")
            )
            workbook.close()

    def test_same_match_id_is_independent_between_tours(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            atp = self._verified()[0]
            wta = copy.deepcopy(atp)
            wta["tour"] = "wta"
            append_submission(
                path, [atp], message_id=10, attachment_id=20,
                submitter_id=30, source_hash="atp-copy",
            )
            result = append_submission(
                path, [wta], message_id=11, attachment_id=21,
                submitter_id=31, source_hash="wta-copy",
            )
            self.assertEqual(result["added"], 1)
            workbook = load_workbook(path, read_only=True)
            self.assertEqual(workbook[RAW_SHEETS["atp"]].max_row, 3)
            self.assertEqual(workbook[RAW_SHEETS["wta"]].max_row, 3)
            workbook.close()

    def test_submitter_display_name_cannot_create_identity_binding(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            append_submission(
                path, self._verified(), message_id=10, attachment_id=20,
                submitter_id=30, source_hash="unapproved-submitter",
            )
            self.assertIsNone(player_summary(path, 30))

    def test_upload_csv_matches_reference_schema_and_preserves_player_id(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            path = directory / "stats.xlsx"
            template = directory / "template.csv"
            base_workbook(path)
            append_submission(
                path, self._verified(), message_id=10, attachment_id=20,
                submitter_id=30, source_hash="csv-source",
            )
            template.write_text(
                "pl_stats_pl_ID,pl_name,pl_first_serve_perc,pl_aces,"
                "pl_double_faults,pl_first_serve_speed,pl_second_serve_speed,"
                "pl_net_points,pl_winners,pl_forced_errors,pl_unforced_errors,"
                "pl_breakpoint_conversion,pl_short_rallies_won,"
                "pl_medium_rallies_won,pl_long_rallies_won,"
                "pl_first_serve_points_won,pl_second_serve_points_won,"
                "pl_return_points_won,pl_rally_length,pl_tour\n"
                "465,Alpha,,,,,,,,,,,,,,,,,,1.0\n"
                "10,Beta,,,,,,,,,,,,,,,,,,1.0\n",
                encoding="utf8",
            )
            rows = list(csv.DictReader(
                build_upload_csv(path, template).decode("utf-8-sig").splitlines()
            ))
            self.assertEqual(len(rows), 3)  # instruction + two players
            alpha = next(row for row in rows if row["pl_name"] == "Alpha")
            self.assertEqual(alpha["pl_stats_pl_ID"], "465")
            self.assertEqual(alpha["pl_first_serve_perc"], "60.0")
            self.assertEqual(alpha["pl_aces"], "5.0")
            self.assertEqual(alpha["pl_tour"], "1.0")

    def test_upload_csv_player_ids_are_scoped_by_tour(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            path = directory / "stats.xlsx"
            template = directory / "template.csv"
            base_workbook(path)
            atp = self._verified()[0]
            wta = copy.deepcopy(atp)
            wta["tour"] = "wta"
            append_submission(
                path, [atp], message_id=10, attachment_id=20,
                submitter_id=30, source_hash="atp-csv",
            )
            append_submission(
                path, [wta], message_id=11, attachment_id=21,
                submitter_id=31, source_hash="wta-csv",
            )
            template.write_text(
                ",".join([
                    "pl_stats_pl_ID", "pl_name", "pl_first_serve_perc",
                    "pl_aces", "pl_double_faults", "pl_first_serve_speed",
                    "pl_second_serve_speed", "pl_net_points", "pl_winners",
                    "pl_forced_errors", "pl_unforced_errors",
                    "pl_breakpoint_conversion", "pl_short_rallies_won",
                    "pl_medium_rallies_won", "pl_long_rallies_won",
                    "pl_first_serve_points_won",
                    "pl_second_serve_points_won",
                    "pl_return_points_won", "pl_rally_length", "pl_tour",
                ])
                + "\n100,Alpha,,,,,,,,,,,,,,,,,,1.0"
                + "\n200,Alpha,,,,,,,,,,,,,,,,,,2.0\n",
                encoding="utf8",
            )
            rows = [
                row for row in csv.DictReader(
                    build_upload_csv(path, template)
                    .decode("utf-8-sig").splitlines()
                )
                if row["pl_name"] == "Alpha"
            ]
            self.assertEqual(
                {(row["pl_tour"], row["pl_stats_pl_ID"]) for row in rows},
                {("1.0", "100"), ("2.0", "200")},
            )

    def test_screenshot_upload_csv_uses_big_workbook_player_summaries(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            workbook_path = directory / "screenshot-stats.xlsx"
            template_path = directory / "upload-template.csv"
            workbook = Workbook()
            workbook.remove(workbook.active)
            summary_headers = [
                "Player",
                "1st Serve %",
                "Aces",
                "Double Faults",
                "Avg 1st Serve Speed",
                "Avg 2nd Serve Speed",
                "Net Points Won %",
                "Winners",
                "Forced Errors",
                "Unforced Errors",
                "Break Points Won %",
                "Short Rallies Won (<5) %",
                "Medium Rallies Won (5-8) %",
                "Long Rallies Won (>8) %",
                "1st Serve Won %",
                "2nd Serve Won %",
                "Return Points Won %",
                "Average Rally Length",
            ]
            for name, player, serve_pct in (
                ("ATP Summary", "Alpha", 0.625),
                ("WTA Summary", "Beta", 0.70),
            ):
                sheet = workbook.create_sheet(name)
                sheet.append(["Summary title"])
                sheet.append(["Summary note"])
                sheet.append(["Summary totals"])
                sheet.append([])
                sheet.append(summary_headers)
                sheet.append([
                    player, serve_pct, 5.25, 2, 181.3, 154.2, 0.58,
                    22.5, 8, 12, 0.375, 0.62, 0.48, 0.30, 0.67,
                    0.52, 0.39, 4.2,
                ])
            workbook.save(workbook_path)
            workbook.close()
            template_path.write_text(
                "pl_stats_pl_ID,pl_name,pl_first_serve_perc,pl_tour\n"
                "465,Alpha,,1.0\n"
                "200,Beta,,2.0\n",
                encoding="utf-8",
            )

            rows = list(csv.DictReader(
                build_screenshot_stats_upload_csv(
                    workbook_path, template_path
                ).decode("utf-8-sig").splitlines()
            ))

        alpha = next(row for row in rows if row["pl_name"] == "Alpha")
        beta = next(row for row in rows if row["pl_name"] == "Beta")
        self.assertEqual(alpha["pl_stats_pl_ID"], "465")
        self.assertEqual(alpha["pl_first_serve_perc"], "62.5")
        self.assertEqual(alpha["pl_aces"], "5.2")
        self.assertEqual(alpha["pl_tour"], "1.0")
        self.assertEqual(beta["pl_stats_pl_ID"], "200")
        self.assertEqual(beta["pl_first_serve_perc"], "70.0")
        self.assertEqual(beta["pl_tour"], "2.0")

    def test_screenshot_upload_csv_keeps_the_full_atp_roster_and_separates_wta(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            workbook_path = directory / "screenshot-stats.xlsx"
            template_path = directory / "upload-template.csv"
            workbook = Workbook()
            workbook.remove(workbook.active)
            for sheet_name, players in (
                ("ATP Summary", ["Alpha", "Duplicate", "Unmatched"]),
                ("WTA Summary", ["Beta"]),
            ):
                sheet = workbook.create_sheet(sheet_name)
                sheet.append(["Summary title"])
                sheet.append(["Summary note"])
                sheet.append(["Summary totals"])
                sheet.append([])
                sheet.append(["Player", "1st Serve %"])
                for player in players:
                    sheet.append([player, 0.5])
            workbook.save(workbook_path)
            workbook.close()
            template_path.write_text(
                "pl_stats_pl_ID,pl_name,pl_tour\n"
                "555,ALPHA,1.0\n"
                "101,Duplicate,1.0\n"
                "102,duplicate,1.0\n"
                "777,Beta,1.0\n"
                ",New Ranked ,1.0\n",
                encoding="utf-8",
            )

            def rows_for(tour):
                return list(csv.DictReader(
                    build_screenshot_stats_upload_csv(
                        workbook_path, template_path, tour=tour
                    ).decode("utf-8-sig").splitlines()
                ))[1:]  # Omit the instructional row.

            atp_rows = rows_for("atp")
            wta_rows = rows_for("wta")

        self.assertEqual({row["pl_tour"] for row in atp_rows}, {"1.0"})
        self.assertEqual({row["pl_tour"] for row in wta_rows}, {"2.0"})
        self.assertEqual(
            [row["pl_name"] for row in atp_rows],
            ["ALPHA", "Duplicate", "duplicate", "Beta", "New Ranked "],
        )
        self.assertNotIn("Unmatched", {row["pl_name"] for row in atp_rows})
        self.assertEqual(
            [row["pl_stats_pl_ID"] for row in atp_rows],
            ["555", "101", "102", "777", ""],
        )
        atp_by_name = {row["pl_name"]: row for row in atp_rows}
        wta_by_name = {row["pl_name"]: row for row in wta_rows}
        self.assertEqual(atp_by_name["ALPHA"]["pl_first_serve_perc"], "50.0")
        self.assertEqual(atp_by_name["Duplicate"]["pl_first_serve_perc"], "")
        self.assertEqual(atp_by_name["duplicate"]["pl_first_serve_perc"], "")
        self.assertEqual(atp_by_name["Beta"]["pl_first_serve_perc"], "")
        self.assertEqual(atp_by_name["New Ranked "]["pl_first_serve_perc"], "")
        self.assertEqual(wta_by_name["Beta"]["pl_stats_pl_ID"], "")
        self.assertEqual(wta_by_name["Beta"]["pl_first_serve_perc"], "50.0")

    def test_composite_log_csv_contains_all_accepted_tours(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            atp = self._verified()[0]
            wta = copy.deepcopy(atp)
            wta["tour"] = "wta"
            wta["match_id"] = "wta-match"
            for row in wta["rows"]:
                row["match_id"] = "wta-match"
            append_submission(
                path, [atp], message_id=10, attachment_id=20,
                submitter_id=30, source_hash="atp-composite",
            )
            append_submission(
                path, [wta], message_id=11, attachment_id=21,
                submitter_id=31, source_hash="wta-composite",
            )
            rows = list(csv.DictReader(
                build_composite_log_csv(path)
                .decode("utf-8-sig").splitlines()
            ))
            self.assertEqual(len(rows), 4)
            self.assertEqual({row["tour"] for row in rows}, {"ATP", "WTA"})
            self.assertEqual(
                {row["source_sha256"] for row in rows},
                {"atp-composite", "wta-composite"},
            )

    def test_player_summary_lists_only_latest_5_matches(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            matches = []
            for day in range(1, 17):
                match = copy.deepcopy(self._verified()[0])
                match["match_id"] = f"match-{day}"
                for row in match["rows"]:
                    row["match_id"] = match["match_id"]
                    row["match_datetime"] = f"2026-08-{day:02d} 12:00:00"
                matches.append(match)
            append_submission(
                path, matches, message_id=10, attachment_id=20,
                submitter_id=30, source_hash="sixteen-matches",
            )
            bind_player_identity(path, 30, "Alpha", "admin receipt")
            summary = player_summary(path, 30)
            self.assertEqual(summary["matches"], 16)
            self.assertEqual(summary["coverage_start"], "2026-08-01")
            self.assertEqual(summary["coverage_end"], "2026-08-16")
            self.assertEqual(len(summary["recent_matches"]), 5)
            self.assertEqual(
                summary["recent_matches"][0]["date"], "2026-08-16"
            )
            self.assertEqual(
                summary["recent_matches"][-1]["date"], "2026-08-12"
            )

    def test_screenshot_coverage_reports_matches_and_field_completeness(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
            "as_of": "2026-09-10",
            "matches": 2,
            "match_records": [
                {
                    "opponent": "Beta",
                    "date": datetime(2026, 12, 31),
                    "tournament": "US Open Arthur Ashe",
                    "result": "4-6 4-6",
                },
                {
                    "opponent": "Beta",
                    "date": datetime(2026, 1, 1),
                    "tournament": "Ground_001 US Open",
                    "result": "6-4 6-4",
                },
                {
                    "opponent": "Gamma",
                    "date": "2026-09-08",
                    "tournament": "US Open",
                    "result": "1-6 1-6",
                },
            ],
            "metrics": [
                ("1st Serve %", 0.60, 2),
                ("Aces", 5, 1),
                ("Tie-breaks Won %", 1.0, 2),
                ("Deciding Sets Won %", 1.0, 2),
            ],
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "Beta",
                    "date": "2026-09-07",
                    "tournament": "Tennis Elbow 4 (ATP Characters) - US Open 2026",
                    "result": "6-4, 6-4",
                },
                {
                    "tour": "atp",
                    "p1": "Gamma",
                    "p2": "Alpha",
                    "date": "2026-09-08",
                    "tournament": "US Open",
                    "result": "4-6, 6-4",
                },
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "Delta",
                    "date": "2026-09-09",
                    "tournament": "US Open",
                    "result": "6-3, 6-3",
                },
            ],
        }
        lines = main._screenshot_coverage_lines(summary, profile)
        rendered = "\n".join(lines)
        self.assertIn("Unique matches from screenshots:** 3", rendered)
        self.assertIn("Official matches on record:** 3", rendered)
        self.assertIn("Verified screenshots available:** 2", rendered)
        self.assertIn(
            "Verified matches used:** 2 of 2 (100%)",
            rendered,
        )
        self.assertNotIn(
            "Score exceptions among matched screenshots — excluded from "
            "calculations:",
            rendered,
        )
        self.assertNotIn("Scores Matching with Website:", rendered)
        self.assertNotIn("Score discrepancies:", rendered)
        self.assertNotIn("Scores unavailable for comparison:", rendered)
        self.assertIn("For Review:** 1", rendered)
        self.assertNotIn("Duplicate screenshot rows:", rendered)
        self.assertNotIn("Missing screenshot matches:", rendered)
        self.assertIn("Data completeness:", rendered)
        self.assertIn("Lowest-covered fields:", rendered)
        self.assertNotIn("Tie-breaks Won %", rendered)
        self.assertNotIn("Deciding Sets Won %", rendered)

    def test_screenshot_coverage_reports_partial_scores_with_verified_denominator(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
            "as_of": "2026-09-10",
            "matches": 1,
            "match_records": [{
                "opponent": "Beta",
                "date": "2026-08-01",
                "tournament": "US Open",
                "result": "1/6 0/0 ret.",
            }],
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [{
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Beta",
                "date": "2026-08-01",
                "tournament": "US Open",
                "result": "6-2, 6-1",
            }],
        }

        rendered = "\n".join(main._screenshot_coverage_lines(summary, profile))

        self.assertIn("Verified matches used:** 1 of 1 (100%)", rendered)
        self.assertIn(
            "Verified matches with partial scores:** 1/1 (100%)",
            rendered,
        )
        self.assertNotIn("Scores Matching with Website:", rendered)
        self.assertNotIn("For review — excluded from screenshot calculations:", rendered)
        self.assertNotIn("Partial/truncated scores:", rendered)

    def test_screenshot_coverage_reports_matches_used_over_verified_matches(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
            "matches": 1,
            "match_records": [
                {
                    "opponent": "Beta",
                    "date": "2026-08-01",
                    "tournament": "US Open",
                    "result": "6-2 6-1",
                },
                {
                    "opponent": "Gamma",
                    "date": "2026-08-02",
                    "tournament": "US Open",
                    "result": "6-3 6-4",
                },
            ],
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "Beta",
                    "date": "2026-08-01",
                    "tournament": "US Open",
                    "result": "6-2, 6-1",
                },
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "Gamma",
                    "date": "2026-08-02",
                    "tournament": "US Open",
                    "result": "6-3, 6-4",
                },
            ],
        }

        rendered = "\n".join(main._screenshot_coverage_lines(summary, profile))

        self.assertIn("Verified matches used:** 1 of 2 (50%)", rendered)

    def test_dashboard_score_parser_handles_compact_scores_and_date_cells(self):
        self.assertEqual(
            main._dashboard_score_key("60 6/1 6/1"),
            ((0, 6), (1, 6), (1, 6)),
        )
        self.assertEqual(
            main._dashboard_score_key(datetime(2026, 4, 6)),
            (),
        )

    def test_dashboard_normalizes_legacy_player_and_event_labels(self):
        self.assertEqual(
            main._dashboard_player_key("LalaSong"),
            main._dashboard_player_key("Lala_Song"),
        )
        self.assertEqual(
            main._dashboard_player_key("Cotillion"),
            main._dashboard_player_key("IsCotillion"),
        )
        self.assertEqual(
            main._dashboard_tournament_key("Ground_0261 Atlanta"),
            main._dashboard_tournament_key(
                "Tennis Elbow 4 (ATP Characters) - Atlanta Open 2022"
            ),
        )
        self.assertEqual(
            main._dashboard_tournament_key("Ground_0332 WTA Zhengzhou"),
            main._dashboard_tournament_key(
                "Tennis Elbow 4 (ATP Characters) - Zhengzhou 2022"
            ),
        )
        self.assertEqual(
            main._dashboard_tournament_key("Beijing Lotus ATP 500"),
            main._dashboard_tournament_key(
                "Tennis Elbow 4 (ATP Characters) - Beijing 2023"
            ),
        )
        self.assertEqual(
            main._dashboard_tournament_key("RG Philippe Chartier Day"),
            main._dashboard_tournament_key(
                "Tennis Elbow 4 (ATP Characters) - Roland Garros 2024"
            ),
        )
        self.assertTrue(
            main.is_exhibition_tournament("Year End Holidays Cup 2025")
        )
        self.assertTrue(main.is_exhibition_tournament("Six Kings Slam"))
        self.assertTrue(main.is_exhibition_tournament("Mystery Cup"))
        self.assertTrue(
            main._dashboard_score_is_exhibition_only("1-0(4) 0-1(6)")
        )

    def test_screenshot_coverage_excludes_exhibition_matches(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
            "matches": 2,
            "match_records": [
                {
                    "opponent": "Beta",
                    "date": "2025-12-28",
                    "tournament": "Year End Holiday Cup",
                    "result": "1-0(4)",
                },
                {
                    "opponent": "Gamma",
                    "date": "2026-01-08",
                    "tournament": "Brisbane ATP 250",
                    "result": "6-4 6-4",
                },
            ],
            "metrics": [],
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "Beta",
                    "date": "28.12.2025",
                    "tournament": "Year End Holidays Cup 2025",
                    "result": "1-0(4)",
                },
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "Gamma",
                    "date": "08.01.2026",
                    "tournament": "Brisbane 2026",
                    "result": "6-4,6-4",
                },
            ],
        }
        rendered = "\n".join(main._screenshot_coverage_lines(summary, profile))
        self.assertIn("Unique matches from screenshots:** 1", rendered)
        self.assertIn("Verified matches used:** 1 of 1 (100%)", rendered)

    def test_dashboard_event_identity_allows_missing_official_ground(self):
        self.assertTrue(
            main._dashboard_event_identity_compatible(
                "Ground_0261 Atlanta",
                "Tennis Elbow 4 (ATP Characters) - Atlanta Open 2022",
            )
        )
        self.assertTrue(
            main._dashboard_event_identity_compatible(
                "RG Philippe Chatrier Night",
                "Tennis Elbow 4 (ATP Characters) - Olympics 2024",
                screenshot_date="2024-08-05",
                official_date="08.08.2024",
            )
        )

    def test_dashboard_infers_unique_legacy_opponent_from_event_and_score(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
            "matches": 1,
            "match_records": [{
                "opponent": "Legacy Alias",
                "date": "2026-08-01",
                "tournament": "Ground_001 US Open",
                "result": "6-4 6-4",
            }],
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [{
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Official Account",
                "date": "2026-08-03",
                "tournament": (
                    "Tennis Elbow 4 (ATP Characters) - US Open 2026"
                ),
                "result": "6-4, 6-4",
            }],
        }
        details = []
        rendered = "\n".join(
            main._screenshot_coverage_lines(summary, profile, details)
        )

        self.assertIn("Verified matches used:** 1 of 1 (100%)", rendered)
        self.assertEqual(details[0]["status"], "matched")
        self.assertEqual(
            details[0]["match_method"],
            "unique event/score inference",
        )

    def test_atp_cup_is_trusted_globally_without_wtsl_candidate(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
            "matches": 1,
            "match_records": [{
                "match_key": "alpha-atp-cup",
                "opponent": "Official Cup Opponent",
                "date": "2022-12-27",
                "tournament": "ATP Cup",
                "result": "6-1 0-8",
            }],
        }
        details = []
        rendered = "\n".join(main._screenshot_coverage_lines(
            summary,
            {"player_name": "Alpha", "official_results": [{
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Other",
                "date": "2026-09-01",
                "tournament": "US Open",
                "result": "6-2, 6-2",
            }]},
            details,
        ))

        self.assertIn("Verified matches used:** 0 of 0 (0%)", rendered)
        self.assertIn(
            "Trusted official screenshots accepted outside the WTSL feed:** 1",
            rendered,
        )
        self.assertEqual(details[0]["status"], "matched")
        self.assertEqual(details[0]["match_method"], "trusted ATP Cup result")
        self.assertNotIn("Score exceptions", rendered)

    def test_squeaky_manual_overrides_do_not_apply_globally(self):
        records = [
            {
                "match_key": "lampjavel",
                "opponent": "Lampjavel",
                "date": "2022-07-11",
                "tournament": "Wimbledon Centre",
                "result": "7-6(1) 7-6(4) 6-1",
            },
            {
                "match_key": "tennis-star",
                "opponent": "Tennis_Star",
                "date": "2025-01-24",
                "tournament": "AO Rod Laver Night",
                "result": "6/4 6/4",
            },
            {
                "match_key": "madferit",
                "opponent": "Madferit",
                "date": "2025-10-25",
                "tournament": "Wimbledon Center Court Day",
                "result": "6-1 7-5",
            },
        ]
        profile = {
            "player_name": "Squeaky",
            "official_results": [{
                "tour": "atp",
                "p1": "Squeaky",
                "p2": "Other",
                "date": "2026-09-01",
                "tournament": "US Open",
                "result": "6-2, 6-2",
            }],
        }
        summary = {
            "player": "Squeaky",
            "tour": "atp",
            "period": "career",
            "matches": len(records),
            "match_records": records,
        }
        details = []
        rendered = "\n".join(main._screenshot_coverage_lines(
            summary, profile, details
        ))

        self.assertIn("Verified matches used:** 0 of 0 (0%)", rendered)
        self.assertIn(
            "Trusted official screenshots accepted outside the WTSL feed:** 2",
            rendered,
        )
        self.assertIn("Davis Cup:** 1 match included", rendered)
        self.assertEqual(
            [detail["status"] for detail in details],
            ["matched", "matched", "davis_cup"],
        )
        self.assertEqual(
            [detail["match_method"] for detail in details[:2]],
            ["manual Squeaky verification", "manual Squeaky verification"],
        )

        other_summary = dict(summary, player="Other Player")
        other_details = []
        other_profile = {
            "player_name": "Other Player",
            "official_results": [{
                "tour": "atp",
                "p1": "Other Player",
                "p2": "Someone Else",
                "date": "2026-09-01",
                "tournament": "US Open",
                "result": "6-2, 6-2",
            }],
        }
        main._screenshot_coverage_lines(
            other_summary, other_profile, other_details
        )
        self.assertEqual(
            [detail["status"] for detail in other_details],
            ["unmatched", "unmatched", "unmatched"],
        )

    def test_nonroutine_competitions_have_review_reasons(self):
        self.assertTrue(main._dashboard_record_is_davis_cup({
            "tournament": "Davis Cup (Spain)",
        }))
        self.assertFalse(main._dashboard_record_is_exhibition({
            "tournament": "Next Gen ATP Finals",
            "result": "4-1 4-2 4-0",
        }))
        self.assertTrue(main._dashboard_record_is_exhibition({
            "tournament": "Wimbledon Center Court Day",
            "result": "4-1 4-2 4-0",
        }))
        self.assertIsNone(main._dashboard_special_competition_reason({
            "tournament": "Davis Cup (Spain)",
        }))
        self.assertIn(
            "Laver Cup",
            main._dashboard_special_competition_reason({
                "tournament": "Laver Cup",
            }),
        )
        self.assertIn(
            "excluded",
            main._dashboard_special_competition_reason({
                "tournament": "Year End Holidays Cup",
            }),
        )

    def test_davis_cup_is_included_in_screenshot_statistics(self):
        summaries = [{
            "player": "Alpha",
            "tour": "atp",
            "matches": 1,
            "match_records": [{
                "match_key": "davis-alpha-beta",
                "opponent": "Beta",
                "date": "2026-09-07",
                "tournament": "Davis Cup (Spain)",
                "result": "6-4 6-4",
            }],
        }]
        official = [{
            "tour": "atp",
            "p1": "Alpha",
            "p2": "Gamma",
            "date": "2026-09-07",
            "tournament": "US Open 2026",
            "result": "6-4, 6-4",
        }]
        details = []
        rendered = "\n".join(main._screenshot_coverage_lines(
            summaries[0],
            {"player_name": "Alpha", "official_results": official},
            details,
        ))
        payload, count = main._build_screenshot_review_csv(summaries, official)
        rows = list(csv.DictReader(io.StringIO(payload.decode("utf-8"))))

        self.assertIn(
            "Davis Cup:** 1 match included in screenshot calculations",
            rendered,
        )
        self.assertNotIn("For review", rendered)
        self.assertEqual(details[0]["status"], "davis_cup")
        self.assertEqual(
            main._screenshot_statistics_exclusion_keys(summaries, official),
            {"atp": {}, "wta": {}},
        )
        self.assertEqual(count, 1)
        self.assertIn("Davis Cup", rows[0]["Review reason"])

    def test_screenshot_coverage_uses_unique_nearby_score_fallback(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
            "matches": 1,
            "match_records": [{
                "opponent": "Beta",
                "date": "2026-08-05",
                "tournament": "Wrong Stadium Label",
                "result": "6/0 6/2",
            }],
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [{
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Beta",
                "date": "2026-08-08",
                "tournament": "Olympics 2026",
                "result": "6-0, 6-2",
            }],
        }
        rendered = "\n".join(main._screenshot_coverage_lines(summary, profile))
        self.assertIn("Verified matches used:** 1 of 1 (100%)", rendered)

    def test_screenshot_coverage_uses_placeholder_date_year_for_event_match(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
            "matches": 1,
            "match_records": [{
                "opponent": "Beta",
                "date": "2022-01-01",
                "tournament": "Wimbledon",
                "result": "7-6 6-4 6-3",
            }],
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [{
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Beta",
                "date": "09.07.2022",
                "tournament": "Wimbledon 2022",
                "result": "7-6,6-4,6-3",
            }],
        }
        rendered = "\n".join(main._screenshot_coverage_lines(summary, profile))
        self.assertIn("Verified matches used:** 1 of 1 (100%)", rendered)

    def test_screenshot_coverage_infers_unique_match_without_event_or_date(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
            "matches": 2,
            "match_records": [
                {
                    "opponent": "Mystery",
                    "date": None,
                    "tournament": "",
                    "result": "4-6 6-4 6-1",
                },
                {
                    "opponent": "KINGBARBOZA",
                    "date": None,
                    "tournament": "",
                    "result": "6-2 7-6(8)",
                },
            ],
            "metrics": [],
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "Mystery",
                    "date": "17.06.2022",
                    "tournament": "Halle 2022",
                    "result": "4-6,6-4,6-1",
                },
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "KINGBARBOZA",
                    "date": "02.07.2022",
                    "tournament": "Eastbourne 2022",
                    "result": "6-2,7-6",
                },
            ],
        }
        rendered = "\n".join(main._screenshot_coverage_lines(summary, profile))
        self.assertIn("Verified matches used:** 2 of 2 (100%)", rendered)
        self.assertNotIn("Matches with tournament inferred", rendered)

    def test_screenshot_review_csv_contains_actionable_non_exhibition_rows(self):
        summaries = [{
            "player": "Alpha",
            "tour": "atp",
            "matches": 5,
            "match_records": [
                {
                    "opponent": "Beta",
                    "date": "2026-09-07",
                    "tournament": "US Open",
                    "result": "6-0 6-0",
                },
                {
                    "opponent": "Gamma",
                    "date": "2026-09-08",
                    "tournament": "US Open",
                    "result": "Score pending",
                },
                {
                    "opponent": "Delta",
                    "date": "2026-09-09",
                    "tournament": "Paris",
                    "result": "6-3 6-3",
                },
                {
                    "opponent": "Epsilon",
                    "date": "2026-09-10",
                    "tournament": "Rome",
                    "result": "6-3 6-3",
                },
                {
                    "opponent": "Holiday",
                    "date": "2026-12-28",
                    "tournament": "Year End Holiday Cup",
                    "result": "1-0(4)",
                },
            ],
        }]
        official = [
            {
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Beta",
                "date": "2026-09-07",
                "tournament": "US Open 2026",
                "result": "6-4, 6-4",
            },
            {
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Gamma",
                "date": "2026-09-08",
                "tournament": "US Open 2026",
                "result": "6-2, 6-2",
            },
            {
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Delta",
                "date": "2026-09-09",
                "tournament": "Paris 2026",
                "result": "Result unavailable",
            },
        ]

        payload, count = main._build_screenshot_review_csv(summaries, official)
        rows = list(csv.DictReader(io.StringIO(payload.decode("utf-8"))))

        self.assertEqual(count, 4)
        self.assertEqual(
            {row["Review reason"] for row in rows},
            {
                "Score discrepancy",
                "Screenshot score unavailable",
                "Official score unavailable",
                "No unique official match found",
            },
        )
        self.assertTrue(all(row["Player"] == "Alpha" for row in rows))
        self.assertTrue(all(row["Tour"] == "ATP" for row in rows))
        self.assertTrue(all(row["Date"] for row in rows))
        self.assertTrue(all(row["Screenshot tournament"] for row in rows))
        self.assertTrue(all(row["Opponent"] for row in rows))
        self.assertNotIn("Year End Holiday Cup", payload.decode("utf-8"))
        mismatch = next(
            row for row in rows if row["Review reason"] == "Score discrepancy"
        )
        self.assertEqual(mismatch["Official or inferred tournament"], "US Open 2026")
        self.assertEqual(mismatch["Screenshot score"], "6-0 6-0")
        self.assertEqual(mismatch["Official score"], "6-4, 6-4")
        missing_official = next(
            row for row in rows if row["Review reason"] == "Official score unavailable"
        )
        self.assertEqual(
            missing_official["Official or inferred tournament"], "Paris 2026"
        )

    def test_screenshot_review_csv_marks_players_without_official_results_unresolved(self):
        payload, count = main._build_screenshot_review_csv(
            [{
                "player": "Unmatched",
                "tour": "wta",
                "matches": 1,
                "match_records": [{
                    "opponent": "Opponent",
                    "date": "2026-09-10",
                    "tournament": "Rome",
                    "result": "6-4 6-4",
                }],
            }],
            [],
        )
        rows = list(csv.DictReader(io.StringIO(payload.decode("utf-8"))))

        self.assertEqual(count, 1)
        self.assertEqual(rows[0]["Review reason"], "No unique official match found")
        self.assertEqual(rows[0]["Official or inferred tournament"], "")

    def test_screenshot_review_annotations_preserve_status_and_reason(self):
        summaries = [{
            "player": "Alpha",
            "tour": "atp",
            "matches": 2,
            "match_records": [
                {
                    "match_key": "score-discrepancy",
                    "opponent": "Beta",
                    "date": "2026-09-07",
                    "tournament": "US Open",
                    "result": "6-0 6-0",
                },
                {
                    "match_key": "davis-cup",
                    "opponent": "Gamma",
                    "date": "2026-09-08",
                    "tournament": "Davis Cup (Spain)",
                    "result": "6-4 6-4",
                },
            ],
        }]
        official = [{
            "tour": "atp",
            "p1": "Alpha",
            "p2": "Beta",
            "date": "2026-09-07",
            "tournament": "US Open",
            "result": "6-4 6-4",
        }]

        annotations = main._screenshot_review_annotations(summaries, official)

        self.assertEqual(
            annotations["atp"][("alpha", "score-discrepancy")],
            {"status": "FOR REVIEW", "reason": "Score discrepancy"},
        )
        self.assertEqual(
            annotations["atp"][("alpha", "davis-cup")]["status"], "DAVIS CUP"
        )
        self.assertIn(
            "hosted separately",
            annotations["atp"][("alpha", "davis-cup")]["reason"],
        )

    def test_screenshot_review_annotations_ignore_partial_scores(self):
        annotations = main._screenshot_review_annotations(
            [{
                "player": "Alpha",
                "tour": "atp",
                "matches": 1,
                "match_records": [{
                    "match_key": "partial-score",
                    "opponent": "Beta",
                    "date": "2026-09-07",
                    "tournament": "US Open",
                    "result": "1/6 0/0 ret.",
                }],
            }],
            [{
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Beta",
                "date": "2026-09-07",
                "tournament": "US Open",
                "result": "6-2, 6-1",
            }],
        )

        self.assertEqual(annotations["atp"], {})

    def test_screenshot_review_annotations_do_not_flag_unreliable_histories(self):
        annotations = main._screenshot_review_annotations(
            [{
                "player": "Sparse",
                "tour": "atp",
                "matches": 2,
                "match_records": [
                    {
                        "match_key": "sparse-one",
                        "opponent": "One",
                        "date": "2026-09-01",
                        "tournament": "Rome",
                        "result": "6-4 6-4",
                    },
                    {
                        "match_key": "sparse-two",
                        "opponent": "Two",
                        "date": "2026-09-02",
                        "tournament": "Paris",
                        "result": "6-3 6-3",
                    },
                ],
            }],
            [],
        )

        self.assertEqual(annotations["atp"], {})

    def test_screenshot_review_csv_includes_blank_scores_from_the_workbook(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            workbook = Workbook()
            atp = workbook.active
            atp.title = "atp"
            atp.append([
                "Player", "Opponent", "Tournament", "Date", "Result",
                "Unique ID B",
            ])
            atp.append([
                "Alpha", "Beta", "US Open", "2026-09-07", None,
                "alpha-us-open",
            ])
            atp.append([
                "Fixture", "Opponent", "Rome", "2026-09-08", "Scheduled",
                "fixture-rome",
            ])
            atp.append([
                "Fixture Two", "Opponent", "Rome", "2026-09-09",
                "Scheduled - 2026-09-09", "fixture-two-rome",
            ])
            atp.append([
                "Fixture Three", "Opponent", "Rome", "2026-09-10",
                "Not started (tomorrow)", "fixture-three-rome",
            ])
            workbook.create_sheet("wta")
            workbook.save(path)
            workbook.close()

            summaries = match_record_summaries(path)
        payload, count = main._build_screenshot_review_csv(
            summaries,
            [{
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Beta",
                "date": "2026-09-07",
                "tournament": "US Open",
                "result": "6-4 6-4",
            }],
        )
        rows = list(csv.DictReader(io.StringIO(payload.decode("utf-8"))))

        self.assertEqual(count, 1)
        self.assertEqual(rows[0]["Player"], "Alpha")
        self.assertEqual(rows[0]["Review reason"], "Screenshot score unavailable")

    def test_dashboard_score_fragments_are_partial_but_real_mismatches_remain(self):
        official = main._dashboard_score_key("6-3, 6-4, 6-4")
        self.assertTrue(
            main._dashboard_score_is_partial(
                main._dashboard_score_key("6/3 6/4 5/3 ret."),
                official,
                "6/3 6/4 5/3 ret.",
            )
        )
        self.assertTrue(
            main._dashboard_score_is_partial(
                main._dashboard_score_key("6-4 6-2"),
                main._dashboard_score_key("4-6, 6-0, 4-6, 6-2, 6-4"),
                "6-4 6-2",
            )
        )
        self.assertTrue(
            main._dashboard_score_is_partial(
                main._dashboard_score_key("1/6 0/0 ret."),
                main._dashboard_score_key("6-2, 6-1"),
                "1/6 0/0 ret.",
            )
        )
        self.assertTrue(
            main._dashboard_score_is_partial(
                main._dashboard_score_key("5-1 ret."),
                main._dashboard_score_key("6-1, 6-4"),
                "5-1 ret.",
            )
        )
        self.assertFalse(
            main._dashboard_score_is_partial(
                main._dashboard_score_key("5-2 ret."),
                main._dashboard_score_key("6-3, 7-6"),
                "5-2 ret.",
            )
        )
        self.assertFalse(
            main._dashboard_score_is_partial(
                main._dashboard_score_key("3/0 ret."),
                main._dashboard_score_key("6-1, 6-4"),
                "3/0 ret.",
            )
        )
        self.assertFalse(
            main._dashboard_score_is_partial(
                main._dashboard_score_key("6-3 6-3"),
                main._dashboard_score_key("6-3, 6-4, 6-3"),
                "6-3 6-3",
            )
        )

    def test_screenshot_challenger_can_match_main_tour_court_by_start_date(self):
        for screenshot_category in ("challenger", "futures"):
            for main_category in ("250", "500", "1000"):
                with self.subTest(
                    screenshot_category=screenshot_category,
                    main_category=main_category,
                ):
                    summary = {
                        "player": "Alpha",
                        "tour": "atp",
                        "period": "career",
                        "matches": 1,
                        "match_records": [{
                            "opponent": "Beta",
                            "date": "2026-06-10",
                            "tournament": "Lexus Challenger 2026",
                            "event_category": screenshot_category,
                            "event_start_date": "2026-06-09",
                            "result": "6-4 6-4",
                        }],
                    }
                    profile = {
                        "player_name": "Alpha",
                        "official_results": [{
                            "tour": "atp",
                            "p1": "Alpha",
                            "p2": "Beta",
                            "date": "2026-06-10",
                            "tournament": f"Lyon ATP {main_category}",
                            "event_category": main_category,
                            "event_start_date": "2026-06-09",
                            "result": "6-4, 6-4",
                        }],
                    }
                    rendered = "\n".join(
                        main._screenshot_coverage_lines(summary, profile)
                    )
                    self.assertIn(
                        "Verified matches used:** 1 of 1 (100%)",
                        rendered,
                    )

    def test_same_day_same_category_events_do_not_cross_match(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
            "matches": 1,
            "match_records": [{
                "opponent": "Beta",
                "date": "2026-06-10",
                "tournament": "Lexus Challenger 2026",
                "event_category": "challenger",
                "event_start_date": "2026-06-09",
                "result": "6-4 6-4",
            }],
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [{
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Beta",
                "date": "2026-06-10",
                "tournament": "Roma Challenger 2026",
                "event_category": "challenger",
                "event_start_date": "2026-06-09",
                "result": "6-4, 6-4",
            }],
        }
        rendered = "\n".join(main._screenshot_coverage_lines(summary, profile))
        self.assertIn("Verified matches used:** 0 of 0 (0%)", rendered)


class MatchLogDiscordTests(unittest.IsolatedAsyncioTestCase):
    async def test_screenshot_exclusions_are_cached_until_inputs_change(self):
        original_cache = main._screenshot_exclusions_cache
        main._screenshot_exclusions_cache = None
        try:
            with (
                patch.object(
                    Path,
                    "stat",
                    return_value=SimpleNamespace(st_mtime_ns=123),
                ),
                patch.object(
                    main,
                    "get_screenshot_match_record_summaries",
                    return_value=[],
                ) as summaries,
                patch.object(
                    main,
                    "_screenshot_statistics_exclusion_keys",
                    return_value={"atp": {}, "wta": {}},
                ) as reconcile,
            ):
                official_results = []
                first = await main._get_screenshot_statistics_exclusions(
                    official_results
                )
                second = await main._get_screenshot_statistics_exclusions(
                    official_results
                )

            self.assertEqual(first, {"atp": {}, "wta": {}})
            self.assertIs(second, first)
            summaries.assert_called_once()
            reconcile.assert_called_once()
        finally:
            main._screenshot_exclusions_cache = original_cache

    async def test_live_embed_handoff_reuses_newest_message_and_removes_older_duplicates(self):
        older = SimpleNamespace(
            author=main.client.user,
            embeds=[SimpleNamespace(title="🎾 WTSL Live")],
            delete=AsyncMock(),
        )
        newest = SimpleNamespace(
            author=main.client.user,
            embeds=[SimpleNamespace(title="🎾 WTSL Live")],
            delete=AsyncMock(),
        )

        class FakeChannel:
            async def history(self, limit):
                for message in (newest, older):
                    yield message

        adopted = await main._adopt_existing_wtsl_live_message(FakeChannel())

        self.assertIs(adopted, newest)
        newest.delete.assert_not_awaited()
        older.delete.assert_awaited_once()

    def test_main_entrypoint_follows_workbook_review_annotation_helpers(self):
        source = Path(main.__file__).read_text(encoding="utf-8")
        entrypoint = source.rfind('if __name__ == "__main__":')

        self.assertGreater(entrypoint, source.index(
            "async def _build_workbook_review_snapshot"
        ))

    async def test_on_ready_uses_only_the_normal_workbook_delivery_task(self):
        queued = []

        def queue(coroutine):
            queued.append(coroutine.cr_code.co_name)
            coroutine.close()
            return SimpleNamespace()

        owner = SimpleNamespace(send=AsyncMock())
        fake_client = SimpleNamespace(
            user="test bot",
            tree=SimpleNamespace(
                sync=AsyncMock(return_value=[]),
                copy_global_to=MagicMock(),
            ),
            loop=SimpleNamespace(create_task=queue),
            fetch_user=AsyncMock(return_value=owner),
        )
        original_promotion_started = main._stats_workbook_promotion_started
        original_rebuild_state = main._matchlog_rebuild_state
        try:
            with (
                patch.object(main, "client", fake_client),
                patch.object(
                    main, "_activate_newer_statistics_workbook",
                    new=AsyncMock(return_value=None),
                ),
                patch.object(main, "start_wtsl_system_once"),
                patch.object(main.asyncio, "create_task", side_effect=queue),
            ):
                await main.on_ready()
            self.assertIn("_stats_workbook_delivery_loop", queued)
            self.assertNotIn("_screenshot_review_delivery_loop", queued)
        finally:
            main._stats_workbook_promotion_started = original_promotion_started
            main._matchlog_rebuild_state = original_rebuild_state

    async def test_workbook_attachment_refreshes_review_columns_before_send(self):
        owner = SimpleNamespace(send=AsyncMock())
        with tempfile.TemporaryDirectory() as directory:
            workbook = Path(directory) / "stats.xlsx"
            workbook.write_bytes(b"workbook")
            snapshot = Path(directory) / "snapshot.xlsx"
            snapshot.write_bytes(b"annotated workbook")
            with (
                patch.object(main, "MATCH_STATS_WORKBOOK", workbook),
                patch.object(
                    main.client,
                    "fetch_user",
                    new=AsyncMock(return_value=owner),
                ),
                patch.object(
                    main,
                    "_build_workbook_review_snapshot",
                    new=AsyncMock(return_value=(snapshot, 12)),
                ) as refresh,
            ):
                await main._dm_stats_owner("Daily workbook", include_workbook=True)

        refresh.assert_awaited_once()
        owner.send.assert_awaited_once()
        self.assertIn("12 rows are flagged", owner.send.await_args.args[0])
        sent_file = owner.send.await_args.kwargs["file"]
        try:
            self.assertEqual(sent_file.filename, "stats.xlsx")
        finally:
            sent_file.close()

    async def test_workbook_attachment_survives_review_refresh_failure(self):
        owner = SimpleNamespace(send=AsyncMock())
        with tempfile.TemporaryDirectory() as directory:
            workbook = Path(directory) / "stats.xlsx"
            workbook.write_bytes(b"preserved workbook")
            with (
                patch.object(main, "MATCH_STATS_WORKBOOK", workbook),
                patch.object(
                    main.client,
                    "fetch_user",
                    new=AsyncMock(return_value=owner),
                ),
                patch.object(
                    main,
                    "_build_workbook_review_snapshot",
                    new=AsyncMock(side_effect=asyncio.TimeoutError),
                ),
            ):
                await main._dm_stats_owner(
                    "Startup workbook",
                    include_workbook=True,
                )

        owner.send.assert_awaited_once()
        self.assertIn(
            "preserved workbook is attached unchanged",
            owner.send.await_args.args[0],
        )
        sent_file = owner.send.await_args.kwargs["file"]
        try:
            self.assertEqual(sent_file.filename, "stats.xlsx")
        finally:
            sent_file.close()

    async def test_timed_out_review_worker_cannot_replace_live_workbook(self):
        with tempfile.TemporaryDirectory() as directory:
            workbook = Path(directory) / "stats.xlsx"
            workbook.write_bytes(b"live workbook")

            def slow_annotation_write(_annotations, path):
                time.sleep(0.05)
                Path(path).write_bytes(b"annotated snapshot")
                return 1

            with (
                patch.object(main, "MATCH_STATS_WORKBOOK", workbook),
                patch.object(
                    main,
                    "_get_matchlog_official_results",
                    new=AsyncMock(return_value=[]),
                ),
                patch.object(
                    main,
                    "get_screenshot_match_record_summaries",
                    return_value=[],
                ),
                patch.object(
                    main,
                    "_screenshot_review_annotations",
                    return_value={"atp": {}, "wta": {}},
                ),
                patch.object(
                    main,
                    "apply_screenshot_review_annotations",
                    side_effect=slow_annotation_write,
                ),
            ):
                with self.assertRaises(asyncio.TimeoutError):
                    await asyncio.wait_for(
                        main._build_workbook_review_snapshot(),
                        timeout=0.01,
                    )
                await asyncio.sleep(0.1)

            self.assertEqual(workbook.read_bytes(), b"live workbook")
            self.assertEqual(
                list(Path(directory).glob(".*.delivery-*.xlsx")),
                [],
            )

    async def test_timed_out_review_copy_cleans_deferred_snapshot(self):
        with tempfile.TemporaryDirectory() as directory:
            workbook = Path(directory) / "stats.xlsx"
            workbook.write_bytes(b"live workbook")
            real_copy = main.shutil.copy2

            def slow_copy(source, destination):
                time.sleep(0.05)
                return real_copy(source, destination)

            with (
                patch.object(main, "MATCH_STATS_WORKBOOK", workbook),
                patch.object(
                    main,
                    "_get_matchlog_official_results",
                    new=AsyncMock(return_value=[]),
                ),
                patch.object(
                    main,
                    "get_screenshot_match_record_summaries",
                    return_value=[],
                ),
                patch.object(
                    main,
                    "_screenshot_review_annotations",
                    return_value={"atp": {}, "wta": {}},
                ),
                patch.object(main.shutil, "copy2", side_effect=slow_copy),
            ):
                with self.assertRaises(asyncio.TimeoutError):
                    await asyncio.wait_for(
                        main._build_workbook_review_snapshot(),
                        timeout=0.01,
                    )
                await asyncio.sleep(0.1)

            self.assertEqual(workbook.read_bytes(), b"live workbook")
            self.assertEqual(
                list(Path(directory).glob(".*.delivery-*.xlsx")),
                [],
            )

    async def asyncSetUp(self):
        self.original_matchlog_rebuild_state = main._matchlog_rebuild_state
        main._matchlog_rebuild_state = "complete"
        self.targeted_results = AsyncMock(return_value=[])
        self.owner_submission_progress = AsyncMock(
            return_value=SimpleNamespace(edit=AsyncMock())
        )
        self.targeted_results_patch = patch.object(
            main,
            "_get_matchlog_player_official_results",
            new=self.targeted_results,
        )
        self.owner_submission_progress_patch = patch.object(
            main,
            "_send_matchlog_owner_submission_progress",
            new=self.owner_submission_progress,
        )
        self.targeted_results_patch.start()
        self.owner_submission_progress_patch.start()
        self.source_store_patch = patch.object(
            main, "save_matchlog_source", return_value=True
        )
        self.identity_store_patch = patch.object(
            main, "save_matchlog_identity", return_value=None
        )
        self.mystats_ranking_patch = patch.object(
            main,
            "_fetch_mystats_ranking",
            new=AsyncMock(return_value={
                "category": "ATP Singles",
                "rank": 7,
                "wtsl_elo": 1640,
                "movement": 2,
                "previous_rank": 9,
                "ytd_wins": 8,
                "ytd_losses": 4,
                "ytd_win_pct": 67,
            }),
        )
        self.mystats_insights_patch = patch.object(
            main,
            "_generate_mystats_insights_sync",
            return_value={
                "strengths": ["Strong first serve", "Effective return"],
                "weaknesses": ["Second serve can improve", "Pressure sample is small"],
                "focus": "Protect the second serve under pressure.",
            },
        )
        self.player_fixture_patch = patch.object(
            main,
            "_verified_player_fixture",
            new=AsyncMock(return_value=None),
        )
        self.pair_fixture_patch = patch.object(
            main,
            "_verified_pair_fixture",
            new=AsyncMock(return_value=None),
        )
        self.source_store_patch.start()
        self.identity_store_patch.start()
        self.mystats_ranking_patch.start()
        self.mystats_insights_patch.start()
        self.player_fixture_patch.start()
        self.pair_fixture_patch.start()

    async def asyncTearDown(self):
        main._matchlog_rebuild_state = self.original_matchlog_rebuild_state
        self.pair_fixture_patch.stop()
        self.player_fixture_patch.stop()
        self.mystats_insights_patch.stop()
        self.mystats_ranking_patch.stop()
        self.identity_store_patch.stop()
        self.source_store_patch.stop()
        self.owner_submission_progress_patch.stop()
        self.targeted_results_patch.stop()

    async def test_mystats_is_private(self):
        interaction = SimpleNamespace(
            user=SimpleNamespace(
                id=30, display_name="Alpha", global_name=None, name="alpha",
                send=AsyncMock(),
            ),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        summary = {"player": "Alpha", "matches": 2, "metrics": [("Aces", 4, 2)]}
        with (
            patch.object(main, "get_matchlog_player_summary", return_value=summary),
            patch.object(main, "get_screenshot_player_summary", return_value=None),
            patch.object(
                main,
                "_matchlog_identity_index",
                {30: {"atp": "Alpha"}},
            ),
            patch.object(
                main, "_restore_matchlog_identity_for_user",
                new=AsyncMock(return_value=False),
            ),
        ):
            await main.mystats.callback(
                interaction,
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Career", value="career"),
            )
        interaction.response.defer.assert_awaited_once_with(
            ephemeral=True, thinking=True
        )
        interaction.followup.send.assert_awaited_once()
        interaction.user.send.assert_awaited_once()
        self.assertTrue(interaction.followup.send.await_args.kwargs["ephemeral"])
        self.assertEqual(interaction.followup.send.await_args.args, ())
        embed = interaction.followup.send.await_args.kwargs["embed"]
        self.assertIn("My WTSL Dashboard", embed.title)
        self.assertIn("Alpha", embed.title)
        fields = {field.name: field.value for field in embed.fields}
        self.assertEqual(fields["🏆 Ranking"], "#7")
        self.assertEqual(fields["🎯 Tour Elo"], "1640")
        self.assertEqual(fields["Category"], "ATP Singles")
        self.assertIn("▲ 2 places", fields["📈 Weekly movement"])
        self.assertIn("Strong first serve", fields["✅ Strengths"])
        self.assertIn("📅 2026 Season Highlights", fields)
        self.assertIn(
            "Winning record this year",
            fields["📅 2026 Season Highlights"],
        )

    async def test_mystats_shows_character_recommendations(self):
        interaction = SimpleNamespace(
            user=SimpleNamespace(
                id=30, display_name="Alpha", global_name=None, name="alpha",
                send=AsyncMock(),
            ),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "matches": 8,
            "metrics": [("Aces", 4, 8)],
            "relative_profile": {
                "serve": {
                    "percentile": 85,
                    "metrics": [{"metric": "Aces", "percentile": 85}],
                },
                "return": {
                    "percentile": 35,
                    "metrics": [
                        {"metric": "Return Points Won %", "percentile": 35}
                    ],
                },
            },
        }
        recommendations = [{
            "character": "Roger Federer",
            "strength_group": "serve",
            "development_group": "return",
            "edge_attributes": ["Service Precision"],
            "edge_details": [
                {
                    "attribute": "Service Precision",
                    "value": 92,
                }
            ],
            "tradeoff": "Needs a clean first-strike pattern.",
            "player_strength_metric": {
                "metric": "Aces",
                "percentile": 85,
            },
            "player_development_metric": {
                "metric": "Return Points Won %",
                "percentile": 35,
            },
            "mechanics_reason": "Use the first ball to open the court.",
            "development_route": "Take returns early and reset the rally.",
        }]
        with (
            patch.object(main, "get_matchlog_player_summary", return_value=summary),
            patch.object(main, "get_screenshot_player_summary", return_value=None),
            patch.object(
                main,
                "_matchlog_identity_index",
                {30: {"atp": "Alpha"}},
            ),
            patch.object(
                main, "_restore_matchlog_identity_for_user",
                new=AsyncMock(return_value=False),
            ),
            patch.object(
                main,
                "recommend_character_choices",
                return_value=recommendations,
            ) as recommend,
        ):
            await main.mystats.callback(
                interaction,
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Career", value="career"),
            )
        recommend.assert_called_once()
        embed = interaction.followup.send.await_args.kwargs["embed"]
        fields = {field.name: field.value for field in embed.fields}
        self.assertIn("🎭 Character recommendations", fields)
        self.assertIn("Roger Federer", fields["🎭 Character recommendations"])
        self.assertIn("Service Precision", fields["🎭 Character recommendations"])

    async def test_mystats_screenshot_choice_keeps_screenshot_as_primary(self):
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {30: {"atp": "Alpha"}}
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=30),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "source": "screenshots",
            "matches": 3,
            "metrics": [("Aces", 4, 3)],
            "ratings": [("Serve Rating", 150)],
            "recent_matches": [],
        }
        try:
            with (
                patch.object(
                    main, "get_screenshot_player_summary", return_value=summary
                ) as screenshot_summary,
                patch.object(
                    main,
                    "_get_screenshot_statistics_exclusions",
                    new=AsyncMock(return_value={"atp": {}, "wta": {}}),
                ),
                patch.object(
                    main, "get_matchlog_player_summary", return_value=None
                ) as matchlog_summary,
            ):
                await main.mystats.callback(
                    interaction,
                    tour=main.app_commands.Choice(name="ATP", value="atp"),
                    source=main.app_commands.Choice(
                        name="Screenshots", value="screenshots"
                    ),
                    period=main.app_commands.Choice(
                        name="Career", value="career"
                    ),
                )
            self.assertEqual(
                screenshot_summary.call_args.args[:4],
                (main.MATCH_STATS_WORKBOOK, "Alpha", "atp", "career"),
            )
            matchlog_summary.assert_called_once()
            embed = interaction.followup.send.await_args.kwargs["embed"]
            self.assertIn("Source: Screenshot stats", embed.description)
            self.assertIn("verified matches used", embed.description)
            self.assertNotIn("screenshot matches", embed.description)
            self.assertIn(
                "⚡ WTSL ratings",
                {field.name for field in embed.fields},
            )
            self.assertIn(
                "📊 Career Stats",
                {field.name for field in embed.fields},
            )
            self.assertIn("Source: Screenshots", embed.footer.text)
            fields = {field.name: field.value for field in embed.fields}
            self.assertIn("Serve Rating", fields["🧮 Rating Formulas"])
            self.assertIn("Return Rating", fields["🧮 Rating Formulas"])
            self.assertNotIn(
                "unavailable components are skipped",
                fields["🧮 Rating Formulas"],
            )
        finally:
            main._matchlog_identity_index = original_index

    def test_dashboard_records_share_filtered_official_results(self):
        results = [
            {
                "tournament": "Kingston",
                "tour": "atp",
                "p1": "Ruze",
                "p2": "Alpha",
                "date": "01.09.2026",
                "result": "6-4,6-4",
            },
            {
                "tournament": "Kingston",
                "tour": "atp",
                "p1": "Beta",
                "p2": "Ruze",
                "date": "02.09.2026",
                "result": "6-4,6-4",
            },
            {
                "tournament": "Kingston",
                "tour": "atp",
                "p1": "Ruze",
                "p2": "Gamma",
                "date": "03.09.2026",
                "result": "6-4,6-4",
            },
            {
                "tournament": "Kingston",
                "tour": "atp",
                "p1": "Delta",
                "p2": "Ruze",
                "date": "04.09.2026",
                "result": "6-4,6-4",
            },
            {
                "tournament": "Kingston",
                "tour": "atp",
                "p1": "Ruze",
                "p2": "Epsilon",
                "date": "05.09.2026",
                "result": "6-4,6-4",
            },
            {
                "tournament": "Kingston",
                "tour": "atp",
                "p1": "Ruze",
                "p2": "Zeta",
                "date": "06.09.2026",
                "result": "Walkover",
            },
            {
                "tournament": "Kingston",
                "tour": "atp",
                "p1": "Ruze",
                "p2": "Eta",
                "date": "07.09.2026",
                "result": "BCT",
            },
        ]
        profile = main._apply_official_dashboard_records(
            {
                "player_name": "Ruze",
                "career_wins": 9,
                "career_losses": 17,
                "ytd_wins": 9,
                "ytd_losses": 17,
                "official_results": results,
            },
            "Ruze",
            "atp",
            results,
        )

        self.assertEqual(
            (
                profile["career_wins"],
                profile["career_losses"],
                profile["ytd_wins"],
                profile["ytd_losses"],
            ),
            (3, 2, 3, 2),
        )
        self.assertEqual(profile["career_win_pct"], 60)
        self.assertEqual(profile["ytd_win_pct"], 60)

    async def test_mystats_followup_sender_does_not_hang(self):
        never = asyncio.Future()
        async def hang(*args, **kwargs):
            await never

        interaction = SimpleNamespace(
            followup=SimpleNamespace(send=AsyncMock(side_effect=hang))
        )
        sent = await main._send_mystats_followup(
            interaction,
            "Temporary error",
            timeout=0.01,
        )
        self.assertFalse(sent)

    async def test_matchkeys_is_private_and_uses_selected_screenshot_source(self):
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {30: {"atp": "Alpha"}}
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=30),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        player_summary = {
            "player": "Alpha", "tour": "atp", "source": "screenshots",
            "matches": 3,
            "metrics": [("1st Serve %", 0.7, 3), ("Aces", 5, 3)],
            "ratings": [("Serve Rating", 170), ("Return Rating", 120)],
        }
        opponent_summary = {
            "player": "Beta", "tour": "atp", "source": "screenshots",
            "matches": 2,
            "metrics": [("1st Serve %", 0.5, 2), ("Aces", 2, 2)],
            "ratings": [],
        }
        try:
            with (
                patch.object(
                    main,
                    "_verified_player_fixture",
                    new=AsyncMock(return_value={
                        "first_name": "Alpha",
                        "second_name": "Beta",
                        "tour": "ATP",
                        "tournament": "US Open",
                    }),
                ),
                patch.object(
                    main,
                    "get_screenshot_player_summary",
                    side_effect=[player_summary, opponent_summary],
                ) as screenshot_summary,
                patch.object(
                    main,
                    "_get_screenshot_statistics_exclusions",
                    new=AsyncMock(return_value={"atp": {}, "wta": {}}),
                ),
                patch.object(main, "get_matchlog_player_summary") as matchlog_summary,
            ):
                await main.matchkeys.callback(
                    interaction,
                    source=main.app_commands.Choice(
                        name="Screenshots", value="screenshots"
                    ),
                )
            interaction.response.defer.assert_awaited_once_with(
                ephemeral=True, thinking=True
            )
            self.assertEqual(screenshot_summary.call_count, 2)
            matchlog_summary.assert_not_called()
            kwargs = interaction.followup.send.await_args.kwargs
            self.assertTrue(kwargs["ephemeral"])
            self.assertIn("Your keys vs Beta", kwargs["embed"].title)
            self.assertIn("Source: Screenshot stats", kwargs["embed"].description)
        finally:
            main._matchlog_identity_index = original_index

    async def test_matchkeys_explains_when_verified_player_has_no_upcoming_fixture(self):
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {30: {"atp": "Alpha"}}
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=30),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        try:
            with patch.object(
                main,
                "_verified_player_fixture",
                new=AsyncMock(return_value=None),
            ):
                await main.matchkeys.callback(
                    interaction,
                    tour=None,
                    source=None,
                )
            message = interaction.followup.send.await_args.args[0]
            self.assertIn("No upcoming ATP fixture", message)
            self.assertIn("Alpha", message)
            self.assertIn("Other upcoming fixtures do not qualify", message)
            self.assertNotIn("couldn't build your private match keys", message)
        finally:
            main._matchlog_identity_index = original_index

    def test_matchkeys_selects_earliest_dated_fixture(self):
        fixtures = [
            {
                "first_name": "Alpha", "second_name": "Later",
                "tour": "ATP", "scheduled_at": "2026-09-12T10:00:00",
            },
            {
                "first_name": "Earlier", "second_name": "Alpha",
                "tour": "ATP", "scheduled_at": "2026-09-10T10:00:00",
            },
        ]
        selected = main._select_verified_player_fixture(
            fixtures, "Alpha", "atp"
        )
        self.assertEqual(selected["first_name"], "Earlier")
        self.assertIsNone(main._select_verified_player_fixture(
            [
                {**fixtures[0], "scheduled_at": None},
                {**fixtures[1], "scheduled_at": None},
            ],
            "Alpha",
            "atp",
        ))
        self.assertIsNone(main._select_verified_player_fixture(
            [
                fixtures[0],
                {**fixtures[1], "scheduled_at": None},
            ],
            "Alpha",
            "atp",
        ))

    def test_mystats_profile_parser_reads_official_dashboard_values(self):
        parsed = main._parse_mystats_player_profile("""
            <table>
              <tr><td>Rank</td><td>1</td></tr>
              <tr><td>Last Week Rank</td><td>2</td></tr>
              <tr><td>Tour Elo</td><td>2102 <br> (Master)</td></tr>
              <tr><td>YTD Wins/Losses</td><td>43/11</td></tr>
              <tr><td>YTD Win Percentage</td><td>80</td></tr>
              <tr><td>Career Wins/Losses</td><td>83/25</td></tr>
              <tr><td>Career Win Percentage</td><td>77</td></tr>
              <tr><td>Form (Last 10 Matches)</td><td>LWWWWWWWWW</td></tr>
            </table>
            <table>
              <tr>
                <th>Tournament</th><th>Round</th><th>Opponent</th>
                <th>Date</th><th>Result</th>
              </tr>
              <tr>
                <td></td><td>US Open</td><td>Round of 16</td>
                <td>fakefederer</td><td>07.09.2026</td><td>1-6,5-7,6-7</td>
              </tr>
              <tr>
                <td></td><td>US Open</td><td>Round of 32</td>
                <td>gosydar</td><td>01.09.2026</td><td>6-2,1-6,6-2,6-7,6-0</td>
              </tr>
            </table>
        """)
        self.assertEqual(parsed["rank"], 1)
        self.assertEqual(parsed["previous_rank"], 2)
        self.assertEqual(parsed["movement"], 1)
        self.assertEqual(parsed["wtsl_elo"], 2102)
        self.assertEqual(parsed["category"], "Master")
        self.assertEqual((parsed["ytd_wins"], parsed["ytd_losses"]), (43, 11))
        self.assertEqual(
            (parsed["career_wins"], parsed["career_losses"]), (83, 25)
        )
        self.assertEqual(parsed["form"], "LWWWWWWWWW")
        self.assertEqual(len(parsed["recent_matches"]), 2)
        self.assertEqual(
            parsed["recent_matches"][0],
            {
                "tournament": "US Open",
                "round": "Round of 16",
                "opponent": "fakefederer",
                "date": "07.09.2026",
                "result": "1-6,5-7,6-7",
            },
        )

    def test_wtslstats_requires_player_tour_and_source_only(self):
        required = {
            parameter.name: parameter.required
            for parameter in main.stats.parameters
        }
        self.assertEqual(
            required,
            {
                "player": True,
                "tour": True,
                "source": True,
                "compare_with": False,
                "period": True,
            },
        )

    def test_wtslleaderboard_requires_tour_source_and_stat(self):
        self.assertEqual(main.wtslleaderboard.name, "wtslleaderboard")
        self.assertEqual(
            {
                parameter.name: parameter.required
                for parameter in main.wtslleaderboard.parameters
            },
            {"tour": True, "source": True, "stat": True},
        )

    async def test_wtslleaderboard_filters_eligibility_and_adds_avatars(self):
        interaction = SimpleNamespace(
            channel=SimpleNamespace(id=main.TOUR_TALK_CHANNEL_ID),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        rows = [
            {
                "player": f"Player {index}",
                "matches": 20 + index,
                "ratings": {
                    "Serve (Overall)": 200 - index,
                    "Return (Overall)": 180 - index,
                    "Under Pressure": 160 - index,
                },
            }
            for index in range(6)
        ]
        rows[4]["matches"] = 19
        avatar_data = {
            f"player {index}": {
                "profile_url": f"https://example.com/player/{index}",
                "avatar_url": f"https://example.com/avatar/{index}.png",
            }
            for index in range(4)
        }
        with (
            patch.object(
                main,
                "get_screenshot_leaderboard_rows",
                return_value=rows,
            ) as read,
            patch.object(
                main,
                "_fetch_leaderboard_avatars",
                new=AsyncMock(return_value=avatar_data),
            ),
            patch.object(
                main,
                "_fetch_live_leaderboard_rankings",
                new=AsyncMock(return_value={
                    f"player {index}": {"id": index}
                    for index in range(5)
                }),
            ),
        ):
            await main.wtslleaderboard.callback(
                interaction,
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Screenshots", value="screenshots"),
                "Serve (Overall)",
            )
        read.assert_called_once_with(main.MATCH_STATS_WORKBOOK, "atp")
        interaction.response.defer.assert_awaited_once_with(
            thinking=True, ephemeral=False
        )
        embeds = interaction.followup.send.await_args.kwargs["embeds"]
        self.assertEqual(len(embeds), 1)
        embed = embeds[0]
        self.assertIn("Serve", embed.title)
        self.assertEqual(
            embed.thumbnail.url,
            "https://example.com/avatar/0.png",
        )
        self.assertIn(
            "[Player 1](https://example.com/player/1)",
            embed.description,
        )
        self.assertIn("Screenshots", embed.footer.text)
        self.assertIn("Minimum 20 matches", embed.footer.text)
        self.assertNotIn("Weekly screenshot leaderboard", embed.footer.text)
        self.assertIn(
            "Formula: 1st Serve % + 1st Serve Won % + 2nd Serve Won % "
            "+ Aces − Double Faults",
            embed.footer.text,
        )
        self.assertNotIn("Player 4", embed.description)
        self.assertNotIn("Player 5", embed.description)

    def test_overall_leaderboard_footers_include_selected_formula(self):
        expected = {
            "Serve (Overall)": "1st Serve % + 1st Serve Won %",
            "Return (Overall)": (
                "1st Serve Return Points Won % + "
                "2nd Serve Return Points Won % + Break Points Won %"
            ),
            "Under Pressure": (
                "Break Points Won % + Break Points Saved % + "
                "Tie-breaks Won % + Deciding Sets Won %"
            ),
        }
        for category, stat in main.LEADERBOARD_CATEGORIES:
            with self.subTest(stat=stat):
                embeds = main._build_leaderboard_embeds(
                    [{
                        "player": "Alpha",
                        "matches": 20,
                        "category": category,
                        "stat": stat,
                        "value": 100.0,
                        "place": 1,
                    }],
                    "screenshots",
                    "atp",
                    {},
                )
                self.assertIn("Formula:", embeds[0].footer.text)
                self.assertIn(expected[stat], embeds[0].footer.text)

    async def test_weekly_leaderboards_edit_existing_and_post_only_missing(self):
        existing_embed = main.discord.Embed(title="ATP 🎾 Serve Leaderboard")
        existing_embed.set_footer(text=main.WEEKLY_LEADERBOARD_LEGACY_MARKER)
        existing_message = SimpleNamespace(
            author=SimpleNamespace(id=1),
            embeds=[existing_embed],
            edit=AsyncMock(),
        )

        class FakeChannel:
            def __init__(self):
                self.send = AsyncMock()

            async def history(self, limit):
                self.history_limit = limit
                yield existing_message

        updated = main.discord.Embed(title="ATP 🎾 Serve Leaderboard")
        missing = main.discord.Embed(title="WTA ↩️ Return Leaderboard")
        channel = FakeChannel()
        with patch.object(
            main,
            "_generate_weekly_leaderboard_embeds",
            new=AsyncMock(return_value=[updated, missing]),
        ):
            await main._upsert_weekly_leaderboards(channel)

        self.assertEqual(channel.history_limit, 500)
        existing_message.edit.assert_awaited_once_with(embed=updated)
        channel.send.assert_awaited_once_with(embed=missing)

    async def test_wtsl_verification_request_dms_owner_and_confirms_privately(self):
        owner = SimpleNamespace(send=AsyncMock())
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=123, mention="<@123>"),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        with (
            patch.object(
                main,
                "reserve_verification_request",
                return_value=True,
            ),
            patch.object(
                main,
                "release_verification_request",
            ),
            patch.object(
                main,
                "_get_stats_rankings",
                new=AsyncMock(return_value={
                    "atp": {"alpha ace": "Alpha Ace"},
                    "wta": {},
                }),
            ),
            patch.object(main, "_matchlog_links", return_value={}),
            patch.object(
                main.client,
                "fetch_user",
                new=AsyncMock(return_value=owner),
            ),
        ):
            await main._submit_wtsl_verification_request(
                interaction,
                "ATP",
                "Alpha Ace",
            )

        interaction.response.defer.assert_awaited_once_with(
            ephemeral=True,
            thinking=True,
        )
        owner.send.assert_awaited_once()
        owner_dm = owner.send.await_args.args[0]
        self.assertIn("<@123>", owner_dm)
        self.assertIn("ATP: Alpha Ace", owner_dm)
        self.assertIn("/linkmatchlogplayer", owner_dm)
        interaction.followup.send.assert_awaited_once()
        self.assertTrue(
            interaction.followup.send.await_args.kwargs["ephemeral"]
        )

    async def test_wtsl_verification_request_honors_durable_cooldown(self):
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=123, mention="<@123>"),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        with (
            patch.object(
                main,
                "reserve_verification_request",
                return_value=False,
            ) as reserve,
            patch.object(main.client, "fetch_user", new=AsyncMock()) as fetch_user,
        ):
            await main._submit_wtsl_verification_request(
                interaction,
                "ATP",
                "Alpha Ace",
            )

        reserve.assert_called_once_with(123, 300)
        fetch_user.assert_not_awaited()
        self.assertIn(
            "already sent recently",
            interaction.followup.send.await_args.args[0],
        )

    async def test_wtsl_verification_panel_is_persistent_and_updates_in_place(self):
        view = main.WTSLVerificationRequestView()
        self.assertIsNone(view.timeout)
        self.assertEqual(
            view.children[0].custom_id,
            main.WTSL_VERIFICATION_BUTTON_CUSTOM_ID,
        )
        existing_embed = main.discord.Embed(
            title=main.WTSL_VERIFICATION_PANEL_TITLE
        )
        existing_message = SimpleNamespace(
            id=10,
            author=SimpleNamespace(id=1),
            embeds=[existing_embed],
            edit=AsyncMock(),
            delete=AsyncMock(),
        )
        duplicate_message = SimpleNamespace(
            id=11,
            author=SimpleNamespace(id=1),
            embeds=[existing_embed],
            edit=AsyncMock(),
            delete=AsyncMock(),
        )

        class FakeChannel:
            async def history(self, limit):
                self.history_limit = limit
                yield duplicate_message
                yield existing_message

            fetch_message = AsyncMock(return_value=existing_message)
            send = AsyncMock()

        channel = FakeChannel()
        with (
            patch.object(main.client, "wait_until_ready", new=AsyncMock()),
            patch.object(main.client, "get_channel", return_value=channel),
            patch.object(
                main,
                "load_bot_message",
                return_value=(main.WTSL_VERIFICATION_CHANNEL_ID, 10),
            ),
            patch.object(main, "save_bot_message") as save_message,
        ):
            await main._upsert_wtsl_verification_panel()

        self.assertIsNone(channel.history_limit)
        channel.fetch_message.assert_awaited_once_with(10)
        existing_message.edit.assert_awaited_once()
        duplicate_message.delete.assert_awaited_once()
        channel.send.assert_not_awaited()
        save_message.assert_called_once_with(
            main.WTSL_VERIFICATION_PANEL_KEY,
            main.WTSL_VERIFICATION_CHANNEL_ID,
            10,
        )
        self.assertEqual(
            existing_message.edit.await_args.kwargs["embed"].title,
            main.WTSL_VERIFICATION_PANEL_TITLE,
        )

    async def test_wtsl_verification_view_registers_before_ready(self):
        with patch.object(main.client, "add_view") as add_view:
            await main.client.setup_hook()
        add_view.assert_called_once()
        self.assertIsInstance(
            add_view.call_args.args[0],
            main.WTSLVerificationRequestView,
        )

    def test_leaderboard_ranks_lower_double_faults_as_better(self):
        rows = [
            {
                "player": "Low",
                "metrics": {"Double Faults": 1},
                "ratings": {},
            },
            {
                "player": "High",
                "metrics": {"Double Faults": 5},
                "ratings": {},
            },
        ]
        cards = main._leaderboard_cards(rows, "Double Faults")
        self.assertEqual([card["player"] for card in cards], ["Low", "High"])

    async def test_stats_views_and_compares_named_players(self):
        self.assertEqual(main.stats.name, "wtslstats")
        interaction = SimpleNamespace(
            channel=SimpleNamespace(id=main.TOUR_TALK_CHANNEL_ID),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        alpha = {
            "player": "Alpha", "matches": 2, "metrics": [],
            "ratings": [("Serve Rating", 160)],
        }
        beta = {
            "player": "Beta", "matches": 3, "metrics": [],
            "ratings": [("Serve Rating", 170)],
        }
        with patch.object(
            main,
            "get_matchlog_player_summary_by_name",
            side_effect=[alpha, beta],
        ):
            await main.stats.callback(
                interaction,
                "alpha",
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Career", value="career"),
                "beta",
            )
        interaction.response.defer.assert_awaited_once_with(
            thinking=True, ephemeral=False
        )
        embed = interaction.followup.send.await_args.kwargs["embed"]
        self.assertIn("Alpha vs Beta", embed.title)
        fields = {field.name: field.value for field in embed.fields}
        self.assertIn("**Serve Rating:** 160 | 170", fields["⚡ Ratings"])
        self.assertIn("Source: MatchLog", embed.footer.text)
        self.assertIn(
            "Serve Rating",
            fields["🧮 Rating Formulas"],
        )

    async def test_stats_screenshot_source_uses_selected_tour(self):
        interaction = SimpleNamespace(
            channel=SimpleNamespace(id=main.TOUR_TALK_CHANNEL_ID),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "source": "screenshots",
            "matches": 3,
            "metrics": [("Aces", 4, 3)],
            "ratings": [],
            "recent_matches": [],
        }
        with (
            patch.object(
                main,
                "get_screenshot_player_summary",
                return_value=summary,
            ) as screenshot_summary,
            patch.object(
                main,
                "_get_screenshot_statistics_exclusions",
                new=AsyncMock(return_value={"atp": {}, "wta": {}}),
            ),
            patch.object(main, "get_matchlog_player_summary_by_name") as matchlog,
        ):
            await main.stats.callback(
                interaction,
                "Alpha",
                source=main.app_commands.Choice(
                    name="Screenshots",
                    value="screenshots",
                ),
                tour=main.app_commands.Choice(name="ATP", value="atp"),
                period=main.app_commands.Choice(
                    name="Career", value="career"
                ),
            )
        self.assertEqual(
            screenshot_summary.call_args.args[:4],
            (
                main.MATCH_STATS_WORKBOOK,
                "Alpha",
                "atp",
                "career",
            ),
        )
        matchlog.assert_not_called()
        embed = interaction.followup.send.await_args.kwargs["embed"]
        self.assertIn("WTSL Stats Dashboard", embed.title)
        self.assertIn("Source: Screenshots", embed.description)
        self.assertIn("verified matches used", embed.description)
        self.assertNotIn("screenshot matches", embed.description)
        self.assertIn(
            "📊 Career Stats",
            {field.name for field in embed.fields},
        )
        self.assertIn("Source: Screenshots", embed.footer.text)

    async def test_wtslstats_applies_one_period_to_both_compared_players(self):
        interaction = SimpleNamespace(
            channel=SimpleNamespace(id=main.TOUR_TALK_CHANNEL_ID),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        first = {
            "player": "Alpha", "matches": 2, "metrics": [], "ratings": [],
            "period": "90d", "period_label": "Last 90 days",
        }
        second = {
            "player": "Beta", "matches": 3, "metrics": [], "ratings": [],
            "period": "90d", "period_label": "Last 90 days",
        }
        with patch.object(
            main,
            "_get_wtslstats_player_summary",
            side_effect=[first, second],
        ) as summaries:
            await main.stats.callback(
                interaction,
                "Alpha",
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Last 90 days", value="90d"),
                "Beta",
            )
        self.assertEqual(summaries.call_count, 2)
        first_args = summaries.call_args_list[0].args
        second_args = summaries.call_args_list[1].args
        self.assertEqual(first_args[3], "90d")
        self.assertEqual(second_args[3], "90d")
        self.assertEqual(first_args[4], second_args[4])
        embed = interaction.followup.send.await_args.kwargs["embed"]
        self.assertIn("Period: Last 90 days", embed.description)

    def test_mystats_percentiles_use_correct_ordinals(self):
        self.assertEqual(main._ordinal(71), "71st")
        self.assertEqual(main._ordinal(22), "22nd")
        self.assertEqual(main._ordinal(33), "33rd")
        self.assertEqual(main._ordinal(11), "11th")
        self.assertEqual(main._ordinal(12), "12th")
        self.assertEqual(main._ordinal(13), "13th")

    def test_recent_match_fallback_obeys_selected_period_and_as_of(self):
        profile = {
            "recent_matches": [
                {"date": "15.02.2025", "result": "6-4 6-4", "opponent": "Inside"},
                {"date": "15.01.2025", "result": "6-4 6-4", "opponent": "Outside"},
                {"date": "02.03.2025", "result": "6-4 6-4", "opponent": "Future"},
                {"date": "", "result": "6-4 6-4", "opponent": "Undated"},
                {"date": "20.02.2025", "result": "Scheduled", "opponent": "Pending"},
            ],
        }
        recent = main._dashboard_recent_results(
            profile,
            "Alpha",
            "30d",
            "2025-03-01",
        )
        self.assertEqual([match["opponent"] for match in recent], ["Inside"])

    def test_recent_official_results_use_current_played_rows_only(self):
        profile = {
            "official_results": [
                {
                    "date": "07.09.2026",
                    "tournament": "Kingston",
                    "p1": "Ruze",
                    "p2": "Old Player",
                    "result": "Walkover",
                },
                {
                    "date": "06.09.2026",
                    "tournament": "Kingston",
                    "p1": "Ruze",
                    "p2": "Madferit",
                    "result": "6-4,6-4",
                },
                {
                    "date": "05.09.2026",
                    "tournament": "Kingston",
                    "p1": "Dani21",
                    "p2": "Ruze",
                    "result": "6-4,6-4",
                },
                {
                    "date": "04.09.2026",
                    "tournament": "Kingston",
                    "p1": "Ruze",
                    "p2": "Coin Toss Opponent",
                    "result": "Coin toss",
                },
            ],
        }
        recent = main._dashboard_recent_results(
            profile,
            "Ruze",
            "career",
            "2026-09-11",
        )

        self.assertEqual(
            [match["opponent"] for match in recent],
            ["Madferit", "Dani21"],
        )
        self.assertEqual(
            [match["result"] for match in recent],
            ["W 6-4,6-4", "L 6-4,6-4"],
        )

    def test_recent_player_page_history_takes_precedence_over_stale_feed(self):
        profile = {
            "official_results": [
                {
                    "date": "11.09.2026",
                    "tournament": "Stale Event",
                    "p1": "Dani21",
                    "p2": "Stale Opponent",
                    "result": "6-0,6-0",
                },
            ],
            "recent_matches": [
                {
                    "date": "10.09.2026",
                    "tournament": "US Open",
                    "opponent": "Madferit",
                    "result": "0-6,1-6,4-6",
                },
                {
                    "date": "08.09.2026",
                    "tournament": "US Open",
                    "opponent": "fakefederer",
                    "result": "6-2,6-2,6-2",
                },
            ],
        }
        recent = main._dashboard_recent_results(
            profile,
            "Dani21",
            "career",
            "2026-09-12",
        )

        self.assertEqual(
            [match["opponent"] for match in recent],
            ["Madferit", "fakefederer"],
        )
        self.assertEqual(
            [match["result"] for match in recent],
            ["L 0-6,1-6,4-6", "W 6-2,6-2,6-2"],
        )

    def test_current_year_highlights_keep_only_titles_and_finals(self):
        profile = {
            "player_name": "Alpha",
            "rankings": {
                "beta": {"rank": 5},
                "gamma": {"rank": 2},
            },
            "official_results": [
                {
                    "p1": "Alpha", "p2": "Beta", "result": "6-4 6-4",
                    "date": "01.09.2026", "round": "Final",
                    "tournament": "London Open",
                },
                {
                    "p1": "Gamma", "p2": "Alpha", "result": "6-3 6-2",
                    "date": "15.08.2026", "round": "Final",
                    "tournament": "Paris Masters",
                },
            ],
        }
        highlights = main._mystats_year_summary(profile)
        self.assertIn("won **London Open**", highlights)
        self.assertIn("reached the final at **Paris Masters**", highlights)
        self.assertNotIn("best-ranked win", highlights)
        self.assertNotIn("furthest round", highlights)

    async def test_mystats_highlights_keep_cached_results_when_rankings_fail(self):
        cached = [{
            "p1": "Alpha", "p2": "Beta", "result": "6-4 6-4",
            "date": "01.09.2026", "round": "Final",
            "tournament": "London Open",
        }]
        response = AsyncMock()
        response.status = 503
        response.__aenter__.return_value = response
        session = MagicMock()
        session.__aenter__ = AsyncMock(return_value=session)
        session.__aexit__ = AsyncMock(return_value=None)
        session.get.return_value = response
        self.mystats_ranking_patch.stop()
        try:
            with (
                patch.object(
                    main, "fetch_player_results",
                    new=AsyncMock(return_value=cached),
                ),
                patch.object(main.aiohttp, "ClientSession", return_value=session),
            ):
                profile = await main._fetch_mystats_ranking("Alpha", "atp")
        finally:
            self.mystats_ranking_patch.start()
        self.assertEqual(profile["official_results"], cached)
        self.assertIn("won **London Open**", main._mystats_year_summary(profile))

    async def test_mystats_profile_timeout_keeps_cached_official_results(self):
        cached = [{
            "p1": "Alpha", "p2": "Beta", "result": "6-4 6-4",
            "date": "01.09.2026", "round": "Final",
            "tournament": "London Open",
        }]
        session = MagicMock()
        session.__aenter__ = AsyncMock(return_value=session)
        session.__aexit__ = AsyncMock(return_value=None)
        session.get.side_effect = asyncio.TimeoutError
        self.mystats_ranking_patch.stop()
        try:
            with (
                patch.object(
                    main, "fetch_player_results",
                    new=AsyncMock(return_value=cached),
                ),
                patch.object(main.aiohttp, "ClientSession", return_value=session),
            ):
                profile = await main._fetch_mystats_ranking("Alpha", "atp")
        finally:
            self.mystats_ranking_patch.start()
        self.assertEqual(profile["official_results"], cached)
        self.assertIn("won **London Open**", main._mystats_year_summary(profile))

    def test_dashboards_include_all_available_career_stats(self):
        metrics = [
            (f"Metric {index}", index, 2)
            for index in range(14)
        ] + [("Average Rally Length", 6.4, 2)]
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "source": "matchlog",
            "matches": 2,
            "metrics": metrics,
            "ratings": [
                ("Serve Rating", 160),
                ("Return Rating", 140),
                ("Under Pressure", 120),
            ],
            "recent_matches": [],
        }
        mystats = main._build_mystats_dashboard(summary, {}, None)
        named = main._build_wtslstats_dashboard(summary, "matchlog")
        for embed in (mystats, named):
            career_text = "\n".join(
                field.value
                for field in embed.fields
                if field.name.startswith("📊 Career Stats")
            )
            self.assertIn("Average Rally Length", career_text)
            self.assertIn("Metric 13", career_text)
            self.assertTrue(all(len(field.value) <= 1024 for field in embed.fields))
        named_career = "\n".join(
            field.value
            for field in named.fields
            if field.name.startswith("📊 Career Stats")
        )
        self.assertIn("(2 matches used)", named_career)

    def test_screenshot_coverage_is_after_rating_formulas(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "source": "screenshots",
            "period": "career",
            "period_label": "Career",
            "matches": 2,
            "metrics": [],
            "ratings": [],
            "recent_matches": [],
        }
        with patch.object(
            main,
            "_screenshot_coverage_lines",
            return_value=["coverage"],
        ):
            mystats = main._build_mystats_dashboard(
                summary,
                {},
                None,
                screenshot_summary=summary,
            )
            wtslstats = main._build_wtslstats_dashboard(
                summary,
                "screenshots",
                {},
            )
            comparison = main._build_wtslstats_comparison_dashboard(
                summary,
                {**summary, "player": "Beta"},
                "screenshots",
                {},
                {},
            )
        mystats_names = [field.name for field in mystats.fields]
        self.assertLess(
            mystats_names.index("🧮 Rating Formulas"),
            mystats_names.index("🖼️ Screenshot Coverage"),
        )
        for public_embed in (wtslstats, comparison):
            self.assertNotIn(
                "🖼️ Screenshot Coverage",
                [field.name for field in public_embed.fields],
            )
        self.assertNotIn(
            "🖼️ Alpha Screenshot Coverage",
            [field.name for field in comparison.fields],
        )

    def test_matchlog_dashboards_show_unverified_official_match_count(self):
        original_coverage = main._matchlog_raw_coverage_index
        main._matchlog_raw_coverage_index = {
            ("atp", "alpha"): "2023-04-05"
        }
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "source": "matchlog",
            "period": "career",
            "period_label": "Career",
            "matches": 1,
            "coverage_start": "2024-11-01",
            "coverage_end": "2026-09-08",
            "metrics": [],
            "ratings": [],
            "recent_matches": [],
        }
        profile = {
            "official_results": [
                {
                    "tour": "atp", "p1": "Alpha", "p2": "Beta",
                    "date": "01.06.2022", "result": "6-4,6-4",
                },
                {
                    "tour": "atp", "p1": "Gamma", "p2": "Alpha",
                    "date": "02.09.2026", "result": "7-6,6-3",
                },
                {
                    "tour": "atp", "p1": "Alpha", "p2": "Delta",
                    "date": "03.09.2026", "result": "Walkover",
                },
            ],
        }
        try:
            mystats = main._build_mystats_dashboard(summary, profile, None)
            named = main._build_wtslstats_dashboard(
                summary, "matchlog", profile
            )
            for embed in (mystats, named):
                self.assertIn(
                    "**2** official played matches total"
                    " • **1** without verified MatchLog stats",
                    embed.description,
                )
                coverage = next(
                    field.value
                    for field in embed.fields
                    if field.name == "🗓️ MatchLog Coverage"
                )
                self.assertIn("Playing Since:** 01 Jun 2022", coverage)
                self.assertIn(
                    "First MatchLog Record:** 05 Apr 2023", coverage
                )
                self.assertIn(
                    "First Verified MatchLog Match:** 01 Nov 2024", coverage
                )
                self.assertIn(
                    "Last Verified MatchLog Match:** 08 Sep 2026", coverage
                )
                self.assertIn("may contain missing matches", coverage)
        finally:
            main._matchlog_raw_coverage_index = original_coverage

    def test_dashboard_separates_scheduled_fixture_from_completed_last_five(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "source": "screenshots",
            "matches": 2,
            "metrics": [],
            "ratings": [],
        }
        profile = {
            "recent_matches": [
                {
                    "date": "10.09.2026",
                    "opponent": "Beta",
                    "result": "Scheduled",
                },
                {
                    "date": "08.09.2026",
                    "opponent": "Gamma",
                    "result": "6-4,6-3",
                },
            ],
        }
        fixture = {
            "first_name": "Alpha",
            "second_name": "Beta",
            "tournament": "London Masters",
            "scheduled_at": "2026-09-10T18:00:00+00:00",
            "odds": [1.55, 2.45],
        }
        embed = main._build_wtslstats_dashboard(
            summary,
            "screenshots",
            profile,
            fixture,
        )
        fields = {field.name: field.value for field in embed.fields}
        self.assertNotIn("Scheduled", fields["🗓️ Last 5 matches"])
        self.assertIn("Gamma", fields["🗓️ Last 5 matches"])
        self.assertIn("Alpha 1.55", fields["⏭️ Upcoming Match & Odds"])
        self.assertIn("Beta 2.45", fields["⏭️ Upcoming Match & Odds"])
        self.assertIn("🧮 Rating Formulas", fields)

    def test_wtslstats_dashboard_includes_most_picked_characters(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "source": "matchlog",
            "matches": 2,
            "metrics": [],
            "ratings": [],
            "period": "career",
            "as_of": "2026-09-08",
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "Beta",
                    "p1_character": "R. Federer",
                    "result": "6-4 6-4",
                },
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "Beta",
                    "p1_character": "R. Federer",
                    "result": "6-4 6-4",
                },
                {
                    "tour": "atp",
                    "p1": "Gamma",
                    "p2": "Alpha",
                    "p2_character": "R. Federer",
                    "result": "4-6 4-6",
                },
            ],
        }
        embed = main._build_wtslstats_dashboard(
            summary, "matchlog", profile
        )
        fields = {field.name: field.value for field in embed.fields}
        self.assertIn("🎮 Most Picked Characters", fields)
        self.assertIn("#1 R. Federer", fields["🎮 Most Picked Characters"])
        self.assertIn("2 picks", fields["🎮 Most Picked Characters"])
        self.assertIn(
            "Character recorded in **2 of 2** official matches",
            fields["🎮 Most Picked Characters"],
        )

    def test_available_official_feed_with_no_qualifying_matches_reports_zero(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "source": "screenshots",
            "matches": 1,
            "period": "career",
            "match_records": [{"opponent": "Beta", "result": "6-4 6-4"}],
            "metrics": [],
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "Beta",
                    "result": "Coin toss",
                },
            ],
        }
        rendered = "\n".join(main._screenshot_coverage_lines(summary, profile))
        self.assertIn("Official matches on record:** 0", rendered)
        self.assertIn("Verified screenshots available:** 0", rendered)
        self.assertIn("Verified matches used:** 0 of 0 (0%)", rendered)
        self.assertNotIn("feed is unavailable", rendered)

    def test_official_counts_render_without_detailed_screenshot_records(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "source": "screenshots",
            "matches": 1,
            "period": "career",
            "match_records": [],
            "metrics": [],
        }
        profile = {
            "player_name": "Alpha",
            "official_results": [
                {
                    "tour": "atp",
                    "p1": "Alpha",
                    "p2": "Beta",
                    "result": "Retired",
                },
            ],
        }
        rendered = "\n".join(main._screenshot_coverage_lines(summary, profile))
        self.assertIn("Official matches on record:** 1", rendered)
        self.assertIn("Verified screenshots available:** 0", rendered)
        self.assertIn("Verified matches used:** 0 of 0 (0%)", rendered)
        self.assertIn("Detailed screenshot matching is unavailable", rendered)
        self.assertNotIn("feed is unavailable", rendered)

    def test_wtslstats_uses_official_scores_for_deciding_set_record(self):
        summary = {
            "player": "Franky Franchicha",
            "tour": "atp",
            "source": "screenshots",
            "matches": 162,
            "metrics": [("Deciding Sets Won %", 1.0, 162)],
            "ratings": [("Under Pressure", 400.0)],
            "period": "career",
            "as_of": "2026-09-08",
        }
        profile = {
            "player_name": "Franky Franchicha",
            "official_results": [
                {
                    "tour": "atp",
                    "p1": "Franky Franchicha",
                    "p2": "Alpha",
                    "result": "6-4 3-6 6-2",
                },
                {
                    "tour": "atp",
                    "p1": "Beta",
                    "p2": "Franky Franchicha",
                    "result": "4-6 6-3 6-4",
                },
                {
                    "tour": "atp",
                    "p1": "Franky Franchicha",
                    "p2": "Gamma",
                    "result": "6-4 6-4",
                },
            ],
        }
        updated = main._with_official_result_metrics(summary, profile)
        deciding = next(
            item for item in updated["metrics"]
            if item[0] == "Deciding Sets Won %"
        )
        self.assertEqual(deciding, ("Deciding Sets Won %", 0.5, 2))

    def test_official_deciding_set_uses_player_one_as_feed_winner(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
        }
        profile = {
            "official_results": [{
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Beta",
                # Even if a malformed score appears reversed, feed position is
                # authoritative for the match winner.
                "result": "6-4 3-6 4-6",
            }],
        }
        self.assertEqual(
            main._official_deciding_set_metric(summary, profile),
            (1.0, 1),
        )

    def test_leaderboard_deciding_set_uses_official_results(self):
        row = {
            "player": "Alpha",
            "tour": "atp",
            "matches": 40,
            "metrics": {
                "Break Points Won %": 0.5,
                "Deciding Sets Won %": 1.0,
            },
            "ratings": {"Under Pressure": 200.0},
        }
        results = [
            {
                "tour": "atp", "p1": "Alpha", "p2": "Beta",
                "result": "6-4 3-6 6-2",
            },
            {
                "tour": "atp", "p1": "Gamma", "p2": "Alpha",
                "result": "4-6 6-3 6-4",
            },
        ]
        updated = main._with_official_result_metrics_leaderboard_row(
            row, results
        )
        self.assertEqual(updated["metrics"]["Deciding Sets Won %"], 0.5)
        self.assertEqual(updated["ratings"]["Under Pressure"], 100.0)

    def test_official_tiebreak_metric_uses_score_orientation(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
        }
        profile = {
            "official_results": [
                {
                    "tour": "atp", "p1": "Alpha", "p2": "Beta",
                    "result": "7-6(7-4) 3-6 6-2",
                },
                {
                    "tour": "atp", "p1": "Gamma", "p2": "Alpha",
                    "result": "7-6 3-6 6-4",
                },
                {
                    "tour": "atp", "p1": "Alpha", "p2": "Delta",
                    "result": "4-3 3-4 4-2",
                },
            ],
        }
        self.assertEqual(
            main._official_tiebreak_metric(summary, profile),
            (0.5, 4),
        )

    def test_persisted_fallback_does_not_override_pressure_metrics(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "period": "career",
            "metrics": [
                ("Tie-breaks Won %", 0.6, 10),
                ("Deciding Sets Won %", 0.7, 10),
            ],
            "ratings": [("Under Pressure", 204.65)],
        }
        profile = {
            "official_results": [{
                "tour": "atp",
                "p1": "Alpha",
                "p2": "Beta",
                "result": "7-6 3-6 4-6",
                "source_url": "persisted-matchlog",
            }],
        }
        self.assertEqual(
            main._with_official_result_metrics(summary, profile),
            summary,
        )

    def test_comparison_dashboard_includes_pair_odds(self):
        first = {"player": "Alpha", "metrics": [], "ratings": [], "matches": 2}
        second = {"player": "Beta", "metrics": [], "ratings": [], "matches": 3}
        fixture = {
            "first_name": "Alpha",
            "second_name": "Beta",
            "tournament": "US Open",
            "scheduled_at": "2026-09-12T17:00:00+00:00",
            "odds": [1.80, 2.05],
        }
        embed = main._build_wtslstats_comparison_dashboard(
            first,
            second,
            "screenshots",
            fixture=fixture,
        )
        fields = {field.name: field.value for field in embed.fields}
        self.assertIn("Alpha 1.80", fields["🎯 Upcoming Match Odds"])
        self.assertIn("Beta 2.05", fields["🎯 Upcoming Match Odds"])

    async def test_stats_autocomplete_filters_summary_players(self):
        interaction = SimpleNamespace(
            channel=SimpleNamespace(id=main.TOUR_TALK_CHANNEL_ID)
        )
        names = ["Alpha", "Beta", "ATP: Shared Name", "WTA: Shared Name"]
        with patch.object(main, "_stats_autocomplete_cache", (1, names)):
            choices = await main._stats_player_autocomplete(interaction, "shared")
        self.assertEqual(
            [(choice.name, choice.value) for choice in choices],
            [
                ("ATP: Shared Name", "ATP: Shared Name"),
                ("WTA: Shared Name", "WTA: Shared Name"),
            ],
        )

    async def test_stats_autocomplete_caps_discord_choices(self):
        interaction = SimpleNamespace(
            channel=SimpleNamespace(id=main.TOUR_TALK_CHANNEL_ID)
        )
        with patch.object(
            main,
            "_stats_autocomplete_cache",
            (1, [f"Player {number:02}" for number in range(30)]),
        ):
            choices = await main._stats_player_autocomplete(interaction, "")
        self.assertEqual(len(choices), 25)

    async def test_stats_autocomplete_never_opens_workbook_on_cache_miss(self):
        interaction = SimpleNamespace(
            channel=SimpleNamespace(id=main.TOUR_TALK_CHANNEL_ID)
        )
        with (
            patch.object(main, "_stats_autocomplete_cache", None),
            patch.object(
                main,
                "_matchlog_identity_index",
                {30: {"atp": "Alpha"}},
            ),
            patch.object(
                main,
                "_get_stats_autocomplete_names",
                side_effect=AssertionError("workbook read attempted"),
            ),
        ):
            choices = await main._stats_player_autocomplete(interaction, "alp")
        self.assertEqual(
            [(choice.name, choice.value) for choice in choices],
            [("Alpha", "Alpha")],
        )

    async def test_autocomplete_refresh_replaces_collisions_and_removed_names(self):
        original_cache = main._stats_autocomplete_cache
        try:
            with tempfile.TemporaryDirectory() as directory:
                workbook = Path(directory) / "stats.xlsx"
                workbook.write_bytes(b"workbook")
                with (
                    patch.object(main, "MATCH_STATS_WORKBOOK", workbook),
                    patch.object(
                        main,
                        "get_matchlog_player_summary_names",
                        side_effect=[
                            ["ATP: Shared", "WTA: Shared"],
                            [],
                        ],
                    ),
                ):
                    await main._refresh_stats_autocomplete_cache()
                    self.assertEqual(
                        main._stats_autocomplete_cache[1],
                        ["ATP: Shared", "WTA: Shared"],
                    )
                    await main._refresh_stats_autocomplete_cache()
                    self.assertEqual(main._stats_autocomplete_cache[1], [])
        finally:
            main._stats_autocomplete_cache = original_cache

    async def test_secondary_stats_jobs_wait_for_matchlog_rebuild(self):
        original_state = main._matchlog_rebuild_state
        waits = []

        async def finish_rebuild(delay):
            waits.append(delay)
            main._matchlog_rebuild_state = "complete"

        try:
            main._matchlog_rebuild_state = "running"
            with patch.object(main.asyncio, "sleep", side_effect=finish_rebuild):
                await main._wait_for_matchlog_rebuild()
            self.assertEqual(waits, [5])
        finally:
            main._matchlog_rebuild_state = original_state

    async def test_stats_reports_player_without_matchlog_data(self):
        interaction = SimpleNamespace(
            channel=SimpleNamespace(id=main.TOUR_TALK_CHANNEL_ID),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        with patch.object(
            main,
            "get_matchlog_player_summary_by_name",
            return_value=None,
        ):
            await main.stats.callback(
                interaction,
                "Unknown",
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Career", value="career"),
            )
        self.assertEqual(
            interaction.followup.send.await_args.args[0],
            "No verified MatchLog statistics were found for **Unknown**.",
        )

    async def test_stats_reports_missing_comparison_player(self):
        interaction = SimpleNamespace(
            channel=SimpleNamespace(id=main.TOUR_TALK_CHANNEL_ID),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        alpha = {
            "player": "Alpha", "matches": 2, "metrics": [], "ratings": [],
        }
        with patch.object(
            main,
            "get_matchlog_player_summary_by_name",
            side_effect=[alpha, None],
        ):
            await main.stats.callback(
                interaction,
                "Alpha",
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Career", value="career"),
                "Unknown",
            )
        self.assertEqual(
            interaction.followup.send.await_args.args[0],
            "No verified MatchLog statistics were found for **Unknown**.",
        )

    async def test_stats_caps_long_comparison_embed_fields(self):
        interaction = SimpleNamespace(
            channel=SimpleNamespace(id=main.TOUR_TALK_CHANNEL_ID),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        summary = {
            "player": "A" * 1900,
            "matches": 1,
            "metrics": [("Aces", 1, 1)],
            "ratings": [],
        }
        with patch.object(
            main,
            "get_matchlog_player_summary_by_name",
            side_effect=[summary, summary],
        ):
            await main.stats.callback(
                interaction,
                "Alpha",
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Career", value="career"),
                "Beta",
            )
        embed = interaction.followup.send.await_args.kwargs["embed"]
        self.assertTrue(all(len(field.value) <= 1024 for field in embed.fields))
        self.assertLessEqual(len(embed.footer.text), 2048)

    async def test_stats_denies_ordinary_channels_privately(self):
        channel = SimpleNamespace(
            id=999,
            parent_id=None,
            permissions_for=lambda _role: SimpleNamespace(view_channel=True),
        )
        interaction = SimpleNamespace(
            channel=channel,
            guild=SimpleNamespace(default_role=object()),
            user=SimpleNamespace(
                guild_permissions=SimpleNamespace(
                    administrator=False,
                    manage_guild=False,
                )
            ),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        with patch.object(
            main, "get_matchlog_player_summary_by_name"
        ) as read_summary:
            await main.stats.callback(
                interaction,
                "Alpha",
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Career", value="career"),
            )
        read_summary.assert_not_called()
        interaction.response.defer.assert_awaited_once_with(
            thinking=True, ephemeral=True
        )
        self.assertTrue(interaction.followup.send.await_args.kwargs["ephemeral"])
        self.assertIn(
            "<#812742338669576252>",
            interaction.followup.send.await_args.args[0],
        )
        self.assertIn(
            "`/wtslstats`",
            interaction.followup.send.await_args.args[0],
        )

    def test_stats_allows_admin_inside_private_staff_channel(self):
        channel = SimpleNamespace(
            id=999,
            parent_id=None,
            permissions_for=lambda _role: SimpleNamespace(view_channel=False),
        )
        interaction = SimpleNamespace(
            channel=channel,
            guild=SimpleNamespace(default_role=object()),
            user=SimpleNamespace(
                guild_permissions=SimpleNamespace(
                    administrator=True,
                    manage_guild=False,
                )
            ),
        )
        self.assertTrue(main._stats_channel_allowed(interaction))

    def test_stats_allows_additional_public_channel_and_its_threads(self):
        additional_channel = 1411110448333328455
        for channel in (
            SimpleNamespace(id=additional_channel, parent_id=None),
            SimpleNamespace(id=999, parent_id=additional_channel),
        ):
            interaction = SimpleNamespace(
                channel=channel,
                guild=None,
                user=SimpleNamespace(guild_permissions=None),
            )
            self.assertTrue(main._stats_channel_allowed(interaction))

    async def test_stats_autocomplete_hides_names_in_disallowed_channel(self):
        interaction = SimpleNamespace(
            channel=SimpleNamespace(id=999, parent_id=None),
            guild=None,
            user=SimpleNamespace(guild_permissions=None),
        )
        with patch.object(main, "_get_stats_autocomplete_names") as names:
            choices = await main._stats_player_autocomplete(interaction, "")
        self.assertEqual(choices, [])
        names.assert_not_called()

    async def test_mystats_restores_admin_approved_identity_on_demand(self):
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=30),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        summary = {
            "player": "Alpha", "matches": 1,
            "recent_matches": [], "metrics": [],
        }
        with (
            patch.object(
                main, "get_matchlog_player_summary",
                side_effect=[None, summary],
            ) as read_summary,
            patch.object(
                main, "_restore_matchlog_identity_for_user",
                new=AsyncMock(return_value=True),
            ) as restore,
        ):
            await main.mystats.callback(
                interaction,
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Career", value="career"),
            )
        restore.assert_awaited_once_with(30)
        self.assertEqual(read_summary.call_count, 2)
        self.assertIn(
            "My WTSL Dashboard",
            interaction.followup.send.await_args.kwargs["embed"].title,
        )

    async def test_mystats_missing_identity_requires_admin_approval(self):
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=30),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        with (
            patch.object(main, "get_matchlog_player_summary", return_value=None),
            patch.object(
                main, "_restore_matchlog_identity_for_user",
                new=AsyncMock(return_value=False),
            ),
        ):
            await main.mystats.callback(
                interaction,
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Career", value="career"),
            )
        response = interaction.followup.send.await_args.args[0]
        self.assertIn("Ask an administrator to approve you.", response)
        self.assertNotIn("/linkmatchlogplayer", response)
        self.assertNotIn("display name", response)

    async def test_mystats_uses_selected_atp_or_wta_identity(self):
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {30: {"atp": "Alpha", "wta": "Alice"}}
        try:
            for value, player in (("atp", "Alpha"), ("wta", "Alice")):
                interaction = SimpleNamespace(
                    user=SimpleNamespace(id=30),
                    response=SimpleNamespace(defer=AsyncMock()),
                    followup=SimpleNamespace(send=AsyncMock()),
                )
                summary = {"player": player, "matches": 1, "metrics": []}
                with patch.object(
                    main, "get_matchlog_player_summary", return_value=summary
                ) as read:
                    await main.mystats.callback(
                        interaction,
                        main.app_commands.Choice(name=value.upper(), value=value),
                        main.app_commands.Choice(
                            name="Match logs", value="matchlog"
                        ),
                        main.app_commands.Choice(
                            name="Career", value="career"
                        ),
                    )
                self.assertEqual(read.call_args.args[2], value)
                self.assertEqual(read.call_args.args[3], "career")
                self.assertIn(
                    player,
                    interaction.followup.send.await_args.kwargs["embed"].title,
                )
        finally:
            main._matchlog_identity_index = original_index

    async def test_mystats_requires_tour_and_source(self):
        required = {
            parameter.name: parameter.required
            for parameter in main.mystats.parameters
        }
        self.assertEqual(
            required,
            {"tour": True, "source": True, "period": True},
        )

    async def test_mystats_reports_selected_unlinked_tour(self):
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {30: {"atp": "Alpha"}}
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=30),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        try:
            await main.mystats.callback(
                interaction,
                main.app_commands.Choice(name="WTA", value="wta"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Career", value="career"),
            )
            self.assertIn(
                "do not have a verified WTA", interaction.followup.send.await_args.args[0]
            )
        finally:
            main._matchlog_identity_index = original_index

    async def test_mystats_explains_how_to_fix_shared_tour_identity(self):
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {30: {"atp": "Shared"}}
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=30),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        try:
            with patch.object(
                main,
                "get_matchlog_player_summary",
                side_effect=AmbiguousPlayerNameError("shared"),
            ):
                await main.mystats.callback(
                    interaction,
                    main.app_commands.Choice(name="ATP", value="atp"),
                    main.app_commands.Choice(name="Match logs", value="matchlog"),
                    main.app_commands.Choice(name="Career", value="career"),
                )
            response = interaction.followup.send.await_args.args[0]
            self.assertIn("matches both an ATP and WTA player", response)
            self.assertIn("`ATP: Player Name` or `WTA: Player Name`", response)
            self.assertTrue(interaction.followup.send.await_args.kwargs["ephemeral"])
        finally:
            main._matchlog_identity_index = original_index

    async def test_mystats_explains_ambiguity_after_identity_restoration(self):
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=30),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        with (
            patch.object(
                main,
                "get_matchlog_player_summary",
                side_effect=[
                    None,
                    AmbiguousPlayerNameError("shared"),
                ],
            ),
            patch.object(
                main,
                "_restore_matchlog_identity_for_user",
                new=AsyncMock(return_value=True),
            ),
        ):
            await main.mystats.callback(
                interaction,
                main.app_commands.Choice(name="ATP", value="atp"),
                main.app_commands.Choice(name="Match logs", value="matchlog"),
                main.app_commands.Choice(name="Career", value="career"),
            )
        response = interaction.followup.send.await_args.args[0]
        self.assertIn("matches both an ATP and WTA player", response)
        self.assertTrue(interaction.followup.send.await_args.kwargs["ephemeral"])

    async def test_mystats_distinguishes_approved_identity_without_summary(self):
        original_index = main._matchlog_identity_index
        original_state = main._matchlog_rebuild_state
        original_subscribers = main._matchlog_status_subscribers
        main._matchlog_identity_index = {30: {"atp": "Alpha"}}
        main._matchlog_rebuild_state = "running"
        main._matchlog_status_subscribers = set()
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=30),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        try:
            with (
                patch.object(
                    main, "get_matchlog_player_summary", return_value=None
                ),
                patch.object(
                    main, "_restore_matchlog_identity_for_user",
                    new=AsyncMock(return_value=True),
                ),
            ):
                await main.mystats.callback(
                    interaction,
                    main.app_commands.Choice(name="ATP", value="atp"),
                    main.app_commands.Choice(name="Match logs", value="matchlog"),
                    main.app_commands.Choice(name="Career", value="career"),
                )
            response = interaction.followup.send.await_args.args[0]
            self.assertIn("identity is approved as **ATP: Alpha**", response)
            self.assertIn("database sync is still rebuilding", response)
            self.assertIn(
                "owner receives private progress updates", response
            )
            self.assertNotIn("[", response)
            self.assertEqual(main._matchlog_status_subscribers, {30})
            self.assertNotIn("Ask an administrator", response)
        finally:
            main._matchlog_identity_index = original_index
            main._matchlog_rebuild_state = original_state
            main._matchlog_status_subscribers = original_subscribers

    async def test_mystats_never_reads_workbook_until_rebuild_is_definitive(self):
        original_state = main._matchlog_rebuild_state
        original_index = main._matchlog_identity_index
        summary_reader = AsyncMock(
            side_effect=AssertionError("summary read attempted")
        )
        try:
            main._matchlog_identity_index = {}
            for state in ("not_started", "running", "failed"):
                main._matchlog_rebuild_state = state
                interaction = SimpleNamespace(
                    user=SimpleNamespace(id=30),
                    response=SimpleNamespace(defer=AsyncMock()),
                    followup=SimpleNamespace(send=AsyncMock()),
                )
                with patch.object(
                    main,
                    "_get_mystats_summaries",
                    new=summary_reader,
                ):
                    await main.mystats.callback(
                        interaction,
                        main.app_commands.Choice(name="ATP", value="atp"),
                        main.app_commands.Choice(
                            name="Match logs",
                            value="matchlog",
                        ),
                        main.app_commands.Choice(
                            name="Career",
                            value="career",
                        ),
                    )
                response = interaction.followup.send.await_args.args[0]
                if state == "failed":
                    self.assertIn("sync failed", response)
                    self.assertIn("avoid showing stale", response)
                else:
                    self.assertIn("still rebuilding", response)
            summary_reader.assert_not_awaited()
        finally:
            main._matchlog_rebuild_state = original_state
            main._matchlog_identity_index = original_index

    def test_on_ready_marks_rebuild_running_before_first_await(self):
        source = Path(main.__file__).read_text(encoding="utf-8")
        start = source.rindex("@client.event\nasync def on_ready():")
        self.assertLess(
            source.index('_matchlog_rebuild_state = "running"', start),
            source.index("await ", start),
        )

    def test_matchlog_and_stats_runtime_configuration_is_present(self):
        self.assertEqual(
            main.MATCHLOG_SUBMISSIONS_CHANNEL_ID, 1546326289013543043
        )
        self.assertEqual(main.TE4_RESULTS_CHANNEL_ID, 801918765226917988)
        self.assertEqual(
            main.STATS_DELIVERY_STATE_FILE,
            Path("stats_workbook_delivery.json"),
        )
        self.assertTrue(main.MATCHLOG_UPLOAD_TEMPLATE.is_file())
        self.assertTrue(main.SCREENSHOT_STATS_UPLOAD_TEMPLATE.is_file())
        self.assertFalse(main.PERIODIC_ATP_CSV_DELIVERY_ENABLED)

    async def test_mystats_reports_completed_restoration_without_stats(self):
        original_index = main._matchlog_identity_index
        original_state = main._matchlog_rebuild_state
        main._matchlog_identity_index = {30: {"atp": "Alpha"}}
        main._matchlog_rebuild_state = "complete"
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=30),
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        try:
            with (
                patch.object(
                    main, "get_matchlog_player_summary", return_value=None
                ),
                patch.object(
                    main, "_restore_matchlog_identity_for_user",
                    new=AsyncMock(return_value=True),
                ),
            ):
                await main.mystats.callback(
                    interaction,
                    main.app_commands.Choice(name="ATP", value="atp"),
                    main.app_commands.Choice(name="Match logs", value="matchlog"),
                    main.app_commands.Choice(name="Career", value="career"),
                )
            response = interaction.followup.send.await_args.args[0]
            self.assertIn("database sync is complete", response)
            self.assertIn("no verified MatchLog statistics were found", response)
        finally:
            main._matchlog_identity_index = original_index
            main._matchlog_rebuild_state = original_state

    def test_matchlog_restoration_progress_tracks_reconciliation(self):
        original_state = main._matchlog_rebuild_state
        original_done = main._matchlog_rebuild_done
        original_total = main._matchlog_rebuild_total
        original_public = main._matchlog_public_history_task
        original_owner = main._matchlog_owner_history_task
        completed = SimpleNamespace(done=lambda: True)
        try:
            main._matchlog_rebuild_state = "running"
            main._matchlog_public_history_task = completed
            main._matchlog_owner_history_task = completed
            main._matchlog_rebuild_done = 2
            main._matchlog_rebuild_total = 4
            percent, phase = main._matchlog_restoration_progress()
            self.assertEqual(percent, 52)
            self.assertIn("2/4", phase)
            self.assertIn("52%", main._format_matchlog_progress())
        finally:
            main._matchlog_rebuild_state = original_state
            main._matchlog_rebuild_done = original_done
            main._matchlog_rebuild_total = original_total
            main._matchlog_public_history_task = original_public
            main._matchlog_owner_history_task = original_owner

    def test_matchlog_database_loading_progress_is_bounded(self):
        original_state = main._matchlog_rebuild_state
        original_public = main._matchlog_public_history_task
        original_owner = main._matchlog_owner_history_task
        original_public_count = main._matchlog_public_messages_scanned
        original_owner_count = main._matchlog_owner_messages_scanned
        original_total = main._matchlog_rebuild_total
        try:
            main._matchlog_rebuild_state = "running"
            main._matchlog_public_history_task = None
            main._matchlog_owner_history_task = None
            main._matchlog_public_messages_scanned = 300
            main._matchlog_owner_messages_scanned = 700
            main._matchlog_rebuild_total = None
            progress = main._format_matchlog_progress()
            self.assertIn("10%", progress)
            self.assertIn("Loading persistent MatchLog records", progress)
            self.assertNotIn("Public messages", progress)
        finally:
            main._matchlog_rebuild_state = original_state
            main._matchlog_public_history_task = original_public
            main._matchlog_owner_history_task = original_owner
            main._matchlog_public_messages_scanned = original_public_count
            main._matchlog_owner_messages_scanned = original_owner_count
            main._matchlog_rebuild_total = original_total

    async def test_startup_rebuild_locks_before_database_snapshot(self):
        original_state = main._matchlog_rebuild_state
        original_done = main._matchlog_rebuild_done
        original_total = main._matchlog_rebuild_total
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {}
        lock_observations = []

        def load_sources():
            lock_observations.append(main._stats_scrape_lock.locked())
            return []

        def load_identities():
            lock_observations.append(main._stats_scrape_lock.locked())
            return {30: {"wta": "Riachsoup"}}

        owner = SimpleNamespace(send=AsyncMock())
        try:
            with (
                patch.object(main, "load_matchlog_sources", load_sources),
                patch.object(main, "load_matchlog_identities", load_identities),
                patch.object(
                    main, "rebuild_matchlog_from_sources", return_value=0
                ) as rebuild,
                patch.object(
                    main, "_update_matchlog_owner_progress", new=AsyncMock()
                ),
                patch.object(
                    main,
                    "_get_stats_rankings",
                    new=AsyncMock(return_value={"atp": {}, "wta": {}}),
                ),
                patch.object(
                    main,
                    "_get_matchlog_official_results",
                    new=AsyncMock(return_value=[]),
                ),
                patch.object(
                    main.client, "fetch_user",
                    new=AsyncMock(return_value=owner),
                ),
            ):
                await main._matchlog_startup_rebuild()
            self.assertEqual(lock_observations, [True, True])
            rebuild.assert_called_once()
            self.assertEqual(main._matchlog_rebuild_state, "complete")
            self.assertEqual(
                main._matchlog_identity_index,
                {30: {"wta": "Riachsoup"}},
            )
        finally:
            main._matchlog_rebuild_state = original_state
            main._matchlog_rebuild_done = original_done
            main._matchlog_rebuild_total = original_total
            main._matchlog_identity_index = original_index

    async def test_startup_rebuild_survives_live_wtsl_timeout(self):
        original_state = main._matchlog_rebuild_state
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {}
        source = {"verified_matches": [{"match_id": "old"}]}
        try:
            with (
                patch.object(
                    main,
                    "_get_stats_rankings",
                    new=AsyncMock(side_effect=asyncio.TimeoutError),
                ),
                patch.object(
                    main,
                    "_get_matchlog_official_results",
                    new=AsyncMock(return_value=[]),
                ),
                patch.object(main, "load_matchlog_sources", return_value=[source]),
                patch.object(
                    main,
                    "load_matchlog_identities",
                    return_value={30: {"atp": "Squeaky"}},
                ),
                patch.object(
                    main,
                    "rebuild_matchlog_from_sources",
                    return_value=1,
                ) as rebuild,
                patch.object(
                    main,
                    "_update_matchlog_owner_progress",
                    new=AsyncMock(),
                ),
                patch.object(
                    main.client,
                    "fetch_user",
                    new=AsyncMock(
                        return_value=SimpleNamespace(send=AsyncMock())
                    ),
                ),
            ):
                await main._matchlog_startup_rebuild()
            rebuild.assert_called_once()
            self.assertEqual(
                rebuild.call_args.args[1][0]["verified_matches"],
                [{"match_id": "old"}],
            )
            self.assertEqual(main._matchlog_rebuild_state, "complete")
            self.assertEqual(
                main._matchlog_identity_index,
                {30: {"atp": "Squeaky"}},
            )
        finally:
            main._matchlog_rebuild_state = original_state
            main._matchlog_identity_index = original_index

    async def test_current_verification_version_skips_expensive_refresh(self):
        original_state = main._matchlog_rebuild_state
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {}
        source = {
            "source_hash": "current",
            "verification_version": main.MATCHLOG_VERIFICATION_VERSION,
            "verified_matches": [{"tour": "atp", "match_id": "verified"}],
        }
        rankings = AsyncMock()
        official = AsyncMock()
        try:
            with (
                patch.object(
                    main, "load_matchlog_sources", return_value=[source]
                ),
                patch.object(
                    main, "load_matchlog_identities", return_value={}
                ),
                patch.object(main, "_get_stats_rankings", new=rankings),
                patch.object(
                    main, "_get_matchlog_official_results", new=official
                ),
                patch.object(
                    main,
                    "_get_screenshot_statistics_exclusions",
                    new=AsyncMock(return_value={"atp": {}, "wta": {}}),
                ),
                patch.object(
                    main,
                    "_get_stats_autocomplete_names",
                    return_value=[],
                ),
                patch.object(
                    main, "save_reverified_matchlog_sources"
                ) as save_reverified,
                patch.object(
                    main, "rebuild_matchlog_from_sources", return_value=1
                ) as rebuild,
                patch.object(
                    main, "_update_matchlog_owner_progress", new=AsyncMock()
                ),
                patch.object(
                    main.client,
                    "fetch_user",
                    new=AsyncMock(
                        return_value=SimpleNamespace(send=AsyncMock())
                    ),
                ),
            ):
                await main._matchlog_startup_rebuild()
            rankings.assert_not_awaited()
            official.assert_not_awaited()
            save_reverified.assert_not_called()
            rebuild.assert_called_once()
            self.assertEqual(
                rebuild.call_args.args[1][0]["verified_matches"],
                source["verified_matches"],
            )
        finally:
            main._matchlog_rebuild_state = original_state
            main._matchlog_identity_index = original_index

    def test_startup_database_load_retries_transient_failure(self):
        with (
            patch.object(
                main,
                "load_matchlog_sources",
                side_effect=[
                    RuntimeError("SSL connection closed"),
                    [{"verified_matches": []}],
                ],
            ) as load_sources,
            patch.object(
                main,
                "load_matchlog_identities",
                return_value={30: {"atp": "Squeaky"}},
            ) as load_identities,
            patch.object(main.time, "sleep") as sleep,
        ):
            sources, identities = main._load_matchlog_startup_state()
        self.assertEqual(sources, [{"verified_matches": []}])
        self.assertEqual(identities, {30: {"atp": "Squeaky"}})
        self.assertEqual(load_sources.call_count, 2)
        load_identities.assert_called_once()
        sleep.assert_called_once_with(1)

    async def test_private_identity_receipt_wins_over_legacy_public_receipt(self):
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {}
        try:
            with patch.object(main, "bind_matchlog_player_identity"):
                self.assertTrue(await main._bind_restored_matchlog_identity(
                    30, "Legacy Player", private=False
                ))
                self.assertTrue(await main._bind_restored_matchlog_identity(
                    30, "Private Player", private=True
                ))
                self.assertFalse(await main._bind_restored_matchlog_identity(
                    30, "Older Legacy Player", private=False
                ))
            self.assertEqual(
                main._matchlog_identity_index[30], {"atp": "Private Player"}
            )
        finally:
            main._matchlog_identity_index = original_index

    async def test_concurrent_identity_recovery_uses_one_shared_scan(self):
        original_public_task = main._matchlog_public_history_task
        original_owner_task = main._matchlog_owner_history_task
        original_index = main._matchlog_identity_index
        original_state = main._matchlog_rebuild_state
        main._matchlog_public_history_task = None
        main._matchlog_owner_history_task = None
        main._matchlog_identity_index = {}
        main._matchlog_rebuild_state = "running"

        async def scan_public_once():
            await asyncio.sleep(0.02)
            main._matchlog_identity_index[30] = "Alpha"
            return []

        try:
            with (
                patch.object(
                    main, "_scan_matchlog_public_history",
                    new=AsyncMock(side_effect=scan_public_once),
                ) as public_scan,
                patch.object(
                    main, "_scan_matchlog_owner_history",
                    new=AsyncMock(return_value=[]),
                ) as owner_scan,
                patch.object(main, "load_matchlog_identity", return_value=None),
            ):
                main._matchlog_public_history_scan_task()
                main._matchlog_owner_history_scan_task()
                restored, missing = await asyncio.gather(
                    main._restore_matchlog_identity_for_user(30),
                    main._restore_matchlog_identity_for_user(31),
                )
            self.assertTrue(restored)
            self.assertFalse(missing)
            self.assertEqual(public_scan.await_count, 1)
            self.assertEqual(owner_scan.await_count, 1)
        finally:
            main._matchlog_public_history_task = original_public_task
            main._matchlog_owner_history_task = original_owner_task
            main._matchlog_identity_index = original_index
            main._matchlog_rebuild_state = original_state

    async def test_mystats_identity_cache_miss_refreshes_from_database(self):
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {}
        try:
            with (
                patch.object(
                    main, "load_matchlog_identity", return_value="Alpha"
                ) as load_identity,
                patch.object(
                    main, "bind_matchlog_player_identity"
                ) as bind_identity,
            ):
                self.assertTrue(
                    await main._restore_matchlog_identity_for_user(30)
                )
            load_identity.assert_called_once_with(30)
            bind_identity.assert_called_once()
            self.assertEqual(main._matchlog_identity_index[30], {"atp": "Alpha"})
        finally:
            main._matchlog_identity_index = original_index

    async def test_owner_scan_overrides_existing_legacy_public_identity(self):
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {30: {"atp": "Legacy Player"}}
        receipt = SimpleNamespace(
            author=SimpleNamespace(id=99),
            content="private receipt",
        )

        class OwnerDM:
            def history(self, **kwargs):
                async def messages():
                    yield receipt
                return messages()

        owner = SimpleNamespace(dm_channel=OwnerDM())
        try:
            with (
                patch.object(
                    main.client._connection, "user",
                    SimpleNamespace(id=99),
                ),
                patch.object(
                    main.client, "fetch_user",
                    new=AsyncMock(return_value=owner),
                ),
                patch.object(
                    main, "_matchlog_admin_identities",
                    return_value={30: {"atp": "Private Player"}},
                ),
                patch.object(main, "bind_matchlog_player_identity"),
            ):
                await main._scan_matchlog_owner_history()
            self.assertEqual(
                main._matchlog_identity_index[30], {"atp": "Private Player"}
            )
        finally:
            main._matchlog_identity_index = original_index

    async def test_identity_link_receipt_is_sent_only_to_owner_dm(self):
        owner = SimpleNamespace(send=AsyncMock())
        interaction = SimpleNamespace(
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        member = SimpleNamespace(id=30, mention="<@30>", send=AsyncMock())
        public_channel = SimpleNamespace(send=AsyncMock())
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {}
        try:
            with (
                patch.object(
                    main, "_get_stats_rankings",
                    new=AsyncMock(return_value={
                        "atp": {"alpha": "Alpha"}, "wta": {},
                    }),
                ),
                patch.object(
                    main.client, "fetch_user",
                    new=AsyncMock(return_value=owner),
                ),
                patch.object(
                    main.client, "get_channel", return_value=public_channel
                ),
                patch.object(main, "bind_matchlog_player_identity"),
            ):
                await main.linkmatchlogplayer.callback(
                    interaction, member, "Alpha"
                )
            owner.send.assert_awaited_once()
            self.assertIn(
                "MatchLog admin identity", owner.send.await_args.args[0]
            )
            public_channel.send.assert_not_awaited()
            self.assertEqual(main._matchlog_identity_index[30], {"atp": "Alpha"})
            member.send.assert_awaited_once()
            verification_dm = member.send.await_args.args[0]
            self.assertIn("verified as **ATP: Alpha**", verification_dm)
            self.assertIn("`/mystats`", verification_dm)
            admin_confirmation = interaction.followup.send.await_args.args[0]
            self.assertIn("notified by DM", admin_confirmation)
        finally:
            main._matchlog_identity_index = original_index

    async def test_identity_link_survives_closed_player_dms(self):
        owner = SimpleNamespace(send=AsyncMock())
        interaction = SimpleNamespace(
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        member = SimpleNamespace(
            id=30,
            mention="<@30>",
            send=AsyncMock(side_effect=RuntimeError("DMs disabled")),
        )
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {}
        try:
            with (
                patch.object(
                    main,
                    "_get_stats_rankings",
                    new=AsyncMock(return_value={
                        "atp": {"alpha": "Alpha"}, "wta": {},
                    }),
                ),
                patch.object(
                    main.client,
                    "fetch_user",
                    new=AsyncMock(return_value=owner),
                ),
                patch.object(main, "bind_matchlog_player_identity"),
            ):
                await main.linkmatchlogplayer.callback(
                    interaction, member, "Alpha"
                )
            self.assertEqual(main._matchlog_identity_index[30], {"atp": "Alpha"})
            self.assertIn(
                "DM could not be delivered",
                interaction.followup.send.await_args.args[0],
            )
        finally:
            main._matchlog_identity_index = original_index

    async def test_linkmatchlogplayer_preserves_existing_other_tour_link(self):
        owner = SimpleNamespace(send=AsyncMock())
        interaction = SimpleNamespace(
            response=SimpleNamespace(defer=AsyncMock()),
            followup=SimpleNamespace(send=AsyncMock()),
        )
        member = SimpleNamespace(id=30, mention="<@30>", send=AsyncMock())
        original_index = main._matchlog_identity_index
        main._matchlog_identity_index = {30: {"wta": "Alice"}}
        try:
            with (
                patch.object(
                    main, "_get_stats_rankings",
                    new=AsyncMock(return_value={
                        "atp": {"alpha": "Alpha"}, "wta": {"alice": "Alice"},
                    }),
                ),
                patch.object(main.client, "fetch_user", new=AsyncMock(return_value=owner)),
                patch.object(main, "bind_matchlog_player_identity"),
            ):
                await main.linkmatchlogplayer.callback(interaction, member, "ATP: Alpha")
            self.assertEqual(
                main._matchlog_identity_index[30],
                {"atp": "Alpha", "wta": "Alice"},
            )
        finally:
            main._matchlog_identity_index = original_index

    async def test_cleanup_is_skipped_when_targeted_history_is_incomplete(self):
        message = SimpleNamespace(
            id=100,
            author=SimpleNamespace(id=30, bot=False),
            attachments=[
                SimpleNamespace(
                    id=20,
                    filename="mixed.html",
                    content_type="text/html",
                    size=len(matchlog_html()),
                    read=AsyncMock(return_value=matchlog_html()),
                )
            ],
        )
        self.targeted_results.side_effect = RuntimeError(
            "incomplete targeted history"
        )
        with (
            patch.object(main, "_get_stats_rankings", AsyncMock(return_value={
                "atp": {"alpha": "Alpha", "beta": "Beta"},
                "wta": {},
            })),
            patch.object(
                main, "_get_matchlog_official_results",
                AsyncMock(return_value=[]),
            ),
            patch.object(main, "reconcile_matchlog_source") as reconcile,
        ):
            await main._process_matchlog_submission(
                message,
                announce=False,
                trusted_hashes={hashlib.sha256(matchlog_html()).hexdigest()},
            )
        reconcile.assert_not_called()

    async def test_cleanup_requests_complete_targeted_history(self):
        mixed = (
            history_match_html()
            + history_match_html("Practice One", "Practice Two", "6/0")
        ).encode()
        message = SimpleNamespace(
            id=101,
            author=SimpleNamespace(id=30, bot=False),
            attachments=[
                SimpleNamespace(
                    id=21,
                    filename="mixed.html",
                    content_type="text/html",
                    size=len(mixed),
                    read=AsyncMock(return_value=mixed),
                )
            ],
        )
        source_hash = hashlib.sha256(mixed).hexdigest()
        rankings = {
            "atp": {
                "alpha": "Alpha", "beta": "Beta",
                "practice one": "Practice One",
                "practice two": "Practice Two",
            },
            "wta": {},
        }
        self.targeted_results.return_value = parse_official_results(
            OFFICIAL_HTML
        )
        with (
            patch.object(
                main, "_get_stats_rankings", AsyncMock(return_value=rankings)
            ),
            patch.object(
                main, "_get_matchlog_official_results",
                AsyncMock(return_value=parse_official_results(OFFICIAL_HTML)),
            ),
            patch.object(
                main, "reconcile_matchlog_source",
                return_value={"removed_rows": 2, "removed_matches": 1},
            ) as reconcile,
            patch.object(
                main, "append_matchlog_submission",
                return_value={"added": 0, "duplicate": "file"},
            ),
        ):
            await main._process_matchlog_submission(
                message,
                announce=False,
                trusted_hashes={source_hash},
            )
        self.assertTrue(
            self.targeted_results.await_args.kwargs["require_complete"]
        )
        reconcile.assert_called_once()

    def test_only_html_attachments_are_accepted(self):
        message = SimpleNamespace(attachments=[
            *[
                SimpleNamespace(
                    filename=f"match-{index}.html", content_type="text/html"
                )
                for index in range(11)
            ],
            SimpleNamespace(filename="screen.png", content_type="image/png"),
        ])
        self.assertEqual(
            len(main._matchlog_attachments(message)),
            10,
        )

    def test_only_bot_authored_receipts_are_trusted(self):
        digest = "a" * 64
        messages = [
            SimpleNamespace(
                author=SimpleNamespace(id=99),
                reference=SimpleNamespace(message_id=10),
                content=f"MatchLog receipt: `{digest}`",
            ),
            SimpleNamespace(
                author=SimpleNamespace(id=99),
                reference=None,
                content=f"MatchLog receipt: `{'c' * 64}|12`",
            ),
            SimpleNamespace(
                author=SimpleNamespace(id=7),
                reference=SimpleNamespace(message_id=11),
                content=f"MatchLog receipt: `{'b' * 64}`",
            ),
        ]
        self.assertEqual(
            main._matchlog_receipts_by_message(messages, 99),
            {10: {digest}, 12: {"c" * 64}},
        )

    def test_only_bot_authored_private_retained_receipts_are_trusted(self):
        digest = "d" * 64
        messages = [
            SimpleNamespace(
                author=SimpleNamespace(id=99),
                content=f"MatchLog retained source: `{digest}|30|14|20`",
            ),
            SimpleNamespace(
                author=SimpleNamespace(id=7),
                content=f"MatchLog retained source: `{'e' * 64}|31|15|21`",
            ),
        ]
        self.assertEqual(
            main._matchlog_private_receipts_by_message(messages, 99),
            {14: {digest}},
        )

    def test_only_bot_authored_admin_identity_receipts_are_trusted(self):
        encoded = "Álpha".encode().hex()
        messages = [
            SimpleNamespace(
                author=SimpleNamespace(id=99),
                content=f"MatchLog admin identity: `30|{encoded}`",
            ),
            SimpleNamespace(
                author=SimpleNamespace(id=7),
                content=f"MatchLog admin identity: `31|{encoded}`",
            ),
        ]
        self.assertEqual(
            main._matchlog_admin_identities(messages, 99),
            {30: {"atp": "Álpha"}},
        )

    async def test_only_owner_receives_unlinked_verification_request(self):
        owner = SimpleNamespace(send=AsyncMock())
        author = SimpleNamespace(id=30, mention="<@30>")
        message = SimpleNamespace(
            author=author,
            jump_url="https://discord.com/channels/1/2/3",
        )
        with patch.object(
            main.client, "fetch_user", new=AsyncMock(return_value=owner)
        ) as fetch_user:
            await main._notify_matchlog_owner_for_verification(
                message, {"Alpha", "Beta"}
            )
        fetch_user.assert_awaited_once_with(main.OWNER_ID)
        owner.send.assert_awaited_once()
        notification = owner.send.await_args.args[0]
        self.assertIn(f"<@{main.OWNER_ID}>", notification)
        self.assertIn("<@30>", notification)
        self.assertIn("`Alpha`", notification)
        self.assertIn("`Beta`", notification)
        self.assertIn("/linkmatchlogplayer", notification)
        self.assertIn("archived privately", notification)
        self.assertFalse(owner.send.await_args.kwargs["silent"])
        allowed_mentions = owner.send.await_args.kwargs["allowed_mentions"]
        self.assertTrue(allowed_mentions.users)
        self.assertFalse(allowed_mentions.everyone)
        self.assertFalse(allowed_mentions.roles)

    async def test_daily_screenshot_review_csv_is_persisted_after_owner_delivery(self):
        owner = SimpleNamespace(send=AsyncMock())
        summaries = [{
            "player": "Alpha",
            "tour": "atp",
            "matches": 1,
            "match_records": [{
                "opponent": "Beta",
                "date": "2026-09-07",
                "tournament": "US Open",
                "result": "6-0 6-0",
            }],
        }]
        official = [{
            "tour": "atp",
            "p1": "Alpha",
            "p2": "Beta",
            "date": "2026-09-07",
            "tournament": "US Open",
            "result": "6-4 6-4",
        }]
        with tempfile.TemporaryDirectory() as directory:
            state_file = Path(directory) / "delivery.json"
            workbook = Path(directory) / "stats.xlsx"
            workbook.touch()
            with (
                patch.object(main, "STATS_DELIVERY_STATE_FILE", state_file),
                patch.object(main, "MATCH_STATS_WORKBOOK", workbook),
                patch.object(
                    main,
                    "get_screenshot_match_record_summaries",
                    return_value=summaries,
                ),
                patch.object(
                    main,
                    "_get_matchlog_official_results",
                    new=AsyncMock(return_value=official),
                ),
                patch.object(
                    main.client,
                    "fetch_user",
                    new=AsyncMock(return_value=owner),
                ) as fetch_user,
            ):
                self.assertTrue(await main._send_daily_screenshot_review_csv())
                self.assertFalse(await main._send_daily_screenshot_review_csv())
                state = json.loads(state_file.read_text(encoding="utf-8"))

        self.assertEqual(
            state["screenshot_review_last_sent_date"],
            datetime.now(main.STATS_TIMEZONE).date().isoformat(),
        )
        fetch_user.assert_awaited_once_with(main.OWNER_ID)
        owner.send.assert_awaited_once()
        sent_file = owner.send.await_args.kwargs["file"]
        self.assertEqual(sent_file.filename, main.SCREENSHOT_REVIEW_CSV_FILENAME)

    async def test_startup_stats_upload_runs_before_catchup_history_scan(self):
        events = []
        history_options = {}

        class StopLoop(BaseException):
            pass

        async def controlled_sleep(seconds):
            if seconds != 25:
                raise StopLoop()

        async def history(**kwargs):
            events.append("history")
            history_options.update(kwargs)
            if False:
                yield None

        async def early_upload():
            events.append("upload")

        channel = SimpleNamespace(history=history)
        with (
            patch.object(main.asyncio, "sleep", new=controlled_sleep),
            patch.object(
                main,
                "_wait_for_matchlog_rebuild",
                new=AsyncMock(),
            ),
            patch.object(
                main,
                "_send_startup_player_stats_upload_before_catchup",
                new=AsyncMock(side_effect=early_upload),
            ),
            patch.object(
                main.client,
                "get_channel",
                return_value=channel,
            ),
            patch.object(
                main,
                "_deliver_pending_stats_workbook",
                new=AsyncMock(),
            ),
            patch.object(
                main,
                "_send_daily_player_stats_upload_csv",
                new=AsyncMock(),
            ),
        ):
            with self.assertRaises(StopLoop):
                await main._stats_daily_catchup_loop()

        self.assertEqual(events, ["upload", "history"])
        self.assertAlmostEqual(
            (
                datetime.now(main.timezone.utc) - history_options["after"]
            ).total_seconds(),
            72 * 60 * 60,
            delta=5,
        )

    async def test_daily_player_stats_upload_csv_is_persisted_after_owner_delivery(self):
        owner = SimpleNamespace(send=AsyncMock())
        with tempfile.TemporaryDirectory() as directory:
            state_file = Path(directory) / "delivery.json"
            workbook = Path(directory) / "stats.xlsx"
            template = Path(directory) / "template.csv"
            workbook.touch()
            template.write_text("Player,Metric\nAlpha,1\n", encoding="utf-8")
            with (
                patch.object(main, "STATS_DELIVERY_STATE_FILE", state_file),
                patch.object(main, "MATCH_STATS_WORKBOOK", workbook),
                patch.object(main, "SCREENSHOT_STATS_UPLOAD_TEMPLATE", template),
                patch.object(
                    main.client,
                    "fetch_user",
                    new=AsyncMock(return_value=owner),
                ) as fetch_user,
                patch.object(
                    main,
                    "build_screenshot_player_upload_csv",
                    return_value=b"Player,Metric\nAlpha,1\n",
                ) as build_csv,
            ):
                self.assertTrue(
                    await main._send_daily_player_stats_upload_csv("test")
                )
                self.assertFalse(
                    await main._send_daily_player_stats_upload_csv("test")
                )
                state = json.loads(state_file.read_text(encoding="utf-8"))

        today = datetime.now(main.STATS_TIMEZONE).date().isoformat()
        self.assertEqual(
            state["screenshot_player_stats_upload_startup_sent_date"],
            today,
        )
        fetch_user.assert_awaited_once_with(main.OWNER_ID)
        self.assertEqual(build_csv.call_count, 2)
        self.assertEqual(
            {invocation.args for invocation in build_csv.call_args_list},
            {
                (workbook, template, "atp"),
                (workbook, template, "wta"),
            },
        )
        owner.send.assert_awaited_once()
        self.assertIn(
            main._player_stats_upload_receipt(today),
            owner.send.await_args.args[0],
        )
        self.assertEqual(
            [
                file.filename
                for file in owner.send.await_args.kwargs["files"]
            ],
            ["pl_stats_upload.csv", "pl_stats_upload_wta.csv"],
        )

    async def test_startup_and_end_of_day_player_stats_uploads_both_send_same_day(self):
        owner = SimpleNamespace(send=AsyncMock())
        with tempfile.TemporaryDirectory() as directory:
            state_file = Path(directory) / "delivery.json"
            workbook = Path(directory) / "stats.xlsx"
            template = Path(directory) / "template.csv"
            workbook.touch()
            template.write_text("Player,Metric\nAlpha,1\n", encoding="utf-8")
            with (
                patch.object(main, "STATS_DELIVERY_STATE_FILE", state_file),
                patch.object(main, "MATCH_STATS_WORKBOOK", workbook),
                patch.object(main, "SCREENSHOT_STATS_UPLOAD_TEMPLATE", template),
                patch.object(
                    main.client,
                    "fetch_user",
                    new=AsyncMock(return_value=owner),
                ),
                patch.object(
                    main,
                    "build_screenshot_player_upload_csv",
                    return_value=b"Player,Metric\nAlpha,1\n",
                ),
            ):
                self.assertTrue(
                    await main._send_daily_player_stats_upload_csv(
                        "startup/publish",
                        force=True,
                    )
                )
                self.assertTrue(
                    await main._send_daily_player_stats_upload_csv("daily")
                )
                self.assertFalse(
                    await main._send_daily_player_stats_upload_csv("daily")
                )
                state = json.loads(state_file.read_text(encoding="utf-8"))

        today = datetime.now(main.STATS_TIMEZONE).date().isoformat()
        self.assertEqual(
            state["screenshot_player_stats_upload_startup_sent_date"],
            today,
        )
        self.assertEqual(
            state["screenshot_player_stats_upload_eod_sent_date"],
            today,
        )
        self.assertEqual(owner.send.await_count, 2)
        contents = [call.args[0] for call in owner.send.await_args_list]
        self.assertIn(
            main._player_stats_upload_receipt_for_phase(today, "startup"),
            contents[0],
        )
        self.assertIn(
            main._player_stats_upload_receipt_for_phase(today, "end-of-day"),
            contents[1],
        )

    async def test_daily_player_stats_upload_csv_recovers_owner_receipt(self):
        messages = []

        async def history(*, limit, after):
            for message in messages:
                yield message

        owner = SimpleNamespace(
            send=AsyncMock(),
            dm_channel=None,
            create_dm=AsyncMock(),
        )
        owner.create_dm.return_value = SimpleNamespace(history=history)
        today = datetime.now(main.STATS_TIMEZONE).date().isoformat()
        messages.append(SimpleNamespace(
            content=(
                "📄 **Screenshot-based player stats upload sheet**\n"
                f"{main._player_stats_upload_receipt(today)}"
            ),
            author=SimpleNamespace(id=None),
        ))
        with tempfile.TemporaryDirectory() as directory:
            state_file = Path(directory) / "delivery.json"
            workbook = Path(directory) / "stats.xlsx"
            template = Path(directory) / "template.csv"
            workbook.touch()
            template.write_text("Player,Metric\nAlpha,1\n", encoding="utf-8")
            with (
                patch.object(main, "STATS_DELIVERY_STATE_FILE", state_file),
                patch.object(main, "MATCH_STATS_WORKBOOK", workbook),
                patch.object(main, "SCREENSHOT_STATS_UPLOAD_TEMPLATE", template),
                patch.object(
                    main.client,
                    "fetch_user",
                    new=AsyncMock(return_value=owner),
                ),
                patch.object(
                    main,
                    "build_screenshot_player_upload_csv",
                    return_value=b"unused",
                ) as build_csv,
            ):
                self.assertFalse(
                    await main._send_daily_player_stats_upload_csv("restart")
                )
                state = json.loads(state_file.read_text(encoding="utf-8"))

        self.assertEqual(
            state["screenshot_player_stats_upload_startup_sent_date"],
            today,
        )
        self.assertEqual(
            state["screenshot_player_stats_upload_startup_sent_reason"],
            "receipt-recovery",
        )
        owner.send.assert_not_awaited()
        build_csv.assert_not_called()

    async def test_daily_screenshot_review_recovers_owner_dm_receipt_after_state_write_failure(self):
        owner = SimpleNamespace()
        messages = []

        async def send(content, *, file):
            messages.append(SimpleNamespace(
                content=content,
                author=SimpleNamespace(id=123),
            ))

        async def history(*, limit, after):
            for message in messages:
                yield message

        owner.send = AsyncMock(side_effect=send)
        owner.create_dm = AsyncMock(
            return_value=SimpleNamespace(history=history)
        )
        summaries = [{
            "player": "Alpha",
            "tour": "atp",
            "matches": 1,
            "match_records": [{
                "opponent": "Beta",
                "date": "2026-09-07",
                "tournament": "US Open",
                "result": "6-0 6-0",
            }],
        }]
        official = [{
            "tour": "atp",
            "p1": "Alpha",
            "p2": "Beta",
            "date": "2026-09-07",
            "tournament": "US Open",
            "result": "6-4 6-4",
        }]
        with tempfile.TemporaryDirectory() as directory:
            state_file = Path(directory) / "delivery.json"
            workbook = Path(directory) / "stats.xlsx"
            workbook.touch()
            original_user = main.client.user
            main.client._connection.user = SimpleNamespace(id=123)
            try:
                with (
                    patch.object(main, "STATS_DELIVERY_STATE_FILE", state_file),
                    patch.object(main, "MATCH_STATS_WORKBOOK", workbook),
                    patch.object(
                        main,
                        "get_screenshot_match_record_summaries",
                        return_value=summaries,
                    ),
                    patch.object(
                        main,
                        "_get_matchlog_official_results",
                        new=AsyncMock(return_value=official),
                    ),
                    patch.object(
                        main.client,
                        "fetch_user",
                        new=AsyncMock(return_value=owner),
                    ),
                    patch.object(
                        main,
                        "_save_stats_delivery_state",
                        side_effect=[OSError("disk full"), None],
                    ),
                ):
                    with self.assertRaises(OSError):
                        await main._send_daily_screenshot_review_csv()
                    self.assertFalse(await main._send_daily_screenshot_review_csv())
            finally:
                main.client._connection.user = original_user

        owner.send.assert_awaited_once()
        owner.create_dm.assert_awaited()

    async def test_archive_is_sent_only_to_owner(self):
        owner = SimpleNamespace(send=AsyncMock())
        with patch.object(
            main.client, "fetch_user", new=AsyncMock(return_value=owner)
        ) as fetch_user:
            await main._archive_matchlog_attachment(
                source_hash="a" * 64,
                submitter_id=30,
                message_id=10,
                attachment_id=20,
                filename="match.html",
                raw=b"<html></html>",
            )
        fetch_user.assert_awaited_once_with(main.OWNER_ID)
        owner.send.assert_awaited_once()
        self.assertIn("MatchLog archive:", owner.send.await_args.args[0])
        self.assertEqual(
            owner.send.await_args.kwargs["file"].filename, "match.html"
        )

    async def test_archive_failure_writes_private_retained_source_receipt(self):
        owner = SimpleNamespace(
            send=AsyncMock(side_effect=[OSError("attachment failed"), None])
        )
        with patch.object(
            main.client, "fetch_user", new=AsyncMock(return_value=owner)
        ):
            with self.assertRaises(OSError):
                await main._archive_matchlog_attachment(
                    source_hash="a" * 64,
                    submitter_id=30,
                    message_id=10,
                    attachment_id=20,
                    filename="match.html",
                    raw=b"<html></html>",
                )
        self.assertEqual(owner.send.await_count, 2)
        self.assertIn(
            "MatchLog retained source:",
            owner.send.await_args_list[1].args[0],
        )

    async def test_player_upload_csv_is_sent_only_to_owner(self):
        owner = SimpleNamespace(send=AsyncMock())
        message = SimpleNamespace(
            author=SimpleNamespace(id=30, mention="<@30>")
        )
        with patch.object(
            main.client, "fetch_user", new=AsyncMock(return_value=owner)
        ) as fetch_user:
            await main._send_matchlog_owner_csv(
                message, b"a,b\n1,2\n", b"tour,match_id\nATP,1\n"
            )
        fetch_user.assert_awaited_once_with(main.OWNER_ID)
        owner.send.assert_awaited_once()
        self.assertEqual(
            [file.filename for file in owner.send.await_args.kwargs["files"]],
            [
                "player_stats_upload_matchlog.csv",
                "composite_matchlog.csv",
            ],
        )

    async def test_transient_verification_failure_preserves_upload(self):
        raw = matchlog_html()
        attachment = SimpleNamespace(
            id=20, filename="match.html", content_type="text/html",
            size=len(raw), read=AsyncMock(return_value=raw),
        )
        message = SimpleNamespace(
            id=10,
            attachments=[attachment],
            author=SimpleNamespace(
                id=30, bot=False, mention="<@30>", send=AsyncMock()
            ),
            channel=SimpleNamespace(send=AsyncMock()),
            reply=AsyncMock(side_effect=AssertionError("reply must not be used")),
            delete=AsyncMock(),
        )
        self.targeted_results.side_effect = RuntimeError(
            "temporary feed outage"
        )
        with patch.object(
            main, "_get_stats_rankings",
            new=AsyncMock(return_value={
                "atp": {"alpha": "Alpha", "beta": "Beta"},
                "wta": {},
            }),
        ), patch.object(
            main, "_get_matchlog_official_results",
            new=AsyncMock(side_effect=RuntimeError("full feed outage")),
        ):
            self.assertEqual(
                await main._process_matchlog_submission(message), 0
            )
        message.reply.assert_not_awaited()
        self.assertEqual(message.author.send.await_count, 2)
        message.channel.send.assert_not_awaited()
        self.assertIn(
            "retained for retry", message.author.send.await_args_list[1].args[0]
        )
        message.delete.assert_not_awaited()

    async def test_transient_workbook_failure_preserves_upload(self):
        raw = matchlog_html()
        attachment = SimpleNamespace(
            id=20, filename="match.html", content_type="text/html",
            size=len(raw), read=AsyncMock(return_value=raw),
        )
        message = SimpleNamespace(
            id=10,
            attachments=[attachment],
            author=SimpleNamespace(
                id=30, bot=False, display_name="Alpha",
                global_name=None, name="alpha", mention="<@30>",
                send=AsyncMock(),
            ),
            channel=SimpleNamespace(send=AsyncMock()),
            reply=AsyncMock(side_effect=AssertionError("reply must not be used")),
            delete=AsyncMock(),
        )
        rankings = {
            "atp": {"alpha": "Alpha", "beta": "Beta"},
            "wta": {},
        }
        official = parse_official_results(OFFICIAL_HTML)
        with patch.object(
            main, "_get_stats_rankings",
            new=AsyncMock(return_value=rankings),
        ), patch.object(
            main, "_get_matchlog_official_results",
            new=AsyncMock(return_value=official),
        ), patch.object(
            main, "_archive_matchlog_attachment", new=AsyncMock(),
        ), patch.object(
            main, "append_matchlog_submission",
            side_effect=OSError("workbook temporarily unavailable"),
        ):
            self.assertEqual(
                await main._process_matchlog_submission(message), 0
            )
        message.delete.assert_not_awaited()
        message.reply.assert_not_awaited()
        message.channel.send.assert_not_awaited()
        self.assertIn(
            "Please retry", message.author.send.await_args_list[1].args[0]
        )

    async def test_archive_failure_prevents_workbook_acceptance(self):
        raw = matchlog_html()
        attachment = SimpleNamespace(
            id=20, filename="match.html", content_type="text/html",
            size=len(raw), read=AsyncMock(return_value=raw),
        )
        author = SimpleNamespace(
            id=30, bot=False, display_name="Alpha", global_name=None,
            name="alpha", mention="<@30>", send=AsyncMock(),
        )
        message = SimpleNamespace(
            id=10, attachments=[attachment], author=author,
            channel=SimpleNamespace(send=AsyncMock()),
            reply=AsyncMock(), delete=AsyncMock(),
        )
        rankings = {
            "atp": {"alpha": "Alpha", "beta": "Beta"},
            "wta": {},
        }
        official = parse_official_results(OFFICIAL_HTML)
        with patch.object(
            main, "_get_stats_rankings",
            new=AsyncMock(return_value=rankings),
        ), patch.object(
            main, "_get_matchlog_official_results",
            new=AsyncMock(return_value=official),
        ), patch.object(
            main, "_archive_matchlog_attachment",
            new=AsyncMock(side_effect=OSError("owner DM unavailable")),
        ), patch.object(
            main, "append_matchlog_submission",
        ) as append:
            self.assertEqual(
                await main._process_matchlog_submission(message), 0
            )
        append.assert_not_called()
        message.delete.assert_not_awaited()
        self.assertIn(
            "Please retry", author.send.await_args_list[1].args[0]
        )

    async def test_targeted_player_history_can_verify_missing_global_match(self):
        raw = matchlog_html()
        attachment = SimpleNamespace(
            id=20, filename="match.html", content_type="text/html",
            size=len(raw), read=AsyncMock(return_value=raw),
        )
        author = SimpleNamespace(
            id=30, bot=False, display_name="Alpha", global_name=None,
            name="alpha", mention="<@30>", send=AsyncMock(),
        )
        message = SimpleNamespace(
            id=10, attachments=[attachment], author=author,
            channel=SimpleNamespace(send=AsyncMock()),
            reply=AsyncMock(), delete=AsyncMock(),
        )
        rankings = {
            "atp": {"alpha": "Alpha", "beta": "Beta"},
            "wta": {},
        }
        self.targeted_results.return_value = parse_official_results(
            OFFICIAL_HTML
        )
        with patch.object(
            main, "_get_stats_rankings",
            new=AsyncMock(return_value=rankings),
        ), patch.object(
            main, "_get_matchlog_official_results",
            new=AsyncMock(return_value=[]),
        ), patch.object(
            main, "_archive_matchlog_attachment", new=AsyncMock(),
        ), patch.object(
            main, "append_matchlog_submission",
            return_value={
                "duplicate": None,
                "added": 1,
                "players": ["Alpha", "Beta"],
                "warnings": [],
            },
        ) as append, patch.object(
            main, "_send_matchlog_owner_csv", new=AsyncMock(),
        ), patch.object(
            main, "_notify_matchlog_owner_for_verification",
            new=AsyncMock(return_value=True),
        ):
            self.assertEqual(
                await main._process_matchlog_submission(message), 1
            )
        append.assert_called_once()
        requested_names = self.targeted_results.await_args.args[0]
        self.assertEqual(requested_names, {"Alpha", "Beta"})

    async def test_mixed_history_retries_to_include_targeted_only_matches(self):
        raw = b"<html>mixed history</html>"
        attachment = SimpleNamespace(
            id=20, filename="match.html", content_type="text/html",
            size=len(raw), read=AsyncMock(return_value=raw),
        )
        author = SimpleNamespace(
            id=30, bot=False, mention="<@30>", send=AsyncMock(),
        )
        message = SimpleNamespace(
            id=10, attachments=[attachment], author=author,
            channel=SimpleNamespace(send=AsyncMock()),
            reply=AsyncMock(), delete=AsyncMock(),
        )
        parsed = [
            {"rows": [{"player": "Alpha"}, {"player": "Beta"}]},
            {"rows": [{"player": "Alpha"}, {"player": "Gamma"}]},
        ]
        recent = {"rows": [{"player": "Alpha"}, {"player": "Beta"}]}
        older = {"rows": [{"player": "Alpha"}, {"player": "Gamma"}]}
        self.targeted_results.return_value = [{"targeted": "official"}]
        with patch.object(
            main, "_get_stats_rankings",
            new=AsyncMock(return_value={"atp": {}, "wta": {}}),
        ), patch.object(
            main, "_get_matchlog_official_results",
            new=AsyncMock(return_value=[{"global": "official"}]),
        ), patch.object(
            main, "parse_matchlog_html", return_value=parsed,
        ), patch.object(
            main, "select_official_matches",
            return_value=[recent, older],
        ) as select, patch.object(
            main, "_archive_matchlog_attachment", new=AsyncMock(),
        ), patch.object(
            main, "append_matchlog_submission",
            return_value={
                "duplicate": None,
                "added": 2,
                "players": ["Alpha", "Beta", "Gamma"],
                "warnings": [],
            },
        ) as append, patch.object(
            main, "_send_matchlog_owner_csv", new=AsyncMock(),
        ), patch.object(
            main, "_notify_matchlog_owner_for_verification",
            new=AsyncMock(return_value=True),
        ):
            self.assertEqual(
                await main._process_matchlog_submission(message), 2
            )
        self.assertEqual(select.call_count, 1)
        self.assertEqual(
            select.call_args.args[2],
            [{"global": "official"}, {"targeted": "official"}],
        )
        self.assertEqual(len(append.call_args.args[1]), 2)

    async def test_submission_replies_with_summary_and_duplicate_changes_nothing(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            raw = matchlog_html()
            attachment = SimpleNamespace(
                id=20, filename="match.html", content_type="text/html",
                size=len(raw), read=AsyncMock(return_value=raw),
            )
            author = SimpleNamespace(
                id=30, bot=False, display_name="Alpha",
                global_name=None, name="alpha", mention="<@30>",
                send=AsyncMock(),
            )
            message = SimpleNamespace(
                id=10, attachments=[attachment], author=author,
                channel=SimpleNamespace(send=AsyncMock()),
                reply=AsyncMock(side_effect=AssertionError("reply must not be used")),
                guild=SimpleNamespace(members=[author]),
                delete=AsyncMock(),
            )
            rankings = {
                "atp": {"alpha": "Alpha", "beta": "Beta"},
                "wta": {},
            }
            official = parse_official_results(OFFICIAL_HTML)
            bind_player_identity(path, 30, "Alpha", "admin receipt")
            original_to_thread = asyncio.to_thread
            with patch.object(main, "MATCH_STATS_WORKBOOK", path), \
                 patch.object(
                     main.asyncio, "to_thread", wraps=original_to_thread
                 ) as offload, \
                 patch.object(
                     main, "_archive_matchlog_attachment", new=AsyncMock()
                 ) as archive, \
                 patch.object(
                     main, "_send_matchlog_owner_csv", new=AsyncMock()
                 ) as owner_csv, \
                 patch.object(
                     main, "_get_stats_rankings",
                     new=AsyncMock(return_value=rankings),
                 ), \
                 patch.object(
                     main, "_get_matchlog_official_results",
                     new=AsyncMock(return_value=official),
                 ):
                self.assertEqual(
                    await main._process_matchlog_submission(message), 1
                )
                self.assertEqual(author.send.await_count, 3)
                message.channel.send.assert_not_awaited()
                message.reply.assert_not_awaited()
                self.assertIn(
                    "Processing", author.send.await_args_list[0].args[0]
                )
                progress_updates = [
                    call.kwargs["content"]
                    for call in author.send.return_value.edit.await_args_list
                ]
                self.assertTrue(any(
                    "checking file 1 of 1" in update
                    for update in progress_updates
                ))
                self.assertTrue(any(
                    "checked 1 of 1" in update
                    for update in progress_updates
                ))
                self.assertTrue(any(
                    "Stage 3/3" in update
                    for update in progress_updates
                ))
                first_reply = author.send.await_args_list[1].args[0]
                self.assertIn("Accepted", first_reply)
                self.assertIn("**1** accepted as official", first_reply)
                self.assertIn(
                    "Player dashboards show the number of official played "
                    "matches without verified MatchLog statistics",
                    first_reply,
                )
                self.assertIn("MatchLog receipt:", first_reply)
                self.assertIn(
                    "MatchLog stats — Alpha",
                    author.send.await_args_list[2].args[0],
                )
                archive.assert_awaited_once()
                owner_csv.assert_awaited_once()
                message.delete.assert_awaited_once()
                self.assertIn(
                    main.select_official_matches,
                    [call.args[0] for call in offload.await_args_list],
                )
                self.owner_submission_progress.assert_awaited_once_with(
                    message, 1
                )

                author.send.reset_mock()
                message.delete.reset_mock()
                archive.reset_mock()
                owner_csv.reset_mock()
                self.assertEqual(
                    await main._process_matchlog_submission(message), 0
                )
                self.assertIn(
                    "already recorded",
                    author.send.await_args_list[1].args[0],
                )
                self.assertEqual(author.send.await_count, 3)
                archive.assert_awaited_once()
                owner_csv.assert_awaited_once()
                message.delete.assert_awaited_once()

                author.send.reset_mock()
                author.send.side_effect = RuntimeError("DMs disabled")
                message.delete.reset_mock()
                archive.reset_mock()
                owner_csv.reset_mock()
                self.assertEqual(
                    await main._process_matchlog_submission(message), 0
                )
                self.assertEqual(author.send.await_count, 3)
                archive.assert_awaited_once()
                owner_csv.assert_awaited_once()
                message.delete.assert_awaited_once()
            workbook = load_workbook(path, read_only=True)
            self.assertEqual(workbook[RAW_SHEETS["atp"]].max_row, 3)
            workbook.close()

    async def test_duplicate_recovers_unlinked_verification_and_csv(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stats.xlsx"
            base_workbook(path)
            raw = matchlog_html()
            attachment = SimpleNamespace(
                id=20, filename="match.html", content_type="text/html",
                size=len(raw), read=AsyncMock(return_value=raw),
            )
            author = SimpleNamespace(
                id=30, bot=False, display_name="Alpha",
                global_name=None, name="alpha", mention="<@30>",
                send=AsyncMock(),
            )
            retained_message = SimpleNamespace(delete=AsyncMock())
            message = SimpleNamespace(
                id=10,
                attachments=[attachment],
                author=author,
                channel=SimpleNamespace(
                    send=AsyncMock(),
                    fetch_message=AsyncMock(return_value=retained_message),
                ),
                reply=AsyncMock(side_effect=AssertionError("reply must not be used")),
                delete=AsyncMock(),
            )
            rankings = {
                "atp": {"alpha": "Alpha", "beta": "Beta"},
                "wta": {},
            }
            official = parse_official_results(OFFICIAL_HTML)
            with patch.object(main, "MATCH_STATS_WORKBOOK", path), \
                 patch.object(
                     main, "append_matchlog_submission",
                     return_value={"added": 0, "duplicate": "file"},
                 ), \
                 patch.object(
                     main, "_archive_matchlog_attachment", new=AsyncMock()
                 ) as archive, \
                 patch.object(
                     main, "_notify_matchlog_owner_for_verification",
                     new=AsyncMock(),
                 ) as notify, \
                 patch.object(
                     main, "_send_matchlog_owner_csv", new=AsyncMock()
                 ) as owner_csv, \
                  patch.object(
                      main, "load_matchlog_source_message_ids",
                      return_value={5, 10},
                  ), \
                 patch.object(
                     main, "_get_stats_rankings",
                     new=AsyncMock(return_value=rankings),
                 ), \
                 patch.object(
                     main, "_get_matchlog_official_results",
                     new=AsyncMock(return_value=official),
                 ):
                self.assertEqual(
                    await main._process_matchlog_submission(message), 0
                )
            notify.assert_awaited_once()
            archive.assert_awaited_once()
            self.assertEqual(author.send.await_count, 3)
            message.channel.send.assert_not_awaited()
            self.assertIn(
                "already recorded",
                author.send.await_args_list[1].args[0],
            )
            self.assertIn(
                "pending admin verification",
                author.send.await_args_list[2].args[0],
            )
            self.assertNotIn("file", author.send.await_args_list[2].kwargs)
            owner_csv.assert_awaited_once()
            message.delete.assert_awaited_once()
            message.channel.fetch_message.assert_awaited_once_with(5)
            retained_message.delete.assert_awaited_once()


class OutreachRetryTests(unittest.IsolatedAsyncioTestCase):
    async def test_outreach_state_removes_retired_test_fixture(self):
        with tempfile.TemporaryDirectory() as directory:
            state = main.OutreachState(Path(directory) / "outreach.json")
            state.data = {
                "fixtures": {
                    main.FAKE_OUTREACH_KEY: {
                        "fixture": {"first_name": "Squeaky"},
                    },
                    "real": {"fixture": {"first_name": "Alpha"}},
                },
            }
            self.assertTrue(await state.remove(main.FAKE_OUTREACH_KEY))
            self.assertNotIn(main.FAKE_OUTREACH_KEY, state.data["fixtures"])
            self.assertIn("real", state.data["fixtures"])
            self.assertFalse(await state.remove(main.FAKE_OUTREACH_KEY))

    async def test_requested_fixture_failed_prompts_become_retryable(self):
        original = main._outreach_state.data
        main._outreach_state.data = {
            "fixtures": {
                "fixture-key": {
                    "fixture": {
                        "first_name": "Dani21",
                        "second_name": "Madferit",
                    },
                    "published": False,
                    "prompts": {
                        "side1": {
                            "attempts": 3,
                            "status": "failed",
                        },
                        "side2": {
                            "attempts": 3,
                            "status": "failed",
                        },
                    },
                },
            },
        }
        try:
            with patch.object(
                main._outreach_state,
                "update",
                new=AsyncMock(),
            ) as update:
                await main._reset_requested_outreach_retry()
            prompts = main._outreach_state.data["fixtures"]["fixture-key"]["prompts"]
            self.assertEqual(prompts["side1"]["attempts"], 0)
            self.assertEqual(prompts["side2"]["attempts"], 0)
            update.assert_awaited_once()
        finally:
            main._outreach_state.data = original


class CharacterDashboardTests(unittest.TestCase):
    def test_oversized_source_comparison_preserves_every_statistic(self):
        metrics = [
            (f"Comparison metric {index}", index / 100, 20)
            for index in range(80)
        ]
        screenshot = {
            "player": "Alpha",
            "tour": "atp",
            "source": "screenshots",
            "period": "career",
            "period_label": "Career",
            "ratings": [],
            "metrics": metrics,
        }
        matchlog = {
            **screenshot,
            "source": "matchlog",
            "metrics": [
                (label, value + 0.01, count)
                for label, value, count in metrics
            ],
        }
        embeds = main._build_mystats_source_comparison_embeds(
            screenshot,
            matchlog,
            {"official_results": []},
        )
        rendered = "\n".join(
            field.value
            for embed in embeds
            for field in embed.fields
        )
        for index in range(80):
            self.assertIn(f"Comparison metric {index}", rendered)
        for embed in embeds:
            self.assertLessEqual(
                len(embed),
                main.MYSTATS_EMBED_SAFE_CHARACTER_LIMIT,
            )
            self.assertLessEqual(
                len(embed.fields),
                main.MYSTATS_EMBED_FIELD_LIMIT,
            )

    def test_mystats_dashboard_never_exceeds_discord_embed_limit(self):
        metrics = [
            (f"Long metric label {index}", index / 10, 20)
            for index in range(35)
        ]
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "source": "matchlog",
            "matches": 20,
            "period": "career",
            "period_label": "Career",
            "ratings": [(f"Rating {index}", index) for index in range(20)],
            "metrics": metrics,
        }
        profile = {
            "category": "ATP Singles",
            "rank": 1,
            "wtsl_elo": 2000,
            "movement": 1,
            "official_results": [],
        }
        insights = {
            "strengths": ["Strong evidence " * 20] * 3,
            "weaknesses": ["Development evidence " * 20] * 3,
            "focus": "Training focus " * 80,
        }
        recommendations = [
            {
                "character": f"Character {index}",
                "strength_group": "serve",
                "development_group": "rally",
                "edge_attributes": ["Service Power", "Service Precision"],
                "tradeoff": "A detailed trade-off " * 20,
            }
            for index in range(3)
        ]
        embed = main._build_mystats_dashboard(
            summary,
            profile,
            insights,
            screenshot_summary={**summary, "source": "screenshots"},
            matchlog_summary=summary,
            character_recommendations=recommendations,
        )
        self.assertLessEqual(
            len(embed),
            main.MYSTATS_EMBED_SAFE_CHARACTER_LIMIT,
        )
        self.assertLessEqual(
            len(embed.fields),
            main.MYSTATS_EMBED_FIELD_LIMIT,
        )

    def test_character_recommendation_copy_is_direct_and_compact(self):
        lines = main._mystats_character_recommendation_lines([{
            "character": "Roger Federer",
            "strength_group": "serve",
            "development_group": "return",
            "edge_attributes": ["Service Precision"],
            "edge_details": [
                {"attribute": "Service Precision", "value": 92},
                {"attribute": "Service Consistency", "value": 89},
                {"attribute": "Service Power", "value": 88},
            ],
            "tradeoff": "A very long trade-off sentence. "
            "This extra explanation should not be shown.",
            "player_strength_metric": {
                "metric": "Aces",
                "percentile": 85,
            },
            "player_development_metric": {
                "metric": "Return Points Won %",
                "percentile": 35,
            },
            "mechanics_reason": (
                "Your Aces connects to this character's serve mode: "
                "open the court with the first ball."
            ),
            "development_route": (
                "For Return Points Won % the useful route is "
                "take returns early and reset the rally."
            ),
        }])
        self.assertEqual(len(lines), 1)
        self.assertLess(len(lines[0]), 700)
        self.assertIn("Amplifies your Serve strength", lines[0])
        self.assertIn("Your evidence:", lines[0])
        self.assertIn("Route: take returns early and reset the rally.", lines[0])
        self.assertIn("Trade-off: A very long trade-off sentence.", lines[0])
        self.assertNotIn("This extra explanation", lines[0])
        self.assertNotIn("Development route:", lines[0])

    def test_character_comparison_explains_pros_and_cons(self):
        profile = main.get_character_profile("Roger Federer", "atp")
        comparison = main.compare_character_profiles(
            "Roger Federer", "Rafael Nadal", "atp"
        )
        embed = main._build_character_profile_embed(profile, {}, comparison)
        rendered = "\n".join(
            [embed.description or ""]
            + [f"{field.name}\n{field.value}" for field in embed.fields]
        )
        self.assertIn("Technical Summary", rendered)
        self.assertIn("How to use him", rendered)
        self.assertIn("Why not select him", rendered)
        self.assertNotIn("Simulated impact", rendered)
        self.assertNotIn("Simulated forehand impact", rendered)
        self.assertNotIn("Simulated backhand impact", rendered)
        self.assertNotIn("Raw power, consistency, and precision remain visible", rendered)
        self.assertNotIn("second phase", rendered)
        self.assertNotIn("Documented game impact", rendered)
        self.assertNotIn("Source: ManaGames", rendered)
        self.assertNotIn("TE4 playstyle", rendered)
        self.assertNotIn(
            "columns AS onward excluded",
            embed.footer.text or "",
        )
        fields = {field.name: field.value for field in embed.fields}
        combined_text = fields["🎾 Combined skill ratings"]
        self.assertIn("Serve Rating", combined_text)
        self.assertIn("Power", combined_text)
        self.assertIn("Consistency", combined_text)
        self.assertIn("Precision", combined_text)
        self.assertNotIn("🧩 Technical skill interactions", fields)
        self.assertIn("🇨🇭", embed.description)
        comparison_text = fields["⚔️ Compared with Rafael Nadal"]
        self.assertLessEqual(len(comparison_text), 1024)
        self.assertIn("Pros of Roger Federer", comparison_text)
        self.assertIn("Cons of Roger Federer", comparison_text)
        self.assertIn("Choose Roger Federer if:", comparison_text)
        self.assertIn("Choose Rafael Nadal instead if:", comparison_text)

    def test_character_profile_groups_service_attributes_under_serve(self):
        profile = main.get_character_profile("Roger Federer", "atp")
        groups = main._character_stats_group_lines(profile["stats"])
        serve_text = "\n".join(groups["Serve"])
        movement_text = "\n".join(groups["Movement & Variety"])
        self.assertIn("Service Power", serve_text)
        self.assertIn("Service Consistency", serve_text)
        self.assertIn("Service Precision", serve_text)
        self.assertNotIn("Service Power", movement_text)

    def test_large_character_comparison_stays_within_discord_limit(self):
        profile = main.get_character_profile("Fernando Gonzalez", "atp")
        comparison = main.compare_character_profiles(
            "Fernando Gonzalez", "Roger Federer", "atp"
        )
        embed = main._build_character_profile_embed(
            profile,
            {
                "profile_url": "https://en.wikipedia.org/wiki/Fernando_Gonzalez",
                "avatar_url": "https://upload.wikimedia.org/example.jpg",
                "source": "Wikipedia",
            },
            comparison,
        )
        self.assertLessEqual(
            len(embed),
            main.MYSTATS_EMBED_SAFE_CHARACTER_LIMIT,
        )
        self.assertIn("[Player profile]", embed.description)
        self.assertNotIn("[Official ATP profile]", embed.description)

    def test_mystats_dashboard_shows_most_picked_characters(self):
        summary = {
            "player": "Alpha",
            "tour": "atp",
            "source": "screenshots",
            "matches": 3,
            "period_label": "Career",
            "favorite_character": {
                "character": "J. Sinner",
                "count": 2,
                "percentage": 2 / 3,
            },
            "ratings": [],
            "metrics": [],
        }
        profile = {
            "official_results": [
                {
                    "tour": "atp", "p1": "Alpha", "p2": "Beta",
                    "p1_character": "J. Sinner", "date": "01.09.2026",
                    "result": "6-4 6-4",
                },
                {
                    "tour": "atp", "p1": "Alpha", "p2": "Gamma",
                    "p1_character": "J. Sinner", "date": "02.09.2026",
                    "result": "6-3 6-3",
                },
                {
                    "tour": "atp", "p1": "Delta", "p2": "Alpha",
                    "p2_character": "D. Thiem", "date": "03.09.2026",
                    "result": "4-6 4-6",
                },
                {
                    "tour": "atp", "p1": "Alpha", "p2": "Walkover",
                    "p1_character": "Unused", "date": "04.09.2026",
                    "result": "Walkover",
                },
                {
                    "tour": "atp", "p1": "Toss", "p2": "Alpha",
                    "p2_character": "Unused", "date": "05.09.2026",
                    "result": "Coin toss",
                },
            ],
        }
        embed = main._build_mystats_dashboard(summary, profile, None)
        fields = {field.name: field.value for field in embed.fields}
        character_text = fields["🎮 Most Picked Characters"]
        self.assertIn(
            "**#1 J. Sinner** • 2 picks (66.7%)",
            character_text,
        )
        self.assertIn(
            "**#2 D. Thiem** • 1 pick (33.3%)",
            character_text,
        )
        self.assertIn(
            "Character recorded in **3 of 3** official matches",
            character_text,
        )

    def test_mystats_compares_every_available_stat_across_sources(self):
        screenshot = {
            "ratings": [
                ("Serve Rating", 180),
                ("Return Rating", 150),
                ("Under Pressure", 90),
            ],
            "metrics": [
                ("1st Serve %", 0.70, 10),
                ("Aces", 5.0, 10),
            ],
        }
        matchlog = {
            "ratings": [
                ("Serve Rating", 175),
                ("Return Rating", 240),
                ("Under Pressure", 280),
            ],
            "metrics": [
                ("1st Serve %", 0.68, 12),
                ("Double Faults", 2.0, 12),
            ],
        }
        lines = main._mystats_source_comparison_lines(screenshot, matchlog)
        rendered = "\n".join(lines)
        self.assertIn("Screenshots | MatchLog | Difference", rendered)
        self.assertIn("**Serve Rating:** 180 | 175 | Δ 5", rendered)
        self.assertIn("**1st Serve %:** 70.0% | 68.0% | Δ 2.0% pts", rendered)
        self.assertIn("**Aces:** 5 | N/A | Δ N/A", rendered)
        self.assertIn("**Double Faults:** N/A | 2 | Δ N/A", rendered)
        self.assertIn("**Under Pressure:**", rendered)
        self.assertNotIn("Source formulas differ", rendered)

    def test_mystats_dashboard_leaves_source_comparison_to_separate_page(self):
        screenshot = {
            "player": "Squeaky", "tour": "atp", "period": "career",
            "metrics": [("Deciding Sets Won %", 1.0, 20)],
            "ratings": [],
        }
        matchlog = {
            "player": "Squeaky", "tour": "atp", "period": "career",
            "metrics": [("Deciding Sets Won %", 0.353, 17)],
            "ratings": [],
        }
        profile = {
            "player_name": "Squeaky",
            "official_results": [
                {
                    "tour": "atp", "p1": "Squeaky", "p2": "Alpha",
                    "result": "6-4 3-6 6-2",
                },
                {
                    "tour": "atp", "p1": "Beta", "p2": "Squeaky",
                    "result": "4-6 6-3 6-4",
                },
            ],
        }
        embed = main._build_mystats_dashboard(
            screenshot,
            profile,
            None,
            screenshot_summary=screenshot,
            matchlog_summary=matchlog,
        )
        self.assertNotIn(
            "Screenshots vs MatchLog",
            "\n".join(
                [field.name for field in embed.fields]
                + [field.value for field in embed.fields]
            ),
        )


class MystatsSourceLoadingTests(unittest.IsolatedAsyncioTestCase):
    async def test_matchlog_request_skips_screenshot_reconciliation(self):
        matchlog_summary = {"source": "matchlog", "player": "Alpha"}
        with patch.object(
            main,
            "get_matchlog_player_summary",
            return_value=matchlog_summary,
        ) as get_matchlog, patch.object(
            main,
            "_get_screenshot_statistics_exclusions",
            new=AsyncMock(
                side_effect=AssertionError(
                    "screenshot reconciliation must not run"
                )
            ),
        ):
            screenshot, matchlog = await main._get_mystats_summaries(
                1,
                "Alpha",
                "atp",
                "career",
                datetime.now().date(),
                "matchlog",
            )
        self.assertIsNone(screenshot)
        self.assertEqual(matchlog, matchlog_summary)
        get_matchlog.assert_called_once()

    async def test_screenshot_request_skips_matchlog_summary(self):
        screenshot_summary = {"source": "screenshots", "player": "Alpha"}
        with patch.object(
            main,
            "_get_screenshot_statistics_exclusions",
            new=AsyncMock(return_value={"atp": {}}),
        ), patch.object(
            main,
            "get_screenshot_player_summary",
            return_value=screenshot_summary,
        ) as get_screenshot, patch.object(
            main,
            "get_matchlog_player_summary",
            side_effect=AssertionError("MatchLog summary must not run"),
        ):
            screenshot, matchlog = await main._get_mystats_summaries(
                1,
                "Alpha",
                "atp",
                "career",
                datetime.now().date(),
                "screenshots",
            )
        self.assertEqual(screenshot, screenshot_summary)
        self.assertIsNone(matchlog)
        get_screenshot.assert_called_once()

    async def test_cancelled_summaries_do_not_exceed_real_worker_limit(self):
        release = threading.Event()
        started_lock = threading.Lock()
        started = 0

        def blocking_summary(*args, **kwargs):
            nonlocal started
            with started_lock:
                started += 1
            release.wait(timeout=2)
            return {"source": "matchlog", "player": "Alpha"}

        executor = main.ThreadPoolExecutor(max_workers=2)
        with patch.object(
            main, "_mystats_summary_executor", executor
        ), patch.object(
            main, "get_matchlog_player_summary", side_effect=blocking_summary
        ):
            first_two = [
                asyncio.create_task(main._get_mystats_summaries(
                    user_id,
                    "Alpha",
                    "atp",
                    "career",
                    datetime.now().date(),
                    "matchlog",
                ))
                for user_id in (1, 2)
            ]
            for _ in range(100):
                with started_lock:
                    if started == 2:
                        break
                await asyncio.sleep(0.01)
            self.assertEqual(started, 2)
            for task in first_two:
                task.cancel()
            await asyncio.gather(*first_two, return_exceptions=True)

            third = asyncio.create_task(main._get_mystats_summaries(
                3,
                "Alpha",
                "atp",
                "career",
                datetime.now().date(),
                "matchlog",
            ))
            await asyncio.sleep(0.05)
            with started_lock:
                self.assertEqual(started, 2)
            release.set()
            screenshot, matchlog = await asyncio.wait_for(third, timeout=1)
            self.assertIsNone(screenshot)
            self.assertEqual(matchlog["player"], "Alpha")
            with started_lock:
                self.assertEqual(started, 3)
        executor.shutdown(wait=True)


if __name__ == "__main__":
    unittest.main()
