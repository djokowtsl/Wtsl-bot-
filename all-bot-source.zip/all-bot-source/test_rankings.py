import unittest

import main


class RankingsMoverTests(unittest.TestCase):
    def test_published_table_parser_normalizes_player_names(self):
        content = """**[WTSL TE4 (ATP) Rankings — Top 20](https://example.test)**
```text
#    Player                    Pts    Race    ELO
────────────────────────────────────────────────
1    gifu                     1000     800   2100
2    Dani21                    900     700   2050
```"""

        self.assertEqual(
            main._parse_published_rankings_message(content),
            {"gifu": 1, "dani21": 2},
        )

    def test_same_rank_is_not_reported_as_a_mover(self):
        rows = [
            (1, "gifu", 1000, 800, 2100, 1900),
            (2, "Dani21", 900, 700, 2050, 1850),
            (3, "Arv", 800, 600, 2000, 1800),
        ]

        embed = main.build_movers_embed(
            rows,
            {"gifu": 1, "dani21": 3, "arv": 2},
            "TE4 (ATP)",
            "https://example.test",
        )

        self.assertIsNotNone(embed)
        self.assertNotIn("gifu", embed.description)
        self.assertIn("Dani21", embed.description)
        self.assertIn("#3 → #2", embed.description)


if __name__ == "__main__":
    unittest.main()