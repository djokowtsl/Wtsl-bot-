import unittest

from predictions_leaderboard import (
    aggregate_prediction_rows,
    parse_prediction_module,
    prediction_module_url,
)


PREDICTIONS_HTML = """
<table class="table table-predictions">
  <tbody>
    <tr>
      <td>
        <span data-user-id="5601328">
          <span class="prediction-link">
            <a href="https://example.test/tournaments/1/predictions/1545020">Bel3eve</a>
          </span>
        </span>
        <em><a href="https://challonge.com/users/dani21xkt">Dani21XKT</a></em>
      </td>
      <td class="text-center">1</td>
      <td class="text-center"><strong>12</strong></td>
      <td class="text-center">94</td>
      <td class="text-center">8</td>
      <td class="text-center">2</td>
      <td class="text-center">1</td>
      <td class="text-center">0</td>
      <td class="text-center">0</td>
      <td class="text-center">1</td>
      <td class="text-center"><strong>4&nbsp;/&nbsp;55</strong></td>
      <td class="text-center">55</td>
    </tr>
  </tbody>
</table>
"""

SIX_ROUND_PREDICTIONS_HTML = """
<table class="table-predictions">
  <thead><tr>
    <th></th><th>Rank</th><th>Score</th>
    <th colspan="6">Points per Round</th><th>Picks</th><th>Admin</th>
  </tr></thead>
  <tbody><tr>
    <td><span data-user-id="4738786"><span class="prediction-link">
      <a href="/tournaments/1/predictions/1437024">CRIKEYY</a>
    </span></span><a href="https://challonge.com/users/squeaky94">Squeaky94</a></td>
    <td>1</td><td><strong>158</strong></td>
    <td>22</td><td>28</td><td>28</td><td>16</td><td>32</td><td>32</td>
    <td><strong>48 / 57</strong></td><td>delete</td>
  </tr></tbody>
</table>
"""


class PredictionLeaderboardTests(unittest.TestCase):
    def test_prediction_module_url_preserves_exact_tournament_id(self):
        self.assertEqual(
            prediction_module_url("Hangzhou_2026_TE4"),
            "https://91d510368cb4170cd5ac3776.challonge.com/"
            "Hangzhou_2026_TE4/predictions/module",
        )

    def test_parser_extracts_user_and_prediction_stats(self):
        rows = parse_prediction_module(
            PREDICTIONS_HTML,
            "US_Open_2026_TE4_F",
            "US Open",
            "TE4_(F)",
        )
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["challonge_user_id"], "5601328")
        self.assertEqual(rows[0]["challonge_username"], "Dani21XKT")
        self.assertEqual(rows[0]["prediction_name"], "Bel3eve")
        self.assertEqual(rows[0]["score"], 12)
        self.assertEqual(rows[0]["score_potential"], 94)
        self.assertEqual(rows[0]["round_points"], [8, 2, 1, 0, 0])
        self.assertEqual(rows[0]["picks"], 4)
        self.assertEqual(rows[0]["picks_potential"], 55)

    def test_parser_accepts_six_round_table_without_score_potential(self):
        rows = parse_prediction_module(
            SIX_ROUND_PREDICTIONS_HTML,
            "Australian_Open_2026_TE4",
            "Australian Open",
            "TE4",
        )
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["challonge_username"], "Squeaky94")
        self.assertEqual(rows[0]["score"], 158)
        self.assertEqual(rows[0]["score_potential"], 0)
        self.assertEqual(rows[0]["round_points"], [22, 28, 28, 16, 32, 32])
        self.assertEqual(rows[0]["picks"], 48)
        self.assertEqual(rows[0]["picks_potential"], 57)

    def test_aggregation_keeps_one_latest_snapshot_per_user_tournament(self):
        base = {
            "challonge_user_id": "1",
            "challonge_username": "Dani21XKT",
            "prediction_name": "Bel3eve",
            "score_potential": 90,
            "picks": 2,
            "picks_potential": 20,
            "losers_bracket_points": 0,
            "round_points": [1, 0, 0, 0, 0],
        }
        rows = aggregate_prediction_rows(
            [
                {
                    **base,
                    "tournament_id": "A",
                    "score": 3,
                },
                {
                    **base,
                    "tournament_id": "A",
                    "score": 7,
                },
                {
                    **base,
                    "tournament_id": "B",
                    "score": 4,
                },
            ],
            identity_links={"1": 123},
        )
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["discord_user_id"], 123)
        self.assertEqual(rows[0]["tournaments"], 2)
        self.assertEqual(rows[0]["tournaments_won"], 2)
        self.assertEqual(rows[0]["total_score"], 11)
        self.assertEqual(rows[0]["average_score"], 5.5)
        self.assertEqual(rows[0]["total_picks"], 4)
        self.assertEqual(rows[0]["total_picks_potential"], 40)


if __name__ == "__main__":
    unittest.main()