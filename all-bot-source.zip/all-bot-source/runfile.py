# Runfile
#!/usr/bin/env bash

# Build the Nix environment
nix-shell --run "python3 main.py"