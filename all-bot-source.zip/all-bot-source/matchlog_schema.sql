CREATE TABLE IF NOT EXISTS matchlog_sources (
    source_hash text PRIMARY KEY,
    submitter_id bigint NOT NULL,
    source_message_id bigint NOT NULL,
    attachment_id bigint NOT NULL,
    filename text NOT NULL,
    raw_html bytea NOT NULL,
    verified_matches jsonb NOT NULL,
    accepted_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS matchlog_identities (
    discord_user_id bigint PRIMARY KEY,
    player text NOT NULL,
    receipt text NOT NULL,
    approved_at timestamptz NOT NULL DEFAULT now()
);

-- Canonical multi-tour identity store.  The legacy table above is retained so
-- existing deployments can be upgraded without losing their historical link.
CREATE TABLE IF NOT EXISTS matchlog_player_identities (
    discord_user_id bigint NOT NULL,
    tour text NOT NULL CHECK (tour IN ('atp', 'wta')),
    player text NOT NULL,
    receipt text NOT NULL,
    approved_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (discord_user_id, tour)
);

CREATE INDEX IF NOT EXISTS matchlog_sources_submitter_idx
    ON matchlog_sources (submitter_id);

CREATE TABLE IF NOT EXISTS matchlog_verification_requests (
    discord_user_id BIGINT PRIMARY KEY,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS matchlog_bot_messages (
    message_key TEXT PRIMARY KEY,
    channel_id BIGINT NOT NULL,
    message_id BIGINT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS match_preview_outreach_state (
    state_key TEXT PRIMARY KEY,
    state JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS wtsl_match_schedules (
    schedule_id TEXT PRIMARY KEY,
    guild_id BIGINT NOT NULL,
    tournament_id TEXT NOT NULL,
    tournament_name TEXT NOT NULL,
    round_name TEXT NOT NULL,
    source_match_id TEXT NOT NULL,
    player_one TEXT NOT NULL,
    player_two TEXT NOT NULL,
    player_one_user_id BIGINT,
    player_two_user_id BIGINT,
    thread_id BIGINT UNIQUE,
    log_message_id BIGINT,
    status TEXT NOT NULL DEFAULT 'active',
    is_test BOOLEAN NOT NULL DEFAULT FALSE,
    created_by BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_by BIGINT,
    completed_at TIMESTAMPTZ,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS wtsl_match_scheduler_notices (
    notice_key TEXT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    status TEXT NOT NULL DEFAULT 'sending',
    claimed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    sent_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS screenshot_stats_snapshot_store (
    store_key TEXT PRIMARY KEY,
    workbook BYTEA NOT NULL,
    processed_messages JSONB NOT NULL DEFAULT '[]'::jsonb,
    workbook_sha256 TEXT NOT NULL,
    atp_rows INTEGER NOT NULL,
    wta_rows INTEGER NOT NULL,
    doubles_rows INTEGER NOT NULL,
    revision BIGINT NOT NULL DEFAULT 1,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS screenshot_stats_snapshot_backup (
    store_key TEXT PRIMARY KEY,
    workbook BYTEA NOT NULL,
    processed_messages JSONB NOT NULL DEFAULT '[]'::jsonb,
    workbook_sha256 TEXT NOT NULL,
    atp_rows INTEGER NOT NULL,
    wta_rows INTEGER NOT NULL,
    doubles_rows INTEGER NOT NULL,
    source_revision BIGINT NOT NULL,
    backup_reason TEXT NOT NULL,
    backed_up_at TIMESTAMPTZ NOT NULL DEFAULT now()
);